using GorillaLocomotion;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using easyInputs;

namespace CycyWristMenuTemplate.mods;

internal class CHANGE_NAME_GUN
{
	public static void mBBDVIExRBrUhrFRkUxdlbFBfIoqirnNqcMCPZDZbpICyuzWrCYtBRbkWaxmunpAoEEeFcckrycWtccLisZGtUlybCGOCqENZhoUQurozNbcPeQTXLdcoJhtsfdcvnIbToXlOhVNbKgFTiJXLNRQmCzpaUCKroSlfajAhEfPQpaDCBAjvgqIwROrPHlTFkwMRVASZjPgHbaXBVMytspkXjPnlRKztljFToLHbHjmqkbuRRPTUMzmVmPHfmHhyqNvSudnk()
	{
		//IL_07cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_0545: Unknown result type (might be due to invalid IL or missing references)
		//IL_0559: Unknown result type (might be due to invalid IL or missing references)
		//IL_0511: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fa: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = default(GameObject);
		RaycastHit val3 = default(RaycastHit);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		GameObject val2 = default(GameObject);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0 >> (0 >> 1) << 0) - 0 + 0) ^ -0) << 0) + 0)) % 33)
				{
				case 27u:
					break;
				default:
					return;
				case 29u:
					num = (((int)num2 + -1100503962) ^ 0x77824F1) + 0 >> 0 >> 0 << 0;
					continue;
				case 15u:
					num = ((((int)num2 + -1563535789) ^ -213314432) - 0 << 0 >> 0) ^ 0;
					continue;
				case 5u:
					num = ((((int)num2 + -1439813256) ^ -1407777097) >> 0) + 0 + 0 + 0;
					continue;
				case 6u:
					val.transform.position = ((RaycastHit)(ref val3)).point;
					num = ((((((int)num2 + -2033110311) ^ -2047576795) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 7u:
					num = ((((int)num2 + -1827602905) ^ -15828651) - 0 + 0 >> 0) ^ 0;
					continue;
				case 8u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = ((((int)num2 + -509051253) ^ 0x7F92DF6B) - 0 - 0 << 0) ^ 0;
					continue;
				case 9u:
					num = (((int)num2 + -1891630081) ^ -1613187783 ^ 0) + 0 - 0 << 0;
					continue;
				case 10u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = ((((((int)num2 + -903840450) ^ 0x6033A856) - 0) ^ 0) >> 0) ^ 0;
					continue;
				case 11u:
					num = (int)(((num2 + 1455221297) ^ 0x97C855BFu) - 0 - 0 + 0 - 0);
					continue;
				case 12u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (int)((((((num2 + 1473386669) ^ 0xC37227E8u) << 0) ^ 0) << 0) - 0);
					continue;
				case 0u:
					num = (int)(((((num2 + 1376848916) ^ 0x9E487B8Au) << 0) ^ 0) + 0) >> 0;
					continue;
				case 14u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.red);
					num = (((int)num2 + -182552646) ^ 0x19EDB7F6) + 0 << 0 >> 0 >> 0;
					continue;
				case 13u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val3);
					num = (((int)(((num2 + 1709781230) ^ 0xFB71B067u) - 0) >> 0) ^ 0) - 0;
					continue;
				case 16u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (((int)num2 + -1829903696) ^ -152655019 ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 17u:
					num = (((((int)num2 + -229453252) ^ 0x4CD71341) + 0 << 0) ^ 0) - 0;
					continue;
				case 18u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (((int)num2 + -1761200462) ^ -2102326305) + 0 - 0 + 0 >> 0;
					continue;
				case 19u:
				{
					int num5;
					int num6;
					if (!triggerButtonDown)
					{
						num5 = -1336317899;
						num6 = num5;
					}
					else
					{
						num5 = -1257609481;
						num6 = num5;
					}
					num = ((int)((uint)((num5 << 0) + 0) ^ (num2 + 1919092371)) >> 0 >> 0) + 0 >> 0;
					continue;
				}
				case 20u:
					num = (int)(((num2 + 1363915621) ^ 0x91F47262u ^ 0) + 0 + 0 - 0);
					continue;
				case 21u:
					flag = Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>());
					num = (((int)((num2 + 823506666) ^ 0x3ED4DE3) >> 0) - 0 - 0) ^ 0;
					continue;
				case 22u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -2139250564;
						num4 = num3;
					}
					else
					{
						num3 = -1363601648;
						num4 = num3;
					}
					num = (((int)((uint)(num3 + 0 + 0) ^ (num2 + 1168528836)) >> 0) + 0 - 0) ^ 0;
					continue;
				}
				case 23u:
					num = (((((int)num2 + -340251349) ^ 0x52CD045F) - 0 + 0) ^ 0) >> 0;
					continue;
				case 24u:
					val2 = val;
					num = (int)((((num2 + 733616138) ^ 0xFED1751Fu) << 0 << 0) - 0 - 0);
					continue;
				case 25u:
				{
					Player owner = ((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (int)(((num2 + 360573015) ^ 0xAA5B4E67u ^ 0) - 0 - 0 - 0);
					continue;
				}
				case 26u:
					val2.GetComponent<Renderer>().material.color = Color.green;
					num = (((((int)num2 + -342996398) ^ 0x18344260) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 1u:
					num = (int)((((num2 + 121371131) ^ 0x5EBADE74) + 0 + 0 + 0) ^ 0);
					continue;
				case 28u:
					num = (int)(((((num2 + 440672968) ^ 0x40B6AA77) + 0 << 0) ^ 0) + 0);
					continue;
				case 3u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((((int)num2 + -1650322207) ^ -924137898) << 0) + 0) ^ 0 ^ 0;
					continue;
				case 30u:
					num = 1332531748 - 0 + 0 - 0 << 0;
					continue;
				case 31u:
					num = ((int)((num2 + 435749897) ^ 0xA2C9E32) >> 0) - 0 + 0 >> 0;
					continue;
				case 32u:
					num = (0x6349481F ^ 0) >> 0;
					continue;
				case 4u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (((int)num2 + -871797673) ^ -139212691 ^ 0) + 0 - 0 - 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public CHANGE_NAME_GUN()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num >> 0) - (0 + 0) << 0 << 0 >> 0 >> (0 ^ 0) >> 0) ^ 0u) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0) - 0 >> 0) + 0;
			}
		}
	}
}
