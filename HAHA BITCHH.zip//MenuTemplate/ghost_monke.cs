using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class ghost_monke
{
	public static void UlvbdMUDurDOkybMNXsGEsGwYgURDqCjOhihNtfbZzgkrvqiLkSTMwFBFZcWSca()
	{
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301850;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) >> -0) ^ 0) + 0 - 0) ^ 0) >> 0) ^ 0u) % 13)
				{
				case 12u:
					break;
				default:
					return;
				case 4u:
					num = ((((int)num2 + -1807018533) ^ -1074757917) << 0) - 0 + 0 << 0;
					continue;
				case 8u:
					num = ((((int)num2 + -1397142901) ^ 0x6AF306E8) << 0) - 0 << 0 >> 0;
					continue;
				case 5u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = (int)((((num2 + 266738246) ^ 0x365F1E4D) << 0) + 0 + 0 + 0);
					continue;
				case 0u:
					num = (((((int)num2 + -640398734) ^ -387412666) + 0 >> 0) ^ 0) - 0;
					continue;
				case 7u:
					num = ((((int)num2 + -1579710319) ^ -296225004) - 0 << 0) + 0 >> 0;
					continue;
				case 6u:
					flag = !EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (int)(((num2 + 600520462) ^ 0xB95FCA40u ^ 0) + 0 - 0 - 0);
					continue;
				case 9u:
					num = (1190796318 << 0) - 0 - 0 + 0;
					continue;
				case 10u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = (((int)num2 + -692261737) ^ 0x6C9E3991 ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 11u:
					num = ((((int)num2 + -1284218664) ^ 0x74B3DF12 ^ 0) << 0) - 0 << 0;
					continue;
				case 1u:
					num = ((((int)num2 + -1127256878) ^ 0x678FFB46) >> 0) - 0 - 0 + 0;
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -954971712;
						num4 = num3;
					}
					else
					{
						num3 = -1787490733;
						num4 = num3;
					}
					num = (((num3 - 0 << 0) ^ ((int)num2 + -1496278149)) - 0 + 0 << 0) - 0;
					continue;
				}
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public ghost_monke()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0) ^ 0) - 0) ^ 0) - 0 >> 0 + 0 >> 0 << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0 >> 0) - 0 << 0;
			}
		}
	}
}
