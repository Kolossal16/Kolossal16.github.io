using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class CUM
{
	public static void mjWWZidEXKDmFNRIOUFKQrWXgmIyhwOHPXqzxvDkXeZlaesrRicyrDaVnYPNAFwBWWwHwsl()
	{
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0562: Unknown result type (might be due to invalid IL or missing references)
		//IL_0567: Unknown result type (might be due to invalid IL or missing references)
		//IL_057b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_0584: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0593: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_062e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_065b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0660: Unknown result type (might be due to invalid IL or missing references)
		//IL_0664: Unknown result type (might be due to invalid IL or missing references)
		//IL_066e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0673: Unknown result type (might be due to invalid IL or missing references)
		//IL_0678: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_0417: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_042f: Unknown result type (might be due to invalid IL or missing references)
		//IL_048f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0505: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c6: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val3 = default(Vector3);
		Quaternion val4 = default(Quaternion);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				Vector3 forward;
				switch ((num2 = (uint)((((num << 0 >> (0 ^ 0)) ^ 0) - 0 >> 0) - (0 >> 1) >> 0 << 0)) % 18)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u0a51\u0a46\u0a5f\u0a5f\u0a56\u0a47\u0a63\u0a41\u0a56\u0a55\u0a52\u0a51", 1678248499, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -814951907) ^ 0x6DD668D3) >> 0) + 0 << 0) + 0;
					continue;
				case 11u:
				{
					Vector3 val12 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					Vector3 val13 = val12 + ((Vector3)(ref forward)).normalized * 2f;
					num = (int)((((num2 + 1333463150) ^ 0x908A7768u) + 0 << 0) - 0) >> 0;
					continue;
				}
				case 9u:
					EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((int)(((num2 + 1621957012) ^ 0xFCBDA7C5u) - 0) >> 0 << 0) - 0;
					continue;
				case 14u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("촃촔촍촍촄촕촱촓촄촇촀촃", 54709601, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 1548432940) ^ 0x81127478u) >> 0 << 0) + 0 >> 0;
					continue;
				case 17u:
					num = (((int)((num2 + 1956669763) ^ 0xC1058463u) >> 0) ^ 0 ^ 0) >> 0;
					continue;
				case 0u:
					num = (int)(((((num2 + 647071759) ^ 0x47DB755D) - 0) ^ 0) - 0 - 0);
					continue;
				case 2u:
				{
					Vector3 val10 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					Vector3 val11 = val10 + ((Vector3)(ref forward)).normalized * 1.5f;
					num = (int)((((num2 + 1665746989) ^ 0xEBD1F179u) + 0 + 0) ^ 0) >> 0;
					continue;
				}
				case 10u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("핣해항항핤핵핑핳핤핧할핣", 1007342849, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 770395556) ^ 0x5CC58E1) << 0) ^ 0 ^ 0) - 0);
					continue;
				case 12u:
				{
					Vector3 val9 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					val3 = val9 + ((Vector3)(ref forward)).normalized * 0.5f;
					num = ((int)((num2 + 428697817) ^ 0x252FCDD8) >> 0 << 0 << 0) + 0;
					continue;
				}
				case 3u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쳳쳤쳽쳽쳴쳥쳁쳣쳴쳷쳰쳳", 1066847377, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -227232852) ^ 0x29D14214 ^ 0) << 0) + 0) ^ 0;
					continue;
				case 13u:
				{
					Vector3 val7 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					Vector3 val8 = val7 + ((Vector3)(ref forward)).normalized * 2.5f;
					num = (int)((((num2 + 1107201870) ^ 0x8EBBF8D5u) + 0 << 0) - 0 << 0);
					continue;
				}
				case 15u:
					val4 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = (((int)((num2 + 2106842273) ^ 0x9BA9DDFDu) >> 0) + 0 - 0) ^ 0;
					continue;
				case 4u:
				{
					Vector3 val5 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					Vector3 val6 = val5 + ((Vector3)(ref forward)).normalized * 3f;
					num = ((((int)num2 + -1008375456) ^ -1804404296 ^ 0 ^ 0) >> 0) + 0;
					continue;
				}
				case 16u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("禷禠禹禹禰禡禅禧禰禳禴禷", 476019157, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 1457370637) ^ 0xB216C796u ^ 0) - 0) ^ 0) << 0);
					continue;
				case 1u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⍝⍊⍓⍓⍚⍋⍯⍍⍚⍙⍞⍝", 1458643775, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1125345364) ^ -875507144) + 0) ^ 0) + 0 << 0;
					continue;
				case 7u:
				{
					Vector3 val = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(0f, 1.1f, 0f);
					forward = ((Component)GorillaTagger.Instance.myVRRig).transform.forward;
					Vector3 val2 = val + ((Vector3)(ref forward)).normalized * 1f;
					num = ((int)(((num2 + 1952503976) ^ 0xD9DEA6DFu) + 0) >> 0 >> 0) - 0;
					continue;
				}
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public CUM()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num ^ 0) + (0 >> 1) - 0 + 0 + 0 + (0 << 1) + 0 - 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) + 0 + 0 << 0) - 0;
			}
		}
	}
}
