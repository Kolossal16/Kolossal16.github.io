using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class rigdupe
{
	public static void KKphcfbWTVaFTJDOaYFvoEFMHUzwPzIhrLRxiwSlJbyUiyZOhOnHaNcgeCAiGEhtmToiSgGDfuLnfLDiVKpalbhDIKsFWJFfUeHpkQWahKBGbPbtYrnVpgilLKzhOaHvPGtaeoYeNpSBzABTJZHEwJPNWvEzrOmgdfQvvaoKsiiaoGMkjFyOtcZfQGeJKzMYcLyuKfxIKXlnAPzpJtqLqxNagKFPVFaTwkXCirAdhPevQLFagOZqjbIFXynZAIMfXsRqSWgrSnDAtrjvfEIhFJKuBsEKeBCzcZyyToikHIyVxhmFoSTWZFznIwOzrwnqKextTLBQwyzWkOXtgYvlIGzxzkPwAISlviksKSMDqczBg()
	{
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c3: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		GorillaGameManager instance = default(GorillaGameManager);
		int count = default(int);
		int num3 = default(int);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301865;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 + -0 << 0) ^ 0) + 0 << (0 << 1)) ^ 0) - 0)) % 16)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((int)(((num2 + 359659174) ^ 0x4BFA8ABE) - 0 << 0) >> 0) ^ 0;
					continue;
				case 5u:
					instance.NewVRRig(PhotonNetwork.LocalPlayer, count, num3 != 0);
					num = ((((int)num2 + -517084339) ^ 0x279528E) >> 0) + 0 >> 0 >> 0;
					continue;
				case 1u:
					flag = triggerButtonDown;
					num = (int)(((((num2 + 1621957012) ^ 0x8DF7CB28u) << 0) + 0 << 0) ^ 0);
					continue;
				case 7u:
					num = ((int)(((num2 + 660359990) ^ 0x78FB1F65) + 0) >> 0 << 0) - 0;
					continue;
				case 13u:
				{
					int num4;
					int num5;
					if (flag)
					{
						num4 = -342560089;
						num5 = num4;
					}
					else
					{
						num4 = -1422848211;
						num5 = num4;
					}
					num = ((num4 + 0 - 0) ^ ((int)num2 + -534343288)) << 0 << 0 << 0 >> 0;
					continue;
				}
				case 6u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⽂⽺⽽⽦⽽⽼⽄⽀⼽⽂⽾⽳⽫⽷⽠", 1381707538, true), ((Component)Player.Instance).transform.position + new Vector3(0f, 0.4f, 0f), ((Component)Player.Instance).transform.rotation, (byte)90, (Il2CppReferenceArray<Object>)null);
					num = ((int)((((num2 + 2029155507) ^ 0xC7AF8237u) << 0) - 0) >> 0) - 0;
					continue;
				case 2u:
					num = ((((int)num2 + -1692824216) ^ -1121735359) - 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 10u:
					num3 = -4;
					num = (((int)num2 + -295483064) ^ 0x44745447) - 0 << 0 << 0 << 0;
					continue;
				case 11u:
					Object.Destroy((Object)(object)GorillaTagger.Instance.myVRRig);
					num = ((int)(((num2 + 1954386908) ^ 0x9241D6C4u) + 0) >> 0 << 0) ^ 0;
					continue;
				case 12u:
					num = (((int)((num2 + 1464826632) ^ 0xCC0F8A82u) >> 0 << 0) ^ 0) << 0;
					continue;
				case 3u:
					num = (((int)num2 + -692261737) ^ -1145926859) - 0 + 0 + 0 >> 0;
					continue;
				case 14u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蛄蛼蛻蛠蛻蛺蛂蛆蚻蛄蛸蛵蛭蛱蛦", 504071828, true), ((Component)Player.Instance).transform.position + new Vector3(0f, 0.4f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -649986417) ^ -66507558) << 0 >> 0) - 0) ^ 0;
					continue;
				case 15u:
					instance = GorillaGameManager.instance;
					num = ((((int)num2 + -1284218664) ^ 0x41DEF983) - 0 - 0 - 0) ^ 0;
					continue;
				case 4u:
					count = instance.playerVRRigDict.Count;
					num = (((((int)num2 + -1127256878) ^ 0x40480E1C) << 0) - 0 >> 0) + 0;
					continue;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	public rigdupe()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0) ^ 0 ^ 0) - 0 + 0) ^ 0) + 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) << 0) - 0 >> 0 << 0;
			}
		}
	}
}
