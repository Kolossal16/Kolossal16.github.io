using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class tag_spam
{
	public static void tGNwLEhxHERxkmTlvmwKTsfTaWVIRRRHqqzQfIncQTxZYiOpolrxGNZaBTwOJyFPMkhUMdfMYuTaVgVShGuGAtaDqzplmyssnImNbUCkfEylTZfuYEGceYosjDEnOUA()
	{
		GorillaTagManager current = default(GorillaTagManager);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0 ^ -0) + 0 << 0) ^ 0) << -0) - 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 1u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((((int)num2 + -1874950498) ^ -859104563) >> 0) - 0) ^ 0) + 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6 ^ 0 ^ 0) - 0) ^ 0);
					continue;
				default:
				{
					IEnumerator<GorillaTagManager> enumerator = Object.FindObjectsOfType<GorillaTagManager>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 1352366879;
								num4 = num3;
							}
							else
							{
								num3 = 1190796313;
								num4 = num3;
							}
							int num5 = ((num3 << 0) + 0 >> 0) + 0;
							while (true)
							{
								switch ((num2 = (uint)((num5 - 0 + (0 >> 1) << 0) - 0 + 0 + (0 >> 1) - 0 - 0)) % 8)
								{
								case 0u:
									num5 = 1190796313;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = ((0x71293122 ^ 0) << 0) + 0;
									continue;
								case 2u:
									num5 = (int)((((num2 + 359659174) ^ 0xD6B76933u) << 0 << 0) + 0 - 0);
									continue;
								case 3u:
									current.SetisCurrentlyTag(false);
									num5 = ((int)((num2 + 1621957012) ^ 0xDBA92803u) >> 0 << 0) - 0 >> 0;
									continue;
								case 4u:
									num5 = (int)(((num2 + 647071759) ^ 0xB1C8FF96u ^ 0) - 0 + 0) >> 0;
									continue;
								case 5u:
									num5 = (int)(((((num2 + 428697817) ^ 0x3C5C86A0) << 0) + 0 + 0) ^ 0);
									continue;
								case 6u:
									break;
								case 7u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_0246:
								int num6 = 750340745;
								while (true)
								{
									switch ((num2 = (uint)((((num6 << 0 << 0 + 0) ^ 0) - 0 << 0) - -0 + 0 - 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_024b;
									case 1u:
										enumerator.Dispose();
										num6 = ((((((int)num2 + -1284218664) ^ -1231992841) + 0) ^ 0) >> 0) ^ 0;
										continue;
									case 2u:
										num6 = ((((int)num2 + -1127256878) ^ 0x3B16CB27) - 0 >> 0) + 0 << 0;
										continue;
									case 3u:
										goto end_IL_024b;
									}
									goto IL_0246;
									continue;
									end_IL_024b:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public static void AbBMmTiQnejBWVPKrtUmISqoptUDxqowkeYkrnSBQNsYUxsxuTnTTHRHLnxTYEtXPMqRWFsdBswUzstRbxjEduDDmryeQZDmuvihhABPBjsBkWhtTFSBuOUujMFFgnnBPkAejlJAWudTcbspjflkhbRFANXuVVInVQLawdjHWrFaLas()
	{
		bool gripButtonDown = default(bool);
		bool flag = default(bool);
		GorillaTagManager current = default(GorillaTagManager);
		while (true)
		{
			int num = 1758301854;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 << 0 + 0) ^ 0) >> 0) + 0 << 0 + 0 << 0) - 0)) % 7)
				{
				case 0u:
					break;
				case 1u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = (((((int)num2 + -725091362) ^ 0x852858C) >> 0) ^ 0 ^ 0) >> 0;
					continue;
				case 2u:
					flag = gripButtonDown;
					num = (((int)num2 + -956687329) ^ -415052114 ^ 0) << 0 << 0 << 0;
					continue;
				case 3u:
					if (flag)
					{
						num = ((int)((num2 + 1345212153) ^ 0x7B8CB73B) >> 0 << 0 >> 0) ^ 0;
						continue;
					}
					return;
				case 4u:
					num = (int)((((num2 + 600520462) ^ 0x22720313 ^ 0) - 0 - 0) ^ 0);
					continue;
				case 5u:
					num = ((((int)num2 + -795116775) ^ -5259856) >> 0 << 0 << 0) - 0;
					continue;
				default:
				{
					IEnumerator<GorillaTagManager> enumerator = Object.FindObjectsOfType<GorillaTagManager>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (enumerator.MoveNext())
							{
								num3 = 1621957009;
								num4 = num3;
							}
							else
							{
								num3 = 2106842279;
								num4 = num3;
							}
							int num5 = num3 << 0 << 0 << 0 << 0;
							while (true)
							{
								switch ((num2 = (uint)((((((num5 ^ 0) >> (0 >> 1) << 0) ^ 0) << 0) + (0 >> 1) << 0) - 0)) % 8)
								{
								case 0u:
									num5 = 1621957009;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (0x661A46D2 ^ 0) >> 0 << 0;
									continue;
								case 2u:
									num5 = (((((int)num2 + -1186296972) ^ 0x39F55A4D) + 0) ^ 0) - 0 << 0;
									continue;
								case 3u:
									current.UpdateTagState();
									num5 = (((((int)num2 + -1701687338) ^ -1788238587) - 0) ^ 0) >> 0 >> 0;
									continue;
								case 4u:
									num5 = (((((int)num2 + -1219895373) ^ 0x12193A4A) << 0) - 0 << 0) - 0;
									continue;
								case 5u:
									num5 = (int)(((num2 + 900749756) ^ 0x18B55307) + 0 - 0 + 0 - 0);
									continue;
								case 6u:
									break;
								case 7u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_02fa:
								int num6 = 1630399309;
								while (true)
								{
									switch ((num2 = (uint)(((((num6 - 0 >> (0 ^ 0)) - 0 - 0) ^ 0) << -0) - 0 >> 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_02ff;
									case 1u:
										enumerator.Dispose();
										num6 = (((int)num2 + -1395914388) ^ 0x636456AF ^ 0) >> 0 >> 0 << 0;
										continue;
									case 2u:
										num6 = (int)((((num2 + 1319775793) ^ 0xEA08AB4Cu) - 0 - 0 << 0) ^ 0);
										continue;
									case 3u:
										goto end_IL_02ff;
									}
									goto IL_02fa;
									continue;
									end_IL_02ff:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public tag_spam()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) - (0 >> 1)) ^ 0) >> 0) - 0 >> (0 ^ 0)) - 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 >> 0) + 0 - 0;
			}
		}
	}
}
