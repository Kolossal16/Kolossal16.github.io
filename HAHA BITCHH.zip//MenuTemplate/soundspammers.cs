using System.Collections.Generic;
using GorillaLocomotion;
using Il2CppSystem.Collections.Generic;
using Photon.Pun;
using UnityEngine;

namespace MenuTemplate;

internal class soundspammers
{
	public static void FyEKpukotyPJDxxKJcioevouOMUEUoAmMEYmNQmzzQwQESPjCdJJdpyjkkVCAGtfYDXZylWTQJPnZxPVXLcREQiwfPbDUJZSxqSbVQLqhPTtAljNvZFPECAhuATJjsZhKWQIEOagZLJPXOWUFoiUekoUQKGuWcgOPMJDuAiGZyPSSKkGDYdVkedAIWSThFkWEUakftAegBVFuvbgAaQYYlEKJjUyIoytoSnXKZAkyZOJjxfnUMthPlY()
	{
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0) ^ 0 ^ 0) + 0 >> 0) - -0 + 0 - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(39, 0f, 0f, 999999f);
					num = ((((((int)num2 + -1874950498) ^ -859104592) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 1u:
					num = ((int)((num2 + 414745695) ^ 0x55FC76F6 ^ 0) >> 0) + 0 << 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public static void sqpBVybvRcCrBhdvAzGzZwVBldHDWVrDcUUHvyFLwDXGHgEfQqSI()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num - 0) ^ 0) << 0) ^ 0) << 0) - (0 ^ 0) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(29, 0f, 0f, 999999f);
					num = (((((int)num2 + -1874950498) ^ -859104563) + 0 << 0) + 0) ^ 0;
					continue;
				case 2u:
					num = ((((int)((num2 + 414745695) ^ 0x55FC76F6) >> 0) + 0) ^ 0) - 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void iMYVvOpRRxyWLYoGmwacTVcvzoTfzCNGcIvpWYlGiNUYebVJRXSupQ()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 - -0 >> 0 >> 0 >> 0) + (0 << 1) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(7, 0f, 0f, 999999f);
					num = (((((int)num2 + -1874950498) ^ -859104563) + 0 << 0) - 0) ^ 0;
					continue;
				case 2u:
					num = ((int)((((num2 + 414745695) ^ 0x55FC76F6) << 0) + 0) >> 0) - 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void OnJDwgUjrpKSUcCYKoktTgaeqytkoCJtqlUhGsCfMYwFomhSgSmEjWXImFmXNKVOFrCIivsrLfHUJvQerBdvqfjuolUbgEscdHZWKyJLAUSepcYROiGlGzyAiiuXArlhNFRcvTuTRsVvmfelmdmXYgvDizOCeMkiILrKlWvVONunEdnddjKxeoiGjoUWfSPeiMMANuaqHr()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num ^ 0 ^ 0 ^ 0 ^ 0) + 0 + (0 >> 1) << 0 << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(31, 0f, 0f, 999999f);
					num = ((((int)num2 + -1874950498) ^ -859104563) - 0 << 0 >> 0) ^ 0;
					continue;
				case 2u:
					num = ((int)((num2 + 414745695) ^ 0x55FC76F6) >> 0) + 0 - 0 << 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void jkLhYfmLyUcNeuCKAXbzPVYpfRqMpIitPNeYUbpPJttUcvIsYdUcoiBnmwchOzwQLIXqpEPzHmPvCenKjXOmO()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) - (0 + 0) >> 0) - 0 - 0) ^ 0 ^ 0) + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(1, 0f, 0f, 999999f);
					num = (((int)num2 + -1874950498) ^ -859104563) - 0 + 0 - 0 >> 0;
					continue;
				case 2u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0) >> 0) ^ 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void geGlQLyZiajXCiuxsctnuvbsfLiisYQLkcFDqeySqAzmFxZWSnRUuYtLdogfDpGkjyNACQgnEBWUVPMHLlpehWqlIUAcYtoaTpdhKyuchDqTbyPnBytsZBdnhCRHqdokmWbGMFXmRnXDFxkjfmBAaWarmPZiHMLdogHfxjBWAgAMEzHKrHCdCOkpVKtWFPFeBUozQeMVLEZTwoNMipQZkIBAVrjNPErLAvkJliTmVGsXPqTGWHOpYGUTtODyUZggnntaedBZvDdEqDKFyDQiQbMTBrqxFvsVz()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) << (0 << 1) >> 0) - 0 - 0 << 0 + 0) - 0 + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					clear_infection.ewQYvoWpOCObSKPehcYvDzMjxhajxtcBOmOxhduBrgfDqItDqxMUhayFKHAnoMRuzmmGVrXeHxdwtjTPNwSaHiuONiNACgnEpLddvNHYAInKWclAOLARURNrSySNEwBAjyhIfPtZPTzYVJSLWmMRGwKxXLkXVUudgMAxUCvYsBcarOwjGhQrKKUNOJKtEweUzvSiiuRtRNyftKgjpbqNddtvRMJkRbtWwhBWWnamqxzWlPteDBeDfqRvbwqvKGBQuCImijnbbexGExjctFGqWQQfqfUzXEBJVJCJghVtndBaTkREmocfZlTDMCWdpNexDNLVVAVlKmcTpQmfopnIBvJJPYWEkSeAYexgzWJLsRvNiZoWqQOaAvVhdbfWEraRiCVksgGsGBqKaWBQKantdeaDipcyQNhbQDEGedDkkwtYelhgzplDdGOeCrbddiBTtpTwrVLHxdjGKbyWh();
					num = (((((int)num2 + -1874950498) ^ -859104563) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) - 0 - 0) ^ 0) >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void lKBXSCTgOUvDpDPdYariYqmBzzMNeualheeTjHFaXbbhrqlOAtHuaNBVxZytPfctTjvlyWTqvrlWoekinYmKNGluCjvjjlkRZInhVapEzqYJBFGsPqfQTrFnYaIoAJgjgtWGRdmmJIkxHBTXDcuTftYHcaiVsbdPjPDhJaBMdThlhiFxhLLypndMvoEQVrUHEunSYLnDAIQmmMATuLNHqFAWLQMuvLRLZzGMVNyvxiXHxRAINLvjDmrZUqghZShPRenMgNXHmsjhHSyUqdGKqHiMiGSEGqwEaiQsDNCaNNXldjsbRmRVlwyjWBEAUsbWVFhycgq()
	{
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		int[] array = default(int[]);
		int num5 = default(int);
		while (true)
		{
			int num = 1758301839;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) + (0 + 0)) ^ 0) << 0) + 0 >> (0 ^ 0) >> 0) - 0)) % 19)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = (((int)num2 + -434485547) ^ 0x7B20DA82) + 0 + 0 << 0 << 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = ((((int)num2 + -733318432) ^ 0x11926063) - 0 >> 0) + 0 << 0;
					continue;
				case 3u:
					num = ((((((int)num2 + -678915685) ^ -1206276119) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 4u:
					current = enumerator.Current;
					num = (0x167BBEBA ^ 0) << 0 >> 0;
					continue;
				case 5u:
					num = (int)((((num2 + 2106842273) ^ 0x8CB71F0Du) << 0 << 0 << 0) - 0);
					continue;
				case 6u:
					array = new int[3] { 1, 2, 3 };
					num = (((((int)num2 + -1125345364) ^ -2124224548) - 0 - 0) ^ 0) >> 0;
					continue;
				case 17u:
					num5 = Random.Range(0, array.Length);
					num = (int)(((num2 + 1952503976) ^ 0x80CA71B0u) + 0) >> 0 << 0 >> 0;
					continue;
				case 14u:
					num = (int)(((num2 + 1457370637) ^ 0x27587714) - 0 + 0 - 0) >> 0;
					continue;
				case 7u:
					current.ChangeMaterialLocal(array[num5]);
					num = ((((int)num2 + -814951907) ^ 0x5FB56B4D ^ 0) >> 0 << 0) - 0;
					continue;
				case 8u:
					num = (int)((((num2 + 1665746989) ^ 0xDB6A5568u) + 0 << 0 << 0) ^ 0);
					continue;
				case 9u:
					current.iceParticleSystem.Play();
					num = (int)((((num2 + 770395556) ^ 0xCF3A3030u) - 0 << 0 << 0) - 0);
					continue;
				case 10u:
					num = ((int)(((num2 + 1333463150) ^ 0xF4DB17F0u) - 0 - 0) >> 0) ^ 0;
					continue;
				case 11u:
					current.rockParticleSystem.Play();
					num = ((((int)num2 + -227232852) ^ 0x7E2DC359) - 0 << 0 >> 0) - 0;
					continue;
				case 12u:
					num = (int)((((num2 + 1107201870) ^ 0x64CDDF32) << 0) + 0 + 0 + 0);
					continue;
				case 13u:
					current.lavaParticleSystem.Play();
					num = (int)((((num2 + 1548432940) ^ 0xDD4349B) - 0 << 0) + 0) >> 0;
					continue;
				case 15u:
				{
					int num3;
					int num4;
					if (!enumerator.MoveNext())
					{
						num3 = 1621957018;
						num4 = num3;
					}
					else
					{
						num3 = 272533154;
						num4 = num3;
					}
					num = ((num3 - 0) ^ 0) + 0 + 0;
					continue;
				}
				case 18u:
					num = (((((int)num2 + -1008375456) ^ 0x1EF12CB) << 0) ^ 0 ^ 0) << 0;
					continue;
				case 16u:
					return;
				}
				break;
			}
		}
	}

	public static void CBGXCJWJYoRNtyAtEJGwcjcfvMaqxcTZLWouFzWzaSGmdFHxumCPvJoszACPIGlVuSbxkfNfNgwjDQcPfDVlAeDbHWVeXgRtHKRkDjnoyxbonePIxMKfLZvqoZPnkJiGpcCSYSlVqGNccoOChmGkwLIIpBVEuZeOpvZkCWKFAOOelsnakmgXcXjDuUDwWHBrBYNHpDakCbKIWDwWoVthShMslvQIsnISnxDmFGKHmVvbmBHQxGibotytmuvUNsSosSuyakrHlMVWMKgJOakMfHETZjakkQU()
	{
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		int[] array = default(int[]);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0) + (0 << 1) >> 0) ^ 0) + 0 << (0 << 1) << 0) + 0)) % 15)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((((int)num2 + -795116775) ^ 0xCAE0649 ^ 0) >> 0) - 0 >> 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = (int)((((num2 + 1259723679) ^ 0x9B5F091Au) << 0 << 0) - 0 - 0);
					continue;
				case 3u:
					num = (((((int)num2 + -434485547) ^ 0x22551E67) << 0 >> 0) - 0) ^ 0;
					continue;
				case 4u:
					current = enumerator.Current;
					num = ((0x167BBEB4 ^ 0) >> 0 >> 0) - 0;
					continue;
				case 5u:
					num = (int)(((num2 + 647071759) ^ 0x25B5C2A6) - 0 - 0 << 0) >> 0;
					continue;
				case 6u:
					array = new int[3] { 1, 2, 3 };
					num = (((int)(((num2 + 428697817) ^ 0x668216D8) + 0) >> 0) + 0) ^ 0;
					continue;
				case 14u:
					num3 = Random.Range(0, array.Length);
					num = (int)(((((num2 + 2106842273) ^ 0x9BB97DB2u) + 0 << 0) + 0) ^ 0);
					continue;
				case 12u:
				{
					int num4;
					int num5;
					if (enumerator.MoveNext())
					{
						num4 = 272533144;
						num5 = num4;
					}
					else
					{
						num4 = 17045833;
						num5 = num4;
					}
					num = (num4 << 0 >> 0 << 0) + 0;
					continue;
				}
				case 7u:
					current.ChangeMaterialLocal(array[num3]);
					num = (((int)num2 + -1125345364) ^ 0x403520C2 ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 8u:
					num = ((int)((((num2 + 1952503976) ^ 0xCA73C5E5u) + 0) ^ 0) >> 0) - 0;
					continue;
				case 9u:
					current.iceParticleSystem.Play();
					num = (((int)num2 + -814951907) ^ 0x10B84C4B) - 0 - 0 << 0 << 0;
					continue;
				case 10u:
					num = (int)((((num2 + 1665746989) ^ 0xD805D7BFu) << 0) - 0 - 0) >> 0;
					continue;
				case 11u:
					num = (int)(((((num2 + 770395556) ^ 0xBA96B925u) + 0 + 0) ^ 0) << 0);
					continue;
				case 13u:
					return;
				}
				break;
			}
		}
	}

	public static void TdgJugiQnoAPByCHBoLgMhfjKnBzQkhwvSbSFbMDFkXxERcuxCyVzJhLXXYgEIZdheuJwJbACiACkIFSkgcoLlXLLqUIcFYXlTpAxtYNBXsrjEBpsgVyFKrWgJYgOsxXjCrqsfvRipNOSGBgPFqWJAsACttNvRZizvhGmkXnLepqXDdAiRricBnJkROYLHvqpFoxzUUEHclEkbDZqTFDAQfYhxwvwYBdIYasoGanXMBZqJzjoOIScSQzzppcyyiJBhVlalKJSsGNpgHyYmhHqJaQiBTYrYOy()
	{
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		int[] array = default(int[]);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 + (0 + 0) + 0 << 0) + 0) ^ 0) >> 0) - 0)) % 15)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((((int)num2 + -795116775) ^ 0xCAE0649) >> 0 << 0) - 0 + 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = (((int)((num2 + 1259723679) ^ 0x9B5F091Au) >> 0) ^ 0) - 0 >> 0;
					continue;
				case 3u:
					num = ((((int)num2 + -434485547) ^ 0x22551E67 ^ 0) + 0 >> 0) ^ 0;
					continue;
				case 4u:
					current = enumerator.Current;
					num = ((0x167BBEB4 ^ 0) >> 0) - 0 << 0;
					continue;
				case 5u:
					num = ((int)(((num2 + 647071759) ^ 0x25B5C2A6) << 0) >> 0) ^ 0 ^ 0;
					continue;
				case 6u:
					array = new int[3] { 1, 2, 3 };
					num = ((int)((num2 + 428697817) ^ 0x668216D8) >> 0) - 0 >> 0 << 0;
					continue;
				case 14u:
					num3 = Random.Range(0, array.Length);
					num = (int)(((((num2 + 2106842273) ^ 0x9BB97DB2u) - 0 << 0) ^ 0) + 0);
					continue;
				case 12u:
				{
					int num4;
					int num5;
					if (enumerator.MoveNext())
					{
						num4 = 272533144;
						num5 = num4;
					}
					else
					{
						num4 = 17045833;
						num5 = num4;
					}
					num = (num4 + 0 << 0 << 0) ^ 0;
					continue;
				}
				case 7u:
					current.ChangeMaterialLocal(array[num3]);
					num = (((((int)num2 + -1125345364) ^ 0x403520C2) << 0) + 0 - 0) ^ 0;
					continue;
				case 8u:
					num = (int)(((((num2 + 1952503976) ^ 0xCA73C5E5u) << 0) ^ 0) - 0) >> 0;
					continue;
				case 9u:
					current.rockParticleSystem.Play();
					num = ((((((int)num2 + -814951907) ^ 0x10B84C4B) + 0) ^ 0) >> 0) + 0;
					continue;
				case 10u:
					num = ((int)((num2 + 1665746989) ^ 0xD805D7BFu ^ 0) >> 0 >> 0) - 0;
					continue;
				case 11u:
					num = (int)((((num2 + 770395556) ^ 0xBA96B925u) << 0) - 0 + 0 + 0);
					continue;
				case 13u:
					return;
				}
				break;
			}
		}
	}

	public static void ERyiNniddYZKlcjsIQdlrAsRhfdyrLsTDhjxIyLLeeDrJpEgsAqAVChdzGbIjJLsGggeSMKjeshnXbiRAWgRuRYbZgYbxdButlKDiAoFQhvCuUgyxjimDTXPhfeLNILbRNTLqFIZIAbnvwGfaAEoVoRzoVvdvCRhvuLHauhSAiDcSJuLzYKnexgCWuxukFDgITSbKZfGsLNMKPHEBJDwSEdXniKGWNIVExtYRsazTeVsKtRhMTTAbgoeQUNCozJFdShmvINiIdDNJKnUqDTdThTyjoiXFyluuppSlELefKRXDAvgGSlLFFLWYJdhAQCkSittvvILROXjpVUJTcqM()
	{
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		int[] array = default(int[]);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 >> (0 ^ 0)) + 0 + 0 >> 0) - (0 << 1) >> 0 >> 0)) % 15)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((((int)num2 + -795116775) ^ 0xCAE0649) >> 0) + 0 - 0 + 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = (int)((((num2 + 1259723679) ^ 0x9B5F091Au) << 0) + 0 - 0 + 0);
					continue;
				case 3u:
					num = (((((int)num2 + -434485547) ^ 0x22551E67) + 0 >> 0) ^ 0) << 0;
					continue;
				case 4u:
					current = enumerator.Current;
					num = 0x167BBEB4 ^ 0;
					continue;
				case 5u:
					num = ((int)(((num2 + 647071759) ^ 0x25B5C2A6) - 0 + 0) >> 0) + 0;
					continue;
				case 6u:
					array = new int[3] { 1, 2, 3 };
					num = (((int)((num2 + 428697817) ^ 0x668216D8 ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 14u:
					num3 = Random.Range(0, array.Length);
					num = (int)(((((num2 + 2106842273) ^ 0x9BB97DB2u) << 0) ^ 0 ^ 0) - 0);
					continue;
				case 12u:
				{
					int num4;
					int num5;
					if (enumerator.MoveNext())
					{
						num4 = 272533144;
						num5 = num4;
					}
					else
					{
						num4 = 17045833;
						num5 = num4;
					}
					num = (num4 >> 0) + 0 << 0 << 0;
					continue;
				}
				case 7u:
					current.ChangeMaterialLocal(array[num3]);
					num = ((((int)num2 + -1125345364) ^ 0x403520C2) << 0) + 0 - 0 << 0;
					continue;
				case 8u:
					num = (int)(((num2 + 1952503976) ^ 0xCA73C5E5u) + 0) >> 0 >> 0 << 0;
					continue;
				case 9u:
					current.lavaParticleSystem.Play();
					num = ((((int)num2 + -814951907) ^ 0x10B84C4B) - 0 + 0) ^ 0 ^ 0;
					continue;
				case 10u:
					num = (int)(((num2 + 1665746989) ^ 0xD805D7BFu ^ 0) << 0) >> 0 << 0;
					continue;
				case 11u:
					num = ((int)(((num2 + 770395556) ^ 0xBA96B925u ^ 0) - 0) >> 0) + 0;
					continue;
				case 13u:
					return;
				}
				break;
			}
		}
	}

	public static void nAOOEsTBBEDphHfvhbKlkzTQHCGdPtnyzPXstEPcBgknlIbIQzCRreCNHXgbMQMhqfPsKMbCmIJdpFFZBYmqRwhvnjLvxOpLucWfSJYdxZFIuyybsgzODwqUYueAbFfysYJmIzhSZjSSQyaOKJdqoBhYMchxExbRThpwPmsSYHOuDxdzupQrCPkRRLAGsKnChaYJiDZyrlrGMNuoYIcoHKpeWxFeLLAotlmDzuqRqrarxDedrlIJIYVxLTMLYVMFLdmBARODrlYpKYHttBNzcQFuqPRFHFSvEuFuqDCzxesxaFMNmtrxinDVxSkLZjWMsDLqsncPYncXyhuLcetnnvnrQKWytRAniFfxTwuZrCyUkFxqxzIUPJyXquzHqDvgMOPScXRFJuVKWsglnGbUjFyyghgzXMIOgsivPEnAIdlvNOaYnnuKBBXgqrLVQrHXLgDE()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 << 0 + 0) + 0) ^ 0) + 0 + (0 << 1) << 0 << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(32, 0f, 0f, 999999f);
					num = (((((int)num2 + -1874950498) ^ -859104563) - 0 << 0) ^ 0) >> 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0 - 0) ^ 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void jKvIsAlfucKsgilKsXmEubfyTsKqvoJGkwODRMrbpRMnGsOHgXENUZkiEXOaPVKgsdiKuISFFloCpRSBDdkyJVMlmGYUXrluhFUCjemxfZiJKHSMfnwMLmxwrXxOJXIoZUuJXprzQMsKNdBENlPKUzJVi()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) + -0 << 0) - 0 >> 0) + (0 << 1)) ^ 0) - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(18, 0f, 0f, 999999f);
					num = ((((int)num2 + -1874950498) ^ -859104563) >> 0) - 0 + 0 >> 0;
					continue;
				case 2u:
					num = ((int)((num2 + 414745695) ^ 0x55FC76F6) >> 0) - 0 + 0 >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void xlmGyOhqTKPnjPPVXVYTNJnwSaxiXtzlzBzefSrYltUtLrEvZOXEKcvOXPOyqZszlDNHqLQeDaItOUKAvbijwUBwgKgpeTHlauihDWfoXSaJubZcencoRjcqcqBFEBaJswtuMDXzWTlEURceKekRRtuRsRfnvzKwRqrXIFpBqDrXXxwknxVzqjSYbCbUyJexjPNDAfweOJBobxTUvUZYEkfIysWfDudGyUNiKSJiaQLHIEXDIhzDKgSZJeeiiqAuFUPhJLjCkQXNzyaUvswwVzVsbOyFOBaJqqbNOPUXYWtUifAlekNPTeygZwfVmDOJPoxiwmfFyzyZgakWonBDNkPlSVNrKYKuhJfUIrPReiruGzZZmjGZckVFylpAzNUzOdRwVqnWxJzFTvFsWNfBs()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) + (0 << 1) << 0 << 0 >> 0 << -0 << 0) + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(3, 0f, 0f, 999999f);
					num = (((int)num2 + -1874950498) ^ -859104563 ^ 0 ^ 0) << 0 << 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6 ^ 0) << 0 << 0) - 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void LsWOzvwbosqnRFCHDeWVKBsLqLdGXELIthdLVIvUQUirirbPcLtJiFIjZkyNrQeKGIUKCRMUJbePsbDYKoDmlbzNzTLKkHDaPyKAwrmkYyagBSRYHzddmSzEihkJgbKbyeZUqdBtctnNbsmHcNdKDzNXYfrpgDdWNYIwSWHEXKbTFMDPVDHtYayYrcVlLmmypqZcKPOffyN()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 - (0 ^ 0) - 0 - 0 >> 0) + (0 << 1) >> 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(54, 0f, 0f, 999999f);
					num = (((int)num2 + -1874950498) ^ -859104563) - 0 + 0 + 0 + 0;
					continue;
				case 2u:
					num = (((int)(((num2 + 414745695) ^ 0x55FC76F6) - 0) >> 0) ^ 0) >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void TyTrmBCuCWKYMAJfPbwSLyCEoMBefPBnzmEAyKIJjRJCFsmBbKZeIGcvWpdAaxpNuwyAViGesNJTOZYWzZcvQxFTkjDiHiILCWhiTMFSdULVWiGWqgaauTXXREpLFywjeXrRRQcMujsVLJWcCGSBiHqIZkrpxTnEx()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0 - (0 >> 1) << 0) ^ 0) << 0) ^ 0) << 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(49, 0f, 0f, 999999f);
					num = ((((((int)num2 + -1874950498) ^ -859104563) << 0) + 0) ^ 0) << 0;
					continue;
				case 2u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6 ^ 0) - 0) >> 0) ^ 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void CQZQPfAenGkBblhHniYFVbwGISHyNpAWNxjSXlNBrxUbfhXYjHjLoZCAtsh()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num << 0) - (0 << 1)) ^ 0) >> 0) - 0) ^ 0) + 0 + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(9, 0f, 0f, 999999f);
					num = (((((int)num2 + -1874950498) ^ -859104563) - 0) ^ 0) - 0 + 0;
					continue;
				case 2u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6 ^ 0) + 0 + 0 + 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void XybqYgoNDcpKbvwnygvBBUIpfgPHOVIzEdQdqgWURttWUWhpSLduXRGcPMlSrHZItPfYFtXskAJhALuiYzPdRoBNxNnEUdDjuLCeRjKyNLjwhyBercTRRWQfosARftxhXzNPiqrPOqpgfeFYljmSkLsxVxPzITsuoczHLMVaLecAGKakMBFW()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) - (0 + 0) - 0 - 0 - 0 - (0 >> 1)) ^ 0) << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(8, 0f, 0f, 999999f);
					num = (((int)num2 + -1874950498) ^ -859104563) - 0 + 0 >> 0 << 0;
					continue;
				case 2u:
					num = ((int)((((num2 + 414745695) ^ 0x55FC76F6) - 0) ^ 0) >> 0) - 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void gEWmhpULASgVXVRdFYnznmhfIRRkxFMhnwoJfnzvSkATYhDLSWFOogIUxRDqyJnUfZIBHhXrySGdLnhBofsAaYSgOtlnJjWjWFNZyceKZnpvAEijKcctrNUggBMnWJIoWxhfzhclbHB()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 - (0 ^ 0) << 0) ^ 0 ^ 0 ^ -0) + 0 + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(53, 0f, 0f, 999999f);
					num = ((((int)num2 + -1874950498) ^ -859104563 ^ 0) - 0 + 0) ^ 0;
					continue;
				case 2u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) << 0) >> 0 << 0 >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void NJxGjlbDHgDSjLHSWpQOpEazdxcKCZQrJmhxJVCcUgbisEYuSogWkSmiIXDMiraIqliWDkjbNOUiDSgyzHRnSUgQaZOLsQTCftRgwbRHeejwYdEQQenAzNPvfrWEvyJWVsdkaacyQkiOLKSWuYUnCtcsDwbeemlGvmBFZuPQcPJpEaKuyZkxDvtCpKGEYYtEYCsyjnXaidlNJMODLHFecOcZSYpoNlSevfrbIlklcjozkGSDWdSrsoCjzsGkXImXlhsEuMUzwucSzCPmgMsKsBLgChCpFaouWqodooikitUYmJJWDuelpCFKvlbmjFUwfHVjoMYRDhBYGNUTyFMlVceuKDHcmVaDzySFNAIQvmHibHdIqiO()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0) ^ 0 ^ 0) - 0 - 0 >> (0 >> 1)) ^ 0) - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(8, 0f, 0f, 9999999f);
					num = (((((int)num2 + -1874950498) ^ -859104563) - 0 >> 0) ^ 0) - 0;
					continue;
				case 2u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6 ^ 0) - 0 - 0) >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(int SoundID, float tapcooldown, float Dalay, float volume)
	{
		bool inRoom = default(bool);
		bool flag = default(bool);
		GorillaSurfaceOverride current = default(GorillaSurfaceOverride);
		while (true)
		{
			int num = 1758301851;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0 ^ -0) - 0 + 0 << 0) + (0 ^ 0) + 0 - 0)) % 25)
				{
				case 0u:
					break;
				case 1u:
					GorillaTagger.Instance.leftHandTouching = true;
					num = (((int)num2 + -1186296972) ^ 0x17DF15EE) - 0 + 0 << 0 << 0;
					continue;
				case 2u:
					num = ((((int)num2 + -1701687338) ^ -874857182) >> 0 << 0) - 0 - 0;
					continue;
				case 3u:
					inRoom = PhotonNetwork.InRoom;
					num = (((((int)num2 + -1219895373) ^ -1024244502) >> 0) ^ 0 ^ 0) + 0;
					continue;
				case 4u:
					flag = inRoom;
					num = ((int)((num2 + 900749756) ^ 0x53955EE7) >> 0) + 0 - 0 >> 0;
					continue;
				case 5u:
				{
					int num7;
					int num8;
					if (!flag)
					{
						num7 = -876046602;
						num8 = num7;
					}
					else
					{
						num7 = -1571216456;
						num8 = num7;
					}
					num = ((((num7 >> 0 >> 0) ^ ((int)num2 + -1536825040)) >> 0 << 0) ^ 0) + 0;
					continue;
				}
				case 6u:
					num = (int)(((((num2 + 1855824404) ^ 0xD391DD8Fu) << 0) ^ 0) - 0) >> 0;
					continue;
				case 23u:
					GorillaGameManager.instance.stepVolumeMax = 999999f;
					num = ((((int)num2 + -1395914388) ^ 0x4876A070) - 0 + 0 << 0) ^ 0;
					continue;
				case 20u:
					num = ((int)(((num2 + 1855391286) ^ 0xDFACFEB4u) - 0 << 0) >> 0) ^ 0;
					continue;
				case 7u:
					num = (int)(((((num2 + 1319775793) ^ 0xDE76CF43u) << 0) + 0) ^ 0 ^ 0);
					continue;
				case 8u:
					num = ((int)(((num2 + 747032882) ^ 0x2A9DC59) << 0) >> 0) + 0 + 0;
					continue;
				case 9u:
					Player.Instance.wasLeftHandTouching = true;
					num = (1345212160 + 0 >> 0) - 0 - 0;
					continue;
				case 10u:
					num = (int)(((((num2 + 1620250878) ^ 0xDBB31F76u) + 0) ^ 0 ^ 0) + 0);
					continue;
				case 11u:
					Player.Instance.IsHandTouching(true);
					num = (int)(((num2 + 232892542) ^ 0x5A98DE08) - 0) >> 0 << 0 << 0;
					continue;
				case 12u:
					GorillaTagger.Instance.leftHandTouching = false;
					num = (int)((((num2 + 1133461507) ^ 0x665E6E5F) << 0) + 0 - 0) >> 0;
					continue;
				case 13u:
					num = ((int)(((num2 + 1221206141) ^ 0x195542D3) << 0) >> 0) + 0 - 0;
					continue;
				case 24u:
					num = (int)((((num2 + 1919092371) ^ 0xB47844A6u) + 0 - 0 + 0) ^ 0);
					continue;
				case 22u:
					GorillaTagger.Instance.tapCoolDown = Dalay;
					num = (int)((((num2 + 441892074) ^ 0x7F9DCE9E) + 0 << 0) ^ 0) >> 0;
					continue;
				case 14u:
					num = ((((int)num2 + -1856515560) ^ -304999650) + 0 - 0) ^ 0 ^ 0;
					continue;
				case 15u:
					GorillaTagger.Instance.handTapVolume = volume;
					num = (((((int)num2 + -11398900) ^ 0x2ACAF52E) + 0 << 0) ^ 0) + 0;
					continue;
				case 16u:
					num = ((((int)num2 + -202039689) ^ 0x32B87EEA) - 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 17u:
					GorillaTagger.Instance.lastLeftTap = tapcooldown;
					num = ((((int)num2 + -324874666) ^ 0x742C9D23) << 0) + 0 << 0 >> 0;
					continue;
				case 18u:
					num = (((((int)num2 + -1198330398) ^ -1955723495) << 0) ^ 0) << 0 >> 0;
					continue;
				case 19u:
					Player.Instance.inOverlay = false;
					num = (((int)(((num2 + 502420178) ^ 0x6BB1AD69) + 0) >> 0) ^ 0) - 0;
					continue;
				default:
				{
					IEnumerator<GorillaSurfaceOverride> enumerator = Object.FindObjectsOfType<GorillaSurfaceOverride>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 1493219098;
								num4 = num3;
							}
							else
							{
								num3 = 948759877;
								num4 = num3;
							}
							int num5 = (((num3 << 0) + 0) ^ 0) - 0;
							while (true)
							{
								switch ((num2 = (uint)(((((num5 ^ 0) >> (0 >> 1) << 0) ^ 0) << 0 << (0 << 1)) - 0 << 0)) % 12)
								{
								case 0u:
									num5 = 948759877;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (0x3115B6E6 ^ 0) - 0;
									continue;
								case 2u:
									num5 = ((((int)num2 + -1907731796) ^ -1291480843) << 0) - 0 + 0 + 0;
									continue;
								case 3u:
									current.overrideIndex = SoundID;
									num5 = (int)(((num2 + 1006238481) ^ 0x6E0A5048) + 0 + 0 + 0 << 0);
									continue;
								case 4u:
									num5 = (int)((num2 + 1143130223) ^ 0x7E0C56DE) >> 0 >> 0 << 0 >> 0;
									continue;
								case 5u:
									Player.Instance.leftHandMaterialTouchIndex = current.overrideIndex;
									num5 = (int)((((num2 + 1738827302) ^ 0x44346B4D) - 0 - 0 << 0) - 0);
									continue;
								case 6u:
									num5 = ((int)(((num2 + 1837682201) ^ 0xA0E368B0u ^ 0) + 0) >> 0) - 0;
									continue;
								case 11u:
									Player.Instance.leftHandSurfaceOverride = current;
									num5 = ((int)((num2 + 245809991) ^ 0x29E55F2D) >> 0 >> 0) + 0 - 0;
									continue;
								case 9u:
									break;
								case 7u:
									num5 = ((int)(((num2 + 1024325323) ^ 0x423AD4D2) << 0) >> 0 >> 0) ^ 0;
									continue;
								case 8u:
									num5 = (int)(((num2 + 1574892098) ^ 0xEF1391C3u) + 0 << 0) >> 0 << 0;
									continue;
								case 10u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_0852:
								int num6 = 1609311921;
								while (true)
								{
									switch ((num2 = (uint)((((num6 >> 0) - (0 >> 1) << 0 << 0 << 0) ^ 0) >> 0) ^ 0u) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0857;
									case 1u:
										enumerator.Dispose();
										num6 = ((((int)num2 + -454565845) ^ 0x14C85902) + 0 >> 0 << 0) - 0;
										continue;
									case 2u:
										num6 = ((int)(((num2 + 934005898) ^ 0xC54DF4FBu) + 0) >> 0) - 0 + 0;
										continue;
									case 3u:
										goto end_IL_0857;
									}
									goto IL_0852;
									continue;
									end_IL_0857:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public soundspammers()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0 >> (0 >> 1)) ^ 0 ^ 0) - 0) ^ 0) + 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) - 0 + 0 >> 0 >> 0;
			}
		}
	}
}
