using UnityEngine;

namespace MenuTemplate;

internal class give_shiny_rocks
{
	public static void jkLXzLDeMgzXHGfVaFZJHodQKbVQDptpfKPyBpOhefzptCFKiNRECuMVhUnyQNAwMjSWQHuKRRFCPOxhwlIQxON()
	{
		bool[] array2 = default(bool[]);
		bool[] array = default(bool[]);
		int num3 = default(int);
		CosmeticsController instance = default(CosmeticsController);
		while (true)
		{
			int num = 1758301846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 << (0 << 1)) - 0 - 0 - 0) ^ 0 ^ 0) - 0)) % 17)
				{
				case 12u:
					break;
				default:
					return;
				case 14u:
					CosmeticsController.instance.UpdateCurrencyBoard();
					num = (((int)num2 + -2033110311) ^ -1416073038) >> 0 >> 0 >> 0 >> 0;
					continue;
				case 8u:
					num = (((((int)num2 + -1219895373) ^ 0x45F37EA6) >> 0) + 0 << 0) + 0;
					continue;
				case 5u:
					array2 = array;
					num = (((int)num2 + -678915685) ^ -239294818 ^ 0) << 0 << 0 << 0;
					continue;
				case 0u:
					num3 = Random.Range(0, array2.Length);
					num = ((((int)num2 + -1186296972) ^ -679555457) - 0 >> 0 >> 0) - 0;
					continue;
				case 7u:
					CosmeticsController.instance.checkedDaily = array2[num3];
					num = ((((int)num2 + -1701687338) ^ -410177556) - 0 - 0 << 0) ^ 0;
					continue;
				case 6u:
					num = (int)(((((num2 + 1259723679) ^ 0x862465D0u ^ 0) + 0) ^ 0) + 0);
					continue;
				case 9u:
					CosmeticsController.instance.gotMyDaily = array2[num3];
					num = ((int)(((num2 + 900749756) ^ 0x3968E2D7) + 0 - 0) >> 0) - 0;
					continue;
				case 10u:
					num = ((int)(((num2 + 1709781230) ^ 0xDDCA7C3Cu) + 0) >> 0) + 0 + 0;
					continue;
				case 11u:
					instance = CosmeticsController.instance;
					num = ((((((int)num2 + -1650322207) ^ 0x5EE508E0) << 0) ^ 0) >> 0) - 0;
					continue;
				case 1u:
				{
					CosmeticsController obj = instance;
					int currencyBalance = obj.currencyBalance;
					obj.currencyBalance = currencyBalance + 1;
					num = ((((int)num2 + -871797673) ^ 0x7745FBCE ^ 0) + 0 << 0) - 0;
					continue;
				}
				case 13u:
					num = ((((int)num2 + -1439813256) ^ 0x366B451B) << 0 >> 0) - 0 << 0;
					continue;
				case 3u:
					array = new bool[2];
					num = (((int)num2 + -434485547) ^ 0x62B41E ^ 0) + 0 + 0 << 0;
					continue;
				case 15u:
					num = ((((int)num2 + -1827602905) ^ -997299123) - 0 << 0 >> 0) ^ 0;
					continue;
				case 16u:
					num = ((((int)num2 + -509051253) ^ 0x272C0F03) >> 0) + 0 + 0 - 0;
					continue;
				case 4u:
					array[0] = true;
					num = ((((int)num2 + -733318432) ^ -994542) - 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public give_shiny_rocks()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0 >> (0 << 1) << 0) ^ 0) + 0) ^ 0 ^ 0) << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB3) << 0) ^ 0) - 0) ^ 0;
			}
		}
	}
}
