using GorillaLocomotion;
using UnityEngine;

namespace MenuTemplate;

internal class upsidedownmod1
{
	public static void BncbilfNeTRZktiSpAMBSIQdkSwnOsjkaGVnkiFLcDOhxCUBYqRzPYhTwYQqORZLKGZExUIhUazpTJGHXUpyBKubycRlrpXlDdxQDqedIKEPzRZMsisUBBkZmXfudwQFdnLQlPeHQmPQfFCHdeTjWcJcTxEGlJamUZLlfjACeLdpLtUHuxrYDGIaEIXOlywhlDWfUrBTDqflYurzDWlNrbInrKHwlMrFpWdiwONdWxunBxckrxkonIPkUJOjKeHRZzVcqjdPjiQTHvLTIwfOCcsGhTnNZDsRQDncBZTiuufeSWDzXVBnZToXgpVxVpQFPZddhJrIDWthWnOkqOPdcfRWoqVmevmeDz()
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 << 0 + 0) - 0 >> 0) + 0 - (0 + 0) - 0 >> 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.gravity = new Vector3(Physics.gravity.x, Physics.gravity.y + 17f, Physics.gravity.z);
					num = (int)(((((num2 + 414745695) ^ 0xB4411D0Cu ^ 0) << 0) ^ 0) << 0);
					continue;
				case 2u:
					num = (((((int)num2 + -907893453) ^ -466987136) + 0 - 0) ^ 0) + 0;
					continue;
				case 3u:
					((Component)Player.Instance).transform.Rotate(Vector3.forward, 180f);
					num = ((((int)num2 + -248958683) ^ 0x1C939554) >> 0) + 0 - 0 + 0;
					continue;
				case 4u:
					num = ((((int)num2 + -344833909) ^ -305432172) + 0 >> 0) - 0 >> 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public static void pSSzroDSJczgaSBKhhzNDJhgPQNfEhJoExYVsQwBAjvPxhqcLuofFQVFLMKAAxoBtkCDUFsqKYmuosJHALujTEJNBsjFgWbcUTvmENifbYvGDArtccZOdfIPAPbCvMkNWkAuWwcNDoiUicjaaQCdWmYPkGLPLFKpOHKtaWwFamlPWOGyFbBEjgRJlLjpLmbXESgBsQaduWdJbjSwankKdffHPbhpNhUNkoleHefOaykmchIcSNoycrTyNyLrIKqmcpyMXOPWhvJFUSFIsewZSwLTuMqisOgqhXkMIVfeYsqGH()
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 + -0 + 0 << 0) - 0 - (0 + 0) + 0 - 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.gravity = new Vector3(Physics.gravity.x, Physics.gravity.y + 0f, Physics.gravity.z);
					num = (int)(((((num2 + 414745695) ^ 0xB4411D0Cu) + 0) ^ 0) + 0 + 0);
					continue;
				case 2u:
					num = (((((int)num2 + -907893453) ^ -466987136) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 3u:
					((Component)Player.Instance).transform.Rotate(Vector3.forward, 0f);
					num = (((((int)num2 + -248958683) ^ 0x1C939554) + 0) ^ 0) + 0 + 0;
					continue;
				case 4u:
					num = (((((int)num2 + -344833909) ^ -305432172) >> 0 << 0) ^ 0) + 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public upsidedownmod1()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0) + (0 >> 1) >> 0) + 0 >> 0 >> -0) ^ 0) + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB1) << 0) ^ 0) << 0) + 0;
			}
		}
	}
}
