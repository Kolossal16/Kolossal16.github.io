using Il2CppSystem.Collections.Generic;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class tracers
{
	public static void djohyYJPzFIXVzHdxeScVLPqHomjjcfvOgCzMEdDzQQIgzpJJjASsNXruYAjMAGxAnjOXhqSboCfVgjhZCAa()
	{
		//IL_0634: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Unknown result type (might be due to invalid IL or missing references)
		//IL_063a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0748: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0760: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f1: Expected O, but got Unknown
		GameObject val3 = default(GameObject);
		bool flag3 = default(bool);
		bool flag = default(bool);
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		bool flag4 = default(bool);
		bool flag2 = default(bool);
		GameObject val = default(GameObject);
		LineRenderer val2 = default(LineRenderer);
		while (true)
		{
			int num = 1758301841;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 >> -0 >> 0) - 0 + 0 << -0) ^ 0) + 0)) % 34)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					val3 = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("癑癪癤癫癷癋癢癭癧瘣癀癬癭癷癱癬癯癯癦癱", 1268938243, true));
					num = (int)(((num2 + 770395556) ^ 0xA37FD3D1u) + 0 + 0 - 0 << 0);
					continue;
				case 2u:
					flag3 = PhotonNetwork.CurrentRoom != null;
					num = ((int)(((num2 + 1333463150) ^ 0x9EC1FAF1u) - 0) >> 0 << 0) + 0;
					continue;
				case 3u:
					flag = flag3;
					num = (((int)num2 + -227232852) ^ 0x1DC610CB ^ 0) - 0 << 0 >> 0;
					continue;
				case 4u:
				{
					int num5;
					int num6;
					if (!flag)
					{
						num5 = -1939229680;
						num6 = num5;
					}
					else
					{
						num5 = -312400;
						num6 = num5;
					}
					num = (((num5 >> 0 << 0) ^ ((int)num2 + -649986417)) << 0) + 0 + 0 + 0;
					continue;
				}
				case 5u:
					num = ((((int)((num2 + 660359990) ^ 0x25608D93) >> 0) + 0) ^ 0) + 0;
					continue;
				case 6u:
					num = (((int)num2 + -1950096023) ^ -256142780) + 0 + 0 >> 0 << 0;
					continue;
				case 33u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = ((((int)num2 + -11084362) ^ 0x1DFC7C98) + 0 << 0) - 0 + 0;
					continue;
				case 27u:
					num = ((0x35B059BE ^ 0) << 0) - 0;
					continue;
				case 7u:
					num = (int)(((((num2 + 1047830633) ^ 0xBDE71C20u) + 0) ^ 0 ^ 0) + 0);
					continue;
				case 8u:
					current = enumerator.Current;
					num = (1898524955 + 0 >> 0) - 0 << 0;
					continue;
				case 9u:
					num = (((int)((num2 + 1221206141) ^ 0xE9DD1F60u) >> 0) ^ 0) >> 0 >> 0;
					continue;
				case 10u:
					flag4 = !current.isOfflineVRRig;
					num = (int)((((num2 + 441892074) ^ 0x1F74B97) - 0 + 0) ^ 0) >> 0;
					continue;
				case 11u:
					flag2 = flag4;
					num = (((int)num2 + -1856515560) ^ -553572987) << 0 >> 0 << 0 << 0;
					continue;
				case 12u:
				{
					int num8;
					int num9;
					if (!flag2)
					{
						num8 = 1973836590;
						num9 = num8;
					}
					else
					{
						num8 = 1003393066;
						num9 = num8;
					}
					num = (int)(((((uint)(num8 ^ 0 ^ 0) ^ (num2 + 385831441)) - 0) ^ 0) + 0 + 0);
					continue;
				}
				case 13u:
					num = ((((int)num2 + -67898082) ^ -1402768002) << 0) - 0 >> 0 << 0;
					continue;
				case 28u:
					num = ((((((int)num2 + -1434948216) ^ 0x682884C3) - 0) ^ 0) << 0) ^ 0;
					continue;
				case 31u:
					val = new GameObject(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쟭쟈쟏쟄", 1684981665, true));
					num = (int)(((((num2 + 1106027214) ^ 0x87E7EB49u) + 0) ^ 0) + 0 - 0);
					continue;
				case 14u:
					val2 = val.AddComponent<LineRenderer>();
					num = ((((int)((num2 + 1840812781) ^ 0xC83D523Eu) >> 0) ^ 0) + 0) ^ 0;
					continue;
				case 15u:
				{
					LineRenderer obj2 = val2;
					Color startColor = (val2.endColor = Color.magenta);
					obj2.startColor = startColor;
					num = ((int)((num2 + 907932242) ^ 0xE19ED455u ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				}
				case 16u:
					num = ((int)((num2 + 929994502) ^ 0xFE01F649u) >> 0 << 0 << 0) - 0;
					continue;
				case 17u:
				{
					LineRenderer obj = val2;
					float startWidth = (val2.endWidth = 0.01f);
					obj.startWidth = startWidth;
					num = (int)((((num2 + 1332896518) ^ 0x931D21FFu) << 0) - 0 - 0 << 0);
					continue;
				}
				case 18u:
					num = (int)(((((num2 + 1263618995) ^ 0x25A8A116 ^ 0) + 0) ^ 0) + 0);
					continue;
				case 19u:
					val2.positionCount = 2;
					num = (int)((((num2 + 1798378934) ^ 0xA6F6E077u) - 0 << 0) - 0 - 0);
					continue;
				case 32u:
				{
					int num3;
					int num4;
					if (enumerator.MoveNext())
					{
						num3 = 1190796322;
						num4 = num3;
					}
					else
					{
						num3 = 1665747000;
						num4 = num3;
					}
					num = ((num3 + 0 - 0) ^ 0) - 0;
					continue;
				}
				case 20u:
					num = ((int)((num2 + 1168528836) ^ 0x8BB2F0A) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 30u:
					val2.SetPositions(Il2CppStructArray<Vector3>.op_Implicit((Vector3[])(object)new Vector3[2]
					{
						val3.transform.position,
						current.headMesh.transform.position
					}));
					num = ((((((int)num2 + -340251349) ^ 0x3ED36278) + 0) ^ 0) - 0) ^ 0;
					continue;
				case 21u:
					num = ((int)(((num2 + 733616138) ^ 0x90077FC7u) << 0) >> 0) - 0 << 0;
					continue;
				case 22u:
					((Renderer)val2).material.shader = Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("າຠ\u0ebc\u0edaມຐຍກ໕\u0ea6ຝດຑຐງ", 1878855413, true));
					num = (int)((((num2 + 360573015) ^ 0x7224E47E) << 0) - 0 << 0 << 0);
					continue;
				case 23u:
					num = (((int)num2 + -342996398) ^ 0x32E8AE15) + 0 << 0 << 0 << 0;
					continue;
				case 24u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = ((((int)((num2 + 121371131) ^ 0x55AE914C) >> 0) - 0) ^ 0) << 0;
					continue;
				case 25u:
					num = (((int)((num2 + 440672968) ^ 0xB9ED24BDu ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 26u:
					num = ((((((int)num2 + -1100503962) ^ -1159899641) << 0) - 0) ^ 0) << 0;
					continue;
				case 29u:
					return;
				}
				break;
			}
		}
	}

	public tracers()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) >> (0 >> 1)) ^ 0 ^ 0) + 0 >> -0) ^ 0) << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0 ^ 0) + 0 - 0;
			}
		}
	}
}
