using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class linerenderer
{
	private static Color XhloxAAUaCxxxIyCydRRJnoguBamZkZDOZyhoqqQXfTCaJxHORWPlnnJSeUVznVPDTIxjrniMaTEuLgKesyinjsBLPokwuqKkdZhaZxxDOcktJphYjRhPMBtBhLucdMsJjtqMYKeUaEzhhhczhlmC = Color.blue;

	private static Color jUxBFFTocuAbJBkpYuZzNmOicmuZJVVRzPzoWPhtQQRFdxxGXMAMmNPWgozslTFhzICU;

	public static void bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(GameObject endline, Color color)
	{
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Expected O, but got Unknown
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0417: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		GameObject val2 = default(GameObject);
		LineRenderer val = default(LineRenderer);
		GameObject val4 = default(GameObject);
		LineRenderer val3 = default(LineRenderer);
		while (true)
		{
			int num = 1758301854;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num - 0 - (0 >> 1) + 0 - 0 - 0 << 0 + 0) + 0 - 0)) % 20)
				{
				case 0u:
					break;
				default:
					return;
				case 14u:
					val2 = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鎭鎖鎘鎗鎋鎷鎞鎑鎛鏟鎼鎐鎑鎋鎍鎐鎓鎓鎚鎍", 756978687, true));
					num = (int)(((num2 + 647071759) ^ 0xBA981948u) - 0 + 0 << 0) >> 0;
					continue;
				case 9u:
					((Renderer)val).material.shader = Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("搲搠搼摚搡搐損搁摕搦搝搔搑搐搇", 1034511477, true));
					num = ((int)(((num2 + 1956669763) ^ 0xD05412F1u) << 0) >> 0) + 0 + 0;
					continue;
				case 1u:
					val4 = new GameObject(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("껊껯껨껣", 1686154886, true));
					num = (((int)((num2 + 428697817) ^ 0x54D79A20 ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 2u:
					val = val4.AddComponent<LineRenderer>();
					num = (int)(((num2 + 2106842273) ^ 0x8929399Eu) - 0 - 0 + 0 + 0);
					continue;
				case 15u:
					num = (int)(((num2 + 1457370637) ^ 0x77AB44D) + 0) >> 0 << 0 >> 0;
					continue;
				case 13u:
					val3 = val;
					num = ((((int)num2 + -1125345364) ^ -615472902) << 0 >> 0) - 0 + 0;
					continue;
				case 7u:
					num = (((int)(((num2 + 1548432940) ^ 0xE47641BFu) + 0) >> 0) ^ 0) - 0;
					continue;
				case 3u:
					val.endColor = Color.HSVToRGB(Time.time % 1f, 1f, 1f);
					num = ((int)((num2 + 1952503976) ^ 0x9264133Du ^ 0) >> 0 >> 0) ^ 0;
					continue;
				case 18u:
					num = (((int)num2 + -814951907) ^ -1125995101) + 0 + 0 >> 0 >> 0;
					continue;
				case 10u:
					Object.Destroy((Object)(object)val4, Time.deltaTime);
					num = ((((int)num2 + -434831334) ^ 0x5187C223) >> 0 << 0) - 0 << 0;
					continue;
				case 4u:
					val3.startColor = Color.HSVToRGB(Time.time % 1f, 1f, 1f);
					num = (int)(((((num2 + 1665746989) ^ 0xF1F3E120u) << 0) - 0 - 0) ^ 0);
					continue;
				case 8u:
					val.SetPositions(Il2CppStructArray<Vector3>.op_Implicit((Vector3[])(object)new Vector3[2]
					{
						val2.transform.position,
						endline.transform.position
					}));
					num = ((((int)num2 + -1008375456) ^ -424363713) >> 0) + 0 >> 0 << 0;
					continue;
				case 5u:
					num = (int)((((((num2 + 770395556) ^ 0x3137EED1) << 0) ^ 0) << 0) - 0);
					continue;
				case 16u:
				{
					LineRenderer obj = val;
					float startWidth = (val.endWidth = 0.01f);
					obj.startWidth = startWidth;
					num = ((((int)((num2 + 1333463150) ^ 0xE75C15ACu) >> 0) ^ 0) << 0) - 0;
					continue;
				}
				case 17u:
					num = (((((int)num2 + -2071082168) ^ -756540825) + 0 >> 0) ^ 0) << 0;
					continue;
				case 6u:
					num = (((((int)num2 + -227232852) ^ 0x33B3AA2D) >> 0) - 0 - 0) ^ 0;
					continue;
				case 11u:
					num = (int)(((((num2 + 461443217) ^ 0x1A346CC4) << 0) + 0 << 0) ^ 0);
					continue;
				case 19u:
					val.positionCount = 2;
					num = (int)((((((num2 + 1107201870) ^ 0xF95E9E32u) + 0) ^ 0) - 0) ^ 0);
					continue;
				case 12u:
					return;
				}
				break;
			}
		}
	}

	public linerenderer()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) - (0 + 0) >> 0 >> 0) - 0 >> (0 << 1) << 0) + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) << 0) ^ 0 ^ 0) + 0;
			}
		}
	}

	static linerenderer()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0) ^ -0) + 0 << 0 << 0) - (0 + 0) << 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_0052;
				case 1u:
					return;
				}
				break;
				IL_0052:
				jUxBFFTocuAbJBkpYuZzNmOicmuZJVVRzPzoWPhtQQRFdxxGXMAMmNPWgozslTFhzICU = Color.black;
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) >> 0) + 0 + 0;
			}
		}
	}
}
