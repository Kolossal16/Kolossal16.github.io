using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class CASUAL
{
	public static void VmVKloqrutqKyceGHsaFKZyxfiFPzgkisonbbmywbFqZymEGebfSeBqWNxEcJBSnjisjPcFvTEDfJzZTDZLxbrdQXrnDHwNANdQpUuQbwKZAXlnoyLzKQulReBmyPcNxRdsFIKZiiKbrsDTMeZfWWdKsRYktismuWBJTTHFOLrBgtUzBHAuQWRBOtZOKzGZQxGuQUZSxtrkFBEYWy()
	{
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Expected O, but got Unknown
		Hashtable val = default(Hashtable);
		while (true)
		{
			int num = 1758301862;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num >> 0) ^ -0) - 0 - 0) ^ 0) << 0 + 0 << 0) - 0)) % 8)
				{
				case 0u:
					break;
				default:
					return;
				case 6u:
					num = ((((((int)num2 + -907893453) ^ 0x7773C28) >> 0) - 0) ^ 0) >> 0;
					continue;
				case 3u:
					PhotonNetwork.CurrentRoom.SetCustomProperties(val, (Hashtable)null, (WebFlags)null);
					num = ((int)((num2 + 359659174) ^ 0x3353313E) >> 0 >> 0) + 0 << 0;
					continue;
				case 1u:
					val = new Hashtable();
					num = (((int)num2 + -248958683) ^ 0x3D73A3B4 ^ 0 ^ 0) + 0 - 0;
					continue;
				case 2u:
					((Dictionary<Object, Object>)(object)val).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᐴᐲᐾᐶᐞᐼᐷᐶ", 456987731, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䇷䇾䇣䇴䇢䇥䇕䇔䇗䇐䇄䇝䇅䇒䇐䇂䇄䇐䇝", 27345297, true)));
					num = (((int)num2 + -344833909) ^ 0x16C8A5B0) >> 0 >> 0 >> 0 >> 0;
					continue;
				case 7u:
					num = ((int)((((num2 + 1621957012) ^ 0x2DA2662F) << 0) + 0) >> 0) - 0;
					continue;
				case 5u:
					num = (((((int)num2 + -2130437817) ^ -2026299041) >> 0) - 0 << 0) + 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public CASUAL()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 + (0 + 0) - 0) ^ 0) >> 0 << -0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB5) + 0) ^ 0) >> 0) + 0;
			}
		}
	}
}
