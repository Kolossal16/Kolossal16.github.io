using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class fireball
{
	public static void WGoBDyXcYEgTPXURAkpGcCMfbMtOAtmsFZybMNwmusZWgLrDiKrtHHxuTjARejBErOnQzTeNNdlKCQYquPGPcTLXBdhDnFilQuEsxBeoGEFEvNRdlkwoDMCydqovLBziUaThlFSTLrjynhBOmercjUIeSfphnJDfexJvTKRFrCDlCelWOAjHjwZarPpgqLGbOetPxfUBmMLGrwBNUtsMAVVHyJeevLoFWBxyKvyIFHvxLtJUnBlXtTBSiMrObPgAxfJPZcdyUJgSAyVeajQTAqmdaEqYdJGQAVZGJTVlyNcJMIsKQmOSYmahSFPuMeukdqsEzpugnFvMoDrrmGiR()
	{
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = default(Vector3);
		bool gripButtonDown = default(bool);
		Quaternion rotation = default(Quaternion);
		while (true)
		{
			int num = 1758301851;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 >> 0 + 0 >> 0 >> 0) - 0 >> (0 << 1)) + 0 >> 0)) % 9)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					num = ((((int)num2 + -640398734) ^ 0x677EE378) << 0) - 0 + 0 << 0;
					continue;
				case 5u:
					position = ((Component)Player.Instance.leftHandTransform).transform.position;
					num = (((((int)num2 + -1496278149) ^ -1586193244) << 0) ^ 0) + 0 + 0;
					continue;
				case 3u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)0);
					num = (((int)num2 + -956687329) ^ 0x1A00A54A) - 0 + 0 + 0 >> 0;
					continue;
				case 1u:
					rotation = ((Component)Player.Instance.leftHandTransform).transform.rotation;
					num = ((((int)num2 + -1807018533) ^ -1300344590 ^ 0) << 0) - 0 + 0;
					continue;
				case 7u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㹉㹁㹜㹇㹂㹂㹏㹞㹜㹋㹈㹏㹌㹝㸁㹉㹁㹜㹇㹂㹂㹏㹈㹇㹜㹋㹌㹏㹂㹂", 1775844910, true), position, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 266738246) ^ 0x7C59654F ^ 0) >> 0 >> 0) ^ 0;
					continue;
				case 0u:
				{
					int num3;
					int num4;
					if (gripButtonDown)
					{
						num3 = -627778403;
						num4 = num3;
					}
					else
					{
						num3 = -1997169901;
						num4 = num3;
					}
					num = ((num3 << 0 >> 0) ^ ((int)num2 + -1957679538)) - 0 >> 0 << 0 >> 0;
					continue;
				}
				case 4u:
					num = (int)(((num2 + 1193528119) ^ 0x72992B78 ^ 0) + 0 - 0) >> 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	public fireball()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0 ^ 0 ^ 0) >> 0) ^ 0) >> (0 ^ 0) << 0) - 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB3) + 0 >> 0 << 0 >> 0;
			}
		}
	}
}
