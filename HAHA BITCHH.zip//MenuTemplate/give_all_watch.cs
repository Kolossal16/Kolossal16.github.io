using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class give_all_watch
{
	public static void dPuacpTYuSrGfmvfCQMftyIxrCHCOqjjXzcuWvoSRlxbvQzojUzfgWHEgXIAIqkdIiIGkaihCTnhbHbBcstTRdcaSxoYMNkAatsnhTejLsDmIzDyVhxqXqmFfINNMjuOJMgHpOtinkiyAQrsTPdEqTCKhNizgrwCXPDVsWjhNocNiNfoquTXgQxPkwACGUcWNFBKmvaXFWQcQPBtITiLxzvhrNLWvHATlgaCmucVuWrkZvYuVgTNLrynkutzJeBYvXQKOYhoRnqBiliWOrapNMiTHMsRaClqusObEoGWZFWyaXfYmxKsdmkIPWdcFpnobagPxgrAKdphQJTJHtFDSSnihfmHkErJsIwaRpBffjHZWdSfdtvmJJviNXIrTKqgMGPinSSrRAyJlnmenhEQieZJmnnTHklvSAmqoJRkBdu()
	{
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = default(Vector3);
		Quaternion rotation = default(Quaternion);
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num - 0) ^ 0) >> 0) - 0 >> 0) ^ -0) << 0) ^ 0u) % 5)
				{
				case 2u:
					break;
				default:
					return;
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueff7\uefff\uefe2\ueff9\ueffc\ueffc\ueff1\uefe0\uefe2\ueff5\ueff6\ueff1\ueff2\uefe3\uefbf\ueff7\uefff\uefe2\ueff9\ueffc\ueffc\ueff1\ueff8\uefe5\ueffe\uefe4\ueffd\ueff1\ueffe\ueff1\ueff7\ueff5\uefe2", 1116925840, true), position, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -956687329) ^ -230459302) >> 0) ^ 0 ^ 0) + 0;
					continue;
				case 3u:
					rotation = ((Component)Player.Instance.rightHandTransform).transform.rotation;
					num = (((((int)num2 + -725091362) ^ 0x110CE96A) - 0) ^ 0) + 0 >> 0;
					continue;
				case 1u:
					position = ((Component)Player.Instance.rightHandTransform).transform.position;
					num = (int)(((num2 + 377208505) ^ 0x4A8E42A8 ^ 0 ^ 0) << 0) >> 0;
					continue;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	public give_all_watch()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) - (0 ^ 0) - 0 - 0 - 0 << -0 >> 0) - 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) - 0 >> 0) + 0 - 0;
			}
		}
	}
}
