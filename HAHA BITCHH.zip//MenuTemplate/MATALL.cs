using System.Collections.Generic;
using GorillaLocomotion;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;

namespace MenuTemplate;

internal class MATALL
{
	public static void MDDtncHyTibejoQwLanyJyJmdMAGGCaKrvzKubQodHNbtXGAmpoxjegoTrpACaSriqMOPgcJjYucLHSggatqoDBmokQcLpMcOvTdlSKgnEnkJeDmzjuCHBcFOzzEqZYUmrnpOOUnpndKprDkHEDBUjvntooLtfQnFtYrQnxKohmtxspxWpXMvwZcWaWzAjUkwQeVtltugTnNWbPaYQOeieRjtVvQrYjencXHoueLVDFCjlfUkVBJvPcsYVBxPDciJiAUehMEMdiFypZiPBFvxAJxaEJsSGVrAxSbLlPdjWXsGxUIVtIoXHKiydUAxtMfhQeawYwDLCmADrQDKaxyYGuTMJCHrpFPjSkPsTlWWeDvujFgnrPwVogBwlnMvOmvWwrKhakROBBUdYyDdwuZAiUVLItg()
	{
		bool flag = default(bool);
		int num8 = default(int);
		GorillaTagManager[] array = default(GorillaTagManager[]);
		GorillaTagManager current = default(GorillaTagManager);
		while (true)
		{
			int num = 1758301865;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num << 0) - (0 >> 1) - 0) ^ 0) + 0) ^ 0) >> 0) - 0)) % 16)
				{
				case 0u:
					break;
				case 9u:
					num = (int)(((((num2 + 359659174) ^ 0x4BFA8ABE) - 0) ^ 0) - 0 + 0);
					continue;
				case 5u:
					num = (int)((((num2 + 900749756) ^ 0xF6F7C41Du ^ 0) - 0 + 0) ^ 0);
					continue;
				case 1u:
					num = (int)((((num2 + 1621957012) ^ 0x8DF7CB28u ^ 0 ^ 0) - 0) ^ 0);
					continue;
				case 7u:
					num = (((((int)num2 + -1395914388) ^ -45393493 ^ 0) << 0) ^ 0) - 0;
					continue;
				case 13u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (int)((((num2 + 647071759) ^ 0x522BEC2E ^ 0 ^ 0) << 0) ^ 0);
					continue;
				case 6u:
					flag = num8 < array.Length;
					num = (600520462 + 0 << 0) + 0 << 0;
					continue;
				case 2u:
					array = Il2CppArrayBase<GorillaTagManager>.op_Implicit(Object.FindObjectsOfType<GorillaTagManager>());
					num = (int)((num2 + 428697817) ^ 0x3FB051D0 ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 10u:
					num = ((((int)num2 + -1219895373) ^ -1888826648) - 0 - 0 << 0) + 0;
					continue;
				case 11u:
					num8 = 0;
					num = (int)((((num2 + 2106842273) ^ 0x8CB71F0Fu) - 0 << 0 << 0) - 0);
					continue;
				case 12u:
					num8++;
					num = (int)(((((num2 + 1709781230) ^ 0xDD653F6Cu) - 0) ^ 0) + 0 << 0);
					continue;
				case 3u:
					num = ((((int)num2 + -1125345364) ^ -1093182599 ^ 0) << 0 >> 0) + 0;
					continue;
				case 14u:
				{
					int num9;
					int num10;
					if (!flag)
					{
						num9 = -1821589403;
						num10 = num9;
					}
					else
					{
						num9 = -961600771;
						num10 = num9;
					}
					num = ((int)((uint)(num9 + 0 + 0) ^ (num2 + 1855824404)) >> 0 >> 0) + 0 >> 0;
					continue;
				}
				case 15u:
					num = (0x49E2A534 ^ 0) << 0;
					continue;
				case 4u:
					array[num8].ClearInfectionState();
					num = (((((int)num2 + -1701687338) ^ -1567692528) << 0) - 0 >> 0) ^ 0;
					continue;
				default:
				{
					IEnumerator<GorillaTagManager> enumerator = Object.FindObjectsOfType<GorillaTagManager>().GetEnumerator();
					try
					{
						while (true)
						{
							IL_04e3:
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 830770638;
								num4 = num3;
							}
							else
							{
								num3 = 1497497229;
								num4 = num3;
							}
							int num5 = num3 - 0 - 0 << 0 << 0;
							while (true)
							{
								switch ((num2 = (uint)((((((num5 << 0) ^ 0) << 0 << 0) - 0 - (0 + 0)) ^ 0) << 0)) % 12)
								{
								case 0u:
									num5 = 1497497229;
									continue;
								default:
									goto end_IL_0385;
								case 9u:
									current = enumerator.Current;
									num5 = 747032881 - 0 - 0 >> 0 << 0;
									continue;
								case 5u:
									break;
								case 1u:
									num5 = (int)((num2 + 441892074) ^ 0x6181C520 ^ 0) >> 0 << 0 << 0;
									continue;
								case 4u:
									num5 = ((int)(((num2 + 502420178) ^ 0x5FF532BC) - 0) >> 0) + 0 << 0;
									continue;
								case 7u:
									((GorillaGameManager)current).checkCooldown = 0f;
									num5 = (((((int)num2 + -1856515560) ^ -668529239) << 0) ^ 0 ^ 0) >> 0;
									continue;
								case 8u:
									Player.Instance.disableMovement = false;
									num5 = ((((int)num2 + -1198330398) ^ 0x74668B96) >> 0 << 0 << 0) ^ 0;
									continue;
								case 2u:
									num5 = (((((int)num2 + -11398900) ^ 0x5426C76D) - 0 >> 0) ^ 0) << 0;
									continue;
								case 10u:
									num5 = (int)((((((num2 + 1855391286) ^ 0xE5C186D9u) - 0) ^ 0) << 0) ^ 0);
									continue;
								case 11u:
									current.tagCoolDown = 0f;
									num5 = ((((int)num2 + -202039689) ^ -229069931) >> 0 << 0 >> 0) ^ 0;
									continue;
								case 3u:
									num5 = ((((int)num2 + -324874666) ^ -2049791111) << 0 >> 0) + 0 >> 0;
									continue;
								case 6u:
									goto end_IL_0385;
								}
								goto IL_04e3;
								continue;
								end_IL_0385:
								break;
							}
							break;
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_0612:
								int num6 = 1705340763;
								while (true)
								{
									switch ((num2 = (uint)(((((num6 ^ 0) + (0 ^ 0) + 0 + 0) ^ 0) + (0 + 0) >> 0) + 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0617;
									case 3u:
										enumerator.Dispose();
										num6 = (int)(((num2 + 1798378934) ^ 0x9B87CEA0u) + 0 - 0 << 0 << 0);
										continue;
									case 1u:
										num6 = (int)(((((num2 + 1168528836) ^ 0xFA4F2D9Bu) + 0 + 0) ^ 0) - 0);
										continue;
									case 2u:
										goto end_IL_0617;
									}
									goto IL_0612;
									continue;
									end_IL_0617:
									break;
								}
								break;
							}
						}
					}
					while (true)
					{
						int num7 = 461723282;
						while (true)
						{
							switch ((num2 = (uint)(((((num7 >> 0) - (0 ^ 0)) ^ 0) << 0) + 0 - (0 >> 1) - 0) ^ 0u) % 3)
							{
							case 0u:
								break;
							default:
								return;
							case 2u:
								goto IL_06fc;
							case 1u:
								return;
							}
							break;
							IL_06fc:
							num7 = (((((int)num2 + -1372250924) ^ -503288977) + 0 + 0) ^ 0) << 0;
						}
					}
				}
				}
				break;
			}
		}
	}

	public MATALL()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num - 0 << (0 << 1) << 0) + 0 + 0 + (0 + 0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB5) + 0) ^ 0) << 0) - 0;
			}
		}
	}
}
