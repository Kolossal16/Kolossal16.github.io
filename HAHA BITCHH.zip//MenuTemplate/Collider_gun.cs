using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class Collider_gun
{
	public static void VYBBEXjOAeNbzgcVAFPrLPEDEgaxiuASeVhjarPrKHRQYFXWgKjwIFwgtXXyWLGgDUWEZSVjPyHdXOFY()
	{
		//IL_16fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_215c: Unknown result type (might be due to invalid IL or missing references)
		//IL_215e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2307: Unknown result type (might be due to invalid IL or missing references)
		//IL_230c: Unknown result type (might be due to invalid IL or missing references)
		//IL_230d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2486: Unknown result type (might be due to invalid IL or missing references)
		//IL_248b: Unknown result type (might be due to invalid IL or missing references)
		//IL_26a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_26a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_2850: Unknown result type (might be due to invalid IL or missing references)
		//IL_2855: Unknown result type (might be due to invalid IL or missing references)
		//IL_2856: Unknown result type (might be due to invalid IL or missing references)
		//IL_29d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_29da: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d22: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e99: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_3029: Unknown result type (might be due to invalid IL or missing references)
		//IL_302e: Unknown result type (might be due to invalid IL or missing references)
		//IL_302f: Unknown result type (might be due to invalid IL or missing references)
		//IL_31b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_31b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e60: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eda: Unknown result type (might be due to invalid IL or missing references)
		//IL_1edc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f61: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f66: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f67: Unknown result type (might be due to invalid IL or missing references)
		//IL_2002: Unknown result type (might be due to invalid IL or missing references)
		//IL_2004: Unknown result type (might be due to invalid IL or missing references)
		//IL_209b: Unknown result type (might be due to invalid IL or missing references)
		//IL_209d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2118: Unknown result type (might be due to invalid IL or missing references)
		//IL_211d: Unknown result type (might be due to invalid IL or missing references)
		//IL_211e: Unknown result type (might be due to invalid IL or missing references)
		//IL_218a: Unknown result type (might be due to invalid IL or missing references)
		//IL_218f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2296: Unknown result type (might be due to invalid IL or missing references)
		//IL_2298: Unknown result type (might be due to invalid IL or missing references)
		//IL_232f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2331: Unknown result type (might be due to invalid IL or missing references)
		//IL_23ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_23b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_23b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_241e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2423: Unknown result type (might be due to invalid IL or missing references)
		//IL_252a: Unknown result type (might be due to invalid IL or missing references)
		//IL_252c: Unknown result type (might be due to invalid IL or missing references)
		//IL_25c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_25c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_26d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_26d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_2763: Unknown result type (might be due to invalid IL or missing references)
		//IL_2765: Unknown result type (might be due to invalid IL or missing references)
		//IL_27fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_2800: Unknown result type (might be due to invalid IL or missing references)
		//IL_2801: Unknown result type (might be due to invalid IL or missing references)
		//IL_2887: Unknown result type (might be due to invalid IL or missing references)
		//IL_288c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2966: Unknown result type (might be due to invalid IL or missing references)
		//IL_2968: Unknown result type (might be due to invalid IL or missing references)
		//IL_29f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_29f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a94: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a95: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b20: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bfc: Unknown result type (might be due to invalid IL or missing references)
		//IL_2cb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2cbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_2dcd: Unknown result type (might be due to invalid IL or missing references)
		//IL_2dcf: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e49: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ec9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ece: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ecf: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f52: Unknown result type (might be due to invalid IL or missing references)
		//IL_3061: Unknown result type (might be due to invalid IL or missing references)
		//IL_3063: Unknown result type (might be due to invalid IL or missing references)
		//IL_30dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_30df: Unknown result type (might be due to invalid IL or missing references)
		//IL_315d: Unknown result type (might be due to invalid IL or missing references)
		//IL_3162: Unknown result type (might be due to invalid IL or missing references)
		//IL_3163: Unknown result type (might be due to invalid IL or missing references)
		//IL_31e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_31e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e13: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e15: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e96: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f08: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_182b: Unknown result type (might be due to invalid IL or missing references)
		//IL_182d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1852: Unknown result type (might be due to invalid IL or missing references)
		//IL_1854: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_203a: Unknown result type (might be due to invalid IL or missing references)
		//IL_203f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2040: Unknown result type (might be due to invalid IL or missing references)
		//IL_2073: Unknown result type (might be due to invalid IL or missing references)
		//IL_2078: Unknown result type (might be due to invalid IL or missing references)
		//IL_2079: Unknown result type (might be due to invalid IL or missing references)
		//IL_20c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_20ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_189d: Unknown result type (might be due to invalid IL or missing references)
		//IL_189f: Unknown result type (might be due to invalid IL or missing references)
		//IL_18c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_18c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_14e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_14f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_21bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_21be: Unknown result type (might be due to invalid IL or missing references)
		//IL_14aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_14af: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_21f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_2230: Unknown result type (might be due to invalid IL or missing references)
		//IL_2232: Unknown result type (might be due to invalid IL or missing references)
		//IL_1918: Unknown result type (might be due to invalid IL or missing references)
		//IL_191d: Unknown result type (might be due to invalid IL or missing references)
		//IL_225f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2261: Unknown result type (might be due to invalid IL or missing references)
		//IL_22ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_22d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_22d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_235d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2362: Unknown result type (might be due to invalid IL or missing references)
		//IL_160e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1610: Unknown result type (might be due to invalid IL or missing references)
		//IL_1972: Unknown result type (might be due to invalid IL or missing references)
		//IL_1974: Unknown result type (might be due to invalid IL or missing references)
		//IL_23f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_23f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_2450: Unknown result type (might be due to invalid IL or missing references)
		//IL_2452: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1644: Unknown result type (might be due to invalid IL or missing references)
		//IL_1649: Unknown result type (might be due to invalid IL or missing references)
		//IL_24f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_24f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_2562: Unknown result type (might be due to invalid IL or missing references)
		//IL_2567: Unknown result type (might be due to invalid IL or missing references)
		//IL_2568: Unknown result type (might be due to invalid IL or missing references)
		//IL_259b: Unknown result type (might be due to invalid IL or missing references)
		//IL_25a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_25a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_25f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_25f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2640: Unknown result type (might be due to invalid IL or missing references)
		//IL_2645: Unknown result type (might be due to invalid IL or missing references)
		//IL_2646: Unknown result type (might be due to invalid IL or missing references)
		//IL_2684: Unknown result type (might be due to invalid IL or missing references)
		//IL_2686: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a52: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a57: Unknown result type (might be due to invalid IL or missing references)
		//IL_15d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_270a: Unknown result type (might be due to invalid IL or missing references)
		//IL_270f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2710: Unknown result type (might be due to invalid IL or missing references)
		//IL_2741: Unknown result type (might be due to invalid IL or missing references)
		//IL_2746: Unknown result type (might be due to invalid IL or missing references)
		//IL_2791: Unknown result type (might be due to invalid IL or missing references)
		//IL_2796: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa2: Unknown result type (might be due to invalid IL or missing references)
		//IL_27c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_27c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ac7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ac9: Unknown result type (might be due to invalid IL or missing references)
		//IL_28b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_28bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1693: Unknown result type (might be due to invalid IL or missing references)
		//IL_1698: Unknown result type (might be due to invalid IL or missing references)
		//IL_1699: Unknown result type (might be due to invalid IL or missing references)
		//IL_2918: Unknown result type (might be due to invalid IL or missing references)
		//IL_291a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b20: Unknown result type (might be due to invalid IL or missing references)
		//IL_2937: Unknown result type (might be due to invalid IL or missing references)
		//IL_2939: Unknown result type (might be due to invalid IL or missing references)
		//IL_299e: Unknown result type (might be due to invalid IL or missing references)
		//IL_29a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_29a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ae7: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a25: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_16cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_16cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a57: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a59: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b75: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b77: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ae4: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ae9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2aea: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ba5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1baa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bab: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bac: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bae: Unknown result type (might be due to invalid IL or missing references)
		//IL_1548: Unknown result type (might be due to invalid IL or missing references)
		//IL_154d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_2bcd: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c32: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c37: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c38: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c69: Unknown result type (might be due to invalid IL or missing references)
		//IL_2c6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ceb: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ced: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c20: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c25: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c26: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d65: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d67: Unknown result type (might be due to invalid IL or missing references)
		//IL_172e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1733: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d95: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e05: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e77: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c90: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c92: Unknown result type (might be due to invalid IL or missing references)
		//IL_1750: Unknown result type (might be due to invalid IL or missing references)
		//IL_1752: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f21: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f81: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cea: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cef: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cf0: Unknown result type (might be due to invalid IL or missing references)
		//IL_2fb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_2fb8: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ff9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ffb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d21: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d26: Unknown result type (might be due to invalid IL or missing references)
		//IL_3099: Unknown result type (might be due to invalid IL or missing references)
		//IL_309e: Unknown result type (might be due to invalid IL or missing references)
		//IL_309f: Unknown result type (might be due to invalid IL or missing references)
		//IL_310b: Unknown result type (might be due to invalid IL or missing references)
		//IL_3110: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d70: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d72: Unknown result type (might be due to invalid IL or missing references)
		//IL_312d: Unknown result type (might be due to invalid IL or missing references)
		//IL_312f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d97: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d99: Unknown result type (might be due to invalid IL or missing references)
		//IL_3213: Unknown result type (might be due to invalid IL or missing references)
		//IL_3215: Unknown result type (might be due to invalid IL or missing references)
		//IL_179c: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_324a: Unknown result type (might be due to invalid IL or missing references)
		//IL_324c: Unknown result type (might be due to invalid IL or missing references)
		//IL_328d: Unknown result type (might be due to invalid IL or missing references)
		//IL_328f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1df1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1df6: Unknown result type (might be due to invalid IL or missing references)
		//IL_32f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_32f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_32bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_32c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_32c3: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val3 = default(Vector3);
		RaycastHit val2 = default(RaycastHit);
		GameObject val26 = default(GameObject);
		Vector3 val = default(Vector3);
		Quaternion rotation = default(Quaternion);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301804;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 + (0 << 1) >> 0 << 0) + 0 << (0 ^ 0) << 0) - 0)) % 187)
				{
				case 169u:
					break;
				default:
					return;
				case 171u:
					num = (int)((((num2 + 2033661409) ^ 0xA3F29254u) - 0 << 0) - 0) >> 0;
					continue;
				case 85u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -1512602278) ^ -668474373) >> 0 << 0) + 0 << 0;
					continue;
				case 83u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = (((int)num2 + -1792847307) ^ -935858320) - 0 + 0 + 0 - 0;
					continue;
				case 116u:
					num = ((((int)num2 + -1797063024) ^ -1458184954) >> 0 >> 0 << 0) ^ 0;
					continue;
				case 143u:
				{
					Quaternion rotation32 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((((int)num2 + -2125168122) ^ -913356408) << 0) ^ 0) - 0 << 0;
					continue;
				}
				case 0u:
					val26 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((((int)num2 + -578576915) ^ 0x8C94F61) + 0) ^ 0 ^ 0) >> 0;
					continue;
				case 66u:
					num = ((int)((num2 + 2046147961) ^ 0xED67C34Fu) >> 0 << 0 << 0) ^ 0;
					continue;
				case 76u:
					num = (((((int)num2 + -721027220) ^ 0x54A0C034) >> 0 >> 0) - 0) ^ 0;
					continue;
				case 114u:
					val26.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (int)((((num2 + 2009414705) ^ 0x837799D9u) - 0) ^ 0 ^ 0) >> 0;
					continue;
				case 94u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쐔쐃쐚쐚쐓쐂쐦쐄쐓쐐쐗쐔", 2088813686, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -671533532) ^ -1791264742) >> 0) + 0) ^ 0) + 0;
					continue;
				case 103u:
				{
					Quaternion rotation31 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)(((num2 + 1756065016) ^ 0x8614D3B3u) - 0 << 0) >> 0) - 0;
					continue;
				}
				case 141u:
					num = (int)(((num2 + 2036453601) ^ 0x9FDBE982u) - 0 + 0 << 0) >> 0;
					continue;
				case 125u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -1212076717) ^ -1752309609) - 0) ^ 0) + 0 + 0;
					continue;
				case 134u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("悯悸悡悡您悹悝悿您悫悬悯", 1325621453, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -902129046) ^ 0x35BDADC8) >> 0 >> 0 >> 0) - 0;
					continue;
				case 1u:
					val26.transform.position = ((RaycastHit)(ref val2)).point;
					num = ((((int)num2 + -510636312) ^ -525039295) + 0 << 0 << 0) ^ 0;
					continue;
				case 153u:
				{
					Quaternion rotation30 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((((int)num2 + -1174313155) ^ -658852476) << 0) ^ 0) - 0 >> 0;
					continue;
				}
				case 162u:
				{
					Vector3 val35 = val3;
					num = ((((int)num2 + -1930958370) ^ -1459549717) + 0 + 0 >> 0) + 0;
					continue;
				}
				case 64u:
					num = ((((int)num2 + -147622667) ^ 0x5B2C02C1) + 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 180u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((((num2 + 1980886757) ^ 0xE3CBD1B0u ^ 0) + 0) ^ 0) + 0);
					continue;
				case 63u:
				{
					Quaternion rotation29 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((num2 + 331570234) ^ 0x51D61B36 ^ 0) + 0 - 0 - 0);
					continue;
				}
				case 74u:
					Object.Destroy((Object)(object)val26.GetComponent<BoxCollider>());
					num = (int)(((num2 + 774264733) ^ 0xCB0CF7EEu) + 0 - 0 << 0) >> 0;
					continue;
				case 69u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꏗꏀꏙꏙꏐꏁꏥꏇꏐꏓꏔꏗ", 1060283317, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((((num2 + 175265832) ^ 0x327FC2EA) << 0) ^ 0) + 0) ^ 0);
					continue;
				case 72u:
				{
					Vector3 val34 = val3;
					num = (((int)(((num2 + 136635871) ^ 0x7842BBF5) << 0) >> 0) ^ 0) - 0;
					continue;
				}
				case 2u:
					num = (((int)(((num2 + 549565928) ^ 0x2C5E415C) << 0) >> 0) - 0) ^ 0;
					continue;
				case 79u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﰐﰇﰞﰞﰗﰆﰢﰀﰗﰔﰓﰐ", 1857813618, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -2034261714) ^ -876322471 ^ 0) + 0 << 0) - 0;
					continue;
				case 82u:
				{
					Vector3 val33 = val3;
					num = ((((int)num2 + -425433458) ^ 0x3E8FF86A) << 0 << 0) + 0 + 0;
					continue;
				}
				case 92u:
					Object.Destroy((Object)(object)val26.GetComponent<Rigidbody>());
					num = (int)(((((num2 + 478874001) ^ 0x12AC15A1) << 0) - 0) ^ 0 ^ 0);
					continue;
				case 88u:
				{
					Quaternion rotation28 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)((num2 + 1330271324) ^ 0x77B9C780 ^ 0) >> 0 << 0) ^ 0;
					continue;
				}
				case 91u:
					num = ((((int)num2 + -536432448) ^ -713920634) >> 0) - 0 - 0 + 0;
					continue;
				case 101u:
					num = (((int)num2 + -1525641837) ^ 0x4617F029 ^ 0) << 0 << 0 >> 0;
					continue;
				case 97u:
				{
					Vector3 val32 = val3;
					num = ((((int)num2 + -426114078) ^ 0x4C7BC529) + 0 - 0 >> 0) - 0;
					continue;
				}
				case 100u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -534758591) ^ 0x676ED49B) + 0 - 0 >> 0) - 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val26.GetComponent<Collider>());
					num = (int)((((num2 + 703715978) ^ 0x11526807) << 0) + 0 - 0 - 0);
					continue;
				case 106u:
					num = (int)(((num2 + 1844406723) ^ 0x435D33E3) - 0 - 0 + 0 + 0);
					continue;
				case 109u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䆢䆵䆬䆬䆥䆴䆐䆲䆥䆦䆡䆢", 1466384832, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -252422569) ^ 0x1CE3ABF1) + 0 - 0 >> 0) ^ 0;
					continue;
				case 113u:
				{
					Quaternion rotation27 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)((num2 + 1590229884) ^ 0xDA9AABD9u) >> 0) + 0 + 0 << 0;
					continue;
				}
				case 123u:
					num = ((((int)num2 + -1244482502) ^ 0x28FC252) << 0 << 0 << 0) - 0;
					continue;
				case 119u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("بؿئئدؾ\u061aظدجثب", 116262474, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -703462791) ^ 0x47FDAC01) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 122u:
				{
					Vector3 val31 = val3;
					num = (((((int)num2 + -833145865) ^ -1579483502) - 0 << 0) ^ 0) + 0;
					continue;
				}
				case 132u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val26, Color.magenta);
					num = (int)(((((num2 + 727990850) ^ 0x4E2B60A5) + 0 << 0) ^ 0) + 0);
					continue;
				case 128u:
				{
					Quaternion rotation26 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1005255492) ^ 0x8265FA5 ^ 0) + 0 << 0) - 0;
					continue;
				}
				case 131u:
					num = (((int)num2 + -1004139048) ^ 0x392460B ^ 0) - 0 + 0 << 0;
					continue;
				case 4u:
					num = (((((int)num2 + -725770167) ^ -2057649648) + 0 + 0) ^ 0) >> 0;
					continue;
				case 137u:
				{
					Vector3 val30 = val3;
					num = ((((int)num2 + -983359010) ^ -519425985 ^ 0) << 0) - 0 << 0;
					continue;
				}
				case 140u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((num2 + 166794707) ^ 0x3DC3300D) + 0 - 0 << 0) >> 0;
					continue;
				case 151u:
					Object.Destroy((Object)(object)val26, Time.deltaTime);
					num = (((int)(((num2 + 227301697) ^ 0x4B482391) << 0) >> 0) ^ 0) - 0;
					continue;
				case 146u:
					num = (((((int)num2 + -1829463527) ^ -954145789) + 0 >> 0) - 0) ^ 0;
					continue;
				case 150u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)((((num2 + 1318322646) ^ 0xE74E89DDu ^ 0) + 0 + 0) ^ 0);
					continue;
				case 160u:
					num = (int)(((num2 + 57433052) ^ 0x53C98862) + 0 + 0 + 0 - 0);
					continue;
				case 156u:
					num = ((((int)num2 + -1793899917) ^ -708342399) >> 0) - 0 + 0 >> 0;
					continue;
				case 159u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udba8\udbbf\udba6\udba6\udbaf\udbbe\udb9a\udbb8\udbaf\udbac\udbab\udba8", 1572592586, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1630403934) ^ -613486988) >> 0) ^ 0) - 0 - 0;
					continue;
				case 5u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = ((((int)num2 + -930134712) ^ 0x73083927) >> 0 >> 0 << 0) + 0;
					continue;
				case 165u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -887094261) ^ -516083037) << 0) ^ 0) + 0 << 0;
					continue;
				case 168u:
				{
					Quaternion rotation25 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1670650964) ^ -181070725) - 0 - 0 >> 0) - 0;
					continue;
				}
				case 178u:
					flag = triggerButtonDown;
					num = (((int)((num2 + 1578669452) ^ 0xD8DFE9B0u) >> 0) + 0 << 0) - 0;
					continue;
				case 174u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("호혯혶혶혿혮혊혨혿혼혻호", 1400034906, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 2070337696) ^ 0x94AFB5A2u) + 0 << 0) + 0) >> 0;
					continue;
				case 177u:
				{
					Vector3 val29 = val3;
					num = (int)((((num2 + 2106083184) ^ 0xB8B753DCu) - 0 + 0) ^ 0 ^ 0);
					continue;
				}
				case 61u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 755975233;
						num4 = num3;
					}
					else
					{
						num3 = 1768633414;
						num4 = num3;
					}
					num = (((num3 << 0) - 0) ^ ((int)num2 + -371167956)) + 0 + 0 >> 0 << 0;
					continue;
				}
				case 183u:
				{
					Quaternion rotation24 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((((num2 + 2078330715) ^ 0xDE412443u) + 0 + 0) ^ 0) + 0);
					continue;
				}
				case 62u:
				{
					Vector3 val28 = val3;
					num = (int)((((num2 + 1976826451) ^ 0x8700B1A4u) + 0 + 0 - 0) ^ 0);
					continue;
				}
				case 6u:
					num = (int)((num2 + 1657452078) ^ 0xDD164F37u) >> 0 >> 0 >> 0 << 0;
					continue;
				case 20u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uedf2\uede5\uedfc\uedfc\uedf5\uede4\uedc0\uede2\uedf5\uedf6\uedf1\uedf2", 2117660048, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1380210500) ^ 0x7F994D42 ^ 0) - 0 >> 0 >> 0;
					continue;
				case 65u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((int)((num2 + 1623984847) ^ 0xD765778Fu ^ 0) >> 0 << 0) + 0;
					continue;
				case 67u:
					num = (int)(((num2 + 233036639) ^ 0x7BA3257B) << 0 << 0 << 0) >> 0;
					continue;
				case 21u:
				{
					Vector3 val27 = val3;
					num = (int)(((((num2 + 1592150242) ^ 0xBF8413A3u) << 0) ^ 0 ^ 0) << 0);
					continue;
				}
				case 68u:
				{
					Quaternion rotation23 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1963884100) ^ -2103289337) >> 0 << 0) + 0 >> 0;
					continue;
				}
				case 70u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val26, Color.green);
					num = (int)((((num2 + 1268168873) ^ 0x32ACB069 ^ 0 ^ 0) << 0) + 0);
					continue;
				case 22u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -525873465) ^ 0x20B67EC5) << 0 >> 0) ^ 0 ^ 0;
					continue;
				case 71u:
					num = (int)((((num2 + 824529987) ^ 0x2BA47587) + 0 << 0 << 0) - 0);
					continue;
				case 7u:
					num = (int)(((num2 + 915295779) ^ 0xF3850397u ^ 0 ^ 0) + 0) >> 0;
					continue;
				case 73u:
				{
					Quaternion rotation22 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 1648123118) ^ 0x9211FEC6u) + 0 << 0) + 0 + 0);
					continue;
				}
				case 23u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("臶臡臸臸臱臠臄臦臱臲臵臶", 2003534228, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -302437183) ^ 0x376726D7) + 0) ^ 0) + 0) ^ 0;
					continue;
				case 75u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -1597358327) ^ 0x388FA8DC) << 0) + 0 - 0 + 0;
					continue;
				case 77u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((int)num2 + -1447993658) ^ 0x1E0FB0CA ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 24u:
				{
					Vector3 val25 = val3;
					num = (((int)num2 + -728915637) ^ 0x331597E0) >> 0 << 0 >> 0 >> 0;
					continue;
				}
				case 78u:
				{
					Quaternion rotation21 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 1258593551) ^ 0x7FDA9324) - 0) ^ 0 ^ 0) >> 0;
					continue;
				}
				case 80u:
					num = ((((int)num2 + -2053882348) ^ -2110628151) + 0 << 0) ^ 0 ^ 0;
					continue;
				case 25u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -569852220) ^ 0x46D779F3) >> 0) ^ 0) - 0 >> 0;
					continue;
				case 81u:
					num = ((((int)num2 + -2010711270) ^ -1030964107) >> 0) - 0 + 0 + 0;
					continue;
				case 8u:
					val = val3;
					num = (int)(((((num2 + 333842385) ^ 0x4A40D0BC ^ 0) << 0) - 0) ^ 0);
					continue;
				case 26u:
				{
					Quaternion rotation20 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 888142732) ^ 0x3A93F79B) - 0 + 0) ^ 0) >> 0;
					continue;
				}
				case 84u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("춶춡춸춸춱춠춄춦춱춲춵춶", 1292160468, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1768646571) ^ 0x4597AE0E) + 0 << 0 >> 0) ^ 0;
					continue;
				case 86u:
					rotation = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -2084020147) ^ -365270938) + 0 << 0) - 0 >> 0;
					continue;
				case 27u:
					num = (((int)(((num2 + 905756482) ^ 0x4F82343F) + 0) >> 0) ^ 0) >> 0;
					continue;
				case 87u:
				{
					Vector3 val24 = val3;
					num = ((((int)num2 + -919965348) ^ -1005081154 ^ 0) >> 0) + 0 >> 0;
					continue;
				}
				case 89u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("帐帇帞帞帗帆帢帀帗帔帓帐", 1332043378, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -125279861) ^ 0x5BA0E5AB) << 0) ^ 0) << 0 >> 0;
					continue;
				case 28u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("簗簀簙簙簐簁簥簇簐簓簔簗", 145980533, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 474886867) ^ 0x2899EAF8) << 0 << 0 << 0) ^ 0);
					continue;
				case 90u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((((num2 + 1603814050) ^ 0x7BCC24CC ^ 0) + 0) ^ 0) + 0);
					continue;
				case 9u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -1646096307) ^ -1707033172 ^ 0) << 0) ^ 0) << 0;
					continue;
				case 29u:
				{
					Vector3 val23 = val3;
					num = (int)((((num2 + 1956291900) ^ 0xF5FA5F85u ^ 0) - 0) ^ 0 ^ 0);
					continue;
				}
				case 93u:
				{
					Quaternion rotation19 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)((num2 + 1413811447) ^ 0xCF1A0BB2u ^ 0) >> 0 >> 0) ^ 0;
					continue;
				}
				case 95u:
					num = (int)(((((num2 + 534300211) ^ 0x5AF5C127) << 0 << 0) ^ 0) << 0);
					continue;
				case 30u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -813048556) ^ 0x1EA71459) >> 0 >> 0 >> 0) + 0;
					continue;
				case 96u:
					num = (((int)num2 + -1385468635) ^ 0x28FB9B93) + 0 << 0 << 0 << 0;
					continue;
				case 98u:
				{
					Vector3 val22 = val3;
					num = ((((((int)num2 + -1762539656) ^ -1343527250) + 0) ^ 0) >> 0) ^ 0;
					continue;
				}
				case 31u:
				{
					Quaternion rotation18 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((num2 + 1356560142) ^ 0xBEA657CCu) >> 0 << 0 >> 0 << 0;
					continue;
				}
				case 99u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ቇቐ\u1249\u1249ቀቑት\u1257ቀቃቄቇ", 924520997, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 1510536308) ^ 0xDF674853u) >> 0) + 0 + 0 << 0;
					continue;
				case 10u:
				{
					Quaternion rotation17 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -609303712) ^ 0x5B113BD0 ^ 0) << 0) + 0 >> 0;
					continue;
				}
				case 32u:
					num = (int)(((num2 + 1772381938) ^ 0xA21C7403u) + 0 - 0 - 0 - 0);
					continue;
				case 102u:
				{
					Vector3 val21 = val3;
					num = (int)(((num2 + 412765985) ^ 0x1934F506 ^ 0) << 0 << 0 << 0);
					continue;
				}
				case 104u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꑅꑒꑋꑋꑂꑓꑷꑕꑂꑁꑆꑅ", 1318495271, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -249395649) ^ 0x7AE0FAAD) + 0 << 0) - 0 << 0;
					continue;
				case 33u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("诎诙诀诀诉诘诼诞诉诊词诎", 1342016428, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -460736008) ^ 0x13680BFD ^ 0 ^ 0) - 0 + 0;
					continue;
				case 105u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((((num2 + 1008699021) ^ 0x5A10D4F6 ^ 0) << 0) ^ 0) + 0);
					continue;
				case 107u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((int)num2 + -1984784162) ^ -1438649411 ^ 0) + 0 >> 0 >> 0;
					continue;
				case 34u:
				{
					Vector3 val20 = val3;
					num = (int)(((num2 + 1222861305) ^ 0x50234BB7 ^ 0) + 0 - 0) >> 0;
					continue;
				}
				case 108u:
				{
					Quaternion rotation16 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((((num2 + 1451102922) ^ 0x8F582EF5u) << 0) - 0 << 0) + 0);
					continue;
				}
				case 111u:
					num = ((((int)num2 + -362126171) ^ 0x47777E76) << 0) + 0 << 0 << 0;
					continue;
				case 110u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -1691656707) ^ -172996021) - 0 << 0 << 0) - 0;
					continue;
				case 35u:
					num = ((int)(((num2 + 1888519284) ^ 0xE1442E7Au) - 0 - 0) >> 0) ^ 0;
					continue;
				case 112u:
				{
					Vector3 val19 = val3;
					num = (((((int)num2 + -526380072) ^ 0x17E3BFD4) << 0) ^ 0) << 0 >> 0;
					continue;
				}
				case 11u:
				{
					Vector3 val18 = val3;
					num = ((int)((num2 + 1923808797) ^ 0x8E2F696Du) >> 0) + 0 >> 0 >> 0;
					continue;
				}
				case 36u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("궈궟궆궆궏궞궺궘궏권궋궈", 2125639146, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)(((num2 + 1117249668) ^ 0xFBCE061Fu) << 0) >> 0 << 0) + 0;
					continue;
				case 115u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)((num2 + 811100468) ^ 0xA8068C35u ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 117u:
				{
					Quaternion rotation15 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)(((num2 + 1709401791) ^ 0xC39860FAu) - 0) >> 0 << 0) - 0;
					continue;
				}
				case 37u:
				{
					Vector3 val17 = val3;
					num = (((int)((num2 + 585300927) ^ 0xF7D003D4u ^ 0) >> 0) ^ 0) + 0;
					continue;
				}
				case 118u:
				{
					Quaternion rotation14 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((((num2 + 831498992) ^ 0xED65D941u) + 0 - 0) ^ 0) << 0);
					continue;
				}
				case 120u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udc43\udc54\udc4d\udc4d\udc44\udc55\udc71\udc53\udc44\udc47\udc40\udc43", 354868257, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1544369472) ^ 0x3C494F43 ^ 0 ^ 0) << 0 >> 0;
					continue;
				case 38u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((int)num2 + -573406624) ^ 0x32FF58D) + 0 << 0 << 0 >> 0;
					continue;
				case 121u:
					num = (((int)num2 + -1613484753) ^ -879906241 ^ 0) - 0 - 0 + 0;
					continue;
				case 12u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -1233923822) ^ -1587770044) << 0) ^ 0 ^ 0) - 0;
					continue;
				case 39u:
				{
					Quaternion rotation13 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)num2 + -252277378) ^ 0x65BD00B3 ^ 0) - 0 + 0 >> 0;
					continue;
				}
				case 124u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udebd\udeaa\udeb3\udeb3\udeba\udeab\ude8f\udead\udeba\udeb9\udebe\udebd", 1795808991, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1636505395) ^ -2139200604) + 0) ^ 0) << 0 >> 0;
					continue;
				case 126u:
					num = (((((int)num2 + -1525771312) ^ -505671574 ^ 0) << 0) - 0) ^ 0;
					continue;
				case 40u:
					num = ((((int)num2 + -1668373170) ^ 0x367CA662) + 0 + 0 - 0) ^ 0;
					continue;
				case 127u:
				{
					Vector3 val16 = val3;
					num = ((((((int)num2 + -964312426) ^ -2126337538) >> 0) - 0) ^ 0) >> 0;
					continue;
				}
				case 129u:
				{
					Vector3 val15 = val3;
					num = ((((int)num2 + -246849441) ^ -1538153075) << 0) - 0 - 0 >> 0;
					continue;
				}
				case 41u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䉺䉭䉴䉴䉽䉬䉈䉪䉽䉾䉹䉺", 397951512, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1766777736) ^ -318471104) - 0 << 0 >> 0) + 0;
					continue;
				case 130u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((num2 + 670432471) ^ 0x3658DBF1 ^ 0 ^ 0) + 0 + 0);
					continue;
				case 13u:
				{
					Quaternion rotation12 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)num2 + -1671020797) ^ -341734475) + 0 >> 0 << 0 >> 0;
					continue;
				}
				case 42u:
				{
					Vector3 val14 = val3;
					num = ((((int)num2 + -1802410233) ^ -2077916191) - 0 >> 0 >> 0) ^ 0;
					continue;
				}
				case 133u:
				{
					Quaternion rotation11 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1892315867) ^ -1998461440) << 0) ^ 0 ^ 0 ^ 0;
					continue;
				}
				case 135u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("腸腯腶腶腿腮腊腨腿腼腻腸", 1470529818, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((((num2 + 1499478218) ^ 0x2F945E3E) - 0) ^ 0) + 0) ^ 0);
					continue;
				case 43u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((((int)num2 + -832555601) ^ 0x4CB6ABB) << 0) - 0 - 0) ^ 0;
					continue;
				case 136u:
					num = (((((int)num2 + -1809641322) ^ -1543599570) << 0) ^ 0 ^ 0) + 0;
					continue;
				case 138u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)((num2 + 1578353066) ^ 0xC0515529u) >> 0) - 0) ^ 0) >> 0;
					continue;
				case 44u:
				{
					Quaternion rotation10 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((((num2 + 1799726897) ^ 0xA4F9758Fu) - 0 << 0) - 0) ^ 0);
					continue;
				}
				case 139u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueb83\ueb94\ueb8d\ueb8d\ueb84\ueb95\uebb1\ueb93\ueb84\ueb87\ueb80\ueb83", 1580264417, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1234277106) ^ 0x176984B6) << 0) >> 0 << 0 >> 0;
					continue;
				case 14u:
					num = ((((int)num2 + -145600039) ^ 0xE2765F2) >> 0) - 0 + 0 + 0;
					continue;
				case 45u:
					num = (int)((((num2 + 1663250817) ^ 0x90ED8FADu) - 0 << 0) - 0 - 0);
					continue;
				case 142u:
				{
					Vector3 val13 = val3;
					num = ((int)((((num2 + 517106494) ^ 0x2B0B01AB) + 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 144u:
				{
					Vector3 val12 = val3;
					num = (int)((((num2 + 318542327) ^ 0x669A441E ^ 0) + 0) ^ 0 ^ 0);
					continue;
				}
				case 46u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쉼쉫쉲쉲쉻쉪쉎쉬쉻쉸쉿쉼", 385466910, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1709470886) ^ -83530567 ^ 0) >> 0 << 0 << 0;
					continue;
				case 145u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -689787351) ^ 0x45A6761F ^ 0) << 0) + 0 << 0;
					continue;
				case 148u:
				{
					Quaternion rotation9 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 669023832) ^ 0x4380EA91) - 0 - 0) ^ 0) >> 0;
					continue;
				}
				case 147u:
				{
					Vector3 val11 = val3;
					num = (((int)num2 + -272039883) ^ 0x64EFA73E) - 0 - 0 - 0 >> 0;
					continue;
				}
				case 47u:
				{
					Quaternion rotation8 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((num2 + 151056236) ^ 0x6C313) - 0 + 0 << 0) >> 0;
					continue;
				}
				case 149u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("욂욕욌욌욅요우욒욅욆욁욂", 970049248, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1731769930) ^ 0x9F7870E6u ^ 0) + 0 - 0 + 0);
					continue;
				case 15u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﳸﳯﳶﳶﳿﳮﳊﳨﳿﳼﳻﳸ", 1671822490, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -471734760) ^ 0x12A2337D) << 0) + 0 - 0 >> 0;
					continue;
				case 48u:
					num = (((int)num2 + -259853790) ^ 0x429384FE) + 0 + 0 << 0 >> 0;
					continue;
				case 152u:
				{
					Vector3 val10 = val3;
					num = (((((int)num2 + -2070036447) ^ -63970729) >> 0 << 0) + 0) ^ 0;
					continue;
				}
				case 154u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((int)num2 + -1181284747) ^ 0x73A4FDC ^ 0) << 0 >> 0 >> 0;
					continue;
				case 49u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("瞋瞜瞅瞅瞌瞝瞹瞛瞌瞏瞈瞋", 1557493737, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -2115753654) ^ -782592219 ^ 0) << 0) ^ 0 ^ 0;
					continue;
				case 155u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -1172176595) ^ 0x3FE84E34) + 0 + 0 << 0) ^ 0;
					continue;
				case 157u:
					num = ((((int)num2 + -2098026248) ^ -784556315 ^ 0) >> 0) - 0 - 0;
					continue;
				case 50u:
				{
					Vector3 val9 = val3;
					num = (((((int)num2 + -1060473554) ^ -1680174566) >> 0) + 0 << 0) ^ 0;
					continue;
				}
				case 158u:
				{
					Quaternion rotation7 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)num2 + -1165053593) ^ 0x470286B2) << 0 << 0 >> 0 >> 0;
					continue;
				}
				case 16u:
				{
					Vector3 val8 = val3;
					num = ((((int)num2 + -1491064213) ^ -1681386300) - 0 >> 0) + 0 - 0;
					continue;
				}
				case 51u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((((int)num2 + -870679218) ^ 0x222D5A9A ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 161u:
					num = ((int)((num2 + 988823419) ^ 0x33EDC5A2) >> 0 >> 0) + 0 >> 0;
					continue;
				case 163u:
				{
					Quaternion rotation6 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((((int)num2 + -1762622851) ^ -1428710503 ^ 0) >> 0) ^ 0) + 0;
					continue;
				}
				case 52u:
				{
					Quaternion rotation5 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 1929400563) ^ 0xA26B1C06u) + 0 << 0) + 0) >> 0;
					continue;
				}
				case 164u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("熑熆熟熟熖熇熣熁熖熕熒熑", 1621586419, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1912151594) ^ -211754064) + 0 - 0 << 0 >> 0;
					continue;
				case 166u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u0acc\u0adb\u0ac2\u0ac2\u0acb\u0ada\u0afe\u0adc\u0acb\u0ac8\u0acf\u0acc", 1399065262, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 1207938988) ^ 0x8450D8E2u) - 0 << 0) + 0 - 0);
					continue;
				case 53u:
					num = (((int)num2 + -1391190576) ^ -356183009) + 0 - 0 >> 0 << 0;
					continue;
				case 167u:
				{
					Vector3 val7 = val3;
					num = (int)(((num2 + 1330157026) ^ 0x123E5BF5 ^ 0 ^ 0) + 0 - 0);
					continue;
				}
				case 17u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = ((int)((num2 + 754578745) ^ 0x1A6A0938) >> 0 << 0 << 0) - 0;
					continue;
				case 54u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鑌鑛鑂鑂鑋鑚鑾鑜鑋鑈鑏鑌", 978752558, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((((num2 + 1937346005) ^ 0x83D7F634u) << 0) - 0) >> 0) - 0;
					continue;
				case 170u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (((int)num2 + -1574472783) ^ -353009156) + 0 << 0 << 0 << 0;
					continue;
				case 172u:
					num = (int)((((num2 + 2143573948) ^ 0x88587367u) + 0 << 0 << 0) + 0);
					continue;
				case 55u:
				{
					Vector3 val6 = val3;
					num = ((int)((num2 + 1287913612) ^ 0x85F13BFEu) >> 0 >> 0 << 0) ^ 0;
					continue;
				}
				case 173u:
				{
					Quaternion rotation4 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((int)(((num2 + 1915638162) ^ 0xA2A2B9B9u) - 0 + 0) >> 0) + 0;
					continue;
				}
				case 175u:
				{
					Vector3 val5 = val3;
					num = ((((int)num2 + -677348379) ^ 0x4433E44E ^ 0 ^ 0) + 0) ^ 0;
					continue;
				}
				case 56u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)(((num2 + 2006586017) ^ 0x2B4A8D58) - 0 - 0) >> 0 << 0;
					continue;
				case 176u:
					num = ((((int)num2 + -1235635079) ^ 0x51AD22CC) - 0 >> 0 >> 0) + 0;
					continue;
				case 18u:
				{
					Quaternion rotation3 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((num2 + 831933429) ^ 0xBC483F7Bu) - 0) ^ 0) >> 0 << 0;
					continue;
				}
				case 57u:
				{
					Quaternion rotation2 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)((num2 + 318586722) ^ 0x75CA259C) >> 0) - 0 - 0) ^ 0;
					continue;
				}
				case 179u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㾓㾄㾝㾝㾔㾅㾡㾃㾔㾗㾐㾓", 369901553, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 1756041711) ^ 0x48B4EF0D) - 0 << 0) ^ 0) + 0);
					continue;
				case 181u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᎏ᎘ᎁᎁᎈ᎙Ꮍ\u139fᎈᎋᎌᎏ", 1944720365, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 717746182) ^ 0x670ABA7C) - 0 << 0) ^ 0) << 0);
					continue;
				case 58u:
					num = (((int)num2 + -1208502361) ^ 0x141616C2) + 0 - 0 + 0 << 0;
					continue;
				case 182u:
				{
					Vector3 val4 = val3;
					num = (((int)((num2 + 274840809) ^ 0x6E0BE91B) >> 0) - 0 + 0) ^ 0;
					continue;
				}
				case 185u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val2)).point);
					num = (int)((((num2 + 934014962) ^ 0x68E073A) - 0 + 0 << 0) ^ 0);
					continue;
				case 184u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u1ddd\u1dca\u1dd3\u1dd3\u1dda\u1dcb\u1def\u1dcd\u1dda\u1dd9\u1dde\u1ddd", 172039615, true), val, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -31447238) ^ 0x3FACE99A ^ 0 ^ 0) << 0) ^ 0;
					continue;
				case 59u:
					num = ((int)(((num2 + 1901574653) ^ 0xCD3CD9C3u) - 0) >> 0) - 0 + 0;
					continue;
				case 186u:
					num = (((int)num2 + -1446364877) ^ -1535763787) >> 0 << 0 >> 0 << 0;
					continue;
				case 19u:
					num = (int)(((num2 + 600810435) ^ 0x922E07AFu) << 0) >> 0 >> 0 << 0;
					continue;
				case 60u:
					return;
				}
				break;
			}
		}
	}

	public Collider_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 + (0 >> 1) + 0 + 0 >> 0) + (0 << 1) + 0 << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) << 0 << 0 >> 0) + 0;
			}
		}
	}
}
