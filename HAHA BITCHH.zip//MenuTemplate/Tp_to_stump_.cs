using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class Tp_to_stump_
{
	public static void ferBKtpFrMUBMAclexRtpSutZdtjJbrBUeSkPLNEgqqhHgoOUVbvACanKYCGZgVqvsHHHSvsJnnZCnLSOEoOaWbsdFzQjhEauaLpzGhbzILnpbKxmJSvRhpzrpEcsEjCJnECBwsixmprkNcbUcEApjinKmYkcfIUzjEbxiVQqJXERYoDmChqaJnAerSoyigsEvSajaEMgOjFlDvMXuYzXsTQWeXfqHriDFavfotlXvjmzHoAVgqekGulCcefdzwzwabFDaGJaMBCjGqoPwkjqnYWkPT()
	{
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		MeshCollider current = default(MeshCollider);
		MeshCollider current2 = default(MeshCollider);
		bool flag3 = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301854;
			while (true)
			{
				int num7;
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ 0) >> 0 << 0 >> 0) ^ -0) >> 0) - 0)) % 7)
				{
				case 0u:
					break;
				case 1u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((((((int)num2 + -725091362) ^ 0x852858C) << 0) - 0) ^ 0) - 0;
					continue;
				case 2u:
					flag = triggerButtonDown;
					num = ((((int)num2 + -956687329) ^ -415052114) >> 0 << 0 << 0) + 0;
					continue;
				case 3u:
					if (flag)
					{
						num = (int)((num2 + 1345212153) ^ 0x7B8CB73B ^ 0) >> 0 << 0 << 0;
						continue;
					}
					goto IL_04d2;
				case 4u:
					num = (int)((((((num2 + 600520462) ^ 0x22720313) - 0) ^ 0) << 0) ^ 0);
					continue;
				case 5u:
					num = (((((int)num2 + -795116775) ^ -5259856) >> 0) ^ 0) + 0 - 0;
					continue;
				default:
					{
						IEnumerator<MeshCollider> enumerator = Resources.FindObjectsOfTypeAll<MeshCollider>().GetEnumerator();
						try
						{
							while (true)
							{
								IL_02cc:
								int num3;
								int num4;
								if (enumerator.MoveNext())
								{
									num3 = 1621957009;
									num4 = num3;
								}
								else
								{
									num3 = 2106842279;
									num4 = num3;
								}
								int num5 = ((num3 ^ 0) + 0 << 0) + 0;
								while (true)
								{
									switch ((num2 = (uint)((((num5 - 0 >> (0 >> 1)) ^ 0) << 0 << 0 >> (0 ^ 0)) - 0 - 0)) % 8)
									{
									case 0u:
										num5 = 1621957009;
										continue;
									default:
										goto end_IL_016a;
									case 1u:
										current = enumerator.Current;
										num5 = (0x661A46D2 ^ 0) - 0 + 0 - 0;
										continue;
									case 2u:
										num5 = ((((int)num2 + -1186296972) ^ 0x39F55A4D) + 0 + 0 >> 0) ^ 0;
										continue;
									case 3u:
										((Collider)current).enabled = false;
										num5 = (((((int)num2 + -1701687338) ^ -1788238587) + 0 >> 0) ^ 0) >> 0;
										continue;
									case 4u:
										num5 = (((int)num2 + -1219895373) ^ 0x12193A4A) + 0 + 0 >> 0 << 0;
										continue;
									case 5u:
										num5 = ((int)(((num2 + 900749756) ^ 0x18B55307) + 0) >> 0 << 0) + 0;
										continue;
									case 6u:
										break;
									case 7u:
										goto end_IL_016a;
									}
									goto IL_02cc;
									continue;
									end_IL_016a:
									break;
								}
								break;
							}
						}
						finally
						{
							if (enumerator != null)
							{
								while (true)
								{
									IL_02fb:
									int num6 = 1630399309;
									while (true)
									{
										switch ((num2 = (uint)(((((((num6 >> 0) + -0) ^ 0) << 0) - 0 >> -0) ^ 0) - 0)) % 4)
										{
										case 0u:
											break;
										default:
											goto end_IL_0300;
										case 1u:
											enumerator.Dispose();
											num6 = ((((int)num2 + -1395914388) ^ 0x636456AF) + 0 << 0) + 0 + 0;
											continue;
										case 2u:
											num6 = ((int)(((num2 + 1319775793) ^ 0xEA08AB4Cu) - 0 - 0) >> 0) + 0;
											continue;
										case 3u:
											goto end_IL_0300;
										}
										goto IL_02fb;
										continue;
										end_IL_0300:
										break;
									}
									break;
								}
							}
						}
						((Component)Player.Instance).transform.position = new Vector3(-66.4848f, 11.8871f, -82.6619f);
						goto IL_03be;
					}
					IL_04d2:
					num7 = ((2136399291 << 0) - 0 >> 0) + 0;
					goto IL_03c3;
					IL_03c3:
					while (true)
					{
						switch ((num2 = (uint)((((num7 ^ 0) << (0 ^ 0)) ^ 0) + 0 << 0 << 0 + 0 << 0) ^ 0u) % 7)
						{
						case 0u:
							break;
						case 1u:
							num7 = (int)((((num2 + 1047830633) ^ 0x543FB62) << 0 << 0) + 0 << 0);
							continue;
						case 2u:
							num7 = (int)(((((num2 + 830770635) ^ 0x99D47BA1u) - 0) ^ 0 ^ 0) - 0);
							continue;
						case 3u:
							return;
						case 4u:
							goto IL_04d2;
						case 5u:
							num7 = ((((int)((num2 + 337346832) ^ 0xD0FD1ECDu) >> 0) - 0) ^ 0) + 0;
							continue;
						default:
						{
							IEnumerator<MeshCollider> enumerator2 = Resources.FindObjectsOfTypeAll<MeshCollider>().GetEnumerator();
							try
							{
								while (true)
								{
									int num8;
									int num9;
									if (enumerator2.MoveNext())
									{
										num8 = 1945443956;
										num9 = num8;
									}
									else
									{
										num8 = 628054607;
										num9 = num8;
									}
									int num10 = (num8 + 0 + 0 << 0) + 0;
									while (true)
									{
										switch ((num2 = (uint)(((((((num10 - 0) ^ 0) + 0) ^ 0) + 0) ^ -0) << 0 << 0)) % 13)
										{
										case 0u:
											num10 = 1945443956;
											continue;
										default:
											return;
										case 1u:
											current2 = enumerator2.Current;
											num10 = (1394277627 << 0 >> 0) + 0 << 0;
											continue;
										case 2u:
											num10 = (int)(((((num2 + 1363915621) ^ 0xC8C47E2Du ^ 0) << 0) - 0) ^ 0);
											continue;
										case 3u:
											flag3 = !((Collider)current2).enabled;
											num10 = (int)(((num2 + 823506666) ^ 0xADE4710Du) + 0 + 0 - 0) >> 0;
											continue;
										case 4u:
											flag2 = !flag3;
											num10 = (((((int)num2 + -1504328649) ^ -299870832) >> 0) ^ 0) >> 0 >> 0;
											continue;
										case 5u:
										{
											int num11;
											int num12;
											if (!flag2)
											{
												num11 = 370445371;
												num12 = num11;
											}
											else
											{
												num11 = 415554151;
												num12 = num11;
											}
											num10 = (((num11 - 0 - 0) ^ ((int)num2 + -340251349)) + 0 >> 0) - 0 + 0;
											continue;
										}
										case 6u:
											num10 = (int)((((num2 + 733616138) ^ 0x75BB8BAB ^ 0) - 0 - 0) ^ 0);
											continue;
										case 12u:
											num10 = (int)(((((num2 + 360573015) ^ 0x161F617A ^ 0) + 0) ^ 0) - 0);
											continue;
										case 10u:
											break;
										case 7u:
											((Collider)current2).enabled = true;
											num10 = (1855391286 << 0) - 0 >> 0 >> 0;
											continue;
										case 8u:
											num10 = (((((int)num2 + -1403453257) ^ 0x680D9AD6) << 0) ^ 0 ^ 0) >> 0;
											continue;
										case 9u:
											num10 = (int)((((num2 + 293113464) ^ 0xF6152C2Fu) << 0) + 0 - 0 + 0);
											continue;
										case 11u:
											return;
										}
										break;
									}
								}
							}
							finally
							{
								if (enumerator2 != null)
								{
									while (true)
									{
										IL_07ea:
										int num13 = 1192903713;
										while (true)
										{
											switch ((num2 = (uint)((((num13 + 0 >> -0) - 0 - 0 << 0) - (0 >> 1) >> 0) + 0)) % 4)
											{
											case 0u:
												break;
											default:
												goto end_IL_07ef;
											case 1u:
												enumerator2.Dispose();
												num13 = (((((int)num2 + -837158652) ^ 0x73127CB3) + 0 - 0) ^ 0) + 0;
												continue;
											case 2u:
												num13 = ((((int)num2 + -1018728429) ^ 0x20D3D60E) >> 0 << 0) - 0 - 0;
												continue;
											case 3u:
												goto end_IL_07ef;
											}
											goto IL_07ea;
											continue;
											end_IL_07ef:
											break;
										}
										break;
									}
								}
							}
						}
						}
						break;
					}
					goto IL_03be;
					IL_03be:
					num7 = 660359988;
					goto IL_03c3;
				}
				break;
			}
		}
	}

	public Tp_to_stump_()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 << (0 << 1)) + 0) ^ 0) - 0 - (0 >> 1) - 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) - 0 >> 0) + 0 - 0;
			}
		}
	}
}
