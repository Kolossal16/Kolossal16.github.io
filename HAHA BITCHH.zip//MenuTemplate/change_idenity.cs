using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class change_idenity
{
	public static void FJNyuqwlbCfcWaJSWPVsqLEqbTBPNAfMbqvmXjOOkEpLycdAThrAKZJUfwxAOGyAwsaGFxUNbghLwSSYQaWFjEcbGAgAMnZEgOofbxUvmEyDRYxmEyKNKSrRq()
	{
		string text = default(string);
		int num8 = default(int);
		bool flag2 = default(bool);
		int num5 = default(int);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301831;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 >> -0) + 0 >> 0 >> 0) - -0 >> 0) ^ 0u) % 27)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("藓藛藆藝藘藘藕", 1529447828, true);
					num = ((((int)num2 + -1701687338) ^ 0x3698D1B4 ^ 0) >> 0 >> 0) + 0;
					continue;
				case 2u:
					num8 = 0;
					num = ((((int)num2 + -1219895373) ^ -158135028) - 0 << 0 >> 0) + 0;
					continue;
				case 3u:
					num = (int)((((num2 + 900749756) ^ 0x18D6996D) + 0 << 0 << 0) - 0);
					continue;
				case 4u:
					num = (0x167BBEB4 ^ 0) >> 0;
					continue;
				case 5u:
					text += ZZfrtaNhDFHEMWtgAsEfyjIcUWnDmUnxwPcyPeTDLwotQHRCrHjAMMRPqcwxNkVJrjiWTUqwzaubVpmmeL(0, 9);
					num = (int)(((num2 + 1665746989) ^ 0x617D82B2) + 0 << 0 << 0 << 0);
					continue;
				case 6u:
					num = ((int)(((num2 + 770395556) ^ 0x12642A27) + 0) >> 0 >> 0) - 0;
					continue;
				case 7u:
					num8++;
					num = (int)((num2 + 1333463150) ^ 0xEDA1A11Fu) >> 0 >> 0 << 0 << 0;
					continue;
				case 8u:
					flag2 = num8 < 4;
					num = (0x46FA1C1E ^ 0) - 0;
					continue;
				case 9u:
				{
					int num6;
					int num7;
					if (flag2)
					{
						num6 = -1345186231;
						num7 = num6;
					}
					else
					{
						num6 = -825908750;
						num7 = num6;
					}
					num = (int)(((uint)(num6 - 0 - 0) ^ (num2 + 2029155507)) + 0 + 0 << 0 << 0);
					continue;
				}
				case 10u:
					change_name111.nsFiRSINqlVwHOlXrRljXhyITPCmvBLOTSxpEhSNlheRSQzRcoQAcvefTXocqwrPzhDPrVsjYxYPdGPdpKkgLlLyNrwHTQxPPosKnKAhWGBEwpbnhlMFlkeovfbZzKqiajaOofQEjdkeJgbypjAIdRDEkdohJBIlqtEnomYbviwiZZFpeDJpkHeiFvEkQIVIvZNpCNjckynVuvEkyZdfRsbJpwHTIOlMmOMamqNquHfLujNkQtMQFPQdYeZfgpuwnAIGIEYhmNLknpogIxdocugxXJciqHkemJyTBhBlvEESeGQIQTxImfuSulIYCQR(text);
					num = ((((int)num2 + -649986417) ^ 0x1A456149) >> 0) - 0 - 0 >> 0;
					continue;
				case 11u:
					num = (int)((((num2 + 660359990) ^ 0x1CF8DAA2) - 0 + 0) ^ 0) >> 0;
					continue;
				case 12u:
				{
					byte b3 = (byte)Random.Range(0, 255);
					num = ((((int)num2 + -1950096023) ^ -721612041 ^ 0) - 0 >> 0) ^ 0;
					continue;
				}
				case 13u:
				{
					byte b2 = (byte)Random.Range(0, 255);
					num = ((((int)num2 + -11084362) ^ 0x22260D92) + 0 << 0) - 0 + 0;
					continue;
				}
				case 14u:
				{
					byte b = (byte)Random.Range(0, 255);
					num = ((int)((((num2 + 1047830633) ^ 0x6FE3C2B2) - 0) ^ 0) >> 0) + 0;
					continue;
				}
				case 15u:
					Strobe.LoUcBTPLynoBGKZsMLLkgBzBKezOehVamJrmkUtuxxqKAdjccIVRdXxjPsrwtbHrrnoWsNhSsqMIlObHVxLvldWplhwSCWawQYsnOmJpAdzNlPYarKAWplfnqZLlqppvppSmvNSINwViEjewjwARvegETfWPByYkNdxVXLFDSSjTqXIhUpcUOxZlintqRchoyKuAMiyxQXZDUnoVwPUmwdwqelNJrpMPKUvFDiuMQEdRxvrVYyTchVSuoewAvOgBlkTZSJsouivRZESIUSLTvJHPbaqzLTrcyCFnCrcpgFHZzbuJlNGDdmgBDdXRsSCBRttxZEgDPvNPcHpaGHnYnNYlweKytlXndgigHWKHGcOHzqyV();
					num = (int)((((num2 + 830770635) ^ 0x974FFE6Bu) << 0) + 0 - 0) >> 0;
					continue;
				case 16u:
					num = (((int)num2 + -1377430272) ^ -2008821741 ^ 0) >> 0 >> 0 >> 0;
					continue;
				case 17u:
					num5 = 0;
					num = (int)((((num2 + 337346832) ^ 0x3F9C453C) << 0 << 0) + 0 + 0);
					continue;
				case 18u:
					num = ((((((int)num2 + -1160147690) ^ 0x66157A12) + 0) ^ 0) << 0) ^ 0;
					continue;
				case 19u:
					num = 0x26918810 ^ 0;
					continue;
				case 20u:
					Xcosmetics.vqFzvNAQcCNIAXLMwhpxsdSNCAYBObvtQHWUiacwqlYwRERKwiXHLXvsyRXVPZcahtRTbQDveTggfvWXJneFeOITlEwrdgGrjXpyMXJGFBCRQpmdVZmCVxVtLYHxu();
					num = ((((int)num2 + -202039689) ^ 0x4ECCD46F) + 0 + 0 - 0) ^ 0;
					continue;
				case 21u:
					num = ((((((int)num2 + -324874666) ^ 0x596029E8) - 0) ^ 0) << 0) ^ 0;
					continue;
				case 22u:
					num = (((int)num2 + -1198330398) ^ -2052536567 ^ 0 ^ 0) << 0 >> 0;
					continue;
				case 23u:
					num5++;
					num = ((int)((num2 + 502420178) ^ 0x8E93832) >> 0) + 0 + 0 + 0;
					continue;
				case 24u:
					flag = num5 < 50;
					num = ((0x394A8B7F ^ 0) - 0 << 0) - 0;
					continue;
				case 25u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 379806816;
						num4 = num3;
					}
					else
					{
						num3 = 1280685372;
						num4 = num3;
					}
					num = (int)((((uint)((num3 << 0) - 0) ^ (num2 + 929994502)) << 0) + 0 - 0 + 0);
					continue;
				}
				case 26u:
					return;
				}
				break;
			}
		}
	}

	private static int ZZfrtaNhDFHEMWtgAsEfyjIcUWnDmUnxwPcyPeTDLwotQHRCrHjAMMRPqcwxNkVJrjiWTUqwzaubVpmmeL(int int_0, int int_1)
	{
		int result = default(int);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 - (0 + 0) - 0 - 0) ^ 0) << -0) - 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 1u:
					result = Random.Range(int_0, int_1);
					num = (((((int)num2 + -1874950498) ^ -859104563) >> 0) + 0 << 0) + 0;
					continue;
				case 2u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0 + 0 << 0);
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	public change_idenity()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 >> -0 << 0) - 0) ^ 0) >> (0 >> 1) >> 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB1) >> 0) - 0) ^ 0) + 0;
			}
		}
	}
}
