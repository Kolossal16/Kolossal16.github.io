using System;
using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class FUCK_punchmod
{
	private static float VORnVSNedAytsSGvqNkBRHEsRnSpoyifWDpoyeJHBqdNgbtwXVazvGZojzwHZyPFstxPCrXmdDaBERlPTwstxJKpEbfZIcIcByvNDETFXOvSGyKsnGNCfvhJIilBlXEbVXZfwxlpDMvJnRIgrNMbofWfrLfvsrtakuXJyEWPuxZtZxvRAfkylCMPaTOKsQWlsvyTUYHMQWGQgDgTpnVnhVPHIhJEQlwEANaEYCWBxxIoWVIwNVueVJexGRlMpdWFAbqtCBUNrtPJnAKMymQURrJR = 0f;

	public static float IDYhrjluBcNUFpTmaHNBTvkfgyncmbOisyKZCMvhhvhkNQhjtEUjDhXmtTaSWjizoEBgETJnlGtynZsqreJHhEFlAyGJMClYnIVioaFzVGYXNzYtBKBSAArKZqFgnZBIvvlFejbqyjMBFHxbznibbtyMqkiYuymVepCsosorIktqOQerTEGZQAHcWypTbdWaXQxqfeMgYRsQahXAgQePSmeEIzvPdvqFostXsOmOSAaZhRcPAPNkYgiKLTIFIWdDBNBHNahsEqXrlewQxGpnIfHikJlzgGgVxxyuqvcAHuGIjQyHwRicHPVvgsweOHmYjbUOGbAcDOFnyYZukEcoxeoIBcoXYXMaiIyhWJaur;

	public static void fyTjIWhtbUjFXAfNlnDNCdGbFeQARyAEHWsFvzTfhDXdCvlisuKwxHObSRDEgGBDtFXbhArMtxGYgCzkTIhxNdgaiqNDVpZActJXykaScXdZbPVpssKyzePqyWSRMNReyfWNSBMIHpuQahZsvxlDEBbXDtyBrifpgYBVShxQFbQjKZprXAwoCnAXeZjydlrzjfJbGdznavXCLRmEdhERMQMSyEQTYYNuKr()
	{
		//IL_0861: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0633: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b14: Unknown result type (might be due to invalid IL or missing references)
		//IL_073c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b69: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0810: Unknown result type (might be due to invalid IL or missing references)
		//IL_0815: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c09: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = default(GameObject);
		VRRig componentInParent = default(VRRig);
		RaycastHit val2 = default(RaycastHit);
		bool flag3 = default(bool);
		bool flag4 = default(bool);
		float[] array = default(float[]);
		int num5 = default(int);
		bool flag = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301845;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) + (0 + 0) >> 0) + 0 - 0 << (0 >> 1)) + 0 << 0)) % 53)
				{
				case 18u:
					break;
				default:
					return;
				case 20u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.green);
					num = ((((int)num2 + -1999758855) ^ -931534660 ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 29u:
					componentInParent = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>();
					num = (0x3749DF9E ^ 0) >> 0 << 0;
					continue;
				case 27u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = (((int)((num2 + 1473386669) ^ 0xF558A8A8u) >> 0) ^ 0) + 0 << 0;
					continue;
				case 39u:
					num = (((int)num2 + -844538616) ^ 0x6A3021B1) - 0 - 0 - 0 >> 0;
					continue;
				case 48u:
					soundspammers.ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(31, 0f, 0f, 1E+09f);
					num = (((((int)num2 + -1588304944) ^ -1003221271 ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 0u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (int)((((num2 + 1376848916) ^ 0x9C5BF952u ^ 0) << 0) + 0 + 0);
					continue;
				case 23u:
					flag3 = flag4;
					num = (((int)num2 + -554548610) ^ -1342752029) - 0 - 0 - 0 >> 0;
					continue;
				case 26u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = ((((int)num2 + -404739134) ^ 0x1DC62099) - 0 >> 0 << 0) - 0;
					continue;
				case 37u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((((((int)num2 + -182552646) ^ 0x9CDCFA) + 0) ^ 0) << 0) - 0;
					continue;
				case 32u:
					GorillaTagger.Instance.myVRRig.leftHand.rigTarget.localPosition = GorillaTagger.Instance.myVRRig.head.rigTarget.localPosition;
					num = (int)((((num2 + 1573031133) ^ 0xF03BAEBDu) << 0 << 0) + 0 << 0);
					continue;
				case 35u:
					num = (int)((((num2 + 107741590) ^ 0x29F55BBA) << 0) - 0 - 0 + 0);
					continue;
				case 46u:
					num = ((((int)num2 + -1563535789) ^ -1518902667) - 0 >> 0) + 0 - 0;
					continue;
				case 42u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)componentInParent).transform.position - new Vector3(0f, array[num5], 0f);
					num = (((int)num2 + -808576807) ^ -1965785650) >> 0 >> 0 >> 0 >> 0;
					continue;
				case 45u:
					flag = flag2;
					num = (int)(((((num2 + 1312251543) ^ 0xF3B4B67Fu) - 0 << 0) ^ 0) << 0);
					continue;
				case 1u:
					val.transform.position = ((RaycastHit)(ref val2)).point;
					num = (((((int)num2 + -1829903696) ^ -1311693551) - 0 - 0) ^ 0) + 0;
					continue;
				case 51u:
					num = (int)(((num2 + 595818838) ^ 0x7EADAE9F ^ 0) + 0 << 0 << 0);
					continue;
				case 19u:
					num = ((((int)num2 + -1536809407) ^ 0x63097974) - 0 << 0) - 0 + 0;
					continue;
				case 21u:
					num = ((((int)num2 + -229453252) ^ 0x5FCCAD71 ^ 0) << 0 >> 0) - 0;
					continue;
				case 6u:
					num = (((int)num2 + -1497151632) ^ -1726038617 ^ 0) - 0 << 0 >> 0;
					continue;
				case 22u:
					flag4 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>());
					num = (int)((((num2 + 234277810) ^ 0x7BCC5667) + 0 - 0 << 0) ^ 0);
					continue;
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = ((((int)num2 + -1761200462) ^ -1574135888) << 0 >> 0 << 0) - 0;
					continue;
				case 7u:
				{
					int num6;
					int num7;
					if (!flag3)
					{
						num6 = -240184025;
						num7 = num6;
					}
					else
					{
						num6 = -128184001;
						num7 = num6;
					}
					num = (int)(((uint)((num6 << 0) - 0) ^ (num2 + 776420349)) + 0) >> 0 >> 0 << 0;
					continue;
				}
				case 25u:
					num = ((((int)((num2 + 476044639) ^ 0xA0B93172u) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 2u:
					num = (int)(((num2 + 1661375474) ^ 0xEA132523u) + 0 - 0 - 0 << 0);
					continue;
				case 8u:
					num = ((((int)num2 + -1412658558) ^ -232034851) - 0 >> 0 >> 0) ^ 0;
					continue;
				case 28u:
					num = (int)((((num2 + 1216645994) ^ 0x503DB5E) - 0 + 0) ^ 0) >> 0;
					continue;
				case 30u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (int)(((num2 + 1270048165) ^ 0xE384B0C0u) + 0 - 0 - 0 << 0);
					continue;
				case 9u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = (((int)(((num2 + 1127294952) ^ 0x3517D5AD) - 0) >> 0) - 0) ^ 0;
					continue;
				case 31u:
					num = ((((((int)num2 + -217055685) ^ 0x77CC89A0) >> 0) - 0) ^ 0) << 0;
					continue;
				case 33u:
					num = (int)(((num2 + 364309176) ^ 0xD6CE553Eu ^ 0) - 0 << 0) >> 0;
					continue;
				case 10u:
					num = (((int)num2 + -777708833) ^ 0x510753F8 ^ 0) >> 0 >> 0 >> 0;
					continue;
				case 34u:
					GorillaTagger.Instance.myVRRig.rightHand.rigTarget.localPosition = GorillaTagger.Instance.myVRRig.head.rigTarget.localPosition;
					num = (((int)num2 + -1553473705) ^ 0x24BA5DE0) + 0 + 0 >> 0 << 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (int)(((num2 + 1438922508) ^ 0xCE80C553u) + 0 << 0) >> 0 << 0;
					continue;
				case 36u:
					GorillaTagger.Instance.myVRRig.leftHand.rigTarget.localEulerAngles = Vector3.zero;
					num = (((((int)num2 + -1052270108) ^ -1852653895) >> 0) ^ 0 ^ 0) >> 0;
					continue;
				case 11u:
					num = ((int)((num2 + 2000359224) ^ 0x8ABF7BF5u) >> 0) + 0 - 0 - 0;
					continue;
				case 38u:
					GorillaTagger.Instance.myVRRig.rightHand.rigTarget.localEulerAngles = Vector3.zero;
					num = (((int)num2 + -159507211) ^ 0x30F33A83) + 0 + 0 + 0 >> 0;
					continue;
				case 40u:
					num = (int)(((num2 + 757804180) ^ 0xBB565A2Au ^ 0) - 0 << 0 << 0);
					continue;
				case 12u:
					array = new float[2] { 10f, -10f };
					num = (((((int)num2 + -1264230692) ^ -1624432859) << 0) + 0) ^ 0 ^ 0;
					continue;
				case 41u:
					num5 = new Random().Next(array.Length);
					num = ((int)((num2 + 346463589) ^ 0x50741E22) >> 0) + 0 + 0 >> 0;
					continue;
				case 43u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.magenta);
					num = (int)(((num2 + 403315589) ^ 0x3AD14BA5) - 0) >> 0 << 0 >> 0;
					continue;
				case 13u:
					num = (((int)num2 + -123593846) ^ 0x47FDAFBB) >> 0 << 0 << 0 >> 0;
					continue;
				case 44u:
					flag2 = Time.time - VORnVSNedAytsSGvqNkBRHEsRnSpoyifWDpoyeJHBqdNgbtwXVazvGZojzwHZyPFstxPCrXmdDaBERlPTwstxJKpEbfZIcIcByvNDETFXOvSGyKsnGNCfvhJIilBlXEbVXZfwxlpDMvJnRIgrNMbofWfrLfvsrtakuXJyEWPuxZtZxvRAfkylCMPaTOKsQWlsvyTUYHMQWGQgDgTpnVnhVPHIhJEQlwEANaEYCWBxxIoWVIwNVueVJexGRlMpdWFAbqtCBUNrtPJnAKMymQURrJR > IDYhrjluBcNUFpTmaHNBTvkfgyncmbOisyKZCMvhhvhkNQhjtEUjDhXmtTaSWjizoEBgETJnlGtynZsqreJHhEFlAyGJMClYnIVioaFzVGYXNzYtBKBSAArKZqFgnZBIvvlFejbqyjMBFHxbznibbtyMqkiYuymVepCsosorIktqOQerTEGZQAHcWypTbdWaXQxqfeMgYRsQahXAgQePSmeEIzvPdvqFostXsOmOSAaZhRcPAPNkYgiKLTIFIWdDBNBHNahsEqXrlewQxGpnIfHikJlzgGgVxxyuqvcAHuGIjQyHwRicHPVvgsweOHmYjbUOGbAcDOFnyYZukEcoxeoIBcoXYXMaiIyhWJaur;
					num = ((int)(((num2 + 1538676277) ^ 0x2D223D1A) + 0 << 0) >> 0) - 0;
					continue;
				case 4u:
					num = ((((int)num2 + -396906955) ^ -1178551251) >> 0) + 0 - 0 << 0;
					continue;
				case 14u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -392684950;
						num4 = num3;
					}
					else
					{
						num3 = -386316679;
						num4 = num3;
					}
					num = ((int)((uint)(num3 ^ 0 ^ 0) ^ (num2 + 1553804776)) >> 0 >> 0) + 0 - 0;
					continue;
				}
				case 47u:
					num = ((((int)num2 + -75081790) ^ 0x5D2409F1) - 0 >> 0) + 0 << 0;
					continue;
				case 49u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (int)((((num2 + 1246932057) ^ 0x8F81D14Cu ^ 0) + 0 << 0) - 0);
					continue;
				case 15u:
					num = ((((int)num2 + -1727873598) ^ 0x47835B8E ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 50u:
					VORnVSNedAytsSGvqNkBRHEsRnSpoyifWDpoyeJHBqdNgbtwXVazvGZojzwHZyPFstxPCrXmdDaBERlPTwstxJKpEbfZIcIcByvNDETFXOvSGyKsnGNCfvhJIilBlXEbVXZfwxlpDMvJnRIgrNMbofWfrLfvsrtakuXJyEWPuxZtZxvRAfkylCMPaTOKsQWlsvyTUYHMQWGQgDgTpnVnhVPHIhJEQlwEANaEYCWBxxIoWVIwNVueVJexGRlMpdWFAbqtCBUNrtPJnAKMymQURrJR = Time.time;
					num = ((int)((num2 + 1888003287) ^ 0xBE24E92Fu) >> 0) + 0 + 0 << 0;
					continue;
				case 52u:
					num = ((((int)num2 + -100986504) ^ 0x447ED3DE) << 0) + 0 - 0 + 0;
					continue;
				case 16u:
					num = (1712652299 >> 0) - 0 >> 0 >> 0;
					continue;
				case 5u:
				{
					bool triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = ((int)(((num2 + 583561026) ^ 0xD73535B) + 0 + 0) >> 0) - 0;
					continue;
				}
				case 17u:
					return;
				}
				break;
			}
		}
	}

	public FUCK_punchmod()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 - (0 ^ 0) >> 0) + 0 << 0) ^ 0) - 0 << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) << 0 << 0) + 0 >> 0;
			}
		}
	}

	static FUCK_punchmod()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) >> (0 << 1)) ^ 0) + 0 << 0 >> (0 << 1)) + 0 >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_0052;
				case 0u:
					return;
				}
				break;
				IL_0052:
				IDYhrjluBcNUFpTmaHNBTvkfgyncmbOisyKZCMvhhvhkNQhjtEUjDhXmtTaSWjizoEBgETJnlGtynZsqreJHhEFlAyGJMClYnIVioaFzVGYXNzYtBKBSAArKZqFgnZBIvvlFejbqyjMBFHxbznibbtyMqkiYuymVepCsosorIktqOQerTEGZQAHcWypTbdWaXQxqfeMgYRsQahXAgQePSmeEIzvPdvqFostXsOmOSAaZhRcPAPNkYgiKLTIFIWdDBNBHNahsEqXrlewQxGpnIfHikJlzgGgVxxyuqvcAHuGIjQyHwRicHPVvgsweOHmYjbUOGbAcDOFnyYZukEcoxeoIBcoXYXMaiIyhWJaur = 0.05f;
				num = (((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0) - 0 >> 0) ^ 0;
			}
		}
	}
}
