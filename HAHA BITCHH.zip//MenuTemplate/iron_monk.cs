using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class iron_monk
{
	public static void eQhdxRPFSvoVWPVtHtljXCTTuhYkfeAIMcibdOOaVCQkbMETVWYgKPIBXnIqTFzNUFjTGUqSFlovMIRIDeoiguYWtHePfygpccpwDKmbFgAzBnPowaMOqrHAHmzZPBMheYtJsvfSRmCaTzvgRQtfLrYKvPOrknmetsvCTfVaVTXdOHGiQthZiGwMaInDGOIEayGAeSnLUskRuUWOiGARfmWNWIClSsuhlsdpafeXgvfQwErfLzuanQzNCTEvqbTBYcGbRHNdCCLJhgqrqxzsYtTuTpNhBIHeCDRtYqneMrxLfPFwCmeTCBCEjlhBUFBTUHhDoWtajuGHVhoeJqEpENBbankMiMkgPEQyIbiGTdKhUVIbWdSDampgfgDaLGSxkzRrqQwHiYwAdtgeEjPfTHfDoJsCyhUmlnXverKfHkvcQOdLZywCQ()
	{
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown2 = default(bool);
		bool triggerButtonDown = default(bool);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 + (0 ^ 0) + 0 + 0) ^ 0 ^ 0 ^ 0) + 0)) % 14)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					triggerButtonDown2 = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (((int)num2 + -2130437817) ^ -602494967) >> 0 << 0 << 0 << 0;
					continue;
				case 5u:
				{
					Rigidbody attachedRigidbody2 = ((Collider)Player.Instance.bodyCollider).attachedRigidbody;
					attachedRigidbody2.velocity += -Player.Instance.leftHandTransform.right / 2f;
					num = ((int)(((num2 + 1505546092) ^ 0x9AC84F95u) + 0 << 0) >> 0) + 0;
					continue;
				}
				case 1u:
				{
					int num5;
					int num6;
					if (!triggerButtonDown2)
					{
						num5 = -2145680381;
						num6 = num5;
					}
					else
					{
						num5 = -815817394;
						num6 = num5;
					}
					num = ((((num5 >> 0 >> 0) ^ ((int)num2 + -1625985034)) - 0) ^ 0) >> 0 << 0;
					continue;
				}
				case 4u:
				{
					int num3;
					int num4;
					if (triggerButtonDown)
					{
						num3 = -549224956;
						num4 = num3;
					}
					else
					{
						num3 = -1166912237;
						num4 = num3;
					}
					num = ((int)(((uint)(num3 >> 0 << 0) ^ (num2 + 1339473132)) << 0 << 0) >> 0) - 0;
					continue;
				}
				case 13u:
					num = ((((int)num2 + -715084519) ^ -522581668) - 0 + 0) ^ 0 ^ 0;
					continue;
				case 6u:
					num = ((int)((((num2 + 350301675) ^ 0xA3985978u) - 0) ^ 0) >> 0) + 0;
					continue;
				case 2u:
				{
					Rigidbody attachedRigidbody = ((Collider)Player.Instance.bodyCollider).attachedRigidbody;
					attachedRigidbody.velocity += Player.Instance.rightHandTransform.right / 2f;
					num = (((((int)num2 + -534343288) ^ -434198885) << 0 >> 0) ^ 0) - 0;
					continue;
				}
				case 10u:
					num = ((((int)num2 + -541887392) ^ 0x5784A155) << 0) + 0 >> 0 >> 0;
					continue;
				case 11u:
					num = ((((int)num2 + -1692824216) ^ -1456617352) << 0 << 0 >> 0) + 0;
					continue;
				case 12u:
					num = (int)(((num2 + 820929353) ^ 0xEA6EF2C1u) - 0 - 0 - 0 + 0);
					continue;
				case 3u:
					num = ((((int)((num2 + 1954386908) ^ 0xD9F1E3D1u) >> 0) ^ 0) << 0) - 0;
					continue;
				case 8u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (0x49E2A52C ^ 0) + 0;
					continue;
				case 7u:
					return;
				}
				break;
			}
		}
	}

	public iron_monk()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) >> (0 << 1) >> 0) ^ 0) - 0 << (0 >> 1) >> 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) << 0 >> 0) - 0;
			}
		}
	}
}
