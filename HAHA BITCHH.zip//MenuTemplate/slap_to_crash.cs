using GorillaLocomotion;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;

namespace MenuTemplate;

internal class slap_to_crash
{
	public static void pAjKEEZcQOWjvNpEIjgTySKgERgqQrjeTKFWCWQZfwVLICBCdBAnUPmxPdgNxJmyERqLitcLsgObXZxbpEmpRWjdxhhyQdBwkwhQmPuKyOUObkAQFexTwXHIHmoalDUpEsRARGOzkBQcbvcmHrSLFHZnOyjZBtyUTFjJtZYYqXJVgFG()
	{
		//IL_0d2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e96: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e9b: Unknown result type (might be due to invalid IL or missing references)
		float num8 = default(float);
		PhotonView componentInParent = default(PhotonView);
		RaycastHit[] array2 = default(RaycastHit[]);
		RaycastHit[] array = default(RaycastHit[]);
		int num3 = default(int);
		RaycastHit val = default(RaycastHit);
		bool flag = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301801;
			while (true)
			{
				uint num2;
				int num9;
				switch ((num2 = (uint)((((num << 0 >> (0 << 1)) ^ 0) + 0 + 0 << 0 + 0) - 0 - 0)) % 117)
				{
				case 0u:
					break;
				default:
					return;
				case 61u:
					num8 = 0.3f;
					num = (int)((((num2 + 2033488390) ^ 0xD7C52FDDu) << 0) - 0) >> 0 << 0;
					continue;
				case 32u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1707244019) ^ -609476154) << 0 >> 0 << 0) ^ 0;
					continue;
				case 1u:
					array2 = Il2CppArrayBase<RaycastHit>.op_Implicit((Il2CppArrayBase<RaycastHit>)(object)Physics.RaycastAll(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, num8));
					num = (int)((num2 + 1515080385) ^ 0x8B96B888u ^ 0) >> 0 << 0 >> 0;
					continue;
				case 48u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1605105773) ^ -561927738) << 0) - 0 + 0 - 0;
					continue;
				case 92u:
					num = ((((((int)num2 + -1855006857) ^ -1127465729) - 0) ^ 0) + 0) ^ 0;
					continue;
				case 79u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((int)((num2 + 220436453) ^ 0x41A06E6A ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 2u:
					array = array2;
					num = (int)(((num2 + 179208694) ^ 0xC96B662 ^ 0) + 0 - 0 - 0);
					continue;
				case 104u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((num2 + 238251991) ^ 0x78C1C615) - 0 - 0) >> 0 << 0;
					continue;
				case 77u:
					num3 = 0;
					num = (int)(((num2 + 1989400013) ^ 0x95B710CCu) + 0 + 0 - 0 + 0);
					continue;
				case 36u:
					num = (int)(((((num2 + 1594408389) ^ 0x7E40E3A3) << 0) ^ 0 ^ 0) + 0);
					continue;
				case 3u:
					num = (((int)num2 + -358205772) ^ 0x336FF7AC) >> 0 << 0 << 0 << 0;
					continue;
				case 44u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((((num2 + 1078212659) ^ 0x744BBDF7) - 0) ^ 0) + 0 << 0);
					continue;
				case 102u:
					val = array[num3];
					num = (0x49E2A4C3 ^ 0) + 0;
					continue;
				case 50u:
					num = ((int)(((num2 + 1217819383) ^ 0xA96353D7u) - 0 + 0) >> 0) ^ 0;
					continue;
				case 4u:
					num = (((int)num2 + -1499634342) ^ -1233512926 ^ 0) - 0 - 0 >> 0;
					continue;
				case 57u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)((((num2 + 1519762352) ^ 0xCF7BD562u) << 0) - 0 << 0 << 0);
					continue;
				case 69u:
					componentInParent = ((Component)((RaycastHit)(ref val)).collider).GetComponentInParent<PhotonView>();
					num = (((((int)num2 + -837232188) ^ 0x643BC71D) >> 0) - 0 << 0) - 0;
					continue;
				case 34u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)((((((num2 + 1010977116) ^ 0xDAD81496u) - 0) ^ 0) - 0) ^ 0);
					continue;
				case 5u:
					if ((Object)(object)componentInParent != (Object)null)
					{
						num = ((((int)num2 + -1575253258) ^ 0x436AF2E7) >> 0 >> 0) + 0 + 0;
						continue;
					}
					num9 = 0;
					goto IL_0fb9;
				case 38u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -154508314) ^ 0x468F8519 ^ 0) + 0 << 0) + 0;
					continue;
				case 84u:
					num9 = ((componentInParent.Owner != null) ? 1 : 0);
					goto IL_0fb9;
				case 42u:
					num = (((((int)num2 + -1335133940) ^ -188297644) >> 0) - 0 - 0) ^ 0;
					continue;
				case 6u:
					flag = flag2;
					num = (((int)num2 + -1235864212) ^ 0x2034299) + 0 - 0 - 0 << 0;
					continue;
				case 46u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -1915257242) ^ -2062556965) << 0 << 0) + 0 - 0;
					continue;
				case 96u:
				{
					int num6;
					int num7;
					if (flag)
					{
						num6 = 1929809185;
						num7 = num6;
					}
					else
					{
						num6 = 729539833;
						num7 = num6;
					}
					num = (int)(((((uint)((num6 >> 0) + 0) ^ (num2 + 1312251543) ^ 0) + 0) ^ 0) << 0);
					continue;
				}
				case 7u:
					num = (((int)num2 + -1657935803) ^ -827753918) + 0 - 0 + 0 - 0;
					continue;
				case 51u:
					num = (int)(((((num2 + 608825628) ^ 0xDCB400A1u) + 0) ^ 0) + 0) >> 0;
					continue;
				case 109u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((((int)num2 + -2041068990) ^ -1013134588) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 55u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((int)((((num2 + 38004003) ^ 0x1943CF7A) << 0) + 0) >> 0) + 0;
					continue;
				case 8u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((((num2 + 1415827559) ^ 0x22C61CCB) + 0 << 0) - 0) ^ 0);
					continue;
				case 59u:
					num3++;
					num = (((int)((num2 + 101902708) ^ 0x5DC30CE3 ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 65u:
					num = (int)(((((num2 + 45990464) ^ 0x2D7E8773) + 0 - 0) ^ 0) + 0);
					continue;
				case 33u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (((((int)num2 + -1939090086) ^ -83542640 ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 9u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((((int)num2 + -2002462762) ^ -1890863151) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 35u:
					num = ((int)(((num2 + 1816424631) ^ 0x902DA5ECu) << 0) >> 0) - 0 + 0;
					continue;
				case 73u:
					num = (((((int)num2 + -2089199972) ^ -821945793 ^ 0) - 0) ^ 0) << 0;
					continue;
				case 37u:
					num = (int)((((((num2 + 1258652073) ^ 0xE55ADA3Du) - 0) ^ 0) - 0) ^ 0);
					continue;
				case 10u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((int)num2 + -1893087828) ^ -504283525) - 0 + 0 - 0 >> 0;
					continue;
				case 39u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((int)((num2 + 691650460) ^ 0x67C1B004) >> 0) - 0 + 0 << 0;
					continue;
				case 80u:
					num = (int)(((num2 + 1621186360) ^ 0xAD66A228u ^ 0) + 0 << 0) >> 0;
					continue;
				case 41u:
					num = ((((int)num2 + -870664420) ^ 0x34C570C3) >> 0 >> 0) - 0 << 0;
					continue;
				case 11u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)((((num2 + 1037343940) ^ 0xEA94B8) - 0 << 0) + 0 - 0);
					continue;
				case 43u:
					num = (int)(((num2 + 1670808436) ^ 0x888993FCu) + 0 - 0 + 0) >> 0;
					continue;
				case 88u:
					num = (int)((((num2 + 1569959495) ^ 0xC88FE38Fu ^ 0 ^ 0) - 0) ^ 0);
					continue;
				case 45u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((int)((num2 + 148199600) ^ 0x2932C0F4) >> 0 << 0) - 0 >> 0;
					continue;
				case 12u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((int)(((num2 + 1993159257) ^ 0xCD2B85B0u) + 0) >> 0) + 0 << 0;
					continue;
				case 47u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -807700362) ^ -1741091624) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 13u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -1751013260) ^ -335502243) + 0 << 0 >> 0) - 0;
					continue;
				case 49u:
					num = ((((int)num2 + -1316482294) ^ 0x34DC61F6) << 0 << 0) - 0 - 0;
					continue;
				case 98u:
					num = ((((int)num2 + -1261085613) ^ -346834069) - 0 << 0) - 0 + 0;
					continue;
				case 14u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((int)((num2 + 1334533754) ^ 0x1E7D7505) >> 0) ^ 0) << 0 << 0;
					continue;
				case 52u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((num2 + 839628979) ^ 0xF3C59F85u) + 0 + 0 << 0) >> 0;
					continue;
				case 105u:
					num = (((int)((num2 + 1175360126) ^ 0x8D26B42Cu) >> 0 << 0) - 0) ^ 0;
					continue;
				case 54u:
					num = (((int)num2 + -1968604337) ^ -1448158905 ^ 0) + 0 - 0 + 0;
					continue;
				case 15u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((num2 + 1402561575) ^ 0xC58F9107u) + 0) >> 0 >> 0 >> 0;
					continue;
				case 56u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)(((num2 + 91671962) ^ 0x964337B ^ 0) + 0) >> 0 << 0;
					continue;
				case 113u:
					num = ((int)((num2 + 1448854582) ^ 0x9078CFC8u ^ 0) >> 0 << 0) ^ 0;
					continue;
				case 58u:
					num = (((int)((num2 + 1569497375) ^ 0xDBDEF1D4u) >> 0) ^ 0) - 0 + 0;
					continue;
				case 16u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -1740227389) ^ -1363157442) - 0 >> 0 >> 0) ^ 0;
					continue;
				case 62u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((int)(((num2 + 1314269170) ^ 0x6E85670D) + 0) >> 0) + 0 + 0;
					continue;
				case 63u:
					num = (int)(((((num2 + 2080546621) ^ 0xBAA2D7F2u) << 0) ^ 0) << 0 << 0);
					continue;
				case 64u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((int)(((num2 + 1246000002) ^ 0xE3007031u) - 0 - 0) >> 0) ^ 0;
					continue;
				case 17u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((int)num2 + -606707536) ^ 0x6C54DCEB) >> 0 >> 0 >> 0 << 0;
					continue;
				case 66u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -403027851) ^ -2103687080 ^ 0) - 0 >> 0) - 0;
					continue;
				case 67u:
					num = ((int)(((num2 + 1099667150) ^ 0x72D4F06F) - 0 + 0) >> 0) + 0;
					continue;
				case 68u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)((((num2 + 1289406471) ^ 0xC0BB139Au) << 0 << 0 << 0) ^ 0);
					continue;
				case 18u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)(((((num2 + 1892732207) ^ 0xC109EA5Fu ^ 0) << 0) + 0) ^ 0);
					continue;
				case 70u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((((num2 + 265763261) ^ 0x5767D43A) + 0 << 0) + 0) ^ 0);
					continue;
				case 71u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((((int)num2 + -339525817) ^ 0x77372C73 ^ 0) - 0) ^ 0) << 0;
					continue;
				case 72u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)((((num2 + 948052382) ^ 0x2BA06763) << 0 << 0) - 0 + 0);
					continue;
				case 19u:
					num = ((((int)num2 + -1361039952) ^ -2002965973) - 0 + 0 - 0) ^ 0;
					continue;
				case 74u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)((((((num2 + 1088549557) ^ 0xE27C6C2Cu) << 0) ^ 0) << 0) + 0);
					continue;
				case 75u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((num2 + 895677943) ^ 0x8DF99859u ^ 0) + 0 - 0 - 0);
					continue;
				case 76u:
					num = (((((int)num2 + -966133482) ^ -1526411743) + 0 - 0) ^ 0) - 0;
					continue;
				case 20u:
					num = (((((int)num2 + -302506815) ^ 0x59D8C2DC) >> 0) ^ 0) - 0 << 0;
					continue;
				case 40u:
					num = (int)(((num2 + 756085796) ^ 0x59CF24EA) + 0 - 0 + 0 + 0);
					continue;
				case 78u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((int)((num2 + 823007552) ^ 0x75DD9AFF) >> 0) + 0 + 0 + 0;
					continue;
				case 21u:
					num = ((((int)num2 + -510284876) ^ -1272059903) << 0) - 0 + 0 + 0;
					continue;
				case 81u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -843098288) ^ -2077966067) + 0 - 0 << 0) ^ 0;
					continue;
				case 82u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((((int)num2 + -396185058) ^ 0x57BD1650 ^ 0) - 0) ^ 0) - 0;
					continue;
				case 83u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -1394240509) ^ -1029345752) << 0) - 0 + 0 - 0;
					continue;
				case 22u:
					num = (((int)num2 + -178981126) ^ 0x4B809C82) - 0 - 0 - 0 >> 0;
					continue;
				case 85u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)((((((num2 + 1548848021) ^ 0x93A1FDA1u) << 0) + 0) ^ 0) + 0);
					continue;
				case 86u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (((((int)num2 + -1658609469) ^ -2136902634) >> 0) + 0 >> 0) - 0;
					continue;
				case 87u:
					num = ((((int)num2 + -695321444) ^ -910986507) << 0 >> 0) - 0 << 0;
					continue;
				case 23u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((int)num2 + -393542434) ^ 0x1CEE3575) + 0 + 0 + 0 - 0;
					continue;
				case 89u:
					num = (((int)num2 + -1392310534) ^ -1178411189 ^ 0 ^ 0) + 0 << 0;
					continue;
				case 90u:
					num = ((((((int)num2 + -1859572427) ^ -414785356) - 0) ^ 0) << 0) ^ 0;
					continue;
				case 91u:
					num = ((((int)num2 + -519751904) ^ -764614654) >> 0) + 0 + 0 << 0;
					continue;
				case 24u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((((int)num2 + -1821103394) ^ -703314137) << 0 << 0) ^ 0) - 0;
					continue;
				case 93u:
					num = (((int)((num2 + 1400212651) ^ 0xCFEBF47Bu) >> 0) ^ 0 ^ 0) + 0;
					continue;
				case 94u:
					num = ((((int)num2 + -1969992788) ^ -1256929179) + 0 >> 0) - 0 + 0;
					continue;
				case 95u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((int)((num2 + 435654514) ^ 0xD4314B7Bu) >> 0) - 0 >> 0 >> 0;
					continue;
				case 25u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((((num2 + 984480750) ^ 0x8043B216u) + 0 + 0) ^ 0) + 0);
					continue;
				case 97u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = ((((int)num2 + -30252835) ^ 0x65E368DD) << 0) + 0 - 0 << 0;
					continue;
				case 26u:
					num = ((int)((num2 + 1123855598) ^ 0x11369274) >> 0 >> 0) + 0 >> 0;
					continue;
				case 99u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)((((num2 + 1380504978) ^ 0x2724A75C) + 0) ^ 0 ^ 0 ^ 0);
					continue;
				case 100u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)((((num2 + 1241114836) ^ 0xC6A22CC0u) + 0 << 0) + 0 - 0);
					continue;
				case 101u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1634190642) ^ -1761588821) + 0 >> 0) - 0 >> 0;
					continue;
				case 27u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (((int)((num2 + 1104837485) ^ 0xF03D63EEu ^ 0) >> 0) + 0) ^ 0;
					continue;
				case 53u:
					num = ((((int)num2 + -886966208) ^ 0x619E5CF5) >> 0 << 0 << 0) - 0;
					continue;
				case 103u:
					num = ((((int)num2 + -596265155) ^ 0x2FC6C083 ^ 0) >> 0 << 0) + 0;
					continue;
				case 28u:
					PhotonNetwork.DestroyPlayerObjects(componentInParent.Owner);
					num = (int)(((num2 + 1208831818) ^ 0x319F53A3 ^ 0 ^ 0 ^ 0) + 0);
					continue;
				case 106u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (((((int)num2 + -1714723781) ^ -1351539037) + 0 - 0) ^ 0) + 0;
					continue;
				case 107u:
					num = ((((int)num2 + -1937822222) ^ -2028131122) - 0 >> 0) ^ 0 ^ 0;
					continue;
				case 108u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -182932046) ^ 0x10BE8BB4) >> 0 << 0 << 0) - 0;
					continue;
				case 29u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1268055718) ^ 0x78E6606D ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 110u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1142183813) ^ -1787805891) >> 0) - 0 >> 0 << 0;
					continue;
				case 111u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -1133151541) ^ 0x2B6F094D ^ 0) + 0 << 0) + 0;
					continue;
				case 112u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (((((int)num2 + -1578280308) ^ -782468817) >> 0) + 0 << 0) + 0;
					continue;
				case 30u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (int)(((num2 + 1475137304) ^ 0x50279C27 ^ 0 ^ 0 ^ 0) << 0);
					continue;
				case 114u:
					num = (1742690021 >> 0) + 0 + 0 + 0;
					continue;
				case 115u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = (((((int)num2 + -1850215591) ^ -395179990) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 116u:
				{
					int num4;
					int num5;
					if (num3 < array.Length)
					{
						num4 = 1422392385;
						num5 = num4;
					}
					else
					{
						num4 = 1812043293;
						num5 = num4;
					}
					num = ((num4 + 0) ^ 0 ^ 0) - 0;
					continue;
				}
				case 31u:
					PhotonNetwork.CloseConnection(componentInParent.Owner);
					num = ((((int)num2 + -158355511) ^ 0x416E130A ^ 0) << 0) + 0 + 0;
					continue;
				case 60u:
					return;
					IL_0fb9:
					flag2 = (byte)num9 != 0;
					num = ((0x6B72403C ^ 0) << 0) + 0 + 0;
					continue;
				}
				break;
			}
		}
	}

	public slap_to_crash()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) - (0 ^ 0) >> 0) + 0 - 0 + (0 + 0)) ^ 0) + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 + 0) ^ 0) << 0;
			}
		}
	}
}
