using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class infection
{
	public static void xoxEtsMsHqOhEFtCjAYrrCjlejpeLFUegZUKqrqgfzRbCxTHEcOEzFdUflAjcHHbwJbELImSkSlSLhJGqHAJRqFAVZF()
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Expected O, but got Unknown
		Hashtable val = default(Hashtable);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 + (0 + 0) - 0 + 0) ^ 0) << -0) - 0 + 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 5u:
					val = new Hashtable();
					num = ((int)(((num2 + 414745695) ^ 0xB4411CF3u) - 0) >> 0) + 0 << 0;
					continue;
				case 2u:
					PhotonNetwork.CurrentRoom.SetCustomProperties(val, (Hashtable)null, (WebFlags)null);
					num = ((((int)num2 + -344833909) ^ -305432164) - 0 << 0) ^ 0 ^ 0;
					continue;
				case 1u:
					((Dictionary<Object, Object>)(object)val).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ṤṢṮṦṎṬṧṦ", 286596611, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䲢䲫䲶䲡䲷䲰䲀䲁䲂䲅䲑䲈䲐䲉䲋䲀䲀䲁䲀䲛䲉䲋䲀䲀䲁䲀䲛䲍䲊䲂䲁䲇䲐䲍䲋䲊䲍䲊䲂䲁䲇䲐䲍䲋䲊", 16927940, true)));
					num = (((((int)num2 + -907893453) ^ -466987134) << 0) - 0 >> 0) - 0;
					continue;
				case 4u:
					num = ((((((int)num2 + -248958683) ^ 0x1C939557) << 0) + 0) ^ 0) + 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public infection()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num << 0 << -0 >> 0) - 0 - 0 << -0 >> 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) - 0 + 0 - 0;
			}
		}
	}
}
