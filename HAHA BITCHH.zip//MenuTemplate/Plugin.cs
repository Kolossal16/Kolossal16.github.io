using GorillaLocomotion;
using MelonLoader;
using MenuTemplate.Menu;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

public class Plugin : MelonMod
{
	private static GameObject hyyrqRuYqNFCPGYGPyVxWzCfshgfJYWaHfhxeHhpDhKowpsHaRXbwZXHWsYiLoprREVJyABhqGTOPnJdPyfSbUDHiABMIZDoSsxRuJizqPKPfiRIJUtmjwpWanAYZOzrcFWwQRJfqFCmkOBaJSdOFrfvdBQgikABqtNAmuSRknVDUdLmLAogLKLKzAtoaDXffaWQbbNoalDswBBaPEvHVuPFIcaMaDQHqPyThVlJMafzhsoYZtzwhpkKlqiYabnxvVcGdHTUsLVVoqypNcNHdtAaFNIQMmJKMIelqIUrAFevuovUSSlYoGtbvbaqYchgckjGmmZfhvgypeGrrNXUaLwfocPoIEtxyXtjePIGTgQTAULrvIYkfnfrOdrjwKwDbIasKwmCeraUUCFuqySZFislScvaxzjiJmRRUtGZwwgNmkwlyXSYSxXTpOzIaleFhRlILNzWRTDjcEYHFkCzGlql = null;

	private static GameObject oXBfTYYkrAFuZOzKyVgYUORLQScQJEYWAZtNmtdTVsRBYDIRKRbLfsrAgQpbVhAMCJTZvMyeSmdBWqMmklgSDnRiISHwdbXNReYpKIwYtWSSoPDPedRKbIjpSLrCecbQoqJSrxCBPhyGuYUSpSraknMjVJwZrTTqVbDYfLxGBpVTjCUTQymmKbGbDAXIaDkVniLtuVNEuKyUsSZsPCiSGHGUuCuFNPGYfZFbQBzULIRZCMILAETxuroGBRYRBhQFeAPsmXBodnhYQHrIUIejVjDOLZAZCHtDRlVcXqyCcFthjpPUApXSdHJUWaHmxCLvTEgEMpLEkBgqPwEvjFzmKBzkCafWImfATYnFjlikEtI;

	private static GameObject CAsfAwmdSdyLseVcLkOVYwFxRiZmYxoIqSXJjVEzwjnwvnUAnjwaPxKgUVosxaeuPQuzhmSQFpzOjibDnyYPbnSTiRPoHmcweSHESvtbqFuAYVWLTKeZbptBYBqpwEjtncKqBxKSfXyvSrUnUduWhduOzgGredEMwbnVkGkwZmTeRYIGGdvtjmmkIVRuQtNbtLYReYcoSYXUjqXBxZLbHkCjOdnpPPFGySKgZQCHahBlosarYqXQHMtiiPdaLNycsrvrFRCGxdaAJrUwcVqySOYMyCXjNBWmIyTXWJLgOrtEMTyRUHYPwZkDtJTdTsTVgNSlyXzsjjKBvtZEdfpgDgQInpDmQI;

	private static GameObject nvxxxZbntXhFFnpJhaJoZNdMraXjYitnCBWodYVaDQMrZYACtDhDCCIzsLfxbRokDUceqaGjeJLjbLNszuQvaPKZSxWrSyYLBBNfVwmtWXzTRzxHXNXHbTkOjcmSeprFKZHzXIxdixycqQisaoufArKIrZVSjtpHGTjRSXJppUzEuhysUTSPUmfspZiXNETOiRwwHrAcEePFSgnkBCYpBzMtOQ;

	public static bool[] CSPLBLaKwDKbLCtQkQxzziLXwkFDnIecIQOHmTDdEiKJzARwWKpWWortgRpqfxxNyItUOLDrntUrybyWtjHCtigtzuAuDmXhKWlRgWHkgXJCtZVfttXWPVuqBZutljNavNHCQGP;

	public static string xBxvvyEazzvbkpbsOBUqhBoZXjIgGssoMDzusAZRXYUTPiDLuuSaWqHVmxxlQxuhghoGPGaoCcsiHvjPGWMlAsrvVEhUcNbzENMITWWNuDyTXzoRoHFULiHOPSKkzflObTDTJBWJZYQWTyxwpqFuihNwgXSalLoosKReVuiMLVUMrLVruoViARFUfhNLIVxnKCEjGtAViSInmbeucBFXQfOBeXYOHwdQxGbPhLKbNaZHirHedsIhpAxENdeIu;

	public static Material MnMPSPGZonrQEjQghtNqULoNWAXjwceGcGbMnSpBbeOerrLrGyGJrszbZYSrSwCmjKOXheSpdlpQWjwFPFCYvupJhaMpZXIECCUHCNjBGrGgdJePCnCmUEQPueQhrCqfCLouoOcbwbreNjGxVWNLvwKXLfmyXckdbAErvKBNlAQSmMclxslvPEKgbqIjBEduQndmFpckvZAUFRKZcbaFQPowQxqecrlGwwbZIPGiqaZPePAkFJgAEyDbZHwhYXieOTxjPLrmuRoQPysaXgytkLcYTaZbtzksRVbksrvUsTgNjMmAovkSyPTdRzpPMpTVGWYUxiIFLEbqEpOgNyMXosTcbYtSbFicakgnOrdgMEgUODyBLjbnDVGocWTyOPDfwYqujAswvGlKlZnyARhSEUzfERkSyErXab;

	public static string yPndskRESXKWddIuYXHLABzlQrpzXQonJjAxlwyXbZcBuHOhkdGtppBWqcnbUrHcIwmTCkjCzKKAyXQiDipTkUYuIDhjixcJsaTXvUFZUdUFEayslexMcNRNySlYcZtcHaiyeSNJDpZgasPHfPXdZqHFifyDIGXUJSXESZosrOjMOLNgcDSnbpcrtDpYtjaWsewhvlPfBFLlgUQxssAeNKTuPGkpKpYiNmuKoFKRONLwDRkzMSGbIWjIlcrObzvlGDxTzgjMHJqaYwQYvKDRJXzRdL;

	private static float zloVPorzQatrZGJTtZFiJOmttqWDCIeGPOGXyMUbIyFQFdKWiPEAlVcKZVCyrNXhVMBlZMvGeDzlivNpFauMeEvULWXCjvKVByUSCzXwtXvHvQBDhmSrskdrrHzcOSxJTEJKBVNgcYtgjNyVutvXCsCruDB;

	private static int[] VZUIAALNRhRclzMpuRXhDiEIuxzhAcspXuShhqSFxaHODrkyQdhzxvXNumndaDmPOBeRGEheYrJDAQednbrxUSSBweMUcOFTNSZbmsRlVdAgLumEikQZmPUVJDuBSmbkMQPIRcQUkgBQrMPcSiMSYFHXXdsJYpsIbqtVEENftWPgneEXNsJKAilgiRKNKhVUNSOasTxouHzcQBKTzvVGFIiTenNMTZvlaUsupDETVvpSJjpHhRopmpoeKVWfgKuumobWipEVQbLkspjVXgFcLfZKFoKtHzNkaUGvhtyRnsykEeLuLbiZfsJgorqUFkoroAjyIONDHNPtHPgACqHGrNfIlAgQcEmcdhVeUnLXnEsrDpzzlPrpDIaBvAmiIWAdBMpzTcGpEKsMvNfVbGFmmXzuhuItbDordoQQaaGjjcKSqnfHvqhbroQDmUrytmobvaIgWoVbawckmGeUoaYKwmZPxnDfIhPXOJwp;

	public static float EZLgufbVlGqFQxksnDFibTJJKQsSGfvDkOpppSpqleEQWYplXxKkdooLpbvENjogkNvbhUcvnpXWpSNMAhViukzVAEZowKDcPyFiCodcupWOqrvxnIdFnfLanzACUOYDLVgRmEkmeSNfnLFijCaNHXOJNFVcNAhGrtculEkIyQBvrFMCUrtsNkVOhweGJhzDKhOUIkXErrpQwsrhTtivgPTgyonOADZqrXLkRRTJuPavVfrOeWMqZdxUnHwtWjeOsYyzHhqbzybrPxlsXyJDRIroAQWjvzNkLmcWHShXGKQBbgePwdwxzAWJHkZQkgGZKQFDvoLerLWgRPmuLhNscpLkptpwTrNAeRQkABuhssgODQRRXFedtnWvfvnbZolZYwbaYbTkMFaKiXHzBxzonKgRUvfensidggPgORTVLUrNnmmiOOABPXMoqkfDWOWtxXEbhAKKEDCsttDIiWqzSGniuBQ;

	public static bool ELqZWXXpqHkbneQXmutUWGxuayxARJvHFKgZoDGvvenaXVducIaNaGTXnVZyAxxGmDvDXRJIOYzStwxeucyjIHHYQjLsEiUYGHOuzAwlZsZbhbERyUdyYoYEVxNOfqeFeBlLHcFUFnkqHFROETUJfwZsJkycNHfInuXGQSjvpjSLeHWpFYklwuAHCTcxEChXhBcnIkYMKyuWEnobniwOxTmTUqeXPMRMbUECEJHuaxBXZEdoEbjvgsAopjssgbWYHIUJJLwEAbOZroTqnPsODvGJupmvqpnYBDprKtFSEEUeDAWaqcerIiulckptzbnlNPyOYBGTjzjYBBfUsleokWpsidpzeltDqJqNbib;

	public static bool PvlhjZwKAfvbnXZaRAgFVlgPYfGHRkrSjjoSZOgtMtPuIkgFrIznVDgDpvjdsPTpNCRdIhactNTBwMgOZaqiLdXGcLDEFcaXAzGgscXkIwThJFhCoudsyKDJFlaXDwxrNWbWfavXcgAokPWxDapkZHyPWXBhbaGlZCuNDlxoZgpsjozPoDtDgmrfylaizoVczopHuiTsDblSrfGHxLSyGdeMkppskpOKlnSUZSufJbZfbyNsFtKNvwvwkCwfTBhnmAHemLHFqMPFdZLLBXMRFboOSwKwvpmhTLSARJfULewJHPskQKDWOpIklTlQakkbAHMrglUSRSgAEFgddzGLMptDdHoXxoTBUvjadbeFPLeWjiGGNiNAEzpkoioyWWuDYEGjwgZbvaVblwtUbHkpBtWvgYMUNFISqBXECwkHiLf;

	public static bool DDoYROtwoMfbFIkdxtfoPscKJyOsFxDgQosRSZUgtjtglAsWrsMndwplBDpsZbRRiZkrptlxzZVGYVzjgSamKqcuYhpoKCgrsCYlpbGYhoOeAJnGeflhaEgRWQsidXNXSDovWnTflcfv;

	public static bool CXToTJkEqYrNwgozIyUkBQlXvRJQlgWXyKpZWdouMiHUmAZQYuxNiVULLWTbZusjctoLRpCEjAxtjrLUSTRRJiPDQDnaknusPxRSlnYJRTDHyABulZjgCBATELVncCtWgeDMzTIEUhZPFhfpbTOldnPoWXnAsLHpzHBtXPUsqFluCKowGGliNiTSppPCFiljAJqYGLslZwVxbuLmJQUMzyBqNIdHasMhtcUSupQUnZjrnvQUDDSPozJchZkXHKlGJNdZATRtaZyzokdsSjdxzXTUsRKufTmDOCHzrRtKLyOoakNXWRfyHNhLUjGIixogNVKLDDbbPsMbiETieNynONVavV;

	public static bool FikKBokIBfzbtsQdIobfDppyEvYasZZKpHXSQfRyQAdNIctfxKfHYpsqSMggpjpBgPLMuXnDxDpcmBPCbSDIUrLaoHaeYKiHlBHTqHLzxBkvaqerXDewGGHPdLyNXiEMuH;

	public static bool RKUVmuhdlshqZYDJhvFMbEUSQEjXCoXxaszuxbrKoCvpHNMzkobjhIGmPbfHlkBXvJpGyjlfeVxziFkcSJNnmOqrMmEvWJyeayUYxfaacWeml;

	public static bool hdkRcPCwoKGsYUmEQjvwsyKLmEMIMlqJefFitETTWILNnFzlOwlMJPTItzFydUJduXoSodlmqBzJMXxGfBTqZDaolWPUZuQcYIsqrGWLkZwhpjVvbYtCatdRXZGsnqnVLxLdEhpyEifZgSYcatSabobFEBsrZExUMBvSyRRTJUXSneKeaErTymTxvgzcOXzaKlnFwgEiCYrhqjrARoqumDvzHYwrsOeLuXhcReIUairzUMhmPYlAGeOhPNYyJmQOTGMtcoJMFwudmWEURkCuCEeqjamdgjlNsDGoaNkApyUkJKVTidGyKwlpCvjbcFGwlHKIqqUdacfdJTGyftVcCMdWrqMEEixJSyZcZmDRjDyHrhGIPLWJKETyDOrZEpzSEvlkUEySPdTZovFjKePTlOYoFBylUDnTeFcVWvOlmdTHKUkiihpzAGGQxXFtfmYlPZVItKnoqEGhUqD;

	public static bool KqqdNoOtyZmxYQvfZfHSLZBPyTbjVZzVguUcOjkXbFwJgmoxVyHbmyRLPBETmExyAqqEWsrPUKRfCSIlFEoxrxIICinmFrLxiYjPVKBChRgCGLjWTsoIpagcHHcNfekDZuXEJSqVcMqAqgcRZqtmdchhRghoIOwcHDDmNEnactFCJGLBFlNPKYAWmQNCKcnoqnSNCQdudtjKwFykuGIw;

	public static Player aHsJdHZXRKqagrmwOYYPhtMrOPzHrDhetQoJVjJVQfCtdiEfsbvwHSpGUaUnhsFoClHqcDBEocZcQsoFluophLwAAHOUpwOyzoQRBncPARiFTnQCMobMdphRPgPvOGpSoACCCxeXszPqDRGnRmhaubukhZbvyHaUBqqsLoZpkeuEAQnYzBECypxmgruCvIzKyUOnAoCCmSPqHQJqLdVWdyvmSem;

	public static float tTwTBEJfFbaxlZbqFzhFpIdQsNCHazCuvbjJPZoLXKdoLFJXciPMLzXKPGAOcbfgzGckQrAGlvHEFOfNdFFSJQIWeyTjyAJVFWPfDzgKHjBqRsfbANKwwnxIXffryqhLLMZ;

	public static float IYakDyVkAosfMtSJLPmzrzhiyuOlqbPEesxcADgYAdWuEZtYGHwVznIiRSMjJKTyyObtVPjhIoYoCMDyaPFJFTeRKokHRXoQjyVPYZdQyonlouFeoniTekTEJjJGFBqLZieeROAbMOkqGTDqJftDOuLZFqfOpwlXYCmfpBnANhgqaDYQGtXzhMWExfyBILLqDmreHxaiSSQHovZcspiWyLPlFHIkcLSbvQMNlTjisPH;

	private static float oWpqbgwjsCORSxgzZPQfhaOlxIlQyfaDJdApqrGeFBzyHYUpfujsCJAohdStUFLnCliOWQiIjLAFBpEzOWLdVHaZDmimynkZQmWvPftolBjQjVMRztEXUHrUkjlKIWkWBAOotiKJDxSuykQIzqNfImfjUclGUIGprmpIhxyqJVuwOXvasDkrjfoovEtrWdPURDdlUhAbSwwMRIvXGlnqxofmYanCdgtFgAFlTjfkcjzMIBxMjwKLPywCxQnUUYXLcQFrdjewgcooPsDxDBtHwIPIdcNcWkqelNKSVf;

	public static bool JZroEMkhNenPrtEpptaXnawbzWMjdcIKBxStpidcxWpJPgSXzVxqRYSIDqOIaaeLwCoUAkZhpYzrKNlsdPKhErTCFjQYtvcxREmmSYwoWqbTyAXQfvFkqXgeJLoruaNUVcAgAZAetvloqaeelZTYPRgUxiDgJeUVCgXwaRqgUBRVLSOIHkfuhPfdVFJrvuuoBpLjdIeuJNdoaliEtUyzYzONbTAuhYKAhDtwhEFZfLKtLRdKxfXBWUpcBXij;

	public static bool hJmLdDhxRMwPpytnOvckQPXcajEmnrUkvwRwzZpiKGSLIilxAcngVYtrMjKUZUjARmuTHXNOfUAjXluSXgLleNpxczJqpviPxsTwOsQCoybayjuAOSXSiXveWWQhoxzJLKMEsYeEqjWFMoYTfiBxyqGzWPzRCJoRZrpNxPiQNsCZaQrIXXcfWclvdmICzmbHUfFvYlvpaKJfNHyfxQTFGiUXfUJkhFrAqVeUlWJMBMflsgHwOCfItwaLkIpeBliutiOSDDUBggeTdJEYmnwEAIhUUsJCGFlpEKRksPTkIDBnsgIBdqRoPDUKbUXkTrUAVOptRuGxumWWgUBOKiypOWAaQhjySIqqJbrEQoJJKtTCHXDhsizLSEMYnpDKkiFLWFnfCXXwzPFudXsSDcgJiExepsqBLYzBOhGcJyEuldldZrVpWKhicWDrijQkHvKAqdGVqqjfxLxestfXxaFaRqzREpUAHuMPt;

	public static bool LNVKaYGBcKqyyYOdSMGQKJZEOqbwIxdZHLHGjnxbZzPFjtfrfwOHgZIbOrVJXjSEHrQNqiUFpEQlUuuvlJqmJvSIcFSSrNePGlXSCsbXCirBixhtWzxoTGUlyiKKpboBAbEIwCTTIsJAeqzExyVRpPWaqMttHqIAUPbhTzXuGEFAWthhIgnRfwmKeEsJizlsKjGopsLYABlKjvdWElLAdQvyDrcognlgtnQNNTSpvoqEkBAJAvfWOKoUOhKYqwSmpfrVFqiLtvfOzQocQtNKiosIYVZFjUZYweoejEdkmtDsFAuXTHhWIhebNJXJrCCzwhsvCjTmpDxOLZcyBbMBNcppZnrzHtTKRdWyiZvKNUHfJppNGyi;

	private static float pQaMtRdvoRuEVJNWHcEqBGcOSvkFKXDSilETRrDGfDgStpLvWsIKbiGIOmUXHxLroBwKfTfpzYkYAkuCKOJrpTQaEVfFxFZHSPERTapcnskdXIiERrnSOtbvKvfkOzRUYDfLFCIJyHeWINcWNBNfrhTyNjhyVfnNAqeuCwYoJEthpeMXsiwnLMDRJHXwvkOttqwrIItqCzwNNLiIwkfMIabONmKVzBTzQaNYIvoKOgKmpPeYyoalfbKtpIEwXyRbFXXMYjabVuXCpOyXiMwkBItOquJZQSMqoJHsSsZooZpKdhdAjHnlcHzWDivDAakdHHoGhfeQMhVCtJKjriQjEBnGjKPKWwOnO;

	public static float lcwSwtdCxyULXDUxmmskbzgtHxwquTqtINiGoqUOMGhcsVlhVnKjvdMMWclZWNiDiBdjvniVsDxvsdbMlpvhjgXFbvJmfVRZyDURScMHePRSFruTbzNHrbucDxiZEWPwLyWOjjTjCOcuofaKbPkGhkIxjRnuUMchZugguFKRFEeCYZOyxyXOLipBQzFrWypPLUuTYTpwftbCffzjdPXwPowQfFqVZsVgpoRdFUzDiBIshNvLawogASaxyDOtDuwNyUmQnwEipunnFeJrjFVDeOFwotEbggaOeVTmBFxESfQgFMRuUxjXzTIJoPCURCbjtziKkwPDiqLYXzRBCkhJWcolmkYLdCMpeHMfDhjxHGPihKLPXasHvrnrkXxaydAFEvUqMLXuaJcqngdCyiOdkfTMtvVGKjZDfkEMQvdldXGMpWedTVBppxuyBhWqQqKQKzkdCrMdfCZnzhwwrRNPIJnIPfkIyMvMnQbQMbBBiykMxhZuKA;

	public static float ZYDUialCnwhdEshnZIfGKpplGkzAlIgQXYMwjsHbEkNfueTRFjhqodPJIroXAKqEprgGGLeHbdcABkRBrIVbBPCTicNSeJBTTjPdYmkUfApkbphyzMGROpdA;

	public static Color OnyDXmCrCiGsvODexbWaArRTUpsrdKfEfpoLOHWSXYHSIPcKjCtNscZwvEIITloSdcngASqQfddCKZkfmIhAqrldpRpjYnZMKPPGBWjrmCHoZwMwuDwldNBLQjQJCgSSeqSUjDDqyQoNKWeSeTOvRNJWoeQsfAPfKPkIESmRZfNmyObTfXFIsxbqHVGfNlkYajcVMvolHXvLawyzcWmi;

	public static Color UgNmOTaImhdNUPlpLfgKItbubpqlxgcRZcdUvQhTvGYzTHQlkjOXPCzBfslyCPlgemOSLrTVYnpcuBBtyeborfbxDCOdEIqFuSuGTYzSpTYCmwgDRRZxNWOZlrpjDPqqWJHCgUAAFiYygykgwklNISRyevvCJppzCIGDODwXqySFXpSMgiNsECHdRjxLyYRpTyVySGsSNoxjamAPCJvACWVaaCMEgLyrHDLztuTAPVEpfxdEJIiPDqNXDVxpUNLcQfCwBbviPULGsGVDzhVxCIOqQOWxWDFcjCyZUGcImZaIFgFWaTQMSnzirlGNfXmloIwPhVITfnk;

	public static Color CHfLJiZxcNTjVcqIJZoDpNOtWKPOelWHFcWAlAXEfzjyvyANRnZTQKVPSLOZtktRQlESgPxicKxPDqXxjcWQldRU;

	private static float hhIzLXlVgsHkTHGcQQQfmglCNqPrnCFNtKLZgXxezCJlJNEBvUavmLHaVgLviTHDMUQjWHVStMGKxZTaMoVtBkAHcKdambWFUfyOWuFOYhbAeXDWmLITXnbCuihlEUGrPbPsBedsJhvujZCfhhNBtdIHdWuOmtjdBKLdhluiHqkPSHtuFcexgfYMtioFKpfpYrSyozXVMFTdSSPvCZijpMWvLYKYWOyrkVRAOUggeiKBlVTAtScKhWZlvwNpOZYXhBSXboGITbehbvkQfkFdMNkoVFerhQsfjNtJcWzemuQfRSkamWkDuUlt;

	private static bool rEbvkoAdJZXobAOiLARrXexdveflGOLoBasxVdUXTNwSVVYLhbSTdUwmhXafjpxUnINbiqmHGUxkIFhAgtdEVSlHEfqXdPNEqBEmiXDQPlniwlDCPzZQlSZvwfwdapDQhTThaVriQnPJEdksBOhDPXsxBjQcAAQAHwbCrwCUhQZYdpQtUeBlhZajAwFQfpHqwpcibIafmmvZXttmtwhvYEsHvRbVRLPSiJCOnHrmewZUEb;

	private static bool mhctxIimrRWuMkGenAwDQnRFYLeUrCFxdtFUSxohKWsKSTVhGZiyxalYpxuLEnUOmyqsELlQmpTTVgNeQWorugadiHEvdCCwbDytDCCVOsmhhscjKpUHZDugymkXgQNJNwRrItBotsDbUSWPEvLNIUxyjsVrrFOXFCuKALAqOGnGaslFputKeZbSZtiqykWOEFwrympSUvYbGQxQgpbWleTFBBLhDkREJzcvVUhdfAPJaZliVrjijaDzMRQWBhpKDurhOcUmiXQKojEBqCllbJuJVCIedlCXlfgGIdtTwXaljSlCnpGYWdIUZIlltQiWuSzidYTmisPeIjzdqgROEEbiwmGZRizGOdRrtdzowuPEoElQiiVnYusQRrMRrTuaSipEriJnHCrkPxTRaPQJnmHtLazcrIXCaOLfoHzazHGwcibtxUQCcLNGBWS;

	private static Color qIHWYFPkaLOCtqQjFGkqDZfFwRuzoafEsOirSKHRnXaIIrxmmBiZqFprCbzhkpVZGkkEiyrUZtdFYxWfuinNSfnNzQPQkzGYcbcyhTeOknaXCJsffuNcchhAWwfrJAJzNeDXvxXAdyDFfqkPyK;

	public static string KQMDWUTBBKNNfJDAjxguJIxmYDECuGmpSYPTNjiJdTVnNqtTbEgNJeactAEsprgVyyUgTJNaoxqQMjzIkKAQAyFOYMAnEPtMMaOowmarRfymNkqjaWiERquZSfigjAvzdEdLuklYKjZuataNwrmIHOUvFPwqeTirJZijhFOQLjUIraZyfuKRnNRpJHfFOVTQbIKakRGRDwXxUmeFPXlJjqdWi;

	private static Color TzzzibPqdGJqYonNToRQtuxDAPRJjHKEOSrrhsuuhhRFuoQJXWqblfOycWYskfgvWeBgWVGBTxJlDRilZiMnrJtIdTpktcjbbvJqNKMbqPhOvDUlOMtctSemLTd;

	private static Color dGvhRoIkihRyovKXBBFmAYewGIgHirwETHJvUHqzNsMdWoeHIVCLgGCeBYAihabRKnEHMpcUlfzhmbAsEzYnOLyneETWghsMqVsJJxVtS;

	private static Color IAaguSAyiEIbOcZOrChvgNdMMRqJRJgDFuflxgJLtxYDKKBSsUrUNXMVxnuDCRGzxe;

	private static float wuWOqkSwcIOzcbpyqWrmQHHkOjMgjCQygFohVEDhcrVdgYlsodBKikoONMagyMmzRpswNiCLskkyLDdPYuRfbgqVrztjEwIpevlQFOEgBPrYaPcjIkidVhyLZwenOshWBUuprnkjPLElPsVCwkBuoEuXWARiKrsjHvwfvNRuZYokCnVGBBQDQNHWAwtRvbzysvDuVPhJtgupqkuJFlHiAOsUNAFYuaZYzPRhJBKMugjKssFqbJmkurXDcJHvjipthvPAsmadAUNtFIBuUoXKOPEiRneZTpClRQDXCfXOIiJzDEYuhnAUlEFrRHIfiakkrC;

	private static float COeERPricFfeEnoJSGOIamklfVwSGHXyhbbjpCvLDcCZmMcvQyiDwJBqDTyWtyCuHGXDmetpldeXJlZtSbcizucxzLGwdzrfAhrFPzjLeSssFDGsUfdsvuVnEzdAyXlLLYxCTtEsSqeGcKSVenBYvZJglebpvI;

	private static float mgHGGGgezBBKAfpplUHiwlwnqMprqPsoXjeXZvdlPZOawKzEQWTgHnlbKtqUrPNKimNqasqPQwswxwQFmKBuVlHJYdnFfjTaldRkWjDx;

	public static float FeqlUODnDKHHotOWFerXeLJGCsltEGJdgdORVwOkzZcvCmMSpVFSRGtUuJIBDkJWbDAkEWbiqhyeJoeqGsdIbRlAJUxlOmGppfuZLBntUwBKholgFrVkgbVkraAKzPudAiPDTeFffKOFpBsvIqFwrwjokjHLaCTebyjYzHmALPevmqVPHfbjjXMdZAtKxUfCQJDQruWbdfKBsNbToReVBKUdMgYYnCdRKBEDMeymiafenkLmzzvFPjbgOzelvYNBcTRQjyhktRMBFQQCuMzNgxbAAyOmZmRkmEctsVcaslmYwABYJCQIzZuERqpLKUkgZCoaOwjyJyvVkddaWQDxvjKmjxCcGrqybgYUlAjmtsYaEztNmpOUrMKQRbQqTgSsiWTeejOwGqddlKIKdPPqDwhovickJTtmzGSIFpIdBrnaIGFhtgmerBOLPFIWhDMMXREERZeOgMPligFPDUQDGoUXRhSaGMVXFAd;

	private static float RcaptbyYFMCCIZTsnNjgIWGMKheitQSGHcONDEwCiqplpEjaMtIjwuvVvnFmWpEOTWVGlgPIqGYsGvxgXdvZhIjnHSrqZkFSMArtJDOGEaTPvdoaPypSUEGlMHYsOzIfbgFgdextpPvhOuREErABUMYhTgGbEwRerNNpxiWLbVDeizwrPuNxZhlpiymWxvOSYqPbGChwuPAZiTYuKpmkIufkCyhZWanFhLgRJvLnmrckHlgozRlijDkDlFyiviAuBURxMhLpDYYqrVDqrSzePfvDACGeWCSeQIIMtJCsgVEkFTlqchQC;

	public static float IvEvyoXjAGsbgTzJmQWIqhYTBlXGrqbPMpvvdmnfLsRzCDdLtC;

	private static float dlkhmBxLUnqqSkFDoRyeFZCRWYqyqXhmnOmQEFdUXssaOvzGUZpmnoWdItkokYuWgecdXOZINDhnHCcByJErIUYYSihkvPJYXvTKsvIfZGzKhIwgqJPBudomgelOHOnYTiqlIsicazrcunQkMbTMZiEThHDokUxltBQZrkxYANBVLlRSnbcGUAYLEwebOTRgbgJTxRSBEVlmHJhVQLajRRqSCfuVgvjHVuTFCXvwiAcZpMeUoikdTIokQQqrwXviMEqmPCsSqEaqOqCQbA;

	private static int GXlgOmgJPMGdZlfUnLvSfMQrMoHYvzoAqWrxWFQdggNGlmEOlUdRvjvThTtzFiopxgNdUHXHVrMYYjfAKTNAvwehBxqdmqyXSxifzBUDXwVexwUYNSPLvNUabGBxrUuESOgBaaaiZjDZBaKfCsptBMCeDhdTawlcbqlIptXNSGMlkUzbWwUZFadflcXSXhiCXAXkObPjuBBUarUIIbXDCmxangxnveQKyknJWpmUGLEdzifTiokVkEaLdWWIDCNqLRwPekMsOcXQItBfbDfgUUzUkCGZsErdXnsHMpPXCRgiGjcJuRGZxGwQrBEBDMakKTSvbUsLOhDcOrnbzXFAYrGqRCqkLnuQR;

	public bool WxNqHIAyVlpdtbZoDcGhzmtnBDzEiaANNlSUAKSoecdfqnxAqWhlNJrKdAPdjWqUKCqijfNTjrcxinWnfZnlTpZdTiQaUOfhLivNXpqkinbwGUBQDBXkJebvDmobpNYvlVLaSiqQIcdFnCwZHawtQVyGhZkKapVvpGkLiAXvkgBGbwiaQpuoqFEpwfTSYFQshHqGsKRgcbiJuSFKRjUKVGfKcUpdHfxFqjyugBIfyomowUVEAibOLfxACFExvNyXEDtktkEqBOmHtQnhZLDzdIUkLYRAWlKKPpKTAKkpD;

	public static float LnWTPgMrwxKkZTVIjzvtetpeBRefuHoAnVsvYqWRfizNZzQvPkrlOWzrXRrXcGXPjjWdBzKSCEnVTCecbIqkpcMrwaygZYOylKDQCMUpzyIkIDxvMpWuqMzgxFHBbETEPOKjYozpNaKRtBJTCctJcuiykxsXfsnVFeuTSoxyPHGqbIMVVNZZkjCvGlZBVBjuMPlphQanFVUvNSxBKxcrtoLvCZmGpVCnxlDmxxOfNLtophHOOxRyzSbxdPNiDtYJtGXCoke;

	public static float mJWEIVwgvrySRedNFkfiHJFCtMJVIjfzEtEPDosCGJsQeBhFpSssibxCdukWlBxmmZnyAokrSDCYrOxRFeFPQNqCWbLidwqflgEfnIfbHbAFzzloXtqhVHvzILCyCcnvnwMlkrDWZEiOnLcwQxlKfjjDKfxCgGyFOescMaeFPuirzHmXJfIfRDqdnjAfUbQsgDajsZKPtFVKaSddTzSbYtNkNoPCzZLNEQkWGdEJuSLlIGdvfxlujO;

	public static bool tMPPvekhpuUigkHgwPViGgHCCgltxcNqEPwxhRHAzmCrrAzSNYawzainfnnpSQKnGEDrOjZFiuJtDpkcHsGycrQDGjsUDsHJCpKNWieEZvnfqOJPckHAkmkpNaKEQfbQNaRoExgyobyGdLnSADRtKhypevZWyzNUtwrqXukEejliNDlbNSen;

	public static float nIgFBBjjxkZOoEnGtWUftmoAVqCAjYjGvzGLqMPvlahUjxTiqEHQXZUatFJkZIazbttOYBpHgyUsftrywtkEqsIvFGrLcEwCaITQdfkPpaJyfBUZolNFyviIKXjrjEECcrsxAAurjupqIkqdLsxQQQdEzkfgVSGKvhwNjxzNRwwdgRaAHfGRgOLloNXpvovqOEVBOCToSKZuuZyIkEzPmODHwkzwzjrDagpBWzMemsYwOqRoppfROFeZaneDdxOJswtnKWLLRuDUQhSfskgkdAOubpAIuiaODodsWDEsEtZubkjTvZlTqDFSIZmvwcrItPqCdAiOGOGJAtsRgGnvXhxZIlKXriWBcqamTGQVQwnCXVsoGupPOVLmrqTSPkwxSeHjtgXzQsEATVcMTwrXTgNgFNUDNXfFaQJToi;

	public static float UAwPYwrksvogZtTzDLrAEFluLTmYAdmiyKBQAeiqPuuzpHYMMAmXCODppbefksKojfIoRcYzDaKjkLfeUzmaRoGJhmByZcfwKgpjYKUJBNuBdteDWZkKgKxUzYhFBzzAVnzewVfkFCydUfFNiYCZSuqaIvKaDpicoTGPUZhaUafDlt;

	public static float atstxCXzIAXywblfHpuvPazQSiRBfSpMOouqHjSFeOlfSvDgPPsPiPEZUCAoLvtPlkKhGUxyxOrbPtXwFLLqzzEYKvvfIDUJuvUHLvzVrUsuyDkBEdJaJdqLGLxlyrPTUIGuyqLjlQYFhjzgkUAEUTZrfjbZYowaeyzQXQcosAPTeKDwmqaERlZaIoopoLkWuYAJKJjuRlltegnuFENHoRiTyzhIBNZHpSyfkUMDhFNFZFVCbUKKXDICPHkkBA;

	public static bool TelEelHhjKSkAIeDUTDFHGcpJMkWpDKBbGLJtuBJVTKaSNcZxmMrHVTnbWVrbKRGaqiUXvkzsTKNVcxWJkzdQsTgMyHxzjIkcdZBEicbcmZOlfrZyZIQlNQHwchyOMaikzLRcWrBixbDtfUHhIYzBRYonseBaDnpmQDLtzWCHgHOMmnriArfOAHtAxEKRQAFjMrDCinHLwSukkCaeNtAliALiklWVmKRFcFaVKPZnJusIniqVDFewatblFvrXqMyLaOhFBetXunCNicVbUbrGGvFJEOppx;

	public static bool bWXVGHybKtylgbMRncDzqcovSfFiybNPezsqESBuwZkISuztTSqLMPhZHCdBcpDJFJhGJvmuAidqSGCxGmpGKbcpstJcPashwAcinSJxFWkDMRgbZFUPZX;

	public static GameObject ZEHSopMkFzQVTrDukNCSaOQzCAmHcjgChzByBvDtLuqKMQXOxFvgmhWlOhpNcehwtnOuQfSPjjgFxfMLCyjxNZqZCqKtfQrGnUrybDYsMGWdbqNIvDlEVKIuXPRAvzJtSAsCOnKZzRKgcmYlCbX;

	public static GameObject BEMLDlWBmMyWnXClAYkTiTmfdZBsLRFXtBiPfOPrRMxmbUxjzbxnrhPHsGHDJEQvgACLONfMjTbvwZdjCsSKtrGmLAwyhlHnWbgArLvLVLeyfultDybrLfbOUqanrGFXmOzuTDRQXhOInhgrpdVIkpBQZrGaLhuoghmrUQAZHluErtBMkIYoKWMWmIuBWQeQNACgVOwyDVbZVXzGQTQcigDjuqfmvYdQgERRRvQwmzKOV;

	public static GameObject NaojOLcabHGWsLFJkdESkTrgIOucuQJvPnHpQcGmaQeWkUyKlMcwfWLTJiBZqZFlYlhfdqThwsStOuVNqKRHOmpSCNGHBGVakTYYNtGVTUZNerfonNJFiYwLWoCpJlGPwRiUwWZXeWOTnBOkIsuNXqSmwmczQrlHojrmikSqNLBljCyuzsHrRSRgYWxjUAhNLhFdkCbxAdZmOHcUOIayJUPwsknmMIwnEOAcXujWqjRNSFrrTDvlAIdQriLZoPKRHMHagZWt;

	public static GameObject zdhAdbDMTWsjmkNVKJLOJjIByZggXqkUHbMwBDNpFYgsxBEwYMpxohJqvGbdVxOCLyBlyquhWvjLcpeXuJhlbNFzswbUBJuhjDHYZtXHrhBTYYnfCeJlpDBYTcScpAGmabBzIfXaMAUTlLAtjVrxajRGcIfXBVsRBpTWxNxxhIzPJHMhByTtiimQjUwZaZzRhcsWREWvyUqrKcXvWXvcbYJscdMCrxxhjHHGoPqXByUnSUfhWbdcDwPjtaTORuebxiicurggHyADdvzhXEFpuuDMSynoVBghuTPKMdNFUWvfVmfXALRmOOGdFvkVeSkfrtjjFPvTRZuxZxQFtpNjJUsFnMerSRBcLpNCdVsLqXuOujdhEFCOeawxaDWSKebZxrLKJnBxWcTLzEl;

	public static bool eJXMnpMXKTqCzYzamWvqcxtxrdeSchKYwsSjNrNJLtaQtLbyxbGOdniGpzvkkUVDirghgqnUjLFIwCeFbGubBVVjjlTnWDzQyxHcFUshNLFsHAkMvPiEzTbnwWXUwZXGmPjYUbZgnnnPqCBJbhShuUqEvuFIXyKNNZfSrlRtPbqmFmXTvnSphQlryECAvriPDAbrxJsPpyrsDeZjxMnKFvGXNOtMJrXySBIflGwLVdZIzSNuFtcJdyjhUeDJpGgYBSzcvTYRqBOCvXyVaZgpoouurBlhcNwpXbhGsLYMvltCJHLWGHIqzQJmyfKUHRODfzEuPRDobuUdVSKKPoAvefPgsUimbdeEwQwkcrhOeuoeWFrFvZftqtyZJybUJqnXqqGfwzHxhMqKRLkMDDRbYKndrwAEpmfNgqOF;

	public static bool YmjVrHlDcOiYnprgzmZFcDNZZdhVHCDAXENqtVJqzKbCoCqaUYoUriDvykWoAqVzkIbJBbMECJgsClKxNgaIoJiObsRjYvPiOBrGAHzSmKrHclSnzzBtpnkBznHjkDFhTXDaUeWfHhwDrBMQzEJzUwTBrPgnZpIIfkOeHStvDvLhQGkYBRJFTgnxecJeXIfrzNygMHjHkoVyKLKKFiM;

	public static bool iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx;

	public static Vector3[] RcbGLzFxExmZhHJiWMcbyvGLGdXuwBmegyLuCPJqbyjrGzCTYZXZjhZvwpZIBlbdlhTIWoGgcMaZmofhAdwwDnVYyqYmQbPQwfgzFUXJtQWwhZihkSiyPEzXmVjFpuqbWjDhiGBFfMdNqyQzhRbYSrbSFimJKruYAVAYwbYEqCsdAMHNfKyxssiFiKBatRVOrenvYScgTx;

	public static Vector3[] HqYYrTBzEaTWGhMUQLAYlyGELvzlPnHrEVKSGjtHyUnVUuyfIdcqGUljJunVtpJrsBsLxUnGsSzrlLJqXuDLlqLJJAilWxnjkWCsbNHNQvXNvUYXLWYZMYfbPJbWMbJVEqgpjqojNPVPtYoPClAayoxmQADsMKbOMcieNJNuHPmWdqIRumuABIxqSUzINWxcNgdqPjbTxftJbAjzSLXzpBmdESlTjfHLrjjWnrblkBdwpOosLZQbYXMmTaMXXiJsxHrSrmmAJMoOxQNQEThkoGMuwWcnFencRLYIwwayMqrmIYPdmVteaydRUXvvkZUFymWLSeuhTIxXoALyhZaKLjbtHhNzbFoNvMNwbdlhBllsbfCtmWnlYkTpkDdKrVgnuKCCNoxdOSjAYJrBEtmerdOlSxlxZAQGeXXrDaGXykxgatqAmBgXI;

	public override void OnUpdate()
	{
		//IL_0667: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a41: Unknown result type (might be due to invalid IL or missing references)
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		bool flag4 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301825;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) + (0 << 1) << 0 << 0 << 0 << (0 ^ 0)) + 0 >> 0)) % 48)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					flag2 = !WxNqHIAyVlpdtbZoDcGhzmtnBDzEiaANNlSUAKSoecdfqnxAqWhlNJrKdAPdjWqUKCqijfNTjrcxinWnfZnlTpZdTiQaUOfhLivNXpqkinbwGUBQDBXkJebvDmobpNYvlVLaSiqQIcdFnCwZHawtQVyGhZkKapVvpGkLiAXvkgBGbwiaQpuoqFEpwfTSYFQshHqGsKRgcbiJuSFKRjUKVGfKcUpdHfxFqjyugBIfyomowUVEAibOLfxACFExvNyXEDtktkEqBOmHtQnhZLDzdIUkLYRAWlKKPpKTAKkpD;
					num = ((int)(((num2 + 1956669763) ^ 0xE8AAE7D1u) << 0) >> 0) - 0 >> 0;
					continue;
				case 37u:
					flag3 = flag2;
					num = ((((int)num2 + -2071082168) ^ -1579730481) << 0) - 0 - 0 - 0;
					continue;
				case 27u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㫰㫜㫗㫖㫼㫕㫰㫜㫝㫗㫆㫐㫇", 1249131187, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("俚侅侉侊侉侔俛侔侃侂俘侵侏侁例侇俆侪侏侕侒俚俉侅侉侊侉侔俘", 1801211878, true);
					num = (((((int)num2 + -680051953) ^ 0x63C5DF26) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 2u:
				{
					int num5;
					int num6;
					if (!flag3)
					{
						num5 = -1723352726;
						num6 = num5;
					}
					else
					{
						num5 = -648580639;
						num6 = num5;
					}
					num = ((((num5 - 0 << 0) ^ ((int)num2 + -1377430272)) << 0) - 0) ^ 0 ^ 0;
					continue;
				}
				case 3u:
					num = (int)((((num2 + 337346832) ^ 0x3221B927) << 0) + 0 + 0) >> 0;
					continue;
				case 4u:
					WxNqHIAyVlpdtbZoDcGhzmtnBDzEiaANNlSUAKSoecdfqnxAqWhlNJrKdAPdjWqUKCqijfNTjrcxinWnfZnlTpZdTiQaUOfhLivNXpqkinbwGUBQDBXkJebvDmobpNYvlVLaSiqQIcdFnCwZHawtQVyGhZkKapVvpGkLiAXvkgBGbwiaQpuoqFEpwfTSYFQshHqGsKRgcbiJuSFKRjUKVGfKcUpdHfxFqjyugBIfyomowUVEAibOLfxACFExvNyXEDtktkEqBOmHtQnhZLDzdIUkLYRAWlKKPpKTAKkpD = true;
					num = ((((int)num2 + -1160147690) ^ -907161661 ^ 0) << 0 << 0) - 0;
					continue;
				case 30u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("冼冾冥况冢冲冣冴冴冿", 1967673809, true)).GetComponent<Renderer>().material.color = Color.black;
					num = (int)(((num2 + 85239453) ^ 0x724F22F4) - 0) >> 0 << 0 << 0;
					continue;
				case 41u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("叔受叏叝及厘叔叝収叝叔", 998724536, true)).transform.parent = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᲴᲝ\u1c8eᲝᲔ", 1584471288, true)).transform;
					num = (int)((((num2 + 1394277627) ^ 0x3F147AB1) << 0) - 0 << 0 << 0);
					continue;
				case 5u:
					num = ((((int)num2 + -1336085439) ^ 0x4CC65510) - 0 + 0) ^ 0 ^ 0;
					continue;
				case 25u:
					num = (int)(((num2 + 1285777375) ^ 0x253E74A2) + 0 + 0 + 0) >> 0;
					continue;
				case 6u:
					Application.OpenURL(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䌰䌬䌬䌨䌫䍢䍷䍷䌼䌱䌫䌻䌷䌪䌼䍶䌿䌿䍷䌜䌳䌋䌮䍯䌖䍪䌞䌏䌻", 677135192, true));
					num = (int)(((num2 + 1016054125) ^ 0xC0887AACu) + 0 - 0 << 0 << 0);
					continue;
				case 47u:
					num = ((((int)num2 + -1302358218) ^ -2005892494) - 0 << 0) + 0 >> 0;
					continue;
				case 7u:
					num = (((((int)num2 + -218260425) ^ 0x340883B6) + 0 >> 0) ^ 0) - 0;
					continue;
				case 38u:
					num = (int)(((((num2 + 1254180769) ^ 0xE4BE078Cu) << 0) - 0) ^ 0 ^ 0);
					continue;
				case 8u:
					MenuTemplate.Menu.Menu.gHSaVqheNUSMSfHLcsPHkzYaMgIAogCoqkeQwChirxKmkRPLNIVaYKNGIRoOIGPGrEvIaRoAlHqMOMQUrWNFkCpGxxhFotzLHdVFvgLWuvPruaSWbtwLTkwPpPlCKJmShFfLQkyklRlPNYlwFkDUWORxHfqGVimLjXjPUggRUlzcYHcrEOWzfrVtNHdKUSodEAGPPvCzeMaLpP();
					num = (1802649705 >> 0 << 0) - 0 >> 0;
					continue;
				case 9u:
					num = (((int)num2 + -1519429041) ^ 0x332AADBC) - 0 - 0 - 0 - 0;
					continue;
				case 32u:
					num = ((int)((((num2 + 22787670) ^ 0x35D982D7) - 0) ^ 0) >> 0) + 0;
					continue;
				case 36u:
					NotificationManager.tXlonxzCKOukmHceniLnjstgbPeLSuAAaIHODQIRmLETBFENAbfRuPVaEenytOJqoTkDanAxAUbyOAFwkqkRoIgkNGkyDjyxcnFHvaNnAIrAOxmezQncDScFNZQtccTqvDwAUXbjDXqGrFvpugZMVwTjlaUvjtkyObflbLjBPezGBvoiDBZWcguZJmpUdFajMSRqzkoIXxXRXnIPMMRIuovHGgBOwpxjdpUJDXIsnqZFjCcwDzirNrOywjJtIzmHZNOHsZmOdzveoQydeflWhg();
					num = ((((int)num2 + -1198723765) ^ -581157515) << 0 << 0 << 0) + 0;
					continue;
				case 10u:
					num = ((int)(((num2 + 207985003) ^ 0x5DF2C85E) + 0 << 0) >> 0) ^ 0;
					continue;
				case 11u:
					flag4 = !PhotonNetwork.IsConnected;
					num = (((((int)num2 + -1804281275) ^ -260070404) >> 0) - 0 + 0) ^ 0;
					continue;
				case 42u:
					num = (((int)((num2 + 917808478) ^ 0x61CEEE16) >> 0) - 0 >> 0) + 0;
					continue;
				case 44u:
					flag = flag4;
					num = (((int)num2 + -2057924117) ^ -774679749 ^ 0) + 0 + 0 << 0;
					continue;
				case 12u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -1712856595;
						num4 = num3;
					}
					else
					{
						num3 = -167052174;
						num4 = num3;
					}
					num = ((((num3 >> 0 >> 0) ^ ((int)num2 + -1372250924)) >> 0) ^ 0) << 0 << 0;
					continue;
				}
				case 35u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("輼輾輥輵輥輴輩輥", 1882951505, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf4cd\uf4e0\uf4e9\uf4e9\uf4ea\uf4a5\uf4f1\uf4ed\uf4ec\uf4f6\uf4a5\uf4ec\uf4f6\uf4a5\uf4cd\uf4e4\uf4f7\uf4e8\uf4ea\uf4eb\uf4fc\uf4ab\uf4c9\uf4ca\uf4c9\uf4a5\uf4f1\uf4ed\uf4ec\uf4f6\uf4a5\uf4ec\uf4f6\uf4a5\uf4e4\uf4eb\uf4a5\uf4e7\uf4e0\uf4f1\uf4e4\uf4a5\uf4f6\uf4ea\uf4a5\uf4ec\uf4a5\uf4ed\uf4ea\uf4f5\uf4e0\uf4a5\uf4fc\uf4ea\uf4f0\uf4a5\uf4e0\uf4eb\uf4ef\uf4ea\uf4fc\uf4a4\uf48f\uf4c3\uf4d5\uf4d6\uf4a8\uf4b5\uf48f", 329184389, true);
					num = (int)(((((num2 + 1892787482) ^ 0x831EE634u ^ 0) - 0) ^ 0) + 0);
					continue;
				case 13u:
					num = ((((int)num2 + -1403453257) ^ 0x6B1C5C9A) - 0 << 0) - 0 + 0;
					continue;
				case 14u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("︗\ufe1b\ufe1d\ufe1f︔\ufe0e\ufe1b", 1410399866, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꝌꝥꝶꝩꝫꝪꝽꜪꝈꝋꝈ", 1880401668, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u1cbcᲕᲇ\u1cd4ᲸᲛᲕᲐᲑᲐ\u1cd5", 1892359412, true));
					num = ((int)((((num2 + 293113464) ^ 0x51035D5E) + 0) ^ 0) >> 0) ^ 0;
					continue;
				case 40u:
					num = (((int)((num2 + 1866650904) ^ 0xC19E2FEFu) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 29u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("浘浚流浑", 1073704245, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("풻퓤퓨퓫퓨퓵풺퓪퓦퓠퓢퓩퓳퓦풹퓏퓦퓵퓪퓨퓩퓾풻풨퓤퓨퓫퓨퓵풹풻퓤퓨퓫퓨퓵풺풤퓆풿풵풵퓁퓁풹풩풻풨퓤퓨퓫퓨퓵풹풻퓤퓨퓫퓨퓵풺풤풰풲풵퓃퓆풳풹퓊퓈퓓퓃풻풨퓤퓨퓫퓨퓵풹", 1691473031, true);
					num = (((int)num2 + -707942051) ^ 0x111D0A70 ^ 0 ^ 0) + 0 + 0;
					continue;
				case 15u:
					PhotonNetwork.ConnectUsingSettings();
					num = ((int)(((num2 + 641832775) ^ 0x630162F6) << 0) >> 0 << 0) - 0;
					continue;
				case 16u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("കഺഠഽ", 496373076, true)));
					num = (((int)((num2 + 435749897) ^ 0x640EFD47) >> 0) ^ 0 ^ 0) + 0;
					continue;
				case 45u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("각갑가갗갗개", 1638182002, true)).GetComponent<Renderer>().material.color = Color.black;
					num = (((((int)num2 + -34037221) ^ 0x20767528) << 0 >> 0) + 0) ^ 0;
					continue;
				case 46u:
					num = ((int)(((num2 + 1198527402) ^ 0xE36B79E9u) + 0) >> 0 << 0) + 0;
					continue;
				case 17u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u12b7ኸኢ\u12bf", 585700054, true)));
					num = ((((int)num2 + -877465945) ^ 0x700C403A ^ 0) << 0) + 0 - 0;
					continue;
				case 18u:
					num = (int)((((num2 + 1115582667) ^ 0x47246B9E) - 0 << 0 << 0) ^ 0);
					continue;
				case 26u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㆞㆒㆞ㇽㆉㆸㆥㆩ", 1297822173, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("警譗譀譁譌譑譖謟謯謙譆譊證譊譗謘譈譄譂譀譋譑譄講譭譄譗譈譊譋譜謋譵譄譑譆譍謙謊譆譊證譊譗講謅謟謅警護譠譤譱譪護謯謙譆譊證譊譗謘謆謕謕譡警譣謔講譧譩譬譫譡謉謅譡譠譨譪譫謉謅譧譩譪譶譶譪譨謉謅警譍譀譖謅譇譊譐譂譀譗謉謅譩譌譑譑證譀譶譊譐譑譍謉謅譨譊譊譖譀謙謊譆譊證譊譗講謅謟謅譶譬譢譨譤", 1910213413, true);
					num = ((((int)num2 + -1845072895) ^ -1383589875) - 0 + 0 >> 0) - 0;
					continue;
				case 19u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue6ac\ue687\ue68a\ue68e\ue69b", 128509679, true)));
					num = ((((((int)num2 + -43473754) ^ 0x20C773BE) << 0) ^ 0) >> 0) - 0;
					continue;
				case 39u:
					num = (int)(((((num2 + 1609311921) ^ 0xE1EAE1C) - 0 - 0) ^ 0) - 0);
					continue;
				case 28u:
					num = ((((int)num2 + -2114552292) ^ -304471835) - 0 >> 0) + 0 + 0;
					continue;
				case 20u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("둮둥둨둬둹", 93565965, true)));
					num = ((((int)num2 + -1031415661) ^ 0x1AF6EE2 ^ 0) + 0 << 0) + 0;
					continue;
				case 21u:
					num = (((((int)num2 + -2113674766) ^ -165604468) + 0 - 0) ^ 0) - 0;
					continue;
				case 43u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("if|a", 1955266600, true)));
					num = (int)((num2 + 1780261500) ^ 0x8C392D31u) >> 0 >> 0 << 0 >> 0;
					continue;
				case 31u:
					num = ((((((int)num2 + -1580216808) ^ -150624966) - 0) ^ 0) >> 0) - 0;
					continue;
				case 22u:
					num = ((int)((((num2 + 37957927) ^ 0x54BAC2FA) << 0) + 0) >> 0) ^ 0;
					continue;
				case 23u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쁤쁯쁢쁦쁳", 1815724071, true)));
					num = ((((int)((num2 + 972230654) ^ 0xF8D568CDu) >> 0) - 0) ^ 0) >> 0;
					continue;
				case 33u:
					num = ((((int)num2 + -1974585506) ^ -294917763) - 0 >> 0 >> 0) ^ 0;
					continue;
				case 24u:
					num = (int)(((num2 + 1281213068) ^ 0x9FADBE37u) - 0 + 0 - 0 - 0);
					continue;
				case 34u:
					return;
				}
				break;
			}
		}
	}

	public Plugin()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((((num ^ 0) >> (0 >> 1)) + 0) ^ 0) >> 0) ^ 0) >> 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB1) - 0) ^ 0) << 0 >> 0;
			}
		}
	}

	static Plugin()
	{
		//IL_0aef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ded: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b45: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b51: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b64: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b69: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b88: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b94: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb2: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0735: Expected O, but got Unknown
		//IL_0b13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b18: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301833;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 - (0 + 0)) ^ 0) << 0) - 0 << (0 << 1) >> 0) - 0)) % 56)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					oXBfTYYkrAFuZOzKyVgYUORLQScQJEYWAZtNmtdTVsRBYDIRKRbLfsrAgQpbVhAMCJTZvMyeSmdBWqMmklgSDnRiISHwdbXNReYpKIwYtWSSoPDPedRKbIjpSLrCecbQoqJSrxCBPhyGuYUSpSraknMjVJwZrTTqVbDYfLxGBpVTjCUTQymmKbGbDAXIaDkVniLtuVNEuKyUsSZsPCiSGHGUuCuFNPGYfZFbQBzULIRZCMILAETxuroGBRYRBhQFeAPsmXBodnhYQHrIUIejVjDOLZAZCHtDRlVcXqyCcFthjpPUApXSdHJUWaHmxCLvTEgEMpLEkBgqPwEvjFzmKBzkCafWImfATYnFjlikEtI = null;
					num = ((((int)num2 + -645064961) ^ 0x779DB59B ^ 0) - 0 + 0) ^ 0;
					continue;
				case 51u:
					CAsfAwmdSdyLseVcLkOVYwFxRiZmYxoIqSXJjVEzwjnwvnUAnjwaPxKgUVosxaeuPQuzhmSQFpzOjibDnyYPbnSTiRPoHmcweSHESvtbqFuAYVWLTKeZbptBYBqpwEjtncKqBxKSfXyvSrUnUduWhduOzgGredEMwbnVkGkwZmTeRYIGGdvtjmmkIVRuQtNbtLYReYcoSYXUjqXBxZLbHkCjOdnpPPFGySKgZQCHahBlosarYqXQHMtiiPdaLNycsrvrFRCGxdaAJrUwcVqySOYMyCXjNBWmIyTXWJLgOrtEMTyRUHYPwZkDtJTdTsTVgNSlyXzsjjKBvtZEdfpgDgQInpDmQI = null;
					num = (int)((((num2 + 452787187) ^ 0x4B47EE94 ^ 0) + 0) ^ 0 ^ 0);
					continue;
				case 37u:
					iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx = true;
					num = (((int)num2 + -852338334) ^ 0x64954159) + 0 - 0 << 0 >> 0;
					continue;
				case 2u:
					nvxxxZbntXhFFnpJhaJoZNdMraXjYitnCBWodYVaDQMrZYACtDhDCCIzsLfxbRokDUceqaGjeJLjbLNszuQvaPKZSxWrSyYLBBNfVwmtWXzTRzxHXNXHbTkOjcmSeprFKZHzXIxdixycqQisaoufArKIrZVSjtpHGTjRSXJppUzEuhysUTSPUmfspZiXNETOiRwwHrAcEePFSgnkBCYpBzMtOQ = null;
					num = (int)((((num2 + 1559511532) ^ 0x6846A2F5 ^ 0) << 0) ^ 0) >> 0;
					continue;
				case 3u:
					CSPLBLaKwDKbLCtQkQxzziLXwkFDnIecIQOHmTDdEiKJzARwWKpWWortgRpqfxxNyItUOLDrntUrybyWtjHCtigtzuAuDmXhKWlRgWHkgXJCtZVfttXWPVuqBZutljNavNHCQGP = new bool[169];
					num = ((((int)num2 + -1883148872) ^ -1987818761) + 0 - 0 >> 0) - 0;
					continue;
				case 4u:
					xBxvvyEazzvbkpbsOBUqhBoZXjIgGssoMDzusAZRXYUTPiDLuuSaWqHVmxxlQxuhghoGPGaoCcsiHvjPGWMlAsrvVEhUcNbzENMITWWNuDyTXzoRoHFULiHOPSKkzflObTDTJBWJZYQWTyxwpqFuihNwgXSalLoosKReVuiMLVUMrLVruoViARFUfhNLIVxnKCEjGtAViSInmbeucBFXQfOBeXYOHwdQxGbPhLKbNaZHirHedsIhpAxENdeIu = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䬋", 707939130, true);
					num = (int)(((num2 + 1603745309) ^ 0x6EAA7050 ^ 0) + 0) >> 0 >> 0;
					continue;
				case 30u:
					tMPPvekhpuUigkHgwPViGgHCCgltxcNqEPwxhRHAzmCrrAzSNYawzainfnnpSQKnGEDrOjZFiuJtDpkcHsGycrQDGjsUDsHJCpKNWieEZvnfqOJPckHAkmkpNaKEQfbQNaRoExgyobyGdLnSADRtKhypevZWyzNUtwrqXukEejliNDlbNSen = false;
					num = (int)((((((num2 + 770196872) ^ 0x992385F9u) << 0) ^ 0) << 0) + 0);
					continue;
				case 41u:
					MnMPSPGZonrQEjQghtNqULoNWAXjwceGcGbMnSpBbeOerrLrGyGJrszbZYSrSwCmjKOXheSpdlpQWjwFPFCYvupJhaMpZXIECCUHCNjBGrGgdJePCnCmUEQPueQhrCqfCLouoOcbwbreNjGxVWNLvwKXLfmyXckdbAErvKBNlAQSmMclxslvPEKgbqIjBEduQndmFpckvZAUFRKZcbaFQPowQxqecrlGwwbZIPGiqaZPePAkFJgAEyDbZHwhYXieOTxjPLrmuRoQPysaXgytkLcYTaZbtzksRVbksrvUsTgNjMmAovkSyPTdRzpPMpTVGWYUxiIFLEbqEpOgNyMXosTcbYtSbFicakgnOrdgMEgUODyBLjbnDVGocWTyOPDfwYqujAswvGlKlZnyARhSEUzfERkSyErXab = new Material(Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("Ω℅ℇℜ℁ℐ℆⅚ℱℐℓ℔℀ℙ℁", 1682776437, true)));
					num = (((int)num2 + -40093842) ^ 0x4293403A ^ 0) - 0 + 0 + 0;
					continue;
				case 5u:
					yPndskRESXKWddIuYXHLABzlQrpzXQonJjAxlwyXbZcBuHOhkdGtppBWqcnbUrHcIwmTCkjCzKKAyXQiDipTkUYuIDhjixcJsaTXvUFZUdUFEayslexMcNRNySlYcZtcHaiyeSNJDpZgasPHfPXdZqHFifyDIGXUJSXESZosrOjMOLNgcDSnbpcrtDpYtjaWsewhvlPfBFLlgUQxssAeNKTuPGkpKpYiNmuKoFKRONLwDRkzMSGbIWjIlcrObzvlGDxTzgjMHJqaYwQYvKDRJXzRdL = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꝞꝟꝂꝝꝑꝜ", 116107056, true);
					num = (int)(((num2 + 1868189554) ^ 0x8DC0EE69u ^ 0) - 0 + 0 << 0);
					continue;
				case 49u:
					NaojOLcabHGWsLFJkdESkTrgIOucuQJvPnHpQcGmaQeWkUyKlMcwfWLTJiBZqZFlYlhfdqThwsStOuVNqKRHOmpSCNGHBGVakTYYNtGVTUZNerfonNJFiYwLWoCpJlGPwRiUwWZXeWOTnBOkIsuNXqSmwmczQrlHojrmikSqNLBljCyuzsHrRSRgYWxjUAhNLhFdkCbxAdZmOHcUOIayJUPwsknmMIwnEOAcXujWqjRNSFrrTDvlAIdQriLZoPKRHMHagZWt = null;
					num = (int)((((num2 + 700820505) ^ 0xD4466821u) << 0 << 0 << 0) - 0);
					continue;
				case 6u:
					VZUIAALNRhRclzMpuRXhDiEIuxzhAcspXuShhqSFxaHODrkyQdhzxvXNumndaDmPOBeRGEheYrJDAQednbrxUSSBweMUcOFTNSZbmsRlVdAgLumEikQZmPUVJDuBSmbkMQPIRcQUkgBQrMPcSiMSYFHXXdsJYpsIbqtVEENftWPgneEXNsJKAilgiRKNKhVUNSOasTxouHzcQBKTzvVGFIiTenNMTZvlaUsupDETVvpSJjpHhRopmpoeKVWfgKuumobWipEVQbLkspjVXgFcLfZKFoKtHzNkaUGvhtyRnsykEeLuLbiZfsJgorqUFkoroAjyIONDHNPtHPgACqHGrNfIlAgQcEmcdhVeUnLXnEsrDpzzlPrpDIaBvAmiIWAdBMpzTcGpEKsMvNfVbGFmmXzuhuItbDordoQQaaGjjcKSqnfHvqhbroQDmUrytmobvaIgWoVbawckmGeUoaYKwmZPxnDfIhPXOJwp = new int[38]
					{
						4, 3, 5, 4, 19, 18, 20, 19, 3, 18,
						21, 20, 22, 21, 25, 21, 29, 21, 31, 29,
						27, 25, 24, 22, 6, 5, 7, 6, 10, 6,
						14, 6, 16, 14, 12, 10, 9, 7
					};
					num = ((((int)num2 + -1930605743) ^ -1875514264) >> 0 << 0 >> 0) - 0;
					continue;
				case 47u:
					ELqZWXXpqHkbneQXmutUWGxuayxARJvHFKgZoDGvvenaXVducIaNaGTXnVZyAxxGmDvDXRJIOYzStwxeucyjIHHYQjLsEiUYGHOuzAwlZsZbhbERyUdyYoYEVxNOfqeFeBlLHcFUFnkqHFROETUJfwZsJkycNHfInuXGQSjvpjSLeHWpFYklwuAHCTcxEChXhBcnIkYMKyuWEnobniwOxTmTUqeXPMRMbUECEJHuaxBXZEdoEbjvgsAopjssgbWYHIUJJLwEAbOZroTqnPsODvGJupmvqpnYBDprKtFSEEUeDAWaqcerIiulckptzbnlNPyOYBGTjzjYBBfUsleokWpsidpzeltDqJqNbib = false;
					num = (int)(((((num2 + 1704553265) ^ 0xDDBAB647u ^ 0) << 0) ^ 0) - 0);
					continue;
				case 7u:
					PvlhjZwKAfvbnXZaRAgFVlgPYfGHRkrSjjoSZOgtMtPuIkgFrIznVDgDpvjdsPTpNCRdIhactNTBwMgOZaqiLdXGcLDEFcaXAzGgscXkIwThJFhCoudsyKDJFlaXDwxrNWbWfavXcgAokPWxDapkZHyPWXBhbaGlZCuNDlxoZgpsjozPoDtDgmrfylaizoVczopHuiTsDblSrfGHxLSyGdeMkppskpOKlnSUZSufJbZfbyNsFtKNvwvwkCwfTBhnmAHemLHFqMPFdZLLBXMRFboOSwKwvpmhTLSARJfULewJHPskQKDWOpIklTlQakkbAHMrglUSRSgAEFgddzGLMptDdHoXxoTBUvjadbeFPLeWjiGGNiNAEzpkoioyWWuDYEGjwgZbvaVblwtUbHkpBtWvgYMUNFISqBXECwkHiLf = false;
					num = ((int)(((num2 + 1960461734) ^ 0xB62D3855u) << 0) >> 0 << 0) + 0;
					continue;
				case 52u:
					YmjVrHlDcOiYnprgzmZFcDNZZdhVHCDAXENqtVJqzKbCoCqaUYoUriDvykWoAqVzkIbJBbMECJgsClKxNgaIoJiObsRjYvPiOBrGAHzSmKrHclSnzzBtpnkBznHjkDFhTXDaUeWfHhwDrBMQzEJzUwTBrPgnZpIIfkOeHStvDvLhQGkYBRJFTgnxecJeXIfrzNygMHjHkoVyKLKKFiM = false;
					num = ((((int)num2 + -1817294979) ^ -1937886724) - 0 << 0) - 0 >> 0;
					continue;
				case 8u:
					DDoYROtwoMfbFIkdxtfoPscKJyOsFxDgQosRSZUgtjtglAsWrsMndwplBDpsZbRRiZkrptlxzZVGYVzjgSamKqcuYhpoKCgrsCYlpbGYhoOeAJnGeflhaEgRWQsidXNXSDovWnTflcfv = false;
					num = (int)((((num2 + 1452403640) ^ 0xCDB27AF9u) + 0 << 0) - 0 - 0);
					continue;
				case 9u:
					CXToTJkEqYrNwgozIyUkBQlXvRJQlgWXyKpZWdouMiHUmAZQYuxNiVULLWTbZusjctoLRpCEjAxtjrLUSTRRJiPDQDnaknusPxRSlnYJRTDHyABulZjgCBATELVncCtWgeDMzTIEUhZPFhfpbTOldnPoWXnAsLHpzHBtXPUsqFluCKowGGliNiTSppPCFiljAJqYGLslZwVxbuLmJQUMzyBqNIdHasMhtcUSupQUnZjrnvQUDDSPozJchZkXHKlGJNdZATRtaZyzokdsSjdxzXTUsRKufTmDOCHzrRtKLyOoakNXWRfyHNhLUjGIixogNVKLDDbbPsMbiETieNynONVavV = false;
					num = (int)(((num2 + 483666874) ^ 0xAB8D5B01u) - 0 + 0 + 0) >> 0;
					continue;
				case 32u:
					atstxCXzIAXywblfHpuvPazQSiRBfSpMOouqHjSFeOlfSvDgPPsPiPEZUCAoLvtPlkKhGUxyxOrbPtXwFLLqzzEYKvvfIDUJuvUHLvzVrUsuyDkBEdJaJdqLGLxlyrPTUIGuyqLjlQYFhjzgkUAEUTZrfjbZYowaeyzQXQcosAPTeKDwmqaERlZaIoopoLkWuYAJKJjuRlltegnuFENHoRiTyzhIBNZHpSyfkUMDhFNFZFVCbUKKXDICPHkkBA = 1f;
					num = ((((int)num2 + -1111342977) ^ 0x49B7091E) + 0 + 0 - 0) ^ 0;
					continue;
				case 50u:
					FikKBokIBfzbtsQdIobfDppyEvYasZZKpHXSQfRyQAdNIctfxKfHYpsqSMggpjpBgPLMuXnDxDpcmBPCbSDIUrLaoHaeYKiHlBHTqHLzxBkvaqerXDewGGHPdLyNXiEMuH = false;
					num = (int)((((num2 + 11998589) ^ 0x258655B5) << 0) ^ 0 ^ 0 ^ 0);
					continue;
				case 10u:
					RKUVmuhdlshqZYDJhvFMbEUSQEjXCoXxaszuxbrKoCvpHNMzkobjhIGmPbfHlkBXvJpGyjlfeVxziFkcSJNnmOqrMmEvWJyeayUYxfaacWeml = false;
					num = (((int)num2 + -1904678002) ^ -538542149) >> 0 >> 0 << 0 >> 0;
					continue;
				case 11u:
					hdkRcPCwoKGsYUmEQjvwsyKLmEMIMlqJefFitETTWILNnFzlOwlMJPTItzFydUJduXoSodlmqBzJMXxGfBTqZDaolWPUZuQcYIsqrGWLkZwhpjVvbYtCatdRXZGsnqnVLxLdEhpyEifZgSYcatSabobFEBsrZExUMBvSyRRTJUXSneKeaErTymTxvgzcOXzaKlnFwgEiCYrhqjrARoqumDvzHYwrsOeLuXhcReIUairzUMhmPYlAGeOhPNYyJmQOTGMtcoJMFwudmWEURkCuCEeqjamdgjlNsDGoaNkApyUkJKVTidGyKwlpCvjbcFGwlHKIqqUdacfdJTGyftVcCMdWrqMEEixJSyZcZmDRjDyHrhGIPLWJKETyDOrZEpzSEvlkUEySPdTZovFjKePTlOYoFBylUDnTeFcVWvOlmdTHKUkiihpzAGGQxXFtfmYlPZVItKnoqEGhUqD = false;
					num = (((int)num2 + -719845573) ^ 0x30DC7482 ^ 0) - 0 << 0 >> 0;
					continue;
				case 42u:
					mJWEIVwgvrySRedNFkfiHJFCtMJVIjfzEtEPDosCGJsQeBhFpSssibxCdukWlBxmmZnyAokrSDCYrOxRFeFPQNqCWbLidwqflgEfnIfbHbAFzzloXtqhVHvzILCyCcnvnwMlkrDWZEiOnLcwQxlKfjjDKfxCgGyFOescMaeFPuirzHmXJfIfRDqdnjAfUbQsgDajsZKPtFVKaSddTzSbYtNkNoPCzZLNEQkWGdEJuSLlIGdvfxlujO = 0.5f;
					num = ((int)((num2 + 928946125) ^ 0x6264FCF1 ^ 0) >> 0) - 0 + 0;
					continue;
				case 44u:
					KqqdNoOtyZmxYQvfZfHSLZBPyTbjVZzVguUcOjkXbFwJgmoxVyHbmyRLPBETmExyAqqEWsrPUKRfCSIlFEoxrxIICinmFrLxiYjPVKBChRgCGLjWTsoIpagcHHcNfekDZuXEJSqVcMqAqgcRZqtmdchhRghoIOwcHDDmNEnactFCJGLBFlNPKYAWmQNCKcnoqnSNCQdudtjKwFykuGIw = false;
					num = ((((int)num2 + -1756947900) ^ -408761716) >> 0 << 0) - 0 - 0;
					continue;
				case 12u:
					aHsJdHZXRKqagrmwOYYPhtMrOPzHrDhetQoJVjJVQfCtdiEfsbvwHSpGUaUnhsFoClHqcDBEocZcQsoFluophLwAAHOUpwOyzoQRBncPARiFTnQCMobMdphRPgPvOGpSoACCCxeXszPqDRGnRmhaubukhZbvyHaUBqqsLoZpkeuEAQnYzBECypxmgruCvIzKyUOnAoCCmSPqHQJqLdVWdyvmSem = null;
					num = (int)((((num2 + 67747431) ^ 0x2FB28076 ^ 0) << 0) - 0 - 0);
					continue;
				case 34u:
					bWXVGHybKtylgbMRncDzqcovSfFiybNPezsqESBuwZkISuztTSqLMPhZHCdBcpDJFJhGJvmuAidqSGCxGmpGKbcpstJcPashwAcinSJxFWkDMRgbZFUPZX = false;
					num = (int)(((((num2 + 2035719306) ^ 0xFC36C9DDu ^ 0) - 0) ^ 0) - 0);
					continue;
				case 13u:
					tTwTBEJfFbaxlZbqFzhFpIdQsNCHazCuvbjJPZoLXKdoLFJXciPMLzXKPGAOcbfgzGckQrAGlvHEFOfNdFFSJQIWeyTjyAJVFWPfDzgKHjBqRsfbANKwwnxIXffryqhLLMZ = 0.5f;
					num = (int)(((num2 + 329939053) ^ 0x124DD4BC) - 0 << 0 << 0) >> 0;
					continue;
				case 14u:
					IYakDyVkAosfMtSJLPmzrzhiyuOlqbPEesxcADgYAdWuEZtYGHwVznIiRSMjJKTyyObtVPjhIoYoCMDyaPFJFTeRKokHRXoQjyVPYZdQyonlouFeoniTekTEJjJGFBqLZieeROAbMOkqGTDqJftDOuLZFqfOpwlXYCmfpBnANhgqaDYQGtXzhMWExfyBILLqDmreHxaiSSQHovZcspiWyLPlFHIkcLSbvQMNlTjisPH = 0.01f;
					num = ((((int)num2 + -290999538) ^ 0x725071D3) - 0 + 0 << 0) + 0;
					continue;
				case 55u:
					JZroEMkhNenPrtEpptaXnawbzWMjdcIKBxStpidcxWpJPgSXzVxqRYSIDqOIaaeLwCoUAkZhpYzrKNlsdPKhErTCFjQYtvcxREmmSYwoWqbTyAXQfvFkqXgeJLoruaNUVcAgAZAetvloqaeelZTYPRgUxiDgJeUVCgXwaRqgUBRVLSOIHkfuhPfdVFJrvuuoBpLjdIeuJNdoaliEtUyzYzONbTAuhYKAhDtwhEFZfLKtLRdKxfXBWUpcBXij = true;
					num = ((int)(((num2 + 1892383293) ^ 0xC317708Bu) + 0) >> 0 << 0) - 0;
					continue;
				case 29u:
					GXlgOmgJPMGdZlfUnLvSfMQrMoHYvzoAqWrxWFQdggNGlmEOlUdRvjvThTtzFiopxgNdUHXHVrMYYjfAKTNAvwehBxqdmqyXSxifzBUDXwVexwUYNSPLvNUabGBxrUuESOgBaaaiZjDZBaKfCsptBMCeDhdTawlcbqlIptXNSGMlkUzbWwUZFadflcXSXhiCXAXkObPjuBBUarUIIbXDCmxangxnveQKyknJWpmUGLEdzifTiokVkEaLdWWIDCNqLRwPekMsOcXQItBfbDfgUUzUkCGZsErdXnsHMpPXCRgiGjcJuRGZxGwQrBEBDMakKTSvbUsLOhDcOrnbzXFAYrGqRCqkLnuQR = 0;
					num = ((((int)num2 + -1235864212) ^ -24774749) >> 0 >> 0 >> 0) ^ 0;
					continue;
				case 15u:
					hJmLdDhxRMwPpytnOvckQPXcajEmnrUkvwRwzZpiKGSLIilxAcngVYtrMjKUZUjARmuTHXNOfUAjXluSXgLleNpxczJqpviPxsTwOsQCoybayjuAOSXSiXveWWQhoxzJLKMEsYeEqjWFMoYTfiBxyqGzWPzRCJoRZrpNxPiQNsCZaQrIXXcfWclvdmICzmbHUfFvYlvpaKJfNHyfxQTFGiUXfUJkhFrAqVeUlWJMBMflsgHwOCfItwaLkIpeBliutiOSDDUBggeTdJEYmnwEAIhUUsJCGFlpEKRksPTkIDBnsgIBdqRoPDUKbUXkTrUAVOptRuGxumWWgUBOKiypOWAaQhjySIqqJbrEQoJJKtTCHXDhsizLSEMYnpDKkiFLWFnfCXXwzPFudXsSDcgJiExepsqBLYzBOhGcJyEuldldZrVpWKhicWDrijQkHvKAqdGVqqjfxLxestfXxaFaRqzREpUAHuMPt = false;
					num = (((int)num2 + -1532611491) ^ -511848484 ^ 0 ^ 0) << 0 << 0;
					continue;
				case 16u:
					LNVKaYGBcKqyyYOdSMGQKJZEOqbwIxdZHLHGjnxbZzPFjtfrfwOHgZIbOrVJXjSEHrQNqiUFpEQlUuuvlJqmJvSIcFSSrNePGlXSCsbXCirBixhtWzxoTGUlyiKKpboBAbEIwCTTIsJAeqzExyVRpPWaqMttHqIAUPbhTzXuGEFAWthhIgnRfwmKeEsJizlsKjGopsLYABlKjvdWElLAdQvyDrcognlgtnQNNTSpvoqEkBAJAvfWOKoUOhKYqwSmpfrVFqiLtvfOzQocQtNKiosIYVZFjUZYweoejEdkmtDsFAuXTHhWIhebNJXJrCCzwhsvCjTmpDxOLZcyBbMBNcppZnrzHtTKRdWyiZvKNUHfJppNGyi = false;
					num = ((int)(((num2 + 649143086) ^ 0x17B61D98) - 0) >> 0) - 0 - 0;
					continue;
				case 45u:
					UAwPYwrksvogZtTzDLrAEFluLTmYAdmiyKBQAeiqPuuzpHYMMAmXCODppbefksKojfIoRcYzDaKjkLfeUzmaRoGJhmByZcfwKgpjYKUJBNuBdteDWZkKgKxUzYhFBzzAVnzewVfkFCydUfFNiYCZSuqaIvKaDpicoTGPUZhaUafDlt = 2f;
					num = (int)((((num2 + 1674602320) ^ 0xC61DAE2Du) << 0) - 0 + 0 - 0);
					continue;
				case 46u:
					pQaMtRdvoRuEVJNWHcEqBGcOSvkFKXDSilETRrDGfDgStpLvWsIKbiGIOmUXHxLroBwKfTfpzYkYAkuCKOJrpTQaEVfFxFZHSPERTapcnskdXIiERrnSOtbvKvfkOzRUYDfLFCIJyHeWINcWNBNfrhTyNjhyVfnNAqeuCwYoJEthpeMXsiwnLMDRJHXwvkOttqwrIItqCzwNNLiIwkfMIabONmKVzBTzQaNYIvoKOgKmpPeYyoalfbKtpIEwXyRbFXXMYjabVuXCpOyXiMwkBItOquJZQSMqoJHsSsZooZpKdhdAjHnlcHzWDivDAakdHHoGhfeQMhVCtJKjriQjEBnGjKPKWwOnO = 0f;
					num = ((((((int)num2 + -661434340) ^ 0x4D883D2B) >> 0) ^ 0) << 0) - 0;
					continue;
				case 17u:
					lcwSwtdCxyULXDUxmmskbzgtHxwquTqtINiGoqUOMGhcsVlhVnKjvdMMWclZWNiDiBdjvniVsDxvsdbMlpvhjgXFbvJmfVRZyDURScMHePRSFruTbzNHrbucDxiZEWPwLyWOjjTjCOcuofaKbPkGhkIxjRnuUMchZugguFKRFEeCYZOyxyXOLipBQzFrWypPLUuTYTpwftbCffzjdPXwPowQfFqVZsVgpoRdFUzDiBIshNvLawogASaxyDOtDuwNyUmQnwEipunnFeJrjFVDeOFwotEbggaOeVTmBFxESfQgFMRuUxjXzTIJoPCURCbjtziKkwPDiqLYXzRBCkhJWcolmkYLdCMpeHMfDhjxHGPihKLPXasHvrnrkXxaydAFEvUqMLXuaJcqngdCyiOdkfTMtvVGKjZDfkEMQvdldXGMpWedTVBppxuyBhWqQqKQKzkdCrMdfCZnzhwwrRNPIJnIPfkIyMvMnQbQMbBBiykMxhZuKA = 0.25f;
					num = ((((int)num2 + -504175385) ^ 0x66CC4ADA) << 0) + 0 - 0 + 0;
					continue;
				case 18u:
					ZYDUialCnwhdEshnZIfGKpplGkzAlIgQXYMwjsHbEkNfueTRFjhqodPJIroXAKqEprgGGLeHbdcABkRBrIVbBPCTicNSeJBTTjPdYmkUfApkbphyzMGROpdA = 0.5f;
					num = ((((int)num2 + -1568917589) ^ -416656210) << 0 << 0) - 0 - 0;
					continue;
				case 35u:
					zdhAdbDMTWsjmkNVKJLOJjIByZggXqkUHbMwBDNpFYgsxBEwYMpxohJqvGbdVxOCLyBlyquhWvjLcpeXuJhlbNFzswbUBJuhjDHYZtXHrhBTYYnfCeJlpDBYTcScpAGmabBzIfXaMAUTlLAtjVrxajRGcIfXBVsRBpTWxNxxhIzPJHMhByTtiimQjUwZaZzRhcsWREWvyUqrKcXvWXvcbYJscdMCrxxhjHHGoPqXByUnSUfhWbdcDwPjtaTORuebxiicurggHyADdvzhXEFpuuDMSynoVBghuTPKMdNFUWvfVmfXALRmOOGdFvkVeSkfrtjjFPvTRZuxZxQFtpNjJUsFnMerSRBcLpNCdVsLqXuOujdhEFCOeawxaDWSKebZxrLKJnBxWcTLzEl = null;
					num = ((((int)num2 + -1588119460) ^ -268796213) << 0 << 0) + 0 - 0;
					continue;
				case 19u:
					OnyDXmCrCiGsvODexbWaArRTUpsrdKfEfpoLOHWSXYHSIPcKjCtNscZwvEIITloSdcngASqQfddCKZkfmIhAqrldpRpjYnZMKPPGBWjrmCHoZwMwuDwldNBLQjQJCgSSeqSUjDDqyQoNKWeSeTOvRNJWoeQsfAPfKPkIESmRZfNmyObTfXFIsxbqHVGfNlkYajcVMvolHXvLawyzcWmi = Color.black;
					num = ((int)(((num2 + 824698952) ^ 0x74863005) - 0 - 0) >> 0) - 0;
					continue;
				case 54u:
					UgNmOTaImhdNUPlpLfgKItbubpqlxgcRZcdUvQhTvGYzTHQlkjOXPCzBfslyCPlgemOSLrTVYnpcuBBtyeborfbxDCOdEIqFuSuGTYzSpTYCmwgDRRZxNWOZlrpjDPqqWJHCgUAAFiYygykgwklNISRyevvCJppzCIGDODwXqySFXpSMgiNsECHdRjxLyYRpTyVySGsSNoxjamAPCJvACWVaaCMEgLyrHDLztuTAPVEpfxdEJIiPDqNXDVxpUNLcQfCwBbviPULGsGVDzhVxCIOqQOWxWDFcjCyZUGcImZaIFgFWaTQMSnzirlGNfXmloIwPhVITfnk = Color.black;
					num = ((int)(((num2 + 268319629) ^ 0x5EF05327) - 0) >> 0 >> 0) ^ 0;
					continue;
				case 39u:
					HqYYrTBzEaTWGhMUQLAYlyGELvzlPnHrEVKSGjtHyUnVUuyfIdcqGUljJunVtpJrsBsLxUnGsSzrlLJqXuDLlqLJJAilWxnjkWCsbNHNQvXNvUYXLWYZMYfbPJbWMbJVEqgpjqojNPVPtYoPClAayoxmQADsMKbOMcieNJNuHPmWdqIRumuABIxqSUzINWxcNgdqPjbTxftJbAjzSLXzpBmdESlTjfHLrjjWnrblkBdwpOosLZQbYXMmTaMXXiJsxHrSrmmAJMoOxQNQEThkoGMuwWcnFencRLYIwwayMqrmIYPdmVteaydRUXvvkZUFymWLSeuhTIxXoALyhZaKLjbtHhNzbFoNvMNwbdlhBllsbfCtmWnlYkTpkDdKrVgnuKCCNoxdOSjAYJrBEtmerdOlSxlxZAQGeXXrDaGXykxgatqAmBgXI = (Vector3[])(object)new Vector3[10]
					{
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero
					};
					num = (((int)num2 + -715369700) ^ -1563660373 ^ 0) + 0 + 0 << 0;
					continue;
				case 20u:
					CHfLJiZxcNTjVcqIJZoDpNOtWKPOelWHFcWAlAXEfzjyvyANRnZTQKVPSLOZtktRQlESgPxicKxPDqXxjcWQldRU = new Color(0.5f, 0f, 0.5f);
					num = ((((int)num2 + -1030955589) ^ 0x1A469EA) + 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 21u:
					hhIzLXlVgsHkTHGcQQQfmglCNqPrnCFNtKLZgXxezCJlJNEBvUavmLHaVgLviTHDMUQjWHVStMGKxZTaMoVtBkAHcKdambWFUfyOWuFOYhbAeXDWmLITXnbCuihlEUGrPbPsBedsJhvujZCfhhNBtdIHdWuOmtjdBKLdhluiHqkPSHtuFcexgfYMtioFKpfpYrSyozXVMFTdSSPvCZijpMWvLYKYWOyrkVRAOUggeiKBlVTAtScKhWZlvwNpOZYXhBSXboGITbehbvkQfkFdMNkoVFerhQsfjNtJcWzemuQfRSkamWkDuUlt = 0f;
					num = ((((int)num2 + -1524965430) ^ -1828164260) + 0 << 0) + 0 >> 0;
					continue;
				case 43u:
					rEbvkoAdJZXobAOiLARrXexdveflGOLoBasxVdUXTNwSVVYLhbSTdUwmhXafjpxUnINbiqmHGUxkIFhAgtdEVSlHEfqXdPNEqBEmiXDQPlniwlDCPzZQlSZvwfwdapDQhTThaVriQnPJEdksBOhDPXsxBjQcAAQAHwbCrwCUhQZYdpQtUeBlhZajAwFQfpHqwpcibIafmmvZXttmtwhvYEsHvRbVRLPSiJCOnHrmewZUEb = true;
					num = ((int)((num2 + 1742690051) ^ 0x82FC70E8u) >> 0) + 0 + 0 >> 0;
					continue;
				case 31u:
					nIgFBBjjxkZOoEnGtWUftmoAVqCAjYjGvzGLqMPvlahUjxTiqEHQXZUatFJkZIazbttOYBpHgyUsftrywtkEqsIvFGrLcEwCaITQdfkPpaJyfBUZolNFyviIKXjrjEECcrsxAAurjupqIkqdLsxQQQdEzkfgVSGKvhwNjxzNRwwdgRaAHfGRgOLloNXpvovqOEVBOCToSKZuuZyIkEzPmODHwkzwzjrDagpBWzMemsYwOqRoppfROFeZaneDdxOJswtnKWLLRuDUQhSfskgkdAOubpAIuiaODodsWDEsEtZubkjTvZlTqDFSIZmvwcrItPqCdAiOGOGJAtsRgGnvXhxZIlKXriWBcqamTGQVQwnCXVsoGupPOVLmrqTSPkwxSeHjtgXzQsEATVcMTwrXTgNgFNUDNXfFaQJToi = 0.037f;
					num = ((int)(((num2 + 1472348834) ^ 0x29362984) << 0) >> 0) ^ 0 ^ 0;
					continue;
				case 22u:
					mhctxIimrRWuMkGenAwDQnRFYLeUrCFxdtFUSxohKWsKSTVhGZiyxalYpxuLEnUOmyqsELlQmpTTVgNeQWorugadiHEvdCCwbDytDCCVOsmhhscjKpUHZDugymkXgQNJNwRrItBotsDbUSWPEvLNIUxyjsVrrFOXFCuKALAqOGnGaslFputKeZbSZtiqykWOEFwrympSUvYbGQxQgpbWleTFBBLhDkREJzcvVUhdfAPJaZliVrjijaDzMRQWBhpKDurhOcUmiXQKojEBqCllbJuJVCIedlCXlfgGIdtTwXaljSlCnpGYWdIUZIlltQiWuSzidYTmisPeIjzdqgROEEbiwmGZRizGOdRrtdzowuPEoElQiiVnYusQRrMRrTuaSipEriJnHCrkPxTRaPQJnmHtLazcrIXCaOLfoHzazHGwcibtxUQCcLNGBWS = true;
					num = ((int)((num2 + 1812043280) ^ 0xC2F8A7D1u ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 23u:
					KQMDWUTBBKNNfJDAjxguJIxmYDECuGmpSYPTNjiJdTVnNqtTbEgNJeactAEsprgVyyUgTJNaoxqQMjzIkKAQAyFOYMAnEPtMMaOowmarRfymNkqjaWiERquZSfigjAvzdEdLuklYKjZuataNwrmIHOUvFPwqeTirJZijhFOQLjUIraZyfuKRnNRpJHfFOVTQbIKakRGRDwXxUmeFPXlJjqdWi = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("柋柑柉柆", 966748072, true);
					num = ((int)(((num2 + 1201792116) ^ 0xCF021C63u) << 0) >> 0 >> 0) ^ 0;
					continue;
				case 33u:
					TelEelHhjKSkAIeDUTDFHGcpJMkWpDKBbGLJtuBJVTKaSNcZxmMrHVTnbWVrbKRGaqiUXvkzsTKNVcxWJkzdQsTgMyHxzjIkcdZBEicbcmZOlfrZyZIQlNQHwchyOMaikzLRcWrBixbDtfUHhIYzBRYonseBaDnpmQDLtzWCHgHOMmnriArfOAHtAxEKRQAFjMrDCinHLwSukkCaeNtAliALiklWVmKRFcFaVKPZnJusIniqVDFewatblFvrXqMyLaOhFBetXunCNicVbUbrGGvFJEOppx = false;
					num = (((((int)num2 + -1529358628) ^ -185233633) << 0 >> 0) + 0) ^ 0;
					continue;
				case 24u:
					wuWOqkSwcIOzcbpyqWrmQHHkOjMgjCQygFohVEDhcrVdgYlsodBKikoONMagyMmzRpswNiCLskkyLDdPYuRfbgqVrztjEwIpevlQFOEgBPrYaPcjIkidVhyLZwenOshWBUuprnkjPLElPsVCwkBuoEuXWARiKrsjHvwfvNRuZYokCnVGBBQDQNHWAwtRvbzysvDuVPhJtgupqkuJFlHiAOsUNAFYuaZYzPRhJBKMugjKssFqbJmkurXDcJHvjipthvPAsmadAUNtFIBuUoXKOPEiRneZTpClRQDXCfXOIiJzDEYuhnAUlEFrRHIfiakkrC = 0f;
					num = (int)((((num2 + 990853309) ^ 0x8D132425u) - 0 << 0) - 0 - 0);
					continue;
				case 48u:
					COeERPricFfeEnoJSGOIamklfVwSGHXyhbbjpCvLDcCZmMcvQyiDwJBqDTyWtyCuHGXDmetpldeXJlZtSbcizucxzLGwdzrfAhrFPzjLeSssFDGsUfdsvuVnEzdAyXlLLYxCTtEsSqeGcKSVenBYvZJglebpvI = 0f;
					num = ((int)(((num2 + 2115827143) ^ 0xB1AA57B6u) << 0) >> 0) - 0 + 0;
					continue;
				case 25u:
					mgHGGGgezBBKAfpplUHiwlwnqMprqPsoXjeXZvdlPZOawKzEQWTgHnlbKtqUrPNKimNqasqPQwswxwQFmKBuVlHJYdnFfjTaldRkWjDx = 0f;
					num = ((((((int)num2 + -1453520766) ^ -1987832551) + 0) ^ 0) >> 0) + 0;
					continue;
				case 36u:
					eJXMnpMXKTqCzYzamWvqcxtxrdeSchKYwsSjNrNJLtaQtLbyxbGOdniGpzvkkUVDirghgqnUjLFIwCeFbGubBVVjjlTnWDzQyxHcFUshNLFsHAkMvPiEzTbnwWXUwZXGmPjYUbZgnnnPqCBJbhShuUqEvuFIXyKNNZfSrlRtPbqmFmXTvnSphQlryECAvriPDAbrxJsPpyrsDeZjxMnKFvGXNOtMJrXySBIflGwLVdZIzSNuFtcJdyjhUeDJpGgYBSzcvTYRqBOCvXyVaZgpoouurBlhcNwpXbhGsLYMvltCJHLWGHIqzQJmyfKUHRODfzEuPRDobuUdVSKKPoAvefPgsUimbdeEwQwkcrhOeuoeWFrFvZftqtyZJybUJqnXqqGfwzHxhMqKRLkMDDRbYKndrwAEpmfNgqOF = false;
					num = (((((int)num2 + -727923521) ^ -1885963673) + 0 >> 0) - 0) ^ 0;
					continue;
				case 26u:
					FeqlUODnDKHHotOWFerXeLJGCsltEGJdgdORVwOkzZcvCmMSpVFSRGtUuJIBDkJWbDAkEWbiqhyeJoeqGsdIbRlAJUxlOmGppfuZLBntUwBKholgFrVkgbVkraAKzPudAiPDTeFffKOFpBsvIqFwrwjokjHLaCTebyjYzHmALPevmqVPHfbjjXMdZAtKxUfCQJDQruWbdfKBsNbToReVBKUdMgYYnCdRKBEDMeymiafenkLmzzvFPjbgOzelvYNBcTRQjyhktRMBFQQCuMzNgxbAAyOmZmRkmEctsVcaslmYwABYJCQIzZuERqpLKUkgZCoaOwjyJyvVkddaWQDxvjKmjxCcGrqybgYUlAjmtsYaEztNmpOUrMKQRbQqTgSsiWTeejOwGqddlKIKdPPqDwhovickJTtmzGSIFpIdBrnaIGFhtgmerBOLPFIWhDMMXREERZeOgMPligFPDUQDGoUXRhSaGMVXFAd = 0.62f;
					num = (((((int)num2 + -1520509820) ^ -1194293069) << 0) ^ 0) << 0 << 0;
					continue;
				case 53u:
					RcaptbyYFMCCIZTsnNjgIWGMKheitQSGHcONDEwCiqplpEjaMtIjwuvVvnFmWpEOTWVGlgPIqGYsGvxgXdvZhIjnHSrqZkFSMArtJDOGEaTPvdoaPypSUEGlMHYsOzIfbgFgdextpPvhOuREErABUMYhTgGbEwRerNNpxiWLbVDeizwrPuNxZhlpiymWxvOSYqPbGChwuPAZiTYuKpmkIufkCyhZWanFhLgRJvLnmrckHlgozRlijDkDlFyiviAuBURxMhLpDYYqrVDqrSzePfvDACGeWCSeQIIMtJCsgVEkFTlqchQC = 0f;
					num = (((((int)num2 + -1499634342) ^ -2133695964) >> 0) ^ 0 ^ 0) >> 0;
					continue;
				case 38u:
					RcbGLzFxExmZhHJiWMcbyvGLGdXuwBmegyLuCPJqbyjrGzCTYZXZjhZvwpZIBlbdlhTIWoGgcMaZmofhAdwwDnVYyqYmQbPQwfgzFUXJtQWwhZihkSiyPEzXmVjFpuqbWjDhiGBFfMdNqyQzhRbYSrbSFimJKruYAVAYwbYEqCsdAMHNfKyxssiFiKBatRVOrenvYScgTx = (Vector3[])(object)new Vector3[10]
					{
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero,
						Vector3.zero
					};
					num = (((((int)num2 + -1582795527) ^ -486826720) + 0 << 0) ^ 0) >> 0;
					continue;
				case 27u:
					IvEvyoXjAGsbgTzJmQWIqhYTBlXGrqbPMpvvdmnfLsRzCDdLtC = 0.05f;
					num = ((((((int)num2 + -837232188) ^ 0x6AA3BCDB) << 0) - 0) ^ 0) >> 0;
					continue;
				case 28u:
					dlkhmBxLUnqqSkFDoRyeFZCRWYqyqXhmnOmQEFdUXssaOvzGUZpmnoWdItkokYuWgecdXOZINDhnHCcByJErIUYYSihkvPJYXvTKsvIfZGzKhIwgqJPBudomgelOHOnYTiqlIsicazrcunQkMbTMZiEThHDokUxltBQZrkxYANBVLlRSnbcGUAYLEwebOTRgbgJTxRSBEVlmHJhVQLajRRqSCfuVgvjHVuTFCXvwiAcZpMeUoikdTIokQQqrwXviMEqmPCsSqEaqOqCQbA = 0f;
					num = ((((int)num2 + -1575253258) ^ -1917373617) - 0 << 0 >> 0) - 0;
					continue;
				case 40u:
					return;
				}
				break;
			}
		}
	}
}
