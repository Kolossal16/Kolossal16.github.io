using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class slowgun
{
	public static void mkbtULiJWtDLtxOYQcWiwmtTHsTvHYehjSWPAaEjLVnqPoFACZTSkwjaRiLBRNcYowBAAZyQyNxBYddsNsTHemWMIWYrocrXSobsMeZDBctxZIbOesNyUuTcAOREagBvvzIKbKFJsqgcSzNaVkmWoSdyvYSYmvCuBXbzZqMuMefEoRkabRIQTEgCwkpdSHwWNLAUxnaFxSkkNzkDOSWvNLBWRzdPbJBeIiQDqpCOQctbuWPXaLoZLbickEdYklDOqfBEIGmyqiELsABUKfPpuCsGZNsMmDD()
	{
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_068a: Unknown result type (might be due to invalid IL or missing references)
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val3 = default(RaycastHit);
		GameObject val2 = default(GameObject);
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		Player owner = default(Player);
		PhotonView val = default(PhotonView);
		bool flag = default(bool);
		bool triggerButtonDown = default(bool);
		while (true)
		{
			int num = 1758301873;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) ^ 0 ^ 0 ^ 0) - 0 << 0 + 0) - 0 << 0)) % 32)
				{
				case 0u:
					break;
				default:
					return;
				case 17u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val3);
					num = (int)((((num2 + 1665746989) ^ 0xF9D1D93Fu) << 0) - 0 + 0 << 0);
					continue;
				case 9u:
					num = ((((int)num2 + -218260425) ^ 0x35B0F314) - 0 >> 0) ^ 0 ^ 0;
					continue;
				case 1u:
					val2 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = ((int)((num2 + 770395556) ^ 0x7831BF3C) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 27u:
					num = (int)(((num2 + 360573015) ^ 0x48F8CFDC) << 0) >> 0 >> 0 << 0;
					continue;
				case 25u:
					val2.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
					num = ((int)(((num2 + 1333463150) ^ 0x7AC06DA5) + 0 + 0) >> 0) ^ 0;
					continue;
				case 11u:
					num = (int)(((num2 + 747926746) ^ 0x11A94C3D ^ 0 ^ 0) - 0 - 0);
					continue;
				case 2u:
					num = (((((int)num2 + -227232852) ^ 0x14C8849B) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 15u:
					num = ((int)((num2 + 440672968) ^ 0x1EE2D068) >> 0 >> 0 << 0) ^ 0;
					continue;
				case 21u:
					val2.transform.position = ((RaycastHit)(ref val3)).point;
					num = (int)(((num2 + 1107201870) ^ 0x40C2CA40) - 0 - 0 + 0 << 0);
					continue;
				case 10u:
					flag2 = flag3;
					num = (((int)num2 + -1198723765) ^ -1957427293) - 0 << 0 << 0 >> 0;
					continue;
				case 3u:
					num = (int)(((((num2 + 1548432940) ^ 0x21C441B3) << 0) + 0 << 0) ^ 0);
					continue;
				case 12u:
					owner = ((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>().Owner;
					num = 0x394A8B6D ^ 0;
					continue;
				case 28u:
					Object.Destroy((Object)(object)val2.GetComponent<Rigidbody>());
					num = (((((int)num2 + -1008375456) ^ 0x514FC018) - 0 - 0) ^ 0) >> 0;
					continue;
				case 14u:
					val = GorillaGameManager.instance.FindVRRigForPlayer(owner);
					num = ((((int)num2 + -342996398) ^ 0x7240429D) >> 0 >> 0) + 0 >> 0;
					continue;
				case 4u:
					num = ((int)(((num2 + 1457370637) ^ 0xE63A4722u) - 0) >> 0) + 0 + 0;
					continue;
				case 18u:
				{
					int num5;
					int num6;
					if (flag)
					{
						num5 = -1646761151;
						num6 = num5;
					}
					else
					{
						num5 = -926602376;
						num6 = num5;
					}
					num = ((((num5 - 0 + 0) ^ ((int)num2 + -1302358218) ^ 0) << 0) ^ 0) << 0;
					continue;
				}
				case 19u:
					Object.Destroy((Object)(object)val2.GetComponent<Collider>());
					num = (int)(((((num2 + 1956669763) ^ 0xCAB3B473u) - 0) ^ 0) + 0 - 0);
					continue;
				case 20u:
					flag3 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>());
					num = ((((int)num2 + -1519429041) ^ 0x2D182929) << 0 << 0 >> 0) ^ 0;
					continue;
				case 5u:
					num = ((((int)num2 + -2071082168) ^ -1516719462) << 0 >> 0 << 0) - 0;
					continue;
				case 22u:
				{
					int num3;
					int num4;
					if (flag2)
					{
						num3 = -1831096252;
						num4 = num3;
					}
					else
					{
						num3 = -154860509;
						num4 = num3;
					}
					num = ((int)(((uint)((num3 >> 0) + 0) ^ (num2 + 923559321)) - 0 - 0) >> 0) ^ 0;
					continue;
				}
				case 23u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val2, Color.yellow);
					num = ((((int)num2 + -434831334) ^ 0x5D310F97) + 0 - 0) ^ 0 ^ 0;
					continue;
				case 24u:
					num = (int)((((num2 + 461723281) ^ 0x46BDB199) << 0 << 0) - 0 - 0);
					continue;
				case 6u:
					num = (int)(((num2 + 461443217) ^ 0xA538660Du ^ 0) << 0) >> 0 << 0;
					continue;
				case 13u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)((((num2 + 733616138) ^ 0x59E834CC) - 0 + 0 << 0) + 0);
					continue;
				case 26u:
					Object.Destroy((Object)(object)val2, Time.deltaTime);
					num = ((((int)num2 + -645064961) ^ -61057186 ^ 0) << 0 >> 0) + 0;
					continue;
				case 7u:
					num = ((int)((num2 + 452787187) ^ 0x4C9A6E24) >> 0) + 0 >> 0 << 0;
					continue;
				case 29u:
					val.RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uaac8\uaafe\uaaef\uaacf\uaafa\uaafc\uaafc\uaafe\uaaff\uaacfꫲ\uaaf6\uaafe", 2117773979, true), owner, (Il2CppReferenceArray<Object>)null);
					num = ((((int)((num2 + 121371131) ^ 0x4CD50D17) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 30u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (int)(((num2 + 1559511532) ^ 0xB8E04BA2u) - 0 - 0 - 0 - 0);
					continue;
				case 31u:
					num = (((((int)num2 + -1100503962) ^ 0x38642F35) - 0 << 0) - 0) ^ 0;
					continue;
				case 8u:
					flag = triggerButtonDown;
					num = ((((int)num2 + -1883148872) ^ -299581454) + 0 - 0 >> 0) ^ 0;
					continue;
				case 16u:
					return;
				}
				break;
			}
		}
	}

	public slowgun()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) + (0 >> 1)) ^ 0) - 0) ^ 0) - (0 << 1) + 0 + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 >> 0) ^ 0 ^ 0;
			}
		}
	}
}
