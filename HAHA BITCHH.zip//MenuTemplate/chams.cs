using System.Collections.Generic;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class chams
{
	public static void JLIYvxfaVATSVofrLIMzJHIHXwFGVmPbSlPUrScjpQZzZEyceoPWmwPccbaZRyeIKSaJzlZTFDkTHjHsYDBHwTPvwNRqRcrQLqOhEOCToVqImWuTtIaoXwlRdFnMtJcClthrvAOjaItADgizsYWjcdTofXeYBQAETNxSOdySTQnocKnWwNtvMTAhASlywPIkiPHQIqLpzeplQEluJhCNweRampsWRawdidgndxngceVIDpqVGROpnVNdXHDtYPxzHldNyYrlTwLsjiwXYwpZlhQnqdpwTUinGvbrlDxIACvRjuTPkGuBzxnAvQxvIVsYoyLNhfLvZHzILZdVjAlnAGNii()
	{
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		VRRig current = default(VRRig);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) + (0 + 0) - 0 << 0) + 0 + (0 ^ 0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				case 2u:
					goto IL_0049;
				default:
				{
					IEnumerator<VRRig> enumerator = Object.FindObjectsOfType<VRRig>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (enumerator.MoveNext())
							{
								num3 = 414745704;
								num4 = num3;
							}
							else
							{
								num3 = 1259723680;
								num4 = num3;
							}
							int num5 = ((num3 + 0) ^ 0) + 0 - 0;
							while (true)
							{
								switch ((num2 = (uint)(((num5 - 0 + (0 ^ 0) >> 0 << 0) - 0 << (0 << 1)) + 0 << 0)) % 13)
								{
								case 0u:
									num5 = 414745704;
									continue;
								default:
									return;
								case 9u:
									current = enumerator.Current;
									num5 = (1422392284 - 0 - 0 >> 0) - 0;
									continue;
								case 6u:
									num5 = (int)(((num2 + 758493273) ^ 0x68BEDDD6) - 0 - 0 - 0) >> 0;
									continue;
								case 1u:
									num5 = (int)(((num2 + 1621957012) ^ 0xFC97B059u) + 0 << 0) >> 0 >> 0;
									continue;
								case 2u:
									flag = (Object)(object)current == (Object)(object)GorillaTagger.Instance.offlineVRRig;
									num5 = ((int)(((num2 + 647071759) ^ 0x368E3124) + 0) >> 0) - 0 << 0;
									continue;
								case 10u:
									num5 = (int)((((num2 + 498551263) ^ 0x4E201839) - 0 + 0 - 0) ^ 0);
									continue;
								case 8u:
								{
									int num6;
									int num7;
									if (flag)
									{
										num6 = -1824876392;
										num7 = num6;
									}
									else
									{
										num6 = -1304565892;
										num7 = num6;
									}
									num5 = (((((num6 << 0) + 0) ^ ((int)num2 + -1692824216)) << 0) ^ 0) + 0 >> 0;
									continue;
								}
								case 5u:
									((Renderer)current.mainSkin).material.shader = Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue104\ue116\ue10a\ue16c\ue117\ue126\ue13b\ue137\ue163\ue110\ue12b\ue122\ue127\ue126\ue131", 570483011, true));
									num5 = ((((int)num2 + -1466265009) ^ -849227746 ^ 0) + 0 << 0) - 0;
									continue;
								case 3u:
									num5 = (int)(((((num2 + 1954386908) ^ 0xF0C93256u) << 0) + 0 - 0) ^ 0);
									continue;
								case 11u:
									((Renderer)current.mainSkin).material.color = Color.magenta;
									num5 = 1802649736 - 0 + 0 + 0 - 0;
									continue;
								case 12u:
									break;
								case 4u:
									num5 = (((((int)num2 + -1397142901) ^ 0x3BE0BC19) - 0) ^ 0 ^ 0) >> 0;
									continue;
								case 7u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_036b:
								int num8 = 350301675;
								while (true)
								{
									switch ((num2 = (uint)(((num8 ^ 0) + (0 + 0) + 0 + 0 >> 0) - -0 << 0) ^ 0u) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0370;
									case 3u:
										enumerator.Dispose();
										num8 = ((((((int)num2 + -1280521207) ^ -1058839467) >> 0) - 0) ^ 0) + 0;
										continue;
									case 1u:
										num8 = ((((int)num2 + -1890670034) ^ -68548427) >> 0) - 0 + 0 + 0;
										continue;
									case 2u:
										goto end_IL_0370;
									}
									goto IL_036b;
									continue;
									end_IL_0370:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_0049:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 - 0 >> 0) + 0;
			}
		}
	}

	public chams()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 << (0 << 1)) - 0) ^ 0) - 0 - -0 >> 0) + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) - 0 << 0 << 0) - 0;
			}
		}
	}
}
