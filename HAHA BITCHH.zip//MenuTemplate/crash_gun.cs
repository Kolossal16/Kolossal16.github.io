using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class crash_gun
{
	public static float jerxkejzzbQctrvZbLneIsXnPaGkXtiFsZpRtiVzKweXcSPycIcmABpQheIkxYCgSlKucDFSPOtmnZlWkihpqWeQJyKpALbLUYeQhvwzdjwMidCiTLZpQmPVhTKDSpreMHrpUuOPMImhAsIGWCwPMLVIjiIoKSHNSsZAMnnyWjDiaHvPleGqTBsaMJfLLAfTazoisiUJoXTCiMHBNTdGmqTqZYOchBMveJhBtnwdkWbWHPSZbDYSxzHKFXittRBNlyyyEfizwZvppXIkgObEDTXEcxVvfdJsvoKjrtvVuzvxdsuIpYnEQXjrBTvgkNutqdUbmzSMtfjeyzBKdnghPeCxetIxXoLHechaytvPfAlKOfTbsLdWHmDlAwWTRvPftCZwsAmJRqbpTRJZzGemlOZRyVzbxBYJLfrmgwJSyteqlorJNXtkrCUEChY = 10f;

	public static void wblmpssENAwSdXmNRJJGkDQnziNsilMKYynQnhPYSKEireqnfPcUSANSkXMhEavBOMUEKvzJUKNzZIWvRAmsjRRyKuGquHtSoctEkMCJqtahMoTCbrqeNcsXVvTqPjpnrVkWoslfXCcPQJLwAdodrpfmJwJOSmUgdNQRdWoJfkg()
	{
		//IL_0814: Unknown result type (might be due to invalid IL or missing references)
		//IL_0613: Unknown result type (might be due to invalid IL or missing references)
		//IL_0662: Unknown result type (might be due to invalid IL or missing references)
		//IL_0676: Unknown result type (might be due to invalid IL or missing references)
		//IL_0758: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b41: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = default(GameObject);
		RaycastHit val2 = default(RaycastHit);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		bool flag3 = default(bool);
		int num4 = default(int);
		int num9 = default(int);
		bool flag2 = default(bool);
		bool flag = default(bool);
		bool triggerButtonDown = default(bool);
		Player owner = default(Player);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) ^ 0) + 0) ^ 0) - 0 << -0) + 0 + 0)) % 54)
				{
				case 18u:
					break;
				default:
					return;
				case 20u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.green);
					num = (((int)((num2 + 329939053) ^ 0x5F553751) >> 0) ^ 0) << 0 >> 0;
					continue;
				case 29u:
					num = (int)((((num2 + 972230654) ^ 0xF981F06Cu) + 0 << 0) - 0) >> 0;
					continue;
				case 27u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = (int)(((((num2 + 461443217) ^ 0xB18990FEu) - 0 << 0) ^ 0) - 0);
					continue;
				case 39u:
					num = ((int)((num2 + 951933518) ^ 0x811C3C99u ^ 0) >> 0 << 0) + 0;
					continue;
				case 48u:
					num = (int)(((((num2 + 1587006848) ^ 0x1977B8EB) - 0 - 0) ^ 0) << 0);
					continue;
				case 0u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = ((((int)num2 + -645064961) ^ 0x14D7C45C) - 0 + 0 >> 0) - 0;
					continue;
				case 23u:
				{
					int num7;
					int num8;
					if (flag5)
					{
						num7 = -709189974;
						num8 = num7;
					}
					else
					{
						num7 = -467202268;
						num8 = num7;
					}
					num = (int)((uint)(num7 + 0 >> 0) ^ (num2 + 1755620916) ^ 0) >> 0 >> 0 >> 0;
					continue;
				}
				case 26u:
					flag4 = flag3;
					num = (int)((((((num2 + 65139428) ^ 0x1C0E9E8) << 0) + 0) ^ 0) << 0);
					continue;
				case 37u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((int)((num2 + 452787187) ^ 0x26BE5848) >> 0 << 0 >> 0) - 0;
					continue;
				case 32u:
					num = (((int)num2 + -540388775) ^ 0x5F5AD163) >> 0 << 0 >> 0 >> 0;
					continue;
				case 35u:
					num = (((int)((num2 + 1285777375) ^ 0x396BDC17 ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 46u:
					num = ((((int)((num2 + 1559511532) ^ 0x7B49763B) >> 0) + 0) ^ 0) << 0;
					continue;
				case 42u:
					num4 = num9;
					num = ((((((int)num2 + -595298669) ^ -1088512168) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 45u:
					flag2 = (float)num9 < jerxkejzzbQctrvZbLneIsXnPaGkXtiFsZpRtiVzKweXcSPycIcmABpQheIkxYCgSlKucDFSPOtmnZlWkihpqWeQJyKpALbLUYeQhvwzdjwMidCiTLZpQmPVhTKDSpreMHrpUuOPMImhAsIGWCwPMLVIjiIoKSHNSsZAMnnyWjDiaHvPleGqTBsaMJfLLAfTazoisiUJoXTCiMHBNTdGmqTqZYOchBMveJhBtnwdkWbWHPSZbDYSxzHKFXittRBNlyyyEfizwZvppXIkgObEDTXEcxVvfdJsvoKjrtvVuzvxdsuIpYnEQXjrBTvgkNutqdUbmzSMtfjeyzBKdnghPeCxetIxXoLHechaytvPfAlKOfTbsLdWHmDlAwWTRvPftCZwsAmJRqbpTRJZzGemlOZRyVzbxBYJLfrmgwJSyteqlorJNXtkrCUEChY;
					num = 1638432374 + 0 + 0 + 0 - 0;
					continue;
				case 1u:
					val.transform.position = ((RaycastHit)(ref val2)).point;
					num = ((((((int)num2 + -1883148872) ^ -1098536950) << 0) ^ 0) >> 0) - 0;
					continue;
				case 51u:
				{
					int num12;
					int num13;
					if (flag)
					{
						num12 = 1058620943;
						num13 = num12;
					}
					else
					{
						num12 = 183297077;
						num13 = num12;
					}
					num = (int)(((uint)((num12 - 0) ^ 0) ^ (num2 + 1472348834) ^ 0) + 0 - 0 << 0);
					continue;
				}
				case 19u:
					num = (((int)(((num2 + 67747431) ^ 0x2AC913C) + 0) >> 0) ^ 0) >> 0;
					continue;
				case 21u:
					num = ((int)((num2 + 1603745309) ^ 0x2C8841A2) >> 0 >> 0 >> 0) - 0;
					continue;
				case 6u:
					num = (((int)num2 + -290999538) ^ 0x417349DE ^ 0) - 0 - 0 - 0;
					continue;
				case 22u:
					flag5 = triggerButtonDown;
					num = (((int)((num2 + 1892383293) ^ 0xDC9885DCu ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = (((((int)num2 + -40093842) ^ 0x1B869634) - 0 >> 0) ^ 0) >> 0;
					continue;
				case 7u:
					num = (((int)num2 + -333008605) ^ 0x3E3C9E53) - 0 - 0 >> 0 << 0;
					continue;
				case 25u:
					flag3 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>());
					num = ((((int)num2 + -2049404080) ^ 0x3A26E467) << 0 >> 0) - 0 + 0;
					continue;
				case 2u:
					num = ((int)(((num2 + 1868189554) ^ 0xFFC6E86Au) + 0 - 0) >> 0) - 0;
					continue;
				case 8u:
				{
					int num10;
					int num11;
					if (flag4)
					{
						num10 = -1113885202;
						num11 = num10;
					}
					else
					{
						num10 = -1874795119;
						num11 = num10;
					}
					num = ((((int)((uint)(num10 - 0 + 0) ^ (num2 + 1780261500)) >> 0) + 0) ^ 0) + 0;
					continue;
				}
				case 28u:
					num = (((int)((num2 + 37957927) ^ 0x68B559CE) >> 0) - 0 + 0) ^ 0;
					continue;
				case 30u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = ((((int)num2 + -1930605743) ^ -1563535754) << 0) + 0 - 0 - 0;
					continue;
				case 9u:
					owner = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = 1332531733 + 0 + 0 - 0 << 0;
					continue;
				case 31u:
					num3 = 0;
					num = ((((int)num2 + -574940143) ^ 0x1897B7FC) << 0 << 0 >> 0) + 0;
					continue;
				case 33u:
					num = (int)((((num2 + 1704553265) ^ 0x86ECD2A3u) << 0 << 0) ^ 0 ^ 0);
					continue;
				case 10u:
					num = ((0x65E930FC ^ 0) >> 0) - 0 + 0;
					continue;
				case 34u:
					num9 = 0;
					num = ((int)((((num2 + 1892787482) ^ 0xFB519BA5u) << 0) + 0) >> 0) ^ 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (int)((((num2 + 1960461734) ^ 0xAE7AD40Du ^ 0) + 0 - 0) ^ 0);
					continue;
				case 36u:
					num = (1333463159 - 0 >> 0) - 0 >> 0;
					continue;
				case 11u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((int)num2 + -1777323983) ^ -1451076414) >> 0) + 0 + 0 - 0;
					continue;
				case 38u:
					PhotonNetwork.DestroyPlayerObjects(owner);
					num = (((int)num2 + -462128844) ^ 0x4209563F ^ 0 ^ 0 ^ 0) << 0;
					continue;
				case 40u:
					num = (int)((((num2 + 1452403640) ^ 0xE1CF1B65u) << 0) ^ 0) >> 0 << 0;
					continue;
				case 12u:
					PhotonNetwork.DestroyPlayerObjects(owner);
					num = (((((int)num2 + -171470482) ^ 0x5E0B4D81) >> 0) + 0 << 0) + 0;
					continue;
				case 41u:
					num = (int)(((((num2 + 142740142) ^ 0x4C51A8C9 ^ 0) << 0) ^ 0) << 0);
					continue;
				case 43u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.magenta);
					num = (int)((((num2 + 483666874) ^ 0x419B7BCD ^ 0 ^ 0) << 0) + 0);
					continue;
				case 13u:
					num9 = num4 + 1;
					num = ((int)((num2 + 1700457126) ^ 0xD2B6DEE1u) >> 0 << 0 >> 0) + 0;
					continue;
				case 44u:
					num = (((int)num2 + -641413046) ^ -1355766015 ^ 0 ^ 0) << 0 >> 0;
					continue;
				case 4u:
					num = (((int)((num2 + 11998589) ^ 0x512055BE) >> 0) + 0 - 0) ^ 0;
					continue;
				case 14u:
				{
					int num5;
					int num6;
					if (flag2)
					{
						num5 = 1620140149;
						num6 = num5;
					}
					else
					{
						num5 = 737067698;
						num6 = num5;
					}
					num = (((int)((uint)((num5 ^ 0) >> 0) ^ (num2 + 462091793)) >> 0 << 0) ^ 0) - 0;
					continue;
				}
				case 47u:
					num4 = num3;
					num = ((int)((num2 + 1446341817) ^ 0xA25326C0u) >> 0 << 0) + 0 - 0;
					continue;
				case 49u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = ((((int)num2 + -1904678002) ^ -897871755 ^ 0 ^ 0) + 0) ^ 0;
					continue;
				case 15u:
					num3 = num4 + 1;
					num = ((((int)num2 + -398096355) ^ 0x16C58C32) - 0 - 0) ^ 0 ^ 0;
					continue;
				case 50u:
					flag = num3 < 160;
					num = 76401519 - 0 + 0 - 0 + 0;
					continue;
				case 52u:
					num = ((((((int)num2 + -719845573) ^ -1584257660) >> 0) + 0) ^ 0) << 0;
					continue;
				case 16u:
					num = (int)((((num2 + 1674602320) ^ 0xDC98515Bu) + 0 - 0 << 0) - 0);
					continue;
				case 53u:
					num = (0x57D218AD ^ 0) - 0;
					continue;
				case 5u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (((int)num2 + -1756947900) ^ -2098074454) - 0 - 0 >> 0 << 0;
					continue;
				case 17u:
					return;
				}
				break;
			}
		}
	}

	public crash_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 >> 0 + 0) + 0 << 0) ^ 0) << (0 << 1) >> 0) + 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0 >> 0) + 0) ^ 0;
			}
		}
	}
}
