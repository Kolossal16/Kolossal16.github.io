using System.Collections.Generic;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;

namespace MenuTemplate;

internal class clear_infection
{
	public static void ewQYvoWpOCObSKPehcYvDzMjxhajxtcBOmOxhduBrgfDqItDqxMUhayFKHAnoMRuzmmGVrXeHxdwtjTPNwSaHiuONiNACgnEpLddvNHYAInKWclAOLARURNrSySNEwBAjyhIfPtZPTzYVJSLWmMRGwKxXLkXVUudgMAxUCvYsBcarOwjGhQrKKUNOJKtEweUzvSiiuRtRNyftKgjpbqNddtvRMJkRbtWwhBWWnamqxzWlPteDBeDfqRvbwqvKGBQuCImijnbbexGExjctFGqWQQfqfUzXEBJVJCJghVtndBaTkREmocfZlTDMCWdpNexDNLVVAVlKmcTpQmfopnIBvJJPYWEkSeAYexgzWJLsRvNiZoWqQOaAvVhdbfWEraRiCVksgGsGBqKaWBQKantdeaDipcyQNhbQDEGedDkkwtYelhgzplDdGOeCrbddiBTtpTwrVLHxdjGKbyWh()
	{
		GorillaTagManager current = default(GorillaTagManager);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 - (0 << 1)) ^ 0) << 0 >> 0 >> (0 >> 1) << 0) + 0)) % 3)
				{
				case 0u:
					break;
				case 1u:
					goto IL_0049;
				default:
				{
					IEnumerator<GorillaTagManager> enumerator = Object.FindObjectsOfType<GorillaTagManager>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 1352366883;
								num4 = num3;
							}
							else
							{
								num3 = 414745695;
								num4 = num3;
							}
							int num5 = (num3 >> 0) + 0 << 0 << 0;
							while (true)
							{
								switch ((num2 = (uint)((num5 - 0 - (0 ^ 0) << 0 >> 0 << 0) + (0 ^ 0) + 0 << 0)) % 11)
								{
								case 0u:
									num5 = 414745695;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = ((0x54C7FBD9 ^ 0) >> 0) + 0;
									continue;
								case 2u:
									num5 = (int)(((num2 + 359659174) ^ 0x23D55751) + 0 + 0 - 0 - 0);
									continue;
								case 3u:
									PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
									num5 = (int)(((((num2 + 1621957012) ^ 0xEC75A2D8u) + 0 << 0) - 0) ^ 0);
									continue;
								case 4u:
									current.EndInfectionGame();
									num5 = (int)(((num2 + 647071759) ^ 0x1CA2950A) - 0 - 0) >> 0 << 0;
									continue;
								case 5u:
									num5 = (int)((((((num2 + 428697817) ^ 0xDA98D709u) << 0) ^ 0) << 0) ^ 0);
									continue;
								case 6u:
									Player.Instance.disableMovement = false;
									num5 = ((int)((((num2 + 2106842273) ^ 0xA6B06B04u) << 0) + 0) >> 0) ^ 0;
									continue;
								case 7u:
									num5 = (((((int)num2 + -1125345364) ^ 0xB95EF2D) + 0 + 0) ^ 0) >> 0;
									continue;
								case 8u:
									num5 = (int)((((num2 + 1952503976) ^ 0x992816EBu) - 0 + 0 - 0) ^ 0);
									continue;
								case 9u:
									break;
								case 10u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_02bb:
								int num6 = 758493273;
								while (true)
								{
									switch ((num2 = (uint)((((((num6 + 0) ^ 0) + 0 >> 0) - 0 - (0 << 1)) ^ 0) >> 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_02c0;
									case 1u:
										enumerator.Dispose();
										num6 = ((((((int)num2 + -517084339) ^ 0x6000D2EC) >> 0) + 0) ^ 0) >> 0;
										continue;
									case 2u:
										num6 = ((int)(((num2 + 1464826632) ^ 0xE1D72D61u) + 0 << 0) >> 0) - 0;
										continue;
									case 3u:
										goto end_IL_02c0;
									}
									goto IL_02bb;
									continue;
									end_IL_02c0:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_0049:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB1) >> 0) + 0 >> 0) + 0;
			}
		}
	}

	public clear_infection()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 - (0 >> 1) >> 0) - 0 << 0) + -0 - 0 >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0 >> 0) - 0 << 0;
			}
		}
	}
}
