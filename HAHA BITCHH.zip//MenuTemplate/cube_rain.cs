using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class cube_rain
{
	public static void kZCglKxPLUlVcQYnRIxnKIWMdSUtEOFXhiUmgpxduximSRObeJwaIXwCdQcsQekXonOTVLgBltSmzKTmeSoVsFpjMrjqmenqnlXEdUfsCUOpejdsXQoXPpEJYEhDCQohfCZnNojkMVsxRZfCoRswPqAXGoGyMCQMFGkBjPFIHdkUWhRYyFoKxSrPcbGyIKxkeGRkPEszlKOMfGbzwHZhnfoMpuzhigaXFaPppHjUmPzNeFKvahcaLqWYrfVuekqeJRgeRLkPxeUxGBIJKehbeZmpdQYkMPQczudnzFEpWnCGwzsQwlJadoaKFRaaNadIoRYmyvkfzRfRwFSEyhNAgQZktsIIEDCWjUsFAgrbaDAl()
	{
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Unknown result type (might be due to invalid IL or missing references)
		//IL_0477: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val2 = default(Vector3);
		Quaternion val = default(Quaternion);
		bool flag = default(bool);
		bool gripButtonDown2 = default(bool);
		bool gripButtonDown = default(bool);
		Vector3 val3 = default(Vector3);
		bool flag2 = default(bool);
		Quaternion val4 = default(Quaternion);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num ^ 0) - (0 << 1) + 0 << 0 >> 0 >> (0 ^ 0)) ^ 0u ^ 0u) % 18)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鐚鐍鐔鐔鐝鐌鐨鐊鐝鐞鐙鐚", 170824824, true), val2, val, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1127256878) ^ 0x5875CD88 ^ 0) + 0 + 0) ^ 0;
					continue;
				case 11u:
					flag = gripButtonDown2;
					num = ((((((int)num2 + -517084339) ^ 0x2795289) << 0) + 0) ^ 0) >> 0;
					continue;
				case 9u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = ((int)(((num2 + 1621957012) ^ 0xFCBDA7C5u ^ 0) << 0) >> 0) - 0;
					continue;
				case 14u:
					val3 = ((Component)Player.Instance.headCollider).transform.position + new Vector3(0f, -0.2f, 0f);
					num = (((int)(((num2 + 853099006) ^ 0x57A0604A) + 0) >> 0) ^ 0) << 0;
					continue;
				case 17u:
					num = (((int)((num2 + 67065565) ^ 0x527A9605) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 0u:
					flag2 = gripButtonDown;
					num = (int)(((num2 + 647071759) ^ 0x47DB755D) + 0 + 0 + 0 + 0);
					continue;
				case 2u:
					num = (((((int)num2 + -295483064) ^ 0x7EBFF244) - 0 << 0) ^ 0) << 0;
					continue;
				case 10u:
					gripButtonDown2 = EasyInputs.GetGripButtonDown((EasyHand)0);
					num = 0x7129312D ^ 0;
					continue;
				case 12u:
				{
					int num5;
					int num6;
					if (flag2)
					{
						num5 = -1499203927;
						num6 = num5;
					}
					else
					{
						num5 = -261657566;
						num6 = num5;
					}
					num = (((num5 << 0 << 0) ^ ((int)num2 + -1692824216)) >> 0 >> 0) + 0 - 0;
					continue;
				}
				case 3u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -141539845;
						num4 = num3;
					}
					else
					{
						num3 = -671621403;
						num4 = num3;
					}
					num = ((int)((uint)((num3 + 0) ^ 0) ^ (num2 + 1817661307)) >> 0) + 0 + 0 - 0;
					continue;
				}
				case 13u:
					num = (int)((((num2 + 830009972) ^ 0xBF2005F3u) + 0 + 0 << 0) - 0);
					continue;
				case 15u:
					num = (int)((((((num2 + 1954386908) ^ 0x92C7A4C6u) << 0) - 0) ^ 0) + 0);
					continue;
				case 4u:
					val4 = ((Component)Player.Instance.headCollider).transform.rotation * Quaternion.Euler(0f, 0f, -90f);
					num = ((((((int)num2 + -30974901) ^ -1347416429) << 0) - 0) ^ 0) + 0;
					continue;
				case 16u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᖲᖥᖼᖼᖵᖤᖀᖢᖵᖶᖱᖲ", 73864656, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)(((num2 + 2123088869) ^ 0xDA48C84Eu) << 0) >> 0) ^ 0) << 0;
					continue;
				case 1u:
					val2 = ((Component)Player.Instance.headCollider).transform.position + new Vector3(0f, -0.2f, 0f);
					num = ((((((int)num2 + -692261737) ^ -176148723) + 0) ^ 0) << 0) - 0;
					continue;
				case 7u:
					val = ((Component)Player.Instance.headCollider).transform.rotation * Quaternion.Euler(0f, 0f, -90f);
					num = ((((int)num2 + -1284218664) ^ -1729421585) << 0 << 0 >> 0) + 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public cube_rain()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) + (0 << 1) - 0 - 0 << 0) + (0 << 1) << 0 << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0) + 0 << 0 >> 0;
			}
		}
	}
}
