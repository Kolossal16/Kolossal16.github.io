using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class cubegun
{
	public static void ibxvJqDROzVSlPnGytOilSRBvfyuRwEBZLLsFOUAFvGYHIqWHtBrFjZpkVaDRiasUuSzeVbJzoDQmSTMPBNxUnVQLwhJOqIwuoenPQSLsSSrFjcrcoOqvDxHycOIOsViFgvYOGWZJbecvDkCtPHzCsbRQwONckXaXJLzOeDvsOGuyvmURloYKvGnfDirSiXzdeeLSLOpmlgNLHsvkTWQVZpBcytkVlDkRhquqAcfxYLzoSBxkNhYmhDeODJtrDtbIWWErYeJRQsWoQ()
	{
		//IL_09cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d74: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fcc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_103c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1041: Unknown result type (might be due to invalid IL or missing references)
		//IL_1128: Unknown result type (might be due to invalid IL or missing references)
		//IL_112a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b22: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Unknown result type (might be due to invalid IL or missing references)
		//IL_078b: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c88: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0927: Unknown result type (might be due to invalid IL or missing references)
		//IL_092c: Unknown result type (might be due to invalid IL or missing references)
		//IL_092d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_080b: Unknown result type (might be due to invalid IL or missing references)
		//IL_080d: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_096d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_099b: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e78: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_075a: Unknown result type (might be due to invalid IL or missing references)
		//IL_075c: Unknown result type (might be due to invalid IL or missing references)
		//IL_106e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a76: Unknown result type (might be due to invalid IL or missing references)
		//IL_10dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_10df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aac: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val3 = default(Vector3);
		Vector3 val2 = default(Vector3);
		Quaternion rotation = default(Quaternion);
		RaycastHit val6 = default(RaycastHit);
		GameObject val = default(GameObject);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301864;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0 << (0 ^ 0)) ^ 0) >> 0) + 0) ^ 0) - 0) ^ 0u) % 67)
				{
				case 55u:
					break;
				default:
					return;
				case 57u:
				{
					Vector3 val5 = val3;
					num = ((int)((num2 + 359358379) ^ 0x1BE60173) >> 0) + 0 << 0 >> 0;
					continue;
				}
				case 29u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("僉僞僇僇僎僟僻僙僎働僊僉", 1182290091, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -946770217) ^ 0xCBB9836) + 0 - 0 >> 0) ^ 0;
					continue;
				case 27u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val6);
					num = ((((int)((num2 + 1661375474) ^ 0xFE132D59u) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 39u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("꾏꾘꾁꾁꾈꾙꾽꾟꾈꾋꾌꾏", 1571991533, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)(((num2 + 1344932091) ^ 0xE8B08DFBu) - 0) >> 0) - 0 + 0;
					continue;
				case 48u:
				{
					Quaternion rotation8 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -113808718) ^ 0x7CD7079C) << 0 << 0) + 0 >> 0;
					continue;
				}
				case 0u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((int)((num2 + 1270048165) ^ 0x9AF997D6u) >> 0) - 0 << 0) + 0;
					continue;
				case 66u:
					num = ((int)(((num2 + 853643342) ^ 0x347BF062 ^ 0) << 0) >> 0) + 0;
					continue;
				case 26u:
					num = (int)(((((num2 + 271593804) ^ 0x75962B04) << 0) ^ 0) << 0) >> 0;
					continue;
				case 37u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((int)(((num2 + 364309176) ^ 0x21044BFA) << 0) >> 0) + 0 >> 0;
					continue;
				case 32u:
				{
					Vector3 val11 = val3;
					num = (int)((((num2 + 1525327414) ^ 0xF3D2481Bu) - 0 << 0) + 0) >> 0;
					continue;
				}
				case 35u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = ((int)((num2 + 1824108797) ^ 0x8706EBBFu) >> 0 << 0) - 0 - 0;
					continue;
				case 46u:
					num = (int)(((num2 + 1438922508) ^ 0x70790314) + 0 - 0 << 0) >> 0;
					continue;
				case 42u:
				{
					Vector3 val10 = val3;
					num = (((int)num2 + -1963962512) ^ -846547876 ^ 0) + 0 - 0 >> 0;
					continue;
				}
				case 45u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = (((((int)num2 + -1090264534) ^ 0x634135E1) >> 0) + 0 << 0) + 0;
					continue;
				case 1u:
					val.transform.position = ((RaycastHit)(ref val6)).point;
					num = ((int)((num2 + 757804180) ^ 0x5B1E6FAE ^ 0) >> 0) + 0 - 0;
					continue;
				case 51u:
					num = ((int)((num2 + 557269837) ^ 0x7379E4A8) >> 0) - 0 - 0 >> 0;
					continue;
				case 54u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꖗꖀꖙꖙꖐꖁꖥꖇꖐꖓꖔꖗ", 1907926517, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -227079681) ^ 0x51C83239) - 0 >> 0 << 0) - 0;
					continue;
				case 64u:
					num = (int)((num2 + 403315589) ^ 0x64055BDE) >> 0 >> 0 >> 0 >> 0;
					continue;
				case 60u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = (((int)((num2 + 1667326257) ^ 0xDADBF64Eu) >> 0) + 0 >> 0) - 0;
					continue;
				case 63u:
				{
					Quaternion rotation7 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)num2 + -1814199395) ^ -775150672) - 0 - 0 - 0 - 0;
					continue;
				}
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = (((((int)num2 + -396906955) ^ 0x74FD0F2A) + 0 >> 0) ^ 0) << 0;
					continue;
				case 7u:
					num = ((((int)num2 + -900572852) ^ 0x5C493601) + 0 + 0 << 0) + 0;
					continue;
				case 25u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = (int)(((((num2 + 64584048) ^ 0xB827DD7Fu) - 0 << 0) - 0) ^ 0);
					continue;
				case 2u:
					num = ((int)(((num2 + 1246932057) ^ 0xD2CF4DA2u) << 0) >> 0 << 0) + 0;
					continue;
				case 8u:
					val2 = val3;
					num = ((int)(((num2 + 1954100370) ^ 0xABF783D3u) << 0) >> 0) - 0 >> 0;
					continue;
				case 28u:
					rotation = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((((int)num2 + -1118155190) ^ -1551087999) >> 0) - 0 >> 0) + 0;
					continue;
				case 30u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (((((int)num2 + -100986504) ^ 0x31DC1CBF) - 0 << 0) ^ 0) - 0;
					continue;
				case 9u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = ((((int)num2 + -2113229183) ^ -164078549 ^ 0) + 0 + 0) ^ 0;
					continue;
				case 31u:
					num = ((((int)num2 + -2072603691) ^ -430752707) - 0 - 0 >> 0) + 0;
					continue;
				case 33u:
					num = (((int)((num2 + 583561026) ^ 0xC3DFEE80u ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 10u:
				{
					Quaternion rotation6 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -992982523) ^ 0x4DF0A2FC) + 0 >> 0) - 0 + 0;
					continue;
				}
				case 34u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鞒鞅鞜鞜鞕鞄鞠鞂鞕鞖鞑鞒", 2042992624, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -166613855) ^ 0x761190C7) >> 0 >> 0 >> 0) ^ 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = ((((((int)num2 + -1536809407) ^ -1612303018) - 0) ^ 0) >> 0) - 0;
					continue;
				case 36u:
					num = ((((((int)num2 + -847217407) ^ -1537631631) << 0) ^ 0) + 0) ^ 0;
					continue;
				case 11u:
				{
					Vector3 val9 = val3;
					num = (((int)num2 + -2011313270) ^ -1684947057) + 0 + 0 << 0 << 0;
					continue;
				}
				case 38u:
				{
					Quaternion rotation5 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1562374052) ^ -1667379355) - 0 >> 0 << 0) - 0;
					continue;
				}
				case 40u:
					num = ((((int)num2 + -1999758855) ^ -678728558) >> 0) + 0 + 0 + 0;
					continue;
				case 12u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = ((int)((num2 + 2133633953) ^ 0xE8A4538Du) >> 0) - 0 - 0 << 0;
					continue;
				case 41u:
					num = (((int)num2 + -590282087) ^ 0x181EA0DF ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 43u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.magenta);
					num = ((((int)num2 + -1497151632) ^ -880122023 ^ 0) + 0 - 0) ^ 0;
					continue;
				case 13u:
				{
					Quaternion rotation4 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((((num2 + 427816739) ^ 0x66DBD374) + 0 << 0) - 0) ^ 0);
					continue;
				}
				case 44u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("콊콝콄콄콍콜콸콚콍콎콉콊", 389926696, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1557715738) ^ 0x2C0CB018 ^ 0) - 0 + 0) >> 0;
					continue;
				case 4u:
					num = ((((int)((num2 + 234277810) ^ 0x5E619FDE) >> 0) ^ 0) << 0) + 0;
					continue;
				case 14u:
					num = (int)((((num2 + 2100385416) ^ 0x880462FFu) - 0 + 0 << 0) ^ 0);
					continue;
				case 47u:
				{
					Vector3 val8 = val3;
					num = ((int)((((num2 + 1657774638) ^ 0xB6ED5BAAu) - 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 49u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = ((((((int)num2 + -554548610) ^ 0x3AE24B7A) << 0) ^ 0) << 0) ^ 0;
					continue;
				case 15u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㤲㤥㤼㤼㤵㤤㤀㤢㤵㤶㤱㤲", 653408592, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)((num2 + 485455216) ^ 0xDBAFA391u) >> 0) - 0) ^ 0) - 0;
					continue;
				case 50u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = (int)(((num2 + 501888951) ^ 0x6C877FA0 ^ 0) - 0 - 0 + 0);
					continue;
				case 52u:
					num = (int)((((num2 + 1195113832) ^ 0x17BE2F4D) << 0 << 0) - 0) >> 0;
					continue;
				case 16u:
				{
					Vector3 val7 = val3;
					num = (((((int)num2 + -1873812145) ^ -2129014976) + 0) ^ 0 ^ 0) - 0;
					continue;
				}
				case 53u:
				{
					Quaternion rotation3 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1265694141) ^ 0x4D7612F7) + 0 << 0) + 0 << 0;
					continue;
				}
				case 5u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = ((int)((((num2 + 1608343532) ^ 0xCA5E22F5u) + 0) ^ 0) >> 0) ^ 0;
					continue;
				case 17u:
					val3 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val6)).point);
					num = (((((int)num2 + -946157137) ^ -1324689839) >> 0) + 0 - 0) ^ 0;
					continue;
				case 56u:
					num = (((int)((num2 + 1641116637) ^ 0xEA6F68E4u) >> 0) - 0 >> 0) ^ 0;
					continue;
				case 58u:
					flag = triggerButtonDown;
					num = (((int)num2 + -534003067) ^ 0x26C29AF0 ^ 0 ^ 0) - 0 >> 0;
					continue;
				case 18u:
				{
					Quaternion rotation2 = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = ((((int)num2 + -1078135537) ^ 0x2E27973F) << 0 << 0 >> 0) ^ 0;
					continue;
				}
				case 59u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("耝耊耓耓耚耋耯耍耚耙耞耝", 1143177343, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 614257393) ^ 0x1D57988E) << 0 << 0) - 0 << 0);
					continue;
				case 61u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 930567851;
						num4 = num3;
					}
					else
					{
						num3 = 1819993642;
						num4 = num3;
					}
					num = ((num3 - 0 >> 0) ^ ((int)num2 + -1412658558)) << 0 << 0 >> 0 >> 0;
					continue;
				}
				case 19u:
					num = (((((int)num2 + -6506061) ^ 0x4E7D1954) - 0 << 0) ^ 0) >> 0;
					continue;
				case 62u:
				{
					Vector3 val4 = val3;
					num = ((int)(((num2 + 2123703122) ^ 0x9E426BC1u) << 0 << 0) >> 0) + 0;
					continue;
				}
				case 6u:
					num = ((int)((num2 + 1216645994) ^ 0x3B5C61B2) >> 0) + 0 << 0 << 0;
					continue;
				case 20u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ඟඈඑඑ\u0d98ඉතඏ\u0d98ඛගඟ", 907218429, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)((num2 + 913818940) ^ 0xF75DA121u) >> 0) + 0) ^ 0 ^ 0;
					continue;
				case 65u:
					num = (((int)num2 + -327589424) ^ 0x5B16AEE2 ^ 0) + 0 + 0 << 0;
					continue;
				case 22u:
					num = ((((int)num2 + -1926617086) ^ -117837216) + 0 >> 0) ^ 0 ^ 0;
					continue;
				case 23u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.green);
					num = (((((int)num2 + -1155788487) ^ -2094929787 ^ 0) - 0) ^ 0) >> 0;
					continue;
				case 21u:
					return;
				}
				break;
			}
		}
	}

	public cubegun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 + (0 + 0) >> 0) + 0 + 0 + -0 >> 0 >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) + 0 + 0 + 0) ^ 0;
			}
		}
	}
}
