using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class targetgun
{
	public static void hupwabduNsUDvnpEaLPYlqrTfWDoPvQUAuQaGzHlSwXHBANtGNFpVchRcvqeyPErCacaxoXAdDgOsKsFikHcQBYynYXkiDNcRFfAxMVsPelrVszsdLWoiCBabENzqMrAQdWMERhvopmMqGCVyFhxGzUpeezTZwbdMKBSvNNlDAZSqOKubSaLEUTqjHHzso()
	{
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_0451: Unknown result type (might be due to invalid IL or missing references)
		//IL_0575: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0741: Unknown result type (might be due to invalid IL or missing references)
		//IL_0746: Unknown result type (might be due to invalid IL or missing references)
		//IL_0747: Unknown result type (might be due to invalid IL or missing references)
		//IL_0785: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val3 = default(RaycastHit);
		GameObject val4 = default(GameObject);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		Vector3 val2 = default(Vector3);
		Quaternion rotation = default(Quaternion);
		Vector3 val = default(Vector3);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) + (0 << 1) - 0) ^ 0 ^ 0) + (0 << 1) << 0 >> 0)) % 32)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val3);
					num = (int)(((((num2 + 1665746989) ^ 0xF9D1D92Cu) - 0) ^ 0 ^ 0) << 0);
					continue;
				case 2u:
					val4 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (int)(((((num2 + 770395556) ^ 0x7831BF25) - 0 << 0) ^ 0) - 0);
					continue;
				case 3u:
					val4.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (int)(((num2 + 1333463150) ^ 0x7AC06D95) + 0) >> 0 << 0 >> 0;
					continue;
				case 4u:
					num = ((((int)num2 + -227232852) ^ 0x14C88495) << 0 << 0 >> 0) ^ 0;
					continue;
				case 5u:
					val4.transform.position = ((RaycastHit)(ref val3)).point;
					num = (int)((((num2 + 1107201870) ^ 0x40C2C9B5) << 0) - 0) >> 0 << 0;
					continue;
				case 6u:
					num = (int)(((num2 + 1548432940) ^ 0x21C441AF ^ 0) - 0 - 0) >> 0;
					continue;
				case 29u:
					Object.Destroy((Object)(object)val4.GetComponent<BoxCollider>());
					num = ((((((int)num2 + -1008375456) ^ 0x514FC01A) >> 0) + 0) ^ 0) >> 0;
					continue;
				case 27u:
					num = (((int)((num2 + 1880337016) ^ 0x8A30252Fu) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 7u:
					num = (int)((((num2 + 1457370637) ^ 0xE63A473Cu) << 0) - 0) >> 0 >> 0;
					continue;
				case 8u:
					Object.Destroy((Object)(object)val4.GetComponent<Rigidbody>());
					num = (int)((((((num2 + 1956669763) ^ 0xCAB3B462u) << 0) ^ 0) - 0) ^ 0);
					continue;
				case 9u:
					num = ((((int)num2 + -2071082168) ^ -1516719461) << 0 << 0) - 0 >> 0;
					continue;
				case 10u:
					Object.Destroy((Object)(object)val4.GetComponent<Collider>());
					num = (((((int)num2 + -434831334) ^ 0x5D310F8F) >> 0) + 0 + 0) ^ 0;
					continue;
				case 11u:
					num = ((int)((num2 + 461443217) ^ 0xA5386610u) >> 0 << 0) - 0 >> 0;
					continue;
				case 12u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val4, Color.magenta);
					num = ((((int)num2 + -645064961) ^ -61057210) << 0) - 0 + 0 >> 0;
					continue;
				case 13u:
					num = ((((int)((num2 + 452787187) ^ 0x4C9A6E5F) >> 0) + 0) ^ 0) - 0;
					continue;
				case 26u:
					num = (((int)num2 + -117175874) ^ 0x7F213B63) - 0 - 0 - 0 << 0;
					continue;
				case 31u:
					Object.Destroy((Object)(object)val4, Time.deltaTime);
					num = ((int)(((num2 + 1559511532) ^ 0xB8E04BA5u) + 0) >> 0) - 0 >> 0;
					continue;
				case 14u:
					num = (((((int)num2 + -1883148872) ^ -299581463) << 0) ^ 0) + 0 >> 0;
					continue;
				case 15u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = ((int)((num2 + 1603745309) ^ 0xCA00083Cu) >> 0 << 0) - 0 + 0;
					continue;
				case 16u:
					flag = triggerButtonDown;
					num = ((((((int)num2 + -40093842) ^ 0x3853162F) >> 0) ^ 0) << 0) - 0;
					continue;
				case 17u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1043986588;
						num4 = num3;
					}
					else
					{
						num3 = 756558130;
						num4 = num3;
					}
					num = (((((num3 ^ 0) >> 0) ^ ((int)num2 + -1519429041)) << 0 >> 0) - 0) ^ 0;
					continue;
				}
				case 18u:
					num = ((((int)num2 + -1198723765) ^ -1957427282) >> 0 << 0 >> 0) - 0;
					continue;
				case 19u:
					num = (int)(((num2 + 207985003) ^ 0x793D648A) + 0 - 0) >> 0 << 0;
					continue;
				case 25u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᵅᵂᵟᵕᵝᵗᵔᵚᵓᴶᵂᵗᵄᵑᵓᵂ", 590552342, true), val2, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)((num2 + 1100433178) ^ 0x82B1C069u) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 20u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val4, Color.green);
					num = ((((((int)num2 + -1804281275) ^ -108342649) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 30u:
					num = ((((((int)num2 + -2057924117) ^ -1588789444) >> 0) + 0) ^ 0) >> 0;
					continue;
				case 21u:
					val = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val3)).point);
					num = ((((int)((num2 + 891081771) ^ 0x8BFA3B96u) >> 0) + 0) ^ 0) - 0;
					continue;
				case 22u:
					num = ((int)((((num2 + 1493219093) ^ 0xAEA7D53Cu) << 0) - 0) >> 0) - 0;
					continue;
				case 23u:
					val2 = val;
					num = (int)(((((num2 + 2022602987) ^ 0xAFE95F7Au) - 0) ^ 0) + 0 + 0);
					continue;
				case 24u:
					rotation = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (((int)((num2 + 1121261575) ^ 0x2907BF66) >> 0) ^ 0) << 0 << 0;
					continue;
				case 28u:
					return;
				}
				break;
			}
		}
	}

	public targetgun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0 >> -0) + 0 - 0 - 0 - (0 ^ 0) >> 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB1) >> 0) ^ 0) >> 0) + 0;
			}
		}
	}
}
