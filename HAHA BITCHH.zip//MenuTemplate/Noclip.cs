using System.Collections.Generic;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class Noclip
{
	public static void AnegaTwhQHPPUMKWsXIPGIFiHtqCFQKKRlgfftCKPAMrYljvOOqoonySIWzGCUBZWeXIGEQZuXZfWokvkVOQAwwENoxjTViVZMuTnAOjYqTqnsVtLdvHgKzAItUshGgyPegjUqiJgESjDfqvsdxQzAPonTlUFwcrkuBjlMzvVMBBSpXCdzZdiqZopSWafoeKCAZiEhjFDcUNZnvXWIQfwYiUvmTtQzpHHQYrqOYVquAgv()
	{
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		MeshCollider current = default(MeshCollider);
		MeshCollider current2 = default(MeshCollider);
		bool flag3 = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				int num7;
				uint num2;
				switch ((num2 = (uint)(((((((num ^ 0) << (0 >> 1)) - 0 >> 0) ^ 0) + (0 ^ 0)) ^ 0) << 0)) % 7)
				{
				case 0u:
					break;
				case 5u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((((((int)num2 + -725091362) ^ 0x852856F) << 0) ^ 0) - 0) ^ 0;
					continue;
				case 2u:
					num = ((int)((num2 + 600520462) ^ 0x22720310) >> 0 << 0 << 0) + 0;
					continue;
				case 1u:
					flag = triggerButtonDown;
					num = ((((int)num2 + -956687329) ^ -415052116 ^ 0) >> 0 >> 0) + 0;
					continue;
				case 6u:
					num = (((((int)num2 + -795116775) ^ -5259852) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 4u:
					if (flag)
					{
						num = (int)(((num2 + 1345212153) ^ 0x7B8CB704) + 0 + 0 << 0) >> 0;
						continue;
					}
					goto IL_045c;
				default:
					{
						IEnumerator<MeshCollider> enumerator = Resources.FindObjectsOfTypeAll<MeshCollider>().GetEnumerator();
						try
						{
							while (true)
							{
								IL_0256:
								int num3;
								int num4;
								if (enumerator.MoveNext())
								{
									num3 = 1621957013;
									num4 = num3;
								}
								else
								{
									num3 = 2106842276;
									num4 = num3;
								}
								int num5 = (num3 - 0 - 0 >> 0) ^ 0;
								while (true)
								{
									switch ((num2 = (uint)((((((num5 >> 0) + (0 ^ 0)) ^ 0) << 0) ^ 0) - -0 << 0) ^ 0u) % 8)
									{
									case 0u:
										num5 = 1621957013;
										continue;
									default:
										goto end_IL_016a;
									case 5u:
										current = enumerator.Current;
										num5 = ((0x661A46D1 ^ 0) << 0 >> 0) - 0;
										continue;
									case 3u:
										break;
									case 1u:
										num5 = (((((int)num2 + -1186296972) ^ 0x39F55A4A) >> 0) + 0 << 0) - 0;
										continue;
									case 6u:
										num5 = (((int)(((num2 + 900749756) ^ 0x18B55301) - 0) >> 0) ^ 0) >> 0;
										continue;
									case 7u:
										((Collider)current).enabled = false;
										num5 = (((((int)num2 + -1701687338) ^ -1788238585 ^ 0) - 0) ^ 0) >> 0;
										continue;
									case 2u:
										num5 = (((((int)num2 + -1219895373) ^ 0x12193A4B) << 0) - 0) ^ 0 ^ 0;
										continue;
									case 4u:
										goto end_IL_016a;
									}
									goto IL_0256;
									continue;
									end_IL_016a:
									break;
								}
								break;
							}
						}
						finally
						{
							if (enumerator != null)
							{
								while (true)
								{
									IL_02fb:
									int num6 = 1630399311;
									while (true)
									{
										switch ((num2 = (uint)((((num6 >> 0 >> -0 >> 0) ^ 0) >> 0) - (0 << 1) - 0 << 0)) % 4)
										{
										case 0u:
											break;
										default:
											goto end_IL_0300;
										case 3u:
											enumerator.Dispose();
											num6 = (((((int)num2 + -1395914388) ^ 0x636456AE ^ 0) >> 0) ^ 0) - 0;
											continue;
										case 1u:
											num6 = (int)(((((num2 + 1319775793) ^ 0xEA08AB4Cu) - 0) ^ 0) << 0) >> 0;
											continue;
										case 2u:
											goto end_IL_0300;
										}
										goto IL_02fb;
										continue;
										end_IL_0300:
										break;
									}
									break;
								}
							}
						}
						goto IL_039c;
					}
					IL_045c:
					num7 = (0xBC3E56D ^ 0) >> 0;
					goto IL_03a1;
					IL_03a1:
					while (true)
					{
						switch ((num2 = (uint)(((((num7 << 0) - (0 >> 1) - 0) ^ 0) << 0) ^ 0) ^ 0u ^ 0u) % 5)
						{
						case 0u:
							break;
						case 3u:
							return;
						case 4u:
							num7 = (int)((((num2 + 1047830633) ^ 0x47D92DA8) - 0 - 0) ^ 0) >> 0;
							continue;
						case 1u:
							goto IL_045c;
						default:
						{
							IEnumerator<MeshCollider> enumerator2 = Resources.FindObjectsOfTypeAll<MeshCollider>().GetEnumerator();
							try
							{
								while (true)
								{
									int num8;
									int num9;
									if (enumerator2.MoveNext())
									{
										num8 = 441892083;
										num9 = num8;
									}
									else
									{
										num8 = 1016054123;
										num9 = num8;
									}
									int num10 = (num8 << 0) + 0 - 0 << 0;
									while (true)
									{
										switch ((num2 = (uint)(((num10 ^ 0) - (0 + 0) << 0 >> 0 << 0) - (0 + 0) >> 0 >> 0)) % 13)
										{
										case 0u:
											num10 = 441892083;
											continue;
										default:
											return;
										case 9u:
											current2 = enumerator2.Current;
											num10 = (770053376 << 0) - 0 + 0 + 0;
											continue;
										case 5u:
											num10 = (int)(((num2 + 461723281) ^ 0x7370A724 ^ 0 ^ 0) + 0 << 0);
											continue;
										case 1u:
											num10 = (int)((((((num2 + 502420178) ^ 0x5A8FB5C5) + 0) ^ 0) << 0) ^ 0);
											continue;
										case 4u:
											((Collider)current2).enabled = true;
											num10 = ((1822608980 >> 0) - 0 >> 0) + 0;
											continue;
										case 7u:
											flag3 = !((Collider)current2).enabled;
											num10 = (int)(((num2 + 1855391286) ^ 0x6BF55943) - 0 + 0) >> 0 << 0;
											continue;
										case 8u:
											num10 = (int)(((num2 + 1168528836) ^ 0x8514B554u) << 0) >> 0 << 0 << 0;
											continue;
										case 2u:
											flag2 = !flag3;
											num10 = (int)((((num2 + 1919092371) ^ 0xF92C96B3u) << 0 << 0) + 0 + 0);
											continue;
										case 10u:
											num10 = (int)((((num2 + 747926746) ^ 0xA96BB715u) - 0 + 0 << 0) + 0);
											continue;
										case 11u:
										{
											int num11;
											int num12;
											if (flag2)
											{
												num11 = -260386357;
												num12 = num11;
											}
											else
											{
												num11 = -1715888072;
												num12 = num11;
											}
											num10 = ((int)((uint)(num11 + 0 - 0) ^ (num2 + 1263618995) ^ 0) >> 0) - 0 >> 0;
											continue;
										}
										case 12u:
											break;
										case 3u:
											num10 = (int)((((num2 + 1798378934) ^ 0xD5FFBCBFu) - 0 << 0) + 0 - 0);
											continue;
										case 6u:
											return;
										}
										break;
									}
								}
							}
							finally
							{
								if (enumerator2 != null)
								{
									while (true)
									{
										IL_0758:
										int num13 = 924155371;
										while (true)
										{
											switch ((num2 = (uint)((((((num13 - 0 >> (0 ^ 0)) + 0) ^ 0 ^ 0) << (0 >> 1)) ^ 0) >> 0)) % 4)
											{
											case 0u:
												break;
											default:
												goto end_IL_075d;
											case 3u:
												enumerator2.Dispose();
												num13 = ((((int)num2 + -82741106) ^ 0x608AAF78) << 0 << 0) + 0 >> 0;
												continue;
											case 1u:
												num13 = ((((int)num2 + -932232491) ^ 0x63F0159C) << 0 >> 0 >> 0) + 0;
												continue;
											case 2u:
												goto end_IL_075d;
											}
											goto IL_0758;
											continue;
											end_IL_075d:
											break;
										}
										break;
									}
								}
							}
						}
						}
						break;
					}
					goto IL_039c;
					IL_039c:
					num7 = 660359993;
					goto IL_03a1;
				}
				break;
			}
		}
	}

	public Noclip()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) - (0 + 0) + 0) ^ 0) << 0) - -0 + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 + 0 >> 0) + 0;
			}
		}
	}
}
