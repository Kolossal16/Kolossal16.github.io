using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class StickAble_target_spawner
{
	public static void QOPSXtOklTTPWYKsdPbsmuBTpKAXvUdlOUoUdspskeQVXuMkrXbjydIvnVCnSQPrQHbcJQoKAJihDFVUYqGxTTMKlSGhQbztpzeptKABJqIPUBRIaHoCjrxXUqRRjgUykOSeAFAoQfODkXPJaYhiNXkXbhvdSIsDvkFgJNhugaLdDUMXAhRkZLLmEUcskxvhNkharJamRMcMlguhvxDLRhEKysCOLOjJFDqsNLFQhEtmJZbxAVXMTKqFGxCZhlBcCshHQbuKRMDmOrayqeoPRwQUnKLpjGJVcqJrSuHyBnVggdRowdIcXLlfBmufqeAldIkyIJGWxQoEBJOjTwSfYGXqfDPGZBhwMKcxT()
	{
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown2 = default(bool);
		Vector3 position2 = default(Vector3);
		Quaternion rotation2 = default(Quaternion);
		bool gripButtonDown = default(bool);
		Vector3 position = default(Vector3);
		Quaternion rotation = default(Quaternion);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0) ^ 0) << 0) - 0 >> 0 << -0) - 0) ^ 0u) % 18)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = (int)((((num2 + 1621957012) ^ 0xFCBDA7DFu) << 0) + 0 + 0 - 0);
					continue;
				case 2u:
					gripButtonDown2 = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = (int)((((((num2 + 647071759) ^ 0x47DB7A98) << 0) - 0) ^ 0) + 0);
					continue;
				case 3u:
				{
					int num5;
					int num6;
					if (gripButtonDown2)
					{
						num5 = -1499203943;
						num6 = num5;
					}
					else
					{
						num5 = -261657561;
						num6 = num5;
					}
					num = ((((num5 << 0) + 0) ^ ((int)num2 + -1692824216) ^ 0) >> 0) + 0 >> 0;
					continue;
				}
				case 4u:
					num = ((int)(((num2 + 1954386908) ^ 0x92C7A4C9u ^ 0) - 0) >> 0) + 0;
					continue;
				case 5u:
					position2 = ((Component)Player.Instance.rightHandTransform).transform.position;
					num = (((((int)num2 + -692261737) ^ -176148728) >> 0) ^ 0) + 0 + 0;
					continue;
				case 6u:
					rotation2 = ((Component)Player.Instance.rightHandTransform).transform.rotation;
					num = (((((int)num2 + -1284218664) ^ -1729421609) << 0 << 0) - 0) ^ 0;
					continue;
				case 17u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("┕┒┏┅┍┇┄┊┃╦┒┇└━┃┒", 778904902, true), position2, rotation2, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1127256878) ^ 0x5875CD9C) - 0 - 0 << 0) ^ 0;
					continue;
				case 14u:
					num = (1259723679 + 0 >> 0) + 0 + 0;
					continue;
				case 7u:
					num = ((int)num2 + -295483064) ^ 0x7EBFF257 ^ 0 ^ 0 ^ 0 ^ 0;
					continue;
				case 8u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)0);
					num = ((1898524971 << 0) - 0 << 0) + 0;
					continue;
				case 9u:
				{
					int num3;
					int num4;
					if (gripButtonDown)
					{
						num3 = -702279188;
						num4 = num3;
					}
					else
					{
						num3 = -1822053978;
						num4 = num3;
					}
					num = ((int)(((uint)((num3 >> 0) - 0) ^ (num2 + 350301675)) << 0) >> 0) - 0 + 0;
					continue;
				}
				case 10u:
					num = (int)((((num2 + 1817661307) ^ 0xD7F7DEFCu ^ 0) + 0) ^ 0) >> 0;
					continue;
				case 11u:
					position = ((Component)Player.Instance.leftHandTransform).transform.position;
					num = (int)(((((num2 + 830009972) ^ 0xBF2005F7u) + 0 << 0) ^ 0) - 0);
					continue;
				case 12u:
					rotation = ((Component)Player.Instance.leftHandTransform).transform.rotation;
					num = ((int)(((num2 + 853099006) ^ 0x57A06041) << 0) >> 0) + 0 << 0;
					continue;
				case 13u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("椮椩椴椾椶椼椿椱椸楝椩椼椯椺椸椩", 574450045, true), position, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -30974901) ^ -1347416436 ^ 0) << 0) + 0) ^ 0;
					continue;
				case 16u:
					num = (int)(((num2 + 2123088869) ^ 0xDA48C84Du) + 0 - 0 - 0) >> 0;
					continue;
				case 15u:
					return;
				}
				break;
			}
		}
	}

	public StickAble_target_spawner()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 + (0 >> 1) - 0) ^ 0) << 0 >> (0 ^ 0)) + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) + 0 >> 0) - 0 >> 0;
			}
		}
	}
}
