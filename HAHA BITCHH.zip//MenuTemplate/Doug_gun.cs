using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class Doug_gun
{
	public static void MBtBRlddOEXKvqsWSjbBUQSnRiKmGZQCvEHvxUxaOlUYoacJXorteJcWIgKJARwPOupRJXyYMbMIVTYQfapsIwxMBKMqkNzXOfkTLlaZPtGdWtbOhTDABdgrXCpZkhOYBOTQJffUaqDpQuPiIYjqkZvLYTWjWbOHFIChzlfcOIzlARACMgqmYxOCsiRPiVYZBWJhSIIxSgCBzkkhstwPLBIhUZOruqTSKAKEhtKex()
	{
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_070b: Unknown result type (might be due to invalid IL or missing references)
		//IL_070d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_073e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		bool flag = default(bool);
		Vector3 val3 = default(Vector3);
		Quaternion rotation = default(Quaternion);
		RaycastHit val4 = default(RaycastHit);
		GameObject val = default(GameObject);
		bool triggerButtonDown = default(bool);
		Vector3 val2 = default(Vector3);
		while (true)
		{
			int num = 1758301883;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 << -0) - 0 >> 0) - 0 << (0 << 1) >> 0) + 0)) % 32)
				{
				case 18u:
					break;
				default:
					return;
				case 20u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1043986569;
						num4 = num3;
					}
					else
					{
						num3 = 756558117;
						num4 = num3;
					}
					num = (((num3 + 0 >> 0) ^ ((int)num2 + -1519429041)) << 0 >> 0) - 0 + 0;
					continue;
				}
				case 29u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鲒鲚鲇鲜鲙鲙鲔鲅鲇鲐鲓鲔鲗鲆鳚鲡鲽鲧鲺鲢", 1586207989, true), val3, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1100433178) ^ 0x82B1C07Eu) + 0 + 0 - 0 + 0);
					continue;
				case 27u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val4);
					num = (int)(((num2 + 1665746989) ^ 0xF9D1D908u ^ 0 ^ 0) + 0 << 0);
					continue;
				case 14u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.magenta);
					num = ((((((int)num2 + -645064961) ^ -61057207) << 0) - 0) ^ 0) + 0;
					continue;
				case 17u:
					num = (((((int)num2 + -1883148872) ^ -299581460) >> 0) ^ 0) << 0 >> 0;
					continue;
				case 0u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = ((int)(((num2 + 770395556) ^ 0x7831BF28) + 0 << 0) >> 0) - 0;
					continue;
				case 23u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.green);
					num = ((((int)num2 + -1804281275) ^ -108342629) + 0 >> 0 >> 0) - 0;
					continue;
				case 26u:
					num = ((int)((num2 + 1493219093) ^ 0xAEA7D527u) >> 0) - 0 + 0 + 0;
					continue;
				case 12u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((int)((num2 + 1333463150) ^ 0x7AC06D95) >> 0 >> 0) + 0 + 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (((int)num2 + -434831334) ^ 0x5D310E70) << 0 >> 0 >> 0 << 0;
					continue;
				case 13u:
					num = ((int)(((num2 + 461443217) ^ 0xA5386610u) + 0) >> 0 >> 0) - 0;
					continue;
				case 15u:
					num = (((int)num2 + -227232852) ^ 0x14C8849A ^ 0) >> 0 << 0 >> 0;
					continue;
				case 4u:
					num = (int)(((num2 + 452787187) ^ 0x4C9A6E27) + 0 + 0 - 0) >> 0;
					continue;
				case 16u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (int)(((((num2 + 1559511532) ^ 0xB8E04A4Du) - 0) ^ 0) - 0 << 0);
					continue;
				case 1u:
					val.transform.position = ((RaycastHit)(ref val4)).point;
					num = (int)((((num2 + 1107201870) ^ 0x40C2C9BA ^ 0) << 0 << 0) - 0);
					continue;
				case 5u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (int)(((((num2 + 1603745309) ^ 0xCA000831u) + 0 << 0) + 0) ^ 0);
					continue;
				case 19u:
					flag = triggerButtonDown;
					num = (((((int)num2 + -40093842) ^ 0x385317D5) + 0 >> 0) + 0) ^ 0;
					continue;
				case 21u:
					num = (int)((num2 + 1548432940) ^ 0x21C44159) >> 0 << 0 << 0 >> 0;
					continue;
				case 6u:
					num = ((((((int)num2 + -1198723765) ^ -1957427289) - 0) ^ 0) >> 0) ^ 0;
					continue;
				case 22u:
					num = (int)((((num2 + 207985003) ^ 0x793D64B6) + 0 + 0 << 0) ^ 0);
					continue;
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = (((((int)num2 + -1008375456) ^ 0x514FC01A) << 0) - 0 - 0) ^ 0;
					continue;
				case 7u:
					num = ((((int)num2 + -2057924117) ^ -1588789301 ^ 0) << 0 >> 0) ^ 0;
					continue;
				case 25u:
					val2 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val4)).point);
					num = ((int)((((num2 + 891081771) ^ 0x8BFA3B9Eu) << 0) ^ 0) >> 0) - 0;
					continue;
				case 2u:
					num = (int)((((num2 + 1457370637) ^ 0xE63A4731u) << 0) + 0 << 0 << 0);
					continue;
				case 8u:
					val3 = val2;
					num = (int)(((((num2 + 2022602987) ^ 0xAFE95F4Fu) + 0) ^ 0) << 0 << 0);
					continue;
				case 28u:
					rotation = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)(((num2 + 1121261575) ^ 0x2907BF5E) + 0 + 0 + 0 - 0);
					continue;
				case 30u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (((int)(((num2 + 1956669763) ^ 0xCAB3B44Au) + 0) >> 0) ^ 0) + 0;
					continue;
				case 9u:
					num = (((((int)num2 + -117175874) ^ 0x7F213B78) << 0 >> 0) ^ 0) - 0;
					continue;
				case 31u:
					num = (((int)((num2 + 1880337016) ^ 0x8A30253Du) >> 0 << 0) ^ 0) - 0;
					continue;
				case 11u:
					num = (((int)num2 + -2071082168) ^ -1516719472 ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 10u:
					return;
				}
				break;
			}
		}
	}

	public Doug_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ -0) << 0) - 0 - 0 << -0) ^ 0) >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0 << 0) - 0 >> 0;
			}
		}
	}
}
