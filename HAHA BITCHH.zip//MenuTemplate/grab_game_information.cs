using System.Text;
using Il2CppSystem;
using Photon.Pun;
using PlayFab;
using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class grab_game_information
{
	public static void LYUqGcqrqFcCjKITAshNKOkgtxfcEfKYXwhYVqOHBzpXMlnxNrhxqbcWONWiWnNlVdFMCJYjDzlkzmtikIonYmIWukkhtGKnMdcJGAVetXTQPRxBtOYoZznIvIsrzQQXOYxvkKCJNjTasRgCNINFHwnnQtoXiDEDhWcRtbqJmpBPFmqDCPDQckqsKkFRwEAjFqTwPpjLressUxHDcKvtaNAWGJhiwzmHOskptUOmGRyXRXxmDbOMjhjRQWQfhapSSLDCnrkiViMipDeImUEvKzyHjtzweJfFCGfguVZmQGQaubCmSiTnvUismVtTSOemdhFIyYnqVsEeIxmhRmEVQRjHyMTyCgtbBEXnvTOTUCrdpdJOIlbGkiwlXXkLePOPZCCeAZMYxKbnAgsucePqeMRtiLqxIdPfOCdNBFoJydjAgiLQFQJZZxKnLjVOJopuVWzXcETxQgSbCrmaazR()
	{
		bool flag3 = default(bool);
		bool flag4 = default(bool);
		GameObject val2 = default(GameObject);
		StringBuilder stringBuilder = default(StringBuilder);
		string appIdVoice = default(string);
		GameObject val4 = default(GameObject);
		Text val3 = default(Text);
		string titleId = default(string);
		string appIdRealtime = default(string);
		bool flag2 = default(bool);
		Text val = default(Text);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301888;
			while (true)
			{
				uint num2;
				object obj;
				object obj2;
				switch ((num2 = (uint)((((num >> 0) - (0 >> 1)) ^ 0) >> 0 << 0 << (0 ^ 0) << 0 >> 0)) % 41)
				{
				case 12u:
					break;
				default:
					return;
				case 14u:
					flag3 = flag4;
					num = ((((int)num2 + -229453252) ^ 0x171A106C) >> 0) - 0 - 0 - 0;
					continue;
				case 39u:
					num = (int)(((((num2 + 934005898) ^ 0x800EB1DFu) + 0 + 0) ^ 0) - 0);
					continue;
				case 20u:
					num = (((int)num2 + -1204999380) ^ 0x63D4AE94) << 0 << 0 << 0 >> 0;
					continue;
				case 26u:
					if (!((Object)(object)val2 != (Object)null))
					{
						num = ((int)((num2 + 2022602987) ^ 0x8D3593A3u) >> 0 >> 0) - 0 >> 0;
						continue;
					}
					obj = val2.GetComponent<Text>();
					goto IL_07e9;
				case 33u:
					num = ((int)((num2 + 1115582667) ^ 0xC02E880Cu) >> 0 << 0 >> 0) - 0;
					continue;
				case 37u:
					num = ((((int)num2 + -2033110311) ^ -631648654) - 0 - 0 << 0) - 0;
					continue;
				case 9u:
					stringBuilder.AppendLine(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("燛燃燄營燄燅熫燝燄燂燈燎熱熫", 1831104907, true) + appIdVoice);
					num = (int)(((num2 + 1376848916) ^ 0xDD09AD46u) + 0 - 0 - 0 << 0);
					continue;
				case 10u:
					val4 = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("绤绨绤纇绳绂统结", 446135975, true));
					num = ((((int)num2 + -182552646) ^ 0x4D31A2C1) + 0 >> 0) - 0 << 0;
					continue;
				case 11u:
					if (!((Object)(object)val4 != (Object)null))
					{
						num = ((((int)num2 + -1563535789) ^ 0x43D9C9B9) << 0 << 0) + 0 + 0;
						continue;
					}
					obj2 = val4.GetComponent<Text>();
					goto IL_05dd;
				case 1u:
					obj2 = null;
					goto IL_05dd;
				case 13u:
					flag4 = (Object)(object)val3 != (Object)null;
					num = (((int)num2 + -1829903696) ^ -575990751) - 0 - 0 << 0 << 0;
					continue;
				case 18u:
					titleId = PlayFabSettings.TitleId;
					num = (((((int)num2 + -1827602905) ^ -748950361 ^ 0) - 0) ^ 0) + 0;
					continue;
				case 15u:
				{
					int num5;
					int num6;
					if (!flag3)
					{
						num5 = 1225430855;
						num6 = num5;
					}
					else
					{
						num5 = 1056990305;
						num6 = num5;
					}
					num = (int)(((uint)(num5 >> 0 << 0) ^ (num2 + 1855391286)) + 0 - 0 - 0 << 0);
					continue;
				}
				case 16u:
					num = (int)((num2 + 1919092371) ^ 0xD7917717u) >> 0 << 0 << 0 >> 0;
					continue;
				case 17u:
					val3.text = stringBuilder.ToString();
					num = (int)(((((num2 + 1363915621) ^ 0x2DAE7275) + 0 + 0) ^ 0) - 0);
					continue;
				case 2u:
					num = (int)((((num2 + 823506666) ^ 0x1C868BC9) - 0 << 0) ^ 0) >> 0;
					continue;
				case 19u:
					num = ((((((int)num2 + -1504328649) ^ 0x61189B0C) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 24u:
					appIdRealtime = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime;
					num = (((((int)num2 + -509051253) ^ -317528067 ^ 0) + 0) ^ 0) >> 0;
					continue;
				case 21u:
					num = (1414165216 << 0) + 0 - 0 - 0;
					continue;
				case 22u:
					Debug.LogWarning(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueefc\ueef0\ueefc\uee9f\ueeeb\ueeda\ueec7\ueecb\uee9f\ueed0\ueedd\ueed5\ueeda\ueedc\ueecb\uee9f\ueed1\ueed0\ueecb\uee9f\ueed9\ueed0\ueeca\ueed1\ueedb\uee9f\ueed6\ueed1\uee9f\ueecb\ueed7\ueeda\uee9f\ueecc\ueedc\ueeda\ueed1\ueeda\uee91", 282717887, true)));
					num = ((((int)num2 + -2057924117) ^ -1070830552 ^ 0) << 0) + 0 - 0;
					continue;
				case 23u:
					num = (int)(((num2 + 891081771) ^ 0x1922AC73) - 0) >> 0 << 0 << 0;
					continue;
				case 3u:
					num = ((int)(((num2 + 1493219093) ^ 0xCD1A9407u ^ 0) - 0) >> 0) ^ 0;
					continue;
				case 25u:
					val2 = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("摮摂摉摈摢摋摮摂摃摉摘摎摙", 1819042861, true));
					num = (961186683 << 0 >> 0 << 0) - 0;
					continue;
				case 31u:
					appIdVoice = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice;
					num = ((((((int)num2 + -1891630081) ^ -1996147685) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 27u:
					obj = null;
					goto IL_07e9;
				case 28u:
					flag2 = (Object)(object)val != (Object)null;
					num = ((int)(((num2 + 1121261575) ^ 0x2907BF66) + 0 << 0) >> 0) ^ 0;
					continue;
				case 29u:
					flag = flag2;
					num = (int)((((num2 + 1100433178) ^ 0x82B1C011u) + 0 + 0 << 0) - 0);
					continue;
				case 30u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1289811755;
						num4 = num3;
					}
					else
					{
						num3 = 506343893;
						num4 = num3;
					}
					num = (int)(((((uint)((num3 >> 0) + 0) ^ (num2 + 435749897)) << 0) ^ 0) + 0) >> 0;
					continue;
				}
				case 4u:
					num = ((int)(((num2 + 1198527402) ^ 0xA36CBC16u) << 0) >> 0 >> 0) + 0;
					continue;
				case 32u:
					val.text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("菴菲菾菶莓菺菽菵菼", 936936371, true);
					num = ((((int)num2 + -877465945) ^ 0x622A0039) - 0 - 0 << 0) - 0;
					continue;
				case 0u:
					stringBuilder = new StringBuilder();
					num = (((((int)num2 + -903840450) ^ -131809362) << 0) ^ 0 ^ 0) << 0;
					continue;
				case 34u:
					num = (((((int)num2 + -43473754) ^ 0x4EBA981F) >> 0) ^ 0) >> 0 >> 0;
					continue;
				case 35u:
					num = ((((int)((num2 + 1609311921) ^ 0xA7F945EEu) >> 0) ^ 0) + 0) ^ 0;
					continue;
				case 36u:
					num = (1333463136 >> 0) - 0 + 0 + 0;
					continue;
				case 5u:
					Debug.LogWarning(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뫌뫠뫫뫪뫀뫩뫌뫠뫡뫫뫺뫬뫻몯뫠뫭뫥뫪뫬뫻몯뫡뫠뫻몯뫩뫠뫺뫡뫫몯뫦뫡몯뫻뫧뫪몯뫼뫬뫪뫡뫪몡", 1025817231, true)));
					num = ((int)((num2 + 1344036829) ^ 0xD39E0447u) >> 0 >> 0) + 0 - 0;
					continue;
				case 38u:
					num = (((((int)num2 + -454565845) ^ 0x4285FF6D) << 0) ^ 0) + 0 >> 0;
					continue;
				case 7u:
					stringBuilder.AppendLine(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udb60\udb7c\udb71\udb69\udb76\udb71\udb72\udb10\udb64\udb79\udb64\udb7c\udb75\udb10\udb79\udb74\udb0a\udb10", 311679792, true) + titleId);
					num = (int)(((((num2 + 1455221297) ^ 0x3BB295BA) - 0) ^ 0) + 0 << 0);
					continue;
				case 40u:
					num = (0x41FE8F39 ^ 0) >> 0;
					continue;
				case 8u:
					stringBuilder.AppendLine(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뼭뼵뼲뼩뼲뼳뽝뼯뼸뼼뼱뼩뼴뼰뼸뽇뽝", 812957565, true) + appIdRealtime);
					num = (int)((((num2 + 1473386669) ^ 0xE578B147u) << 0) + 0 << 0 << 0);
					continue;
				case 6u:
					return;
					IL_07e9:
					val = (Text)obj;
					num = (0x1A924FD4 ^ 0) + 0 + 0 << 0;
					continue;
					IL_05dd:
					val3 = (Text)obj2;
					num = (0x6B724077 ^ 0) - 0;
					continue;
				}
				break;
			}
		}
	}

	public grab_game_information()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) + (0 << 1) >> 0 << 0) ^ 0) >> (0 ^ 0)) - 0) ^ 0u) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) + 0 + 0 << 0) + 0;
			}
		}
	}
}
