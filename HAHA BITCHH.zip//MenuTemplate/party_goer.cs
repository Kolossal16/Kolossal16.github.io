using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class party_goer
{
	public static void lpbwZdwxYnEsfNrnQPeMnfioeGiKVPcxcykXSWRwTjJDuZlbHIAEwthfgMssVMCilgpGDtuTYHTewFUeugcnpxbJreRfEyAhHAsnKFynnGGOAdJBSnXOJoTNfFoyCppzhLwVmGuPIPaJRmjnvpnrAMysHFieqZLYrgHOHNolSifTojVSwbcmbXYundnHyqyJdcrKFuGIbbysGEeyJqHpXyWtimBDAGNBJwPmSlmcuulZyFOJZ()
	{
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 << (0 >> 1) << 0) ^ 0) >> 0 >> (0 >> 1) >> 0) ^ 0u) % 12)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					num = ((((int)num2 + -344833909) ^ 0x61F8C0DD) >> 0 << 0 >> 0) + 0;
					continue;
				case 5u:
					num = (1345212150 >> 0) + 0 >> 0 >> 0;
					continue;
				case 1u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = ((((int)num2 + -2130437817) ^ -1387738213) << 0) - 0 + 0 >> 0;
					continue;
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("硖硑硌硌硑硌砑硎硟硌硊硇砞硙硑硛硌", 1237088318, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -692261737) ^ 0x66658DE1) + 0 >> 0) ^ 0) << 0;
					continue;
				case 7u:
					flag2 = gripButtonDown;
					num = (int)((((num2 + 359659174) ^ 0x20CD5FDF) - 0 << 0) + 0) >> 0;
					continue;
				case 8u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (int)((((num2 + 1954386908) ^ 0x80A72A90u ^ 0) << 0 << 0) ^ 0);
					continue;
				case 2u:
					flag = flag2;
					num = (int)(((((num2 + 1621957012) ^ 0x66901EE9) << 0) + 0 + 0) ^ 0);
					continue;
				case 10u:
					num = ((((int)num2 + -1284218664) ^ -1958261285) >> 0 >> 0) ^ 0 ^ 0;
					continue;
				case 11u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -300231660;
						num4 = num3;
					}
					else
					{
						num3 = -2020908694;
						num4 = num3;
					}
					num = (((((num3 - 0 + 0) ^ ((int)num2 + -534343288)) << 0) ^ 0) >> 0) ^ 0;
					continue;
				}
				case 3u:
					num = ((((((int)num2 + -1692824216) ^ -417994201) - 0) ^ 0) >> 0) - 0;
					continue;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	public static void PYiJiMFfYCtTchuoXJkORGxdFVCmWUCyREKIFSAKkhTJTirmRLBWDUhjAeenjsidZVbywLIeiAEKMNkwDpvltFUXwBhAOmARYQKXgTPfcwOcqxxNUHKTXXKtaebVEiqVaMLVdmpKApiWRSGYeuGgCGTagqXcRUBUgScDLBJIratIPOBixcRkBjttTLPNonSGOnPZPcnDLXPCnllsOPEOdrtWzJKaLVtdhNUBYCsuPnyDuQgHzxYzIdCwUSAgsmRPELvzrJtmwjYPSPCICdBnXUvdkxHfbmcDvJZJvGqQdMcyfNEfqRDoLESJqrpUcokjhvtiPTnWMLjkRWYwSCOkINSRRpsdqvOPBTrJuvpxDHCZuHSusSbzzaBtCCrzAkFqXuJYEocwmr()
	{
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ 0) - 0 + 0) ^ 0) >> (0 >> 1)) + 0) ^ 0u) % 10)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = (((((int)num2 + -248958683) ^ 0x6C31B027) << 0) + 0 >> 0) - 0;
					continue;
				case 3u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (((((int)num2 + -534343288) ^ -1407652347 ^ 0) - 0) ^ 0) << 0;
					continue;
				case 1u:
					flag2 = gripButtonDown;
					num = ((((int)num2 + -344833909) ^ 0x3ABAB2D9) - 0 + 0 >> 0) ^ 0;
					continue;
				case 4u:
					num = (int)(((((num2 + 1954386908) ^ 0xF89A2515u) + 0) ^ 0) + 0 - 0);
					continue;
				case 7u:
					flag = flag2;
					num = (((((int)num2 + -2130437817) ^ -1934000822) >> 0) - 0 >> 0) - 0;
					continue;
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("躒躕躈躈躕躈軕躉躊躓躞躟躈", 1347849978, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1692824216) ^ -1509741446) - 0 + 0 - 0 << 0;
					continue;
				case 2u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -374740339;
						num4 = num3;
					}
					else
					{
						num3 = -1188542420;
						num4 = num3;
					}
					num = (((((num3 ^ 0) >> 0) ^ ((int)num2 + -1625985034)) >> 0) ^ 0) >> 0 >> 0;
					continue;
				}
				case 6u:
					num = (((int)num2 + -715084519) ^ -211488882) + 0 - 0 >> 0 >> 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public party_goer()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num - 0 >> (0 ^ 0) << 0) - 0 << 0 << 0 + 0 << 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) << 0 << 0) - 0 >> 0;
			}
		}
	}
}
