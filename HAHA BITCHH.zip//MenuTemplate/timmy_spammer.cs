using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class timmy_spammer
{
	public static void jLiVyMSgBuulMJqnLPVWxKEcIJPdRLyTcMIQubnLoCrbwsnpklUxaHOyhfnOWOoQVAiabATKCkHVtDFqvzTGQbTvXjIoOyOzoAfVjnoKrjVPZTeEAWtxVHZUHMcRRFWewhGSxJghljoHgdveeeNRfrDGBlowlwSMnRtRmmhQPllMtrNDrXMMReYeEarlvJWOqCtpKERSWXbUfQmjxLfnKfUjSonlVVvfoxwQYySNfUQUceZNNhOJEIekHkwvqGXbCWFHuvlZTshQpagOoAyNhMBGtmiNbwwzWOrgzrtrVOQlAoUHdIgQhjUQuYohnyXwWHTBIapXggSsVq()
	{
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301851;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 + (0 >> 1) << 0) ^ 0) + 0 - (0 ^ 0) - 0 << 0)) % 10)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = ((((int)num2 + -248958683) ^ 0x6C31B030) >> 0) + 0 >> 0 >> 0;
					continue;
				case 2u:
					flag2 = gripButtonDown;
					num = ((((int)num2 + -344833909) ^ 0x3ABAB2E4) >> 0) - 0 << 0 >> 0;
					continue;
				case 3u:
					flag = flag2;
					num = ((((int)num2 + -2130437817) ^ -1934000828) + 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 4u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -374740346;
						num4 = num3;
					}
					else
					{
						num3 = -1188542431;
						num4 = num3;
					}
					num = (((((num3 << 0) - 0) ^ ((int)num2 + -1625985034)) << 0 << 0) ^ 0) - 0;
					continue;
				}
				case 5u:
					num = ((((int)num2 + -715084519) ^ -211488846) >> 0 >> 0) ^ 0 ^ 0;
					continue;
				case 6u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((int)num2 + -534343288) ^ -1407652343) << 0 >> 0) - 0 >> 0;
					continue;
				case 9u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uec34\uec33\uec2e\uec2e\uec33\uec2e\uec73\uec28\uec35\uec31\uec31\uec25", 1241967708, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1692824216) ^ -1509741444) >> 0 >> 0 >> 0) + 0;
					continue;
				case 7u:
					num = (int)(((num2 + 1954386908) ^ 0xF89A250Fu) - 0 - 0) >> 0 >> 0;
					continue;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	public timmy_spammer()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num << 0 << (0 >> 1)) + 0 + 0 + 0 << (0 ^ 0) >> 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0) + 0 - 0 + 0;
			}
		}
	}
}
