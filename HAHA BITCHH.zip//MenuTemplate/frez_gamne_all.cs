using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;

namespace MenuTemplate;

internal class frez_gamne_all
{
	public static void xPXwUqEwGYoXsVIaPuvijlaqKTRSeYLHOShLKMIimfRZSuaXYvXMiBwmOGMbyMrHmGizOWqdLmWdtbxqTUTJbZynwUXdaHJzOkNllAjcfUaWEtSNjwhDSHFniVdTZmdeDwpjnlesLREhYCJdckUEzfHgEAdqxpdTRWshdIzXrPSbdyoFlaROryFxPiFNiNVvOKqckBZtKXmJnGcflyewyoCsqVsVdMPEUwmsimvKbyetmVkjfzBJIyXziXLoidpXiHPQtJWYcuvZkifvLjPDlfWwz()
	{
		bool isConnected = default(bool);
		Player current = default(Player);
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				int num7;
				uint num2;
				switch ((num2 = (uint)((((num >> 0) - (0 << 1) >> 0 << 0 << 0) ^ -0) << 0 << 0)) % 7)
				{
				case 6u:
					break;
				case 4u:
					if (isConnected)
					{
						num = (((int)((num2 + 1345212153) ^ 0x7B8CB739) >> 0) ^ 0 ^ 0) - 0;
						continue;
					}
					goto IL_04f9;
				case 5u:
					num = (int)((((((num2 + 600520462) ^ 0x22720308) + 0) ^ 0) + 0) ^ 0);
					continue;
				case 3u:
					num = ((((int)num2 + -725091362) ^ 0x8528590) - 0 - 0 << 0) ^ 0;
					continue;
				case 1u:
					num = (((int)num2 + -795116775) ^ -5259856 ^ 0 ^ 0 ^ 0) + 0;
					continue;
				case 0u:
					isConnected = PhotonNetwork.IsConnected;
					num = ((((int)num2 + -956687329) ^ -415052113) - 0 << 0) + 0 << 0;
					continue;
				default:
					{
						IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerListOthers).GetEnumerator();
						try
						{
							while (true)
							{
								IL_03c9:
								int num3;
								int num4;
								if (!enumerator.MoveNext())
								{
									num3 = 927588276;
									num4 = num3;
								}
								else
								{
									num3 = 1621957021;
									num4 = num3;
								}
								int num5 = ((num3 ^ 0) << 0) ^ 0 ^ 0;
								while (true)
								{
									switch ((num2 = (uint)((((((num5 << 0) + -0) ^ 0) + 0) ^ 0) - (0 << 1) + 0 - 0)) % 13)
									{
									case 6u:
										num5 = 1621957021;
										continue;
									default:
										goto end_IL_0162;
									case 8u:
										num5 = (int)((((num2 + 1107201870) ^ 0x86D8E09Au) << 0 << 0) + 0 - 0);
										continue;
									case 11u:
										num5 = (int)(((num2 + 1457370637) ^ 0x510DD47) - 0 - 0 + 0 - 0);
										continue;
									case 9u:
										current = enumerator.Current;
										num5 = (0x661A46CC ^ 0) >> 0 << 0 << 0;
										continue;
									case 1u:
										PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
										num5 = (int)(((((num2 + 1333463150) ^ 0x3E80E0DB) - 0) ^ 0) + 0 - 0);
										continue;
									case 7u:
										PhotonNetwork.DestroyPlayerObjects(current);
										num5 = (((((int)num2 + -227232852) ^ 0x346E99EF) + 0 + 0) ^ 0) + 0;
										continue;
									case 0u:
										num5 = (((int)num2 + -814951907) ^ 0x131690FB) >> 0 >> 0 >> 0 << 0;
										continue;
									case 2u:
										set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
										num5 = (int)((num2 + 1548432940) ^ 0xA9795631u ^ 0) >> 0 >> 0 << 0;
										continue;
									case 10u:
										num5 = (((int)num2 + -1008375456) ^ 0x1A404EDD) - 0 >> 0 >> 0 >> 0;
										continue;
									case 12u:
										set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
										num5 = (int)((((((num2 + 1665746989) ^ 0xDD90A2E3u) - 0) ^ 0) << 0) + 0);
										continue;
									case 3u:
										break;
									case 5u:
										num5 = (int)(((num2 + 770395556) ^ 0x9BB8A858u) + 0 + 0 - 0 << 0);
										continue;
									case 4u:
										goto end_IL_0162;
									}
									goto IL_03c9;
									continue;
									end_IL_0162:
									break;
								}
								break;
							}
						}
						finally
						{
							if (enumerator != null)
							{
								while (true)
								{
									IL_0413:
									int num6 = 1221206143;
									while (true)
									{
										switch ((num2 = (uint)(((((num6 ^ 0) << (0 << 1)) - 0 >> 0 << 0) ^ 0) >> 0) ^ 0u) % 4)
										{
										case 2u:
											break;
										default:
											goto end_IL_0418;
										case 3u:
											enumerator.Dispose();
											num6 = (((int)num2 + -1377430272) ^ -952846153) - 0 - 0 + 0 - 0;
											continue;
										case 0u:
											num6 = ((int)((num2 + 337346832) ^ 0x5FF6B231) >> 0) - 0 + 0 >> 0;
											continue;
										case 1u:
											goto end_IL_0418;
										}
										goto IL_0413;
										continue;
										end_IL_0418:
										break;
									}
									break;
								}
							}
						}
						goto IL_04b1;
					}
					IL_04b1:
					num7 = 1945443958;
					goto IL_04b6;
					IL_04f9:
					num7 = (0x531AFCFB ^ 0) - 0 - 0;
					goto IL_04b6;
					IL_04b6:
					switch ((num2 = (uint)(((((num7 - 0 - -0 >> 0) + 0 << 0) + (0 >> 1)) ^ 0) - 0)) % 3)
					{
					case 2u:
						break;
					default:
						return;
					case 1u:
						goto IL_04f9;
					case 0u:
						return;
					}
					goto IL_04b1;
				}
				break;
			}
		}
	}

	public frez_gamne_all()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0 << 0 + 0) ^ 0 ^ 0 ^ 0) - (0 << 1)) ^ 0) + 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB3) - 0 >> 0 >> 0 << 0;
			}
		}
	}
}
