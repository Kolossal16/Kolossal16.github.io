using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class rigspam
{
	public static void CdUzuttabIeEaTIVfqOGnBcDFJnmSUFgYqXhVXfozltAgNKYeIlLLUTbaqULfghhcXGJWAZilzhchCxRYohjJTvdxVhFdtisdmxihacDJcAmNQUyTcMQZYxiCCmatufRqPYUeoJYmDAGtjqGbILaHrsfPoFENbkpXIVXSZtFsOEvxRPtmGZKIfkYwTfPIfkktlJKnsObpgHTNXHYzmshczGSyXBYUDWnDtcmiefTSXuCxrlzmhqwMciTEQmqRPhMktptVuQvgzpeeeugMcLNnAAAliIrRPbcQIsdcRDRrUpnNdOzwfEPetzJTOiMLy()
	{
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) - (0 >> 1) - 0 - 0 - 0) ^ -0) - 0 + 0)) % 7)
				{
				case 0u:
					break;
				default:
					return;
				case 5u:
					EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (((((int)num2 + -725091362) ^ 0x852856F) - 0 + 0) ^ 0) << 0;
					continue;
				case 2u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("荰荘荅荞荛荛荖荇荅荒荑荖荕荄茘荴荒荕荂荄荰荂荎", 2143191863, true), ((Component)Player.Instance).transform.position + new Vector3(0.2f, 1.2f, -0.3f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 600520462) ^ 0x22720310 ^ 0) << 0) >> 0 << 0;
					continue;
				case 1u:
					num = (((((int)num2 + -956687329) ^ -415052116) - 0) ^ 0) - 0 >> 0;
					continue;
				case 6u:
					num = ((((((int)num2 + -795116775) ^ -5259852) + 0) ^ 0) << 0) ^ 0;
					continue;
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("죠죘죟죄죟죞죦죢좟죠죜죑죉죕죂", 398772400, true), ((Component)Player.Instance).transform.position + new Vector3(0f, 0.4f, 0f), ((Component)Player.Instance).transform.rotation, (byte)90, (Il2CppReferenceArray<Object>)null);
					num = ((int)(((num2 + 1345212153) ^ 0x7B8CB704) - 0) >> 0) + 0 + 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public rigspam()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) << (0 ^ 0)) + 0 >> 0 << 0) - -0 >> 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 - 0) ^ 0) << 0;
			}
		}
	}
}
