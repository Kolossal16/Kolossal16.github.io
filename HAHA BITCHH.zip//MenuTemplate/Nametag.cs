using System;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class Nametag
{
	public static void ehTYUUjQByDpQCxFMvmUQwWefRTvjxHReHuTVApTgndHghmwAPEQTQrHlOTdbOGdQLkiiEJmftNDtoYXEwUuTQYoqNHhHmSrHZQuXeoWfsLAcOnWQVyEUlkZNWSvWCFTBvVuxDaAiXoBfxlBzKrLNoxvPRGalTZDMSZGSTznVYvWWJTqKqVlkUfmYAEGWZopXLOnxFIFlePOSAyfXqpUXNsSMMIsoSqWJgZlVGSfIpageruxbzIFKtrjsVALWqrtNTfMBnkqxjmHNmOvskqPkLlpOPSZfhjrYHsllHWOoriAhKvfhfsLaBicHPYLulkpaVIgTCjKoBBSCLieuNSaPxrwyqDwJludgTAmbpmEVIxyaqzWHUqHtkACDmIDYNadhyLJlWcf()
	{
		string[] array = default(string[]);
		string userId = default(string);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301853;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 - (0 + 0) << 0) + 0) ^ 0) - -0 << 0) ^ 0u) % 13)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					array = new string[5]
					{
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뒭듲듾듽듾듣뒬듣듴듵뒯듙듰듣듼듾듿듨뒿득듞득뒱듞듟듅듞듁뒭뒾듲듾듽듾듣뒯뒛듵듸듢듲듾듣듵뒿듶듶뒾듕듺듂듧뒦듟뒣듗듆듲", 1365554321, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("НтюэюѓМјфээюіПѩрѓьюяјЏѭѮѭЁѮѯѵѮѱНЎтюэюѓПЫхшђтюѓхЏццЎѥъѲїЖѯГѧѶт", 1117979681, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䉉䈖䈚䈙䈚䈇䉈䈒䈇䈐䈐䈛䉋䈽䈔䈇䈘䈚䈛䈌䉛䈹䈺䈹䉕䈺䈻䈡䈺䈥䉉䉚䈖䈚䈙䈚䈇䉋䉿䈑䈜䈆䈖䈚䈇䈑䉛䈒䈒䉚䈱䈞䈦䈃䉂䈻䉇䈳䈢䈖", 865223285, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("俬侳便侼便侢俭侲侼侥侵修侘侱侢侽便侾侩俾侜侟侜俰侟侞侄侟侀俬俿侳便侼便侢修俚侴侹侣侳便侢侴俾侷侷俿侔侻侃侦俧侞俢侖侇侳", 1367166928, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("킊탕탙탚탙탄킋탛탗탑탓탘탂탗킈탾탗탄탛탙탘탏킘탺탹탺킖탹탸탢탹탦킊킙탕탙탚탙탄킈킼탒탟탅탕탙탄탒킘탑탑킙탲택탥타킁탸킄탰탡탕", 1222889654, true)
					};
					num = (int)(((num2 + 600520462) ^ 0xB95FCA4Du) << 0 << 0) >> 0 >> 0;
					continue;
				case 5u:
					PhotonNetwork.LocalPlayer.UserId = userId;
					num = (int)((num2 + 900749756) ^ 0xF6F7C423u ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 1u:
					num3 = new Random().Next(array.Length);
					num = (((((int)num2 + -795116775) ^ 0x1DE16859) + 0 - 0) ^ 0) + 0;
					continue;
				case 4u:
					num = ((((int)num2 + -1701687338) ^ -1567692513 ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 7u:
					PhotonNetwork.LocalPlayer.NickName = array[num3];
					num = (((int)((num2 + 1259723679) ^ 0x76A738DF) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 8u:
					PlayerPrefs.SetString(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⧻⧓⧎⧕⧐⧐⧝⧰⧓⧟⧓⧑⧓⧈⧕⧓⧒⦒⧬⧐⧝⧅⧙⧎⧲⧝⧑⧙", 312486332, true), array[num3]);
					num = ((((int)num2 + -1186296972) ^ 0x47F0227C) + 0 + 0 << 0) + 0;
					continue;
				case 2u:
					num = ((((int)num2 + -434485547) ^ -534547498) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 10u:
					userId = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("횏획횂횘훬횎획횂훬횁횉훬횎횃횖횃훆훆훆훆훆훆훆훆훆훆훆훆", 391501516, true);
					num = (((((int)num2 + -1219895373) ^ -1888826673) >> 0 >> 0) ^ 0) << 0;
					continue;
				case 11u:
					GorillaComputer.instance.currentName = array[num3];
					num = ((((int)num2 + -733318432) ^ -226576901) + 0 - 0 << 0) ^ 0;
					continue;
				case 12u:
					num = (((int)((num2 + 1709781230) ^ 0xDD653F6Du ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 3u:
					num = ((((int)num2 + -678915685) ^ -1534661090) << 0 >> 0 << 0) - 0;
					continue;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	public Nametag()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 >> (0 << 1) << 0) + 0 - 0 >> (0 >> 1)) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) + 0) ^ 0) + 0;
			}
		}
	}
}
