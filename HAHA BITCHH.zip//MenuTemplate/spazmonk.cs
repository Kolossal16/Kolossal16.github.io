using UnityEngine;

namespace MenuTemplate;

internal class spazmonk
{
	public static void fFTpkucMvEHNQvtKahElfYgmGgfLkOWvTJWMyHyPdumnaCFXsYLRRrqhzGIdprCGIlTgyGltIOhLLSmeBhtldeECsPnRYvAMRFFPJyzLNsjcjFwGuDCiXqDDGrNJttunovTfnxvdHHyKVCsNtGwuTrOAcbisKQrtXVONLqtXiyAqSSIeYa()
	{
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301847;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 << (0 >> 1) >> 0) - 0 << 0) + (0 >> 1) >> 0) ^ 0u) % 14)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					GorillaTagger.Instance.myVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
					num = (((int)num2 + -2130437817) ^ -602494930 ^ 0) - 0 + 0 >> 0;
					continue;
				case 2u:
					num = (int)((((num2 + 359659174) ^ 0x50B4E437 ^ 0) << 0) + 0) >> 0;
					continue;
				case 3u:
					GorillaTagger.Instance.myVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
					num = ((int)((num2 + 1621957012) ^ 0x6C0E7AAF) >> 0 >> 0 << 0) ^ 0;
					continue;
				case 4u:
					num = (((int)((num2 + 647071759) ^ 0x20ABB01C ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 5u:
					GorillaTagger.Instance.myVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
					num = ((int)((((num2 + 428697817) ^ 0x28B1A3D0) << 0) ^ 0) >> 0) - 0;
					continue;
				case 6u:
					num = (int)(((num2 + 2106842273) ^ 0xC28B9B14u) + 0 + 0 << 0 << 0);
					continue;
				case 13u:
					GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
					num = (((int)num2 + -1125345364) ^ 0x585636B8) >> 0 << 0 << 0 << 0;
					continue;
				case 11u:
					num = (int)(((num2 + 1333463150) ^ 0x99267FEBu ^ 0 ^ 0) << 0) >> 0;
					continue;
				case 7u:
					num = (int)((((((num2 + 1952503976) ^ 0xF8B961CDu) << 0) - 0) ^ 0) << 0);
					continue;
				case 8u:
					GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
					num = ((((int)num2 + -814951907) ^ 0x674FDF1A) - 0 >> 0) + 0 >> 0;
					continue;
				case 9u:
					num = ((((int)((num2 + 1665746989) ^ 0x845C37A4u) >> 0) + 0) ^ 0) + 0;
					continue;
				case 10u:
					GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
					num = (int)(((((num2 + 770395556) ^ 0x156BDC2F) << 0) - 0 << 0) - 0);
					continue;
				case 12u:
					return;
				}
				break;
			}
		}
	}

	public spazmonk()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) + (0 >> 1)) ^ 0) - 0 + 0 << (0 >> 1)) - 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB1) - 0 - 0) ^ 0) - 0;
			}
		}
	}
}
