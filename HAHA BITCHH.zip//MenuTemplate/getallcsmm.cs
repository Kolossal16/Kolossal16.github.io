using Il2CppSystem.Collections.Generic;
using UnityEngine;

namespace MenuTemplate;

internal class getallcsmm
{
	public static void MkkBgBXiglEgtPvDCGocXpaSpDZnMMcLsqGzMxWSyRdWAorttaJyHtBxjslCCJwtiTNdjVReKwEglerbmFTLdEdZPjqtltpOuJNHAojyjENlPvleakqWPKqEPOnaFxTrgPLBrJAYvvCzQSjuXmsbdtZJtiSMajTLLwfZJJNqKrAtiRNWETcseRnNQciiRNYmCQOuNkKoycrLSFBBvVhghAHTirjHBEzWtoQrdtjuiOUcACVkAGNWFRfcj()
	{
		CosmeticItem current = default(CosmeticItem);
		bool flag2 = default(bool);
		Enumerator<CosmeticItem> enumerator = default(Enumerator<CosmeticItem>);
		bool flag4 = default(bool);
		bool flag3 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 + (0 + 0) - 0 + 0 << 0) ^ 0) - 0 + 0)) % 28)
				{
				case 18u:
					break;
				default:
					return;
				case 14u:
					CosmeticsController.instance.itemToBuy = current;
					num = ((int)((num2 + 1221206141) ^ 0x6D914EB7) >> 0 >> 0) - 0 - 0;
					continue;
				case 24u:
					flag2 = (Object)(object)CosmeticsController.instance != (Object)null;
					num = (((int)num2 + -871797673) ^ 0x6933CD15) >> 0 >> 0 << 0 << 0;
					continue;
				case 20u:
					CosmeticsController.instance.unlockedFaces = CosmeticsController.instance.allCosmetics;
					num = (((int)num2 + -1198330398) ^ 0x383CBCB8) + 0 - 0 + 0 >> 0;
					continue;
				case 26u:
				{
					int num5;
					int num6;
					if (enumerator.MoveNext())
					{
						num5 = 377208497;
						num6 = num5;
					}
					else
					{
						num5 = 1022138272;
						num6 = num5;
					}
					num = ((num5 - 0) ^ 0) >> 0 >> 0;
					continue;
				}
				case 21u:
					num = ((((int)num2 + -1650322207) ^ -493002074) << 0) + 0 >> 0 << 0;
					continue;
				case 27u:
					num = (int)((num2 + 1952503976) ^ 0xE8E968ABu) >> 0 << 0 << 0 << 0;
					continue;
				case 2u:
					flag4 = flag2;
					num = ((((((int)num2 + -1439813256) ^ -1293235540) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 10u:
					flag3 = flag4;
					num = (((int)num2 + -2033110311) ^ -1126006840 ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 11u:
					flag = flag3;
					num = (((((int)num2 + -1827602905) ^ 0x541461A1) << 0 << 0) - 0) ^ 0;
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 897431540;
						num4 = num3;
					}
					else
					{
						num3 = 597437396;
						num4 = num3;
					}
					num = (int)(((uint)(num3 + 0 << 0) ^ (num2 + 232892542) ^ 0 ^ 0) + 0 - 0);
					continue;
				}
				case 13u:
					num = (int)((((num2 + 1133461507) ^ 0x8CCAB796u ^ 0) + 0) ^ 0) >> 0;
					continue;
				case 0u:
					num = ((((int)num2 + -814951907) ^ 0x1EB00361) >> 0) + 0 + 0 << 0;
					continue;
				case 4u:
					num = ((((int)((num2 + 441892074) ^ 0x4BC1AD32) >> 0) + 0) ^ 0) << 0;
					continue;
				case 16u:
					CosmeticsController.instance.PurchaseItem();
					num = ((((int)num2 + -1856515560) ^ -191054975) - 0 - 0 + 0) ^ 0;
					continue;
				case 17u:
					num = (((int)num2 + -11398900) ^ 0x5FD7DC2C ^ 0) - 0 + 0 - 0;
					continue;
				case 5u:
					CosmeticsController.instance.unlockedBadges = CosmeticsController.instance.allCosmetics;
					num = (((((int)num2 + -202039689) ^ 0x5FA7E3B3) << 0) ^ 0) + 0 + 0;
					continue;
				case 19u:
					num = (((((int)num2 + -324874666) ^ 0x2B55A121 ^ 0) + 0) ^ 0) + 0;
					continue;
				case 12u:
					enumerator = CosmeticsController.instance.allCosmetics.GetEnumerator();
					num = (int)(((num2 + 1665746989) ^ 0x6EF3AC5E ^ 0) - 0 + 0) >> 0;
					continue;
				case 6u:
					num = (int)((num2 + 502420178) ^ 0x10C9A832) >> 0 >> 0 << 0 << 0;
					continue;
				case 22u:
					CosmeticsController.instance.unlockedHats = CosmeticsController.instance.allCosmetics;
					num = ((int)(((num2 + 1855391286) ^ 0xDB6C11FBu) + 0) >> 0 << 0) ^ 0;
					continue;
				case 23u:
					num = ((((int)((num2 + 1919092371) ^ 0xDC78FEF1u) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 7u:
					num = (int)(((num2 + 1363915621) ^ 0xD5479851u) + 0 + 0 - 0) >> 0;
					continue;
				case 25u:
					num = (961186686 << 0 >> 0) - 0 + 0;
					continue;
				case 15u:
					num = (((int)((num2 + 770395556) ^ 0x7635F45) >> 0) + 0 + 0) ^ 0;
					continue;
				case 8u:
					num = (((int)((num2 + 1798378934) ^ 0xB28FE29Fu ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 1u:
					current = enumerator.Current;
					num = 414745709 - 0 - 0 + 0 + 0;
					continue;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	public getallcsmm()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) - -0 + 0 >> 0 >> 0) ^ 0) + 0 - 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB3 ^ 0 ^ 0) + 0 - 0;
			}
		}
	}
}
