using Photon.Pun;

namespace MenuTemplate;

internal class set_master
{
	public static void DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR()
	{
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301862;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 << (0 >> 1)) + 0 - 0 + 0 >> (0 >> 1)) ^ 0) + 0)) % 11)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					flag = !PhotonNetwork.LocalPlayer.IsMasterClient;
					num = ((int)((num2 + 1345212153) ^ 0x8D3CD277u) >> 0) + 0 + 0 << 0;
					continue;
				case 3u:
					GorillaGameManager.instance.takeMaster = true;
					num = ((((int)num2 + -640398734) ^ -1505020660) + 0 + 0) ^ 0 ^ 0;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 230943292;
						num4 = num3;
					}
					else
					{
						num3 = 1734949300;
						num4 = num3;
					}
					num = (int)(((uint)((num3 << 0) + 0) ^ (num2 + 1193528119)) + 0 + 0 - 0 + 0);
					continue;
				}
				case 4u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (((((int)num2 + -1397142901) ^ -1335757926) >> 0) ^ 0) + 0 << 0;
					continue;
				case 7u:
					num = (((((int)num2 + -1496278149) ^ -764741456) << 0) ^ 0 ^ 0) << 0;
					continue;
				case 8u:
					num = (((((int)num2 + -1579710319) ^ -1082318497) << 0 << 0) ^ 0) + 0;
					continue;
				case 2u:
					GorillaGameManager.instance.currentMasterClient = PhotonNetwork.LocalPlayer;
					num = ((((int)num2 + -1807018533) ^ -1292754227) - 0 + 0 << 0) + 0;
					continue;
				case 10u:
					num = (((int)num2 + -1466265009) ^ -1631740084 ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 6u:
					num = (((int)((num2 + 266738246) ^ 0x3ED95D63 ^ 0) >> 0) - 0) ^ 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public set_master()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 << 0 + 0) + 0 << 0) ^ 0) + (0 << 1) + 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) - 0 + 0 >> 0;
			}
		}
	}
}
