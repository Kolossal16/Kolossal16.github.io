using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class cube_s_tump
{
	public static void jjnZYwCFnCCySNSfNCBVpjHCnndrPLzCpNbkfIJibWIHrTMNnmoycEVaCKLLslPBcaieMIaeTsUtAZktAqdDxbzKRaHuXXPPghErL()
	{
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val2 = default(Vector3);
		Quaternion val = default(Quaternion);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num >> 0) + (0 >> 1)) ^ 0 ^ 0) - 0 << 0 + 0) ^ 0) << 0)) % 6)
				{
				case 2u:
					break;
				default:
					return;
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䮜䮔䮉䮒䮗䮗䮚䮋䮉䮞䮝䮚䮙䮈䯔䮜䮔䮉䮒䮗䮗䮚䮞䮕䮞䮖䮂", 1633963003, true), val2, val, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -248958683) ^ 0x1C939554) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 5u:
				{
					Vector3 val3 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -344833909) ^ -305432173) + 0 + 0 >> 0) - 0;
					continue;
				}
				case 3u:
					val2 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((((num2 + 414745695) ^ 0xB4411CF0u) << 0) - 0 << 0) ^ 0);
					continue;
				case 0u:
					val = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = ((((int)num2 + -907893453) ^ -466987131) - 0 - 0 - 0) ^ 0;
					continue;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	public static void IaFmjFJJCADArlbhmebAxmLaFhVDemsuSIRpyrnwPapAeUFMOIUdDRnvpEGcJgFqhiHJtMJVQEKxXkWKBjOwrpRbuwaTKkMJvYtWnWscZZmZgQxeIWAAr()
	{
		//IL_074a: Unknown result type (might be due to invalid IL or missing references)
		//IL_075e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0763: Unknown result type (might be due to invalid IL or missing references)
		//IL_0768: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e36: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_10aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b69: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cfe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ead: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f74: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f7e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1029: Unknown result type (might be due to invalid IL or missing references)
		//IL_103d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1042: Unknown result type (might be due to invalid IL or missing references)
		//IL_1047: Unknown result type (might be due to invalid IL or missing references)
		//IL_10de: Unknown result type (might be due to invalid IL or missing references)
		//IL_10df: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1270: Unknown result type (might be due to invalid IL or missing references)
		//IL_1271: Unknown result type (might be due to invalid IL or missing references)
		//IL_1323: Unknown result type (might be due to invalid IL or missing references)
		//IL_1337: Unknown result type (might be due to invalid IL or missing references)
		//IL_133c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1341: Unknown result type (might be due to invalid IL or missing references)
		//IL_1389: Unknown result type (might be due to invalid IL or missing references)
		//IL_139d: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aeb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0793: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bbb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07de: Unknown result type (might be due to invalid IL or missing references)
		//IL_07df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c68: Unknown result type (might be due to invalid IL or missing references)
		//IL_067a: Unknown result type (might be due to invalid IL or missing references)
		//IL_068e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_0698: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0caf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d31: Unknown result type (might be due to invalid IL or missing references)
		//IL_085b: Unknown result type (might be due to invalid IL or missing references)
		//IL_086f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0874: Unknown result type (might be due to invalid IL or missing references)
		//IL_0879: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dec: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e76: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0812: Unknown result type (might be due to invalid IL or missing references)
		//IL_0826: Unknown result type (might be due to invalid IL or missing references)
		//IL_082b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0830: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0efa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eff: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fac: Unknown result type (might be due to invalid IL or missing references)
		//IL_090f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0923: Unknown result type (might be due to invalid IL or missing references)
		//IL_0928: Unknown result type (might be due to invalid IL or missing references)
		//IL_092d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ffd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1074: Unknown result type (might be due to invalid IL or missing references)
		//IL_1075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0959: Unknown result type (might be due to invalid IL or missing references)
		//IL_096d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0972: Unknown result type (might be due to invalid IL or missing references)
		//IL_0977: Unknown result type (might be due to invalid IL or missing references)
		//IL_08db: Unknown result type (might be due to invalid IL or missing references)
		//IL_08dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1112: Unknown result type (might be due to invalid IL or missing references)
		//IL_1126: Unknown result type (might be due to invalid IL or missing references)
		//IL_112b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0716: Unknown result type (might be due to invalid IL or missing references)
		//IL_0717: Unknown result type (might be due to invalid IL or missing references)
		//IL_115c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1170: Unknown result type (might be due to invalid IL or missing references)
		//IL_1175: Unknown result type (might be due to invalid IL or missing references)
		//IL_117a: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1225: Unknown result type (might be due to invalid IL or missing references)
		//IL_1239: Unknown result type (might be due to invalid IL or missing references)
		//IL_123e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1243: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_12bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_12c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a38: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val3 = default(Vector3);
		Quaternion val4 = default(Quaternion);
		while (true)
		{
			int num = 1758301827;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 >> -0) + 0 << 0 << 0 >> 0 + 0 << 0) - 0)) % 57)
				{
				case 55u:
					break;
				default:
					return;
				case 20u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("树栙栄栟栚栚栗栆栄栓栐栗栔栅桙树栙栄栟栚栚栗栓栘栓栛栏", 1823434870, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((((num2 + 234277810) ^ 0x52809A82) - 0) ^ 0) << 0) ^ 0);
					continue;
				case 29u:
				{
					Vector3 val29 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((num2 + 1381583965) ^ 0xF1F3FB66u) + 0 - 0 << 0 << 0);
					continue;
				}
				case 27u:
					num = ((((int)num2 + -182552646) ^ 0x682B09D9 ^ 0) - 0 - 0) ^ 0;
					continue;
				case 39u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("篠篨篵篮篫篫篦篷篵篢篡篦篥篴箨篠篨篵篮篫篫篦篢篩篢篪篾", 171735943, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 296526287) ^ 0xAE0F640Au) >> 0) + 0 << 0 << 0;
					continue;
				case 48u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue908\ue900\ue91d\ue906\ue903\ue903\ue90e\ue91f\ue91d\ue90a\ue909\ue90e\ue90d\ue91c\ue940\ue908\ue900\ue91d\ue906\ue903\ue903\ue90e\ue90a\ue901\ue90a\ue902\ue916", 789571951, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 2146902915) ^ 0xFB974E84u ^ 0) - 0) ^ 0 ^ 0);
					continue;
				case 0u:
					val3 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -1563535789) ^ -1021934352) << 0) - 0 + 0 - 0;
					continue;
				case 23u:
				{
					Vector3 val28 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((num2 + 1608343532) ^ 0x2EE2595C) - 0 - 0 - 0) >> 0;
					continue;
				}
				case 26u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("襲襺襧襼襹襹襴襥襧襰襳襴襷襦褺襲襺襧襼襹襹襴襰襻襰襸襬", 486115605, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -2071238116) ^ -2126945744) >> 0) - 0) ^ 0) << 0;
					continue;
				case 37u:
					val4 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = ((((((int)num2 + -1829903696) ^ -1102101554) >> 0) ^ 0) >> 0) + 0;
					continue;
				case 32u:
				{
					Vector3 val27 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)((((num2 + 2033488390) ^ 0xCDADA3F0u ^ 0 ^ 0) << 0) - 0);
					continue;
				}
				case 35u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("汲決汧汼汹汹汴汥汧汰汳汴汷汦氺汲決汧汼汹汹汴汰汻汰汸汬", 233597973, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)(((num2 + 179208694) ^ 0x253BDB46) + 0) >> 0) + 0 >> 0;
					continue;
				case 46u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⒟⒗⒊⒑⒔⒔⒙⒈⒊⒝⒞⒙⒚⒋ⓗ⒟⒗⒊⒑⒔⒔⒙⒝⒖⒝⒕⒁", 6497528, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -229453252) ^ 0x14EAE643) + 0 - 0 - 0 - 0;
					continue;
				case 42u:
				{
					Vector3 val26 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)((num2 + 499878478) ^ 0x78D78B0A) >> 0 << 0) ^ 0) + 0;
					continue;
				}
				case 45u:
				{
					Vector3 val25 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((((num2 + 749445460) ^ 0x113974B2 ^ 0) << 0) ^ 0) << 0);
					continue;
				}
				case 1u:
				{
					Vector3 val24 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -1761200462) ^ -1254526707) + 0 - 0 >> 0) ^ 0;
					continue;
				}
				case 51u:
				{
					Vector3 val23 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)((((num2 + 827754557) ^ 0x6358B9BE) + 0 << 0) - 0) >> 0;
					continue;
				}
				case 54u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ญฅธฃฆฆซบธฏฌซจนๅญฅธฃฆฆซฏคฏงณ", 1968180842, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -277516137) ^ 0x5CC699E5) - 0) ^ 0) + 0 + 0;
					continue;
				case 21u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㸔㸜㸁㸚㸟㸟㸒㸃㸁㸖㸕㸒㸑㸀㹜㸔㸜㸁㸚㸟㸟㸒㸖㸝㸖㸞㸊", 1380990579, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1661375474) ^ 0x2F78E385) - 0 - 0 + 0 - 0);
					continue;
				case 6u:
				{
					Vector3 val22 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -554548610) ^ 0x51C9B87E ^ 0) << 0) + 0 - 0;
					continue;
				}
				case 22u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⏺⏲⏯⏴⏱⏱⏼⏭⏯⏸⏻⏼⏿⏮⎲⏺⏲⏯⏴⏱⏱⏼⏸⏳⏸⏰⏤", 18555805, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 1195113832) ^ 0x820B1887u) + 0 - 0) ^ 0) >> 0;
					continue;
				case 24u:
				{
					Vector3 val21 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((int)((((num2 + 1270048165) ^ 0xE999C469u) - 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 7u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("顾顶顫顰页页顸顩顫顼顿顸须顪頶顾顶顫顰页页顸顼顷顼顴顠", 239835161, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -534003067) ^ 0x4A2788A8) << 0) + 0) ^ 0) >> 0;
					continue;
				case 25u:
				{
					Vector3 val20 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((((int)num2 + -863337981) ^ 0x7354D533) << 0) ^ 0) - 0 - 0;
					continue;
				}
				case 2u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("멊멂멟멄멁멁멌멝멟멈멋멌멏멞먂멊멂멟멄멁멁멌멈멃멈멀메", 35174957, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 364309176) ^ 0x196393F7 ^ 0) >> 0 << 0) ^ 0;
					continue;
				case 8u:
				{
					Vector3 val19 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((int)((((num2 + 707265091) ^ 0x7D86D66A) << 0) - 0) >> 0) - 0;
					continue;
				}
				case 28u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䦘䦐䦍䦖䦓䦓䦞䦏䦍䦚䦙䦞䦝䦌䧐䦘䦐䦍䦖䦓䦓䦞䦚䦑䦚䦒䦆", 1769359871, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 470890995) ^ 0x42C3512E ^ 0) << 0) - 0 << 0);
					continue;
				case 30u:
				{
					Vector3 val18 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((((num2 + 1438922508) ^ 0xED976205u ^ 0) + 0) ^ 0) + 0);
					continue;
				}
				case 9u:
				{
					Quaternion val17 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = (((((int)num2 + -646352687) ^ 0x5FAF827C) + 0 - 0) ^ 0) + 0;
					continue;
				}
				case 31u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("腮腦腻腠腥腥腨腹腻腬腯腨腫腺脦腮腦腻腠腥腥腨腬腧腬腤腰", 175210761, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 808537251) ^ 0x4A2E4764) - 0) >> 0 << 0 << 0;
					continue;
				case 33u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("壟壘綾樓雷雷籠凌綾鹿弄籠磊稜金壟壘綾樓雷雷籠鹿屢鹿賂樂", 784267557, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 757804180) ^ 0xCE7A134Cu ^ 0) - 0) ^ 0) - 0);
					continue;
				case 10u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﴈﴀﴝﴆﴃﴃﴎﴟﴝﴊﴉﴎﴍﴜ\ufd40ﴈﴀﴝﴆﴃﴃﴎﴊﴁﴊﴂﴖ", 740949359, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)((num2 + 1515080385) ^ 0xD87EA239u) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 34u:
				{
					Vector3 val16 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -1855006857) ^ -625785352 ^ 0 ^ 0) << 0) ^ 0;
					continue;
				}
				case 3u:
				{
					Vector3 val15 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)(((num2 + 403315589) ^ 0x34A2AC7) - 0 + 0 + 0 - 0);
					continue;
				}
				case 36u:
				{
					Vector3 val14 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)((num2 + 1989400013) ^ 0xDB4EE2D6u) >> 0) + 0 << 0) ^ 0;
					continue;
				}
				case 11u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("懄懌懑懊懏懏懂懓懑懆懅懂懁懐憌懄懌懑懊懏懏懂懆懍懆懎懚", 690512291, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -358205772) ^ 0x7628534C) + 0 >> 0 >> 0 >> 0;
					continue;
				case 38u:
				{
					Vector3 val13 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((((int)num2 + -800455404) ^ 0x6E27C2D0) >> 0) ^ 0) + 0 >> 0;
					continue;
				}
				case 40u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("퐫퐣퐾퐥퐠퐠퐭퐼퐾퐩퐪퐭퐮퐿푣퐫퐣퐾퐥퐠퐠퐭퐩퐢퐩퐡퐵", 1157289036, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -396906955) ^ 0x7002D9F6) + 0 << 0) - 0) ^ 0;
					continue;
				case 12u:
				{
					Vector3 val12 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -1179582984) ^ -1574854639 ^ 0) + 0 - 0) ^ 0;
					continue;
				}
				case 41u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뭓뭛뭆뭝뭘뭘뭕뭄뭆뭑뭒뭕뭖뭇묛뭓뭛뭆뭝뭘뭘뭕뭑뭚뭑뭙뭍", 1067629364, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -2139291301) ^ -995450351 ^ 0) - 0 + 0 - 0;
					continue;
				case 43u:
				{
					Vector3 val11 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((int)(((num2 + 1246932057) ^ 0x6F19FA4F) << 0) >> 0 << 0) - 0;
					continue;
				}
				case 13u:
				{
					Quaternion val10 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = ((((int)num2 + -535798627) ^ 0x2F4B6CEE) - 0 - 0 << 0) + 0;
					continue;
				}
				case 44u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㙐㙘㙅㙞㙛㙛㙖㙇㙅㙒㙑㙖㙕㙄㘘㙐㙘㙅㙞㙛㙛㙖㙒㙙㙒㙚㙎", 311506487, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)(((num2 + 705231750) ^ 0x7EFC90D7) << 0) >> 0) ^ 0) << 0;
					continue;
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꦑꦙꦄꦟꦚꦚꦗꦆꦄꦓꦐꦗꦔꦅ꧙ꦑꦙꦄꦟꦚꦚꦗꦓꦘꦓꦛꦏ", 1509599734, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -100986504) ^ -1436266054) << 0) ^ 0) << 0) + 0;
					continue;
				case 14u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("璄璌璑璊璏璏璂璓璑璆璅璂璁璐瓌璄璌璑璊璏璏璂璆璍璆璎璚", 14841059, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -788358910) ^ 0x6476A16B) << 0) + 0 << 0) + 0;
					continue;
				case 47u:
				{
					Vector3 val9 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -263229304) ^ 0x486D22BB ^ 0) - 0 >> 0) + 0;
					continue;
				}
				case 49u:
				{
					Vector3 val8 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)((num2 + 583561026) ^ 0x660C1CBF) >> 0) - 0 >> 0) ^ 0;
					continue;
				}
				case 15u:
				{
					Vector3 val7 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)num2 + -656729457) ^ 0x75BFEFE) << 0 << 0 >> 0 << 0;
					continue;
				}
				case 50u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue3b9\ue3b1\ue3ac\ue3b7\ue3b2\ue3b2\ue3bf\ue3ae\ue3ac\ue3bb\ue3b8\ue3bf\ue3bc\ue3ad\ue3f1\ue3b9\ue3b1\ue3ac\ue3b7\ue3b2\ue3b2\ue3bf\ue3bb\ue3b0\ue3bb\ue3b3\ue3a7", 1107026910, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)((num2 + 65153632) ^ 0x4A8F6CEC) >> 0) - 0) ^ 0 ^ 0;
					continue;
				case 52u:
				{
					Quaternion val6 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = (((((int)num2 + -1536809407) ^ -222050661) >> 0) + 0) ^ 0 ^ 0;
					continue;
				}
				case 16u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("咯咧咺咡咤咤咩咸咺咭咮咩咪咻哧咯咧咺咡咤咤咩咭咦咭咥咱", 1901810888, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -811454883) ^ 0x404A18B3) >> 0) - 0 << 0) - 0;
					continue;
				case 53u:
				{
					Vector3 val5 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)((((num2 + 929739382) ^ 0xCAADAA38u) << 0) ^ 0) >> 0 >> 0;
					continue;
				}
				case 5u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䤈䤀䤝䤆䤃䤃䤎䤟䤝䤊䤉䤎䤍䤜䥀䤈䤀䤝䤆䤃䤃䤎䤊䤁䤊䤂䤖", 2140424559, true), val3, val4, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1999758855) ^ -1286673384) - 0 + 0 << 0) ^ 0;
					continue;
				case 17u:
				{
					Vector3 val2 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)num2 + -365447244) ^ 0x57A9C410) + 0 + 0 - 0 + 0;
					continue;
				}
				case 56u:
					num = (int)((num2 + 927157583) ^ 0xD0D94F63u ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 19u:
				{
					Vector3 val = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((((int)num2 + -1497151632) ^ 0x616A27D7 ^ 0) + 0) ^ 0 ^ 0;
					continue;
				}
				case 18u:
					return;
				}
				break;
			}
		}
	}

	public static void jYSqFoXLQkFRbbZRawFQMwscSVEYVkNKmrmaAFIHvqjOGhfPynIz()
	{
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = default(Vector3);
		Quaternion val2 = default(Quaternion);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ 0) + 0 << 0) + 0) ^ 0) + 0 - 0)) % 10)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뿤뿬뿱뿪뿯뿯뿢뿳뿱뿦뿥뿢뿡뿰뾬뿤뿬뿱뿪뿯뿯뿢뿦뿭뿦뿮뿺", 563986307, true), val, val2, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 428697817) ^ 0x27B7C189) - 0 + 0 + 0 - 0);
					continue;
				case 5u:
				{
					Vector3 val6 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (int)((num2 + 359659174) ^ 0x33D5C3FC) >> 0 >> 0 >> 0 >> 0;
					continue;
				}
				case 9u:
					val = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = (((int)num2 + -248958683) ^ 0x6C31B026) + 0 - 0 + 0 >> 0;
					continue;
				case 1u:
				{
					Vector3 val5 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((int)((num2 + 1621957012) ^ 0x6F905C28 ^ 0) >> 0) - 0 << 0;
					continue;
				}
				case 7u:
				{
					Quaternion val4 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = ((int)(((num2 + 647071759) ^ 0x6B8DF790) << 0) >> 0 >> 0) + 0;
					continue;
				}
				case 0u:
					val2 = ((Component)GorillaTagger.Instance.myVRRig).transform.rotation * Quaternion.Euler(0f, 90f, 0f);
					num = ((((int)num2 + -344833909) ^ 0x3ABAB2D9 ^ 0) >> 0) - 0 << 0;
					continue;
				case 2u:
				{
					Vector3 val3 = ((Component)GorillaTagger.Instance.myVRRig).transform.position + new Vector3(-66.4848f, 11.8871f, -82.6619f);
					num = ((int)(((num2 + 2106842273) ^ 0x818C9DC8u) + 0) >> 0) - 0 - 0;
					continue;
				}
				case 4u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("걈걀걝걆걃걃걎걟걝걊걉걎걍걜가걈걀걝걆걃걃걎걉걆걝걊걍걎걃걃", 1437117487, true), val, val2, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -2130437817) ^ -1934000828) >> 0) ^ 0) - 0 + 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public cube_s_tump()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 << (0 << 1)) ^ 0) << 0 >> 0 << -0) + 0 + 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3 ^ 0 ^ 0) >> 0) + 0;
			}
		}
	}
}
