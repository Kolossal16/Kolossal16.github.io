using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class custom_stump
{
	public static void squMLsLWbTrGZtpplXvlyFPKsHxpeILUzXJiXRoCCcNUjZxhGGkKbgMNAJueVvSthwgbKhsuJTJwRVBtjpJxxbTtkVHnxjHgjuMMSwwyoPaiwpVFibVFMuVgCNQOAfXzlDmxiOANSkjIaLWVacevobtPzFjfFHYjSAWSdyxuAhMCkngRQVOyaBlkkwYCEvhklaPzOeRCEJVgpQElzsoJTAiqpMIGzVQeaBqkxGdMdlTqGeUtSMcmhxrLSzjcvlcJTQgNAuOSpBGHHRKlRoONSEXCkFsYwaqRjjxPXhTxYjWFRJdaOYkhxpRpSECUcPvokOyxuUnJvqPIHsKBBrjyPjuUshWtEYviOIudkGGULBLgzjIATbtKFXybtEfmXTewVGUYXHqVKpNoynujzwzDFKCQjtJFAuWRwolSoJDmLxaqkjCgkW()
	{
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0398: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301865;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 >> (0 << 1)) - 0 + 0 >> 0) + (0 ^ 0) - 0 >> 0)) % 16)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					num = (int)((((num2 + 1952503976) ^ 0x80CA71B2u) - 0 - 0) ^ 0 ^ 0);
					continue;
				case 11u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uebca\uebc8\uebd3\uebc3\uebd4\uebc4\uebd5\uebc2\uebc2\uebc9", 1155525543, true)).GetComponent<Renderer>().material.color = Color.black;
					num = (int)((((((num2 + 770395556) ^ 0xCF3A303Cu) << 0) - 0) ^ 0) - 0);
					continue;
				case 9u:
					num = (int)((((num2 + 359659174) ^ 0x4BFA8ABF ^ 0) - 0 << 0) ^ 0);
					continue;
				case 14u:
					num = (int)((((num2 + 1107201870) ^ 0x64CDDF18) + 0 + 0 + 0) ^ 0);
					continue;
				case 7u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueb90\uebbc\uebb7\uebb6\ueb9c\uebb5\ueb90\uebbc\uebbd\uebb7\ueba6\uebb0\ueba7", 1190325203, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("裾袡袭袮袭袰裿袰袧袦裼袎袃袁袺袁袍袁裾裭袡袭袮袭袰裼", 333940930, true);
					num = (((((int)num2 + -1125345364) ^ -2124224549) - 0 >> 0) ^ 0) << 0;
					continue;
				case 0u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("荤荦荽荭荽荬荱荽", 611549961, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("豎豯谦豲豮豧豨豭豵谦豠豩豴谦豶豳豴豥豮豧豵豯豨象谦豊豅豋豾豖豇豏豂谦豯谦豮豩豶豣谦豿豩豳谦豣豨豬豩豿谌豤豲豱谦豲豮豯豵谦豯豵谦豲豮豣谦谷豵豲谦豶豧豯豢谦豱豴豯豵豲谦豫豣豨豳", 809339910, true);
					num = (int)((((num2 + 1621957012) ^ 0x8DF7CB28u) << 0 << 0) + 0 - 0);
					continue;
				case 2u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udd2f\udd2d\udd36\udd26", 1663425858, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﴸﵧﵫﵨﵫﵶﴹﵦﵨﵱﵡﴺ\ufd48\ufd45\ufd47ﴸﴫﵧﵫﵨﵫﵶﴺﴤﴸﵧﵫﵨﵫﵶﴹﵨﵭﵩﵡﴺﵜﴸﴫﵧﵫﵨﵫﵶﴺﴤﴸﵧﵫﵨﵫﵶﴹﵶﵡﵠﴺ\ufd49\ufd4bﵐ\ufd40ﴸﴫﵧﵫﵨﵫﵶﴺ", 485096708, true);
					num = (((((int)num2 + -814951907) ^ 0x5FB56B55) - 0) ^ 0 ^ 0) >> 0;
					continue;
				case 10u:
					num = ((int)((num2 + 1665746989) ^ 0xDB6A556Cu ^ 0) >> 0 << 0) + 0;
					continue;
				case 12u:
					num = (int)(((num2 + 647071759) ^ 0x522BEC24) - 0) >> 0 << 0 >> 0;
					continue;
				case 3u:
					num = (int)((((num2 + 1333463150) ^ 0xF4DB17ECu ^ 0) << 0 << 0) + 0);
					continue;
				case 13u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueeac\ueebc\ueead\ueeba\ueeba\ueeb1", 1975971551, true)).GetComponent<Renderer>().material.color = Color.black;
					num = ((((int)num2 + -227232852) ^ 0x7E2DC337) >> 0) + 0 << 0 >> 0;
					continue;
				case 15u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("데덼데댓덧덖덋덇", 1053799219, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("맗맦맱맰맽맠맧릮릞릨맷맻맸맻맦릩맶맸맡맱릪맘맗맙릴맙망맟맑맍릨릻맷맻맸맻맦릪릴릮릴맗맆맑맕맀맛맆릞릨맷맻맸맻맦릩맹맵맳맱맺맠맵릪맆링맇맀맍릴말맕릴맟망맀맀맍릴맕맚말릴맇맛맘맕맆릵릨릻맷맻맸맻맦릪릴릮릴맘맗맙릴맧맥맡맵맰", 1436989844, true);
					num = (int)((((((num2 + 428697817) ^ 0x3FB051C9) + 0) ^ 0) + 0) ^ 0);
					continue;
				case 4u:
					num = (int)(((((num2 + 1548432940) ^ 0xDD43465) + 0) ^ 0) + 0) >> 0;
					continue;
				case 1u:
					num = (int)((((num2 + 2106842273) ^ 0x8CB71F05u ^ 0) - 0 + 0) ^ 0);
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public custom_stump()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) - -0 - 0 - 0 >> 0 >> (0 >> 1)) - 0 + 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) - 0 - 0 << 0) ^ 0;
			}
		}
	}
}
