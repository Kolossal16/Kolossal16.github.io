using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class size_arsm
{
	public static void TDoXMIcsXNwgIXHpctrAMHrBJQGuJxSqRyBbTEuaytcozJcSmimzSgelmMoVbHIzUfpkvFwxYqcsFccZOOiAltyKtqPgqzZQKCttuRwHMPABeMFjKognzhoBHERfPphzrlHdJIFXsBOvSXGHKGwbsLrDnSMPaqRwHajSeCAbJjUYtSIKYkujTfhFUePRWPXbJrNRNOCigurjQskvjcRQVH()
	{
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown2 = default(bool);
		bool flag = default(bool);
		bool flag2 = default(bool);
		bool triggerButtonDown = default(bool);
		while (true)
		{
			int num = 1758301865;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ 0) - 0) ^ 0) - 0 - (0 ^ 0) >> 0) + 0)) % 16)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					triggerButtonDown2 = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (int)((num2 + 359659174) ^ 0x4BFA8ABE ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 5u:
				{
					int num5;
					int num6;
					if (!flag)
					{
						num5 = -225644682;
						num6 = num5;
					}
					else
					{
						num5 = -231089518;
						num6 = num5;
					}
					num = (int)((((uint)(num5 >> 0 << 0) ^ (num2 + 820929353)) << 0 << 0) - 0 - 0);
					continue;
				}
				case 1u:
					flag2 = triggerButtonDown2;
					num = (int)(((((num2 + 1621957012) ^ 0x8DF7CB28u ^ 0) - 0) ^ 0) + 0);
					continue;
				case 7u:
					num = ((int)(((num2 + 853099006) ^ 0x6346205D) + 0) >> 0) - 0 + 0;
					continue;
				case 13u:
				{
					int num3;
					int num4;
					if (flag2)
					{
						num3 = -342560089;
						num4 = num3;
					}
					else
					{
						num3 = -1303850751;
						num4 = num3;
					}
					num = (((num3 >> 0 >> 0) ^ ((int)num2 + -534343288)) + 0 - 0 - 0) ^ 0;
					continue;
				}
				case 6u:
				{
					Transform transform2 = ((Component)GorillaTagger.Instance).transform;
					transform2.localScale -= new Vector3(0.01f, 0.01f, 0.01f);
					num = (int)((((num2 + 1817661307) ^ 0xF402A70Fu ^ 0) << 0) + 0 - 0);
					continue;
				}
				case 2u:
					num = ((((int)num2 + -1692824216) ^ -1121735359 ^ 0) << 0) - 0 - 0;
					continue;
				case 10u:
					flag = triggerButtonDown;
					num = (((int)num2 + -1127256878) ^ 0x72E0B9C9 ^ 0) - 0 - 0 + 0;
					continue;
				case 11u:
				{
					Transform transform = ((Component)GorillaTagger.Instance).transform;
					transform.localScale += new Vector3(0.01f, 0.01f, 0.01f);
					num = (int)((((num2 + 1954386908) ^ 0x9241D6C4u) + 0 << 0 << 0) - 0);
					continue;
				}
				case 12u:
					num = ((((int)((num2 + 350301675) ^ 0xE7D3C61) >> 0) - 0) ^ 0) - 0;
					continue;
				case 3u:
					num = ((((int)num2 + -692261737) ^ -1145926859) >> 0 << 0) + 0 >> 0;
					continue;
				case 14u:
					num = (int)(((num2 + 830009972) ^ 0x544030C5) + 0 + 0 + 0 - 0);
					continue;
				case 15u:
					num = (((int)num2 + -1284218664) ^ 0x41DEF983) + 0 + 0 - 0 - 0;
					continue;
				case 4u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = 0x46FA1C1A ^ 0;
					continue;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	public static void DCTDXaNJfUmTobeQWkHmdyNXOCUtHUXhgbOlYjQCuwpxXXdiqsfHiJEeOWOvftbkWfNnmTSNtfRGjqaRyLdoPqYwxJxcuvwbveASkQWxArodRXVyVXXuqNvGgqPCvQtYIQlePiGHPFOxbVFzOZgwycLIJULUatbJYqubMRIMrpFKYXElKqOwKWzGfCvVwMGvEezLAEMXqtfiwaJL()
	{
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 << (0 >> 1) >> 0 >> 0 >> 0 >> (0 << 1)) ^ 0) >> 0)) % 14)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					flag2 = !EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((((int)num2 + -2130437817) ^ -602494967) - 0 >> 0) - 0 - 0;
					continue;
				case 5u:
				{
					Transform transform2 = ((Component)GorillaTagger.Instance).transform;
					transform2.localScale -= new Vector3(0.01f, 0.01f, 0.01f);
					num = (int)(((num2 + 1505546092) ^ 0x9AC84F95u ^ 0) - 0) >> 0 >> 0;
					continue;
				}
				case 1u:
				{
					int num5;
					int num6;
					if (!flag2)
					{
						num5 = -2145680381;
						num6 = num5;
					}
					else
					{
						num5 = -815817394;
						num6 = num5;
					}
					num = ((((num5 - 0 + 0) ^ ((int)num2 + -1625985034)) << 0) - 0 >> 0) - 0;
					continue;
				}
				case 4u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -549224956;
						num4 = num3;
					}
					else
					{
						num3 = -1166912237;
						num4 = num3;
					}
					num = (int)((((((uint)(num3 + 0 << 0) ^ (num2 + 1339473132)) + 0) ^ 0) + 0) ^ 0);
					continue;
				}
				case 13u:
					num = ((((int)num2 + -715084519) ^ -522581668 ^ 0) << 0 >> 0) - 0;
					continue;
				case 6u:
					num = ((int)(((num2 + 350301675) ^ 0xA3985978u) + 0 - 0) >> 0) - 0;
					continue;
				case 2u:
				{
					Transform transform = ((Component)GorillaTagger.Instance).transform;
					transform.localScale += new Vector3(0.01f, 0.01f, 0.01f);
					num = (((((int)num2 + -534343288) ^ -434198885) + 0) ^ 0 ^ 0) << 0;
					continue;
				}
				case 10u:
					num = (((((int)num2 + -541887392) ^ 0x5784A155) - 0) ^ 0) - 0 - 0;
					continue;
				case 11u:
					num = (((int)num2 + -1692824216) ^ -1456617352 ^ 0) - 0 << 0 << 0;
					continue;
				case 12u:
					num = (int)(((((num2 + 820929353) ^ 0xEA6EF2C1u ^ 0) - 0) ^ 0) - 0);
					continue;
				case 3u:
					num = (int)((((num2 + 1954386908) ^ 0xD9F1E3D1u ^ 0) + 0) ^ 0 ^ 0);
					continue;
				case 8u:
					flag = !EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = 0x49E2A52C ^ 0;
					continue;
				case 7u:
					return;
				}
				break;
			}
		}
	}

	public size_arsm()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num >> 0) + (0 << 1)) ^ 0) - 0 >> 0) + (0 + 0)) ^ 0) >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0 >> 0 << 0) - 0;
			}
		}
	}
}
