using System.Collections.Generic;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate;

internal class hunt
{
	public static void StPfqSQcrJzajNPEjINObWmjSFIKtWVOkxwagRiflCBNqgIoNMcrmKQVhFmLjgIuNLQMqOyszICyvySMWuWHUDBzGASAExVfUgZFqVXYnJSDisAJMAOPjbAjjqgPWYObNxEpynwaxXtkLYqoajNeIgVTGQwZPhcpVQQLNkkzdNrlHpylaSPMkKtGBLJIQwlpVdpVhFAPZoaUOJlqrlZXsqfkxjjcBCJHCcqDZDdvrZNWJySSzsqFxnXFXeyXv()
	{
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0662: Expected O, but got Unknown
		GorillaGameManager current = default(GorillaGameManager);
		bool flag2 = default(bool);
		bool flag5 = default(bool);
		bool flag = default(bool);
		bool isMine = default(bool);
		bool flag4 = default(bool);
		bool flag3 = default(bool);
		Hashtable val2 = default(Hashtable);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 >> -0) ^ 0) - 0 - 0 + -0 - 0 - 0)) % 4)
				{
				case 2u:
					break;
				case 1u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((((int)num2 + -1874950498) ^ -859104564) + 0) ^ 0) << 0) - 0;
					continue;
				case 3u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6) - 0 << 0) >> 0) - 0;
					continue;
				default:
				{
					IEnumerator<GorillaGameManager> enumerator = Object.FindObjectsOfType<GorillaGameManager>().GetEnumerator();
					try
					{
						while (true)
						{
							IL_045d:
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 927588269;
								num4 = num3;
							}
							else
							{
								num3 = 1190796316;
								num4 = num3;
							}
							int num5 = num3 + 0 + 0 >> 0 << 0;
							while (true)
							{
								switch ((num2 = (uint)((((num5 ^ 0) >> (0 << 1)) + 0 - 0 + 0 << (0 >> 1)) - 0 << 0)) % 22)
								{
								case 12u:
									num5 = 1190796316;
									continue;
								default:
									goto end_IL_00bd;
								case 6u:
									current = enumerator.Current;
									num5 = 0x71293130 ^ 0;
									continue;
								case 19u:
									num5 = (((int)num2 + -491758348) ^ 0x50EBB6D ^ 0) + 0 - 0 >> 0;
									continue;
								case 18u:
									num5 = (((int)num2 + -814951907) ^ 0x10B84DA5) + 0 + 0 - 0 >> 0;
									continue;
								case 15u:
								{
									int num8;
									int num9;
									if (!flag2)
									{
										num8 = 682164520;
										num9 = num8;
									}
									else
									{
										num8 = 1706286930;
										num9 = num8;
									}
									num5 = (int)((((uint)((num8 >> 0) - 0) ^ (num2 + 414049813) ^ 0) << 0) + 0 - 0);
									continue;
								}
								case 4u:
									flag5 = !((MonoBehaviourPun)current).photonView.IsMine;
									num5 = (int)((((num2 + 1665746989) ^ 0xD805D790u) << 0) + 0 - 0 - 0);
									continue;
								case 13u:
									flag = isMine;
									num5 = (int)(((((num2 + 1047830633) ^ 0x314C5A9A) - 0 + 0) ^ 0) - 0);
									continue;
								case 5u:
									flag4 = flag5;
									num5 = (int)((num2 + 770395556) ^ 0xBA96B929u) >> 0 << 0 >> 0 >> 0;
									continue;
								case 17u:
									PhotonNetwork.Destroy(((MonoBehaviourPun)current).photonView);
									num5 = ((int)(((num2 + 2008734093) ^ 0xCC043D40u) + 0) >> 0) + 0 << 0;
									continue;
								case 0u:
									flag3 = flag4;
									num5 = (int)((((num2 + 1333463150) ^ 0x7242262D ^ 0) - 0 << 0) - 0);
									continue;
								case 21u:
									break;
								case 7u:
								{
									int num6;
									int num7;
									if (!flag3)
									{
										num6 = 535612195;
										num7 = num6;
									}
									else
									{
										num6 = 695072480;
										num7 = num6;
									}
									num5 = (int)(((uint)((num6 ^ 0) + 0) ^ (num2 + 2029155507)) + 0 + 0 - 0 - 0);
									continue;
								}
								case 14u:
									flag2 = flag;
									num5 = (int)(((((num2 + 830770635) ^ 0x9C426868u) - 0 + 0) ^ 0) + 0);
									continue;
								case 8u:
									num5 = (((int)num2 + -649986417) ^ 0x3CB28F0C ^ 0 ^ 0) + 0 - 0;
									continue;
								case 16u:
									num5 = (int)((((num2 + 202644353) ^ 0x1E0F71B8) << 0) ^ 0) >> 0 >> 0;
									continue;
								case 9u:
									((MonoBehaviourPun)current).photonView.RequestOwnership();
									num5 = (int)((((((num2 + 660359990) ^ 0x77D99A7B) << 0) ^ 0) + 0) ^ 0);
									continue;
								case 2u:
									num5 = (int)(((((num2 + 1448286972) ^ 0xB37131D5u) - 0) ^ 0 ^ 0) - 0);
									continue;
								case 10u:
									num5 = (((int)num2 + -1950096023) ^ -1233856382) - 0 - 0 + 0 >> 0;
									continue;
								case 20u:
									num5 = (0x7460D8AD ^ 0) >> 0 >> 0 >> 0;
									continue;
								case 11u:
									num5 = (((int)num2 + -11084362) ^ 0x619B190 ^ 0 ^ 0) >> 0 << 0;
									continue;
								case 1u:
									isMine = ((MonoBehaviourPun)current).photonView.IsMine;
									num5 = (647071757 + 0 >> 0) - 0 + 0;
									continue;
								case 3u:
									goto end_IL_00bd;
								}
								goto IL_045d;
								continue;
								end_IL_00bd:
								break;
							}
							break;
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_05bc:
								int num10 = 389422579;
								while (true)
								{
									switch ((num2 = (uint)((num10 << 0 >> 0 + 0) - 0 - 0 - 0 + -0 - 0 >> 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_05c1;
									case 3u:
										enumerator.Dispose();
										num10 = (((int)(((num2 + 110359293) ^ 0x1BFCA2AD) - 0) >> 0) ^ 0) >> 0;
										continue;
									case 1u:
										num10 = ((((int)num2 + -1285184145) ^ -1515505318) << 0) + 0 - 0 << 0;
										continue;
									case 2u:
										goto end_IL_05c1;
									}
									goto IL_05bc;
									continue;
									end_IL_05c1:
									break;
								}
								break;
							}
						}
					}
					Hashtable val = new Hashtable();
					while (true)
					{
						int num11 = 426455321;
						while (true)
						{
							switch ((num2 = (uint)(((num11 - 0 - (0 >> 1)) ^ 0 ^ 0 ^ 0) - (0 >> 1) - 0 + 0)) % 6)
							{
							case 0u:
								break;
							default:
								return;
							case 5u:
								((Dictionary<Object, Object>)(object)val).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("읕읓읟읗읿읝읖읗", 2003814194, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⬑⬬⬷⬭", 683223897, true)));
								num11 = (int)((((num2 + 169575766) ^ 0x67B1BA0E ^ 0) + 0) ^ 0) >> 0;
								continue;
							case 2u:
								PhotonNetwork.CurrentRoom.SetCustomProperties(val2, (Hashtable)null, (WebFlags)null);
								num11 = (((int)num2 + -82741106) ^ 0x37D5B52B ^ 0 ^ 0) - 0 << 0;
								continue;
							case 1u:
								num11 = ((int)(((num2 + 1471034652) ^ 0xC1A0E729u) << 0 << 0) >> 0) + 0;
								continue;
							case 4u:
								val2 = val;
								num11 = (int)(((num2 + 1387026688) ^ 0x87DD6B22u) - 0 + 0 << 0 << 0);
								continue;
							case 3u:
								return;
							}
							break;
						}
					}
				}
				}
				break;
			}
		}
	}

	public hunt()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 >> -0) ^ 0) >> 0 >> 0 << (0 ^ 0) << 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 - 0) ^ 0 ^ 0;
			}
		}
	}
}
