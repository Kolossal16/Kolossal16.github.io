using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class doug_spammer
{
	public static void SuRUmciXJwOzjnZnBnSTrdCmKRYAGZZJrrShQnHXGtKTftAmKqFfSlfOSFkudIrKwfhRvSwoFUmYtIhqrMPptUQgleplcnTYbawZlJRSTrzXYhvjxTdrSbqCoaFrDlmsboWtlheHUXwcvSheIfNikBfaJULldAoIehWKkbXqPvwUEnhvSBIxxehzjWJrwTEuJOXnWxUGhxtOfkvwMpsBSQkaZwBnsFTVRclQpTzuHbpaKsuYBnEhBcBSDXoz()
	{
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		bool flag2 = default(bool);
		bool gripButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num + 0) ^ 0) << 0) ^ 0) << 0 << (0 << 1)) ^ 0) >> 0)) % 10)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ҜҔ\u0489ҒҗҗҚҋ\u0489ҞҝҚҙ\u0488ӔүҳҩҴҬ", 1574110459, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)num2 + -1692824216) ^ -1509741448 ^ 0 ^ 0) + 0 + 0;
					continue;
				case 5u:
				{
					int num3;
					int num4;
					if (!flag2)
					{
						num3 = -374740352;
						num4 = num3;
					}
					else
					{
						num3 = -1188542420;
						num4 = num3;
					}
					num = (((num3 + 0 - 0) ^ ((int)num2 + -1625985034)) + 0 >> 0) + 0 >> 0;
					continue;
				}
				case 9u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = ((((int)num2 + -248958683) ^ 0x6C31B026 ^ 0) >> 0 >> 0) ^ 0;
					continue;
				case 1u:
					num = (((((int)num2 + -715084519) ^ -211488849) + 0 << 0) ^ 0) + 0;
					continue;
				case 7u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (((((int)num2 + -534343288) ^ -1407652343) - 0) ^ 0) - 0 + 0;
					continue;
				case 0u:
					flag = gripButtonDown;
					num = ((((int)num2 + -344833909) ^ 0x3ABAB2D9) - 0 << 0) + 0 + 0;
					continue;
				case 2u:
					num = (int)(((((num2 + 1954386908) ^ 0xF89A2515u) + 0 - 0) ^ 0) - 0);
					continue;
				case 4u:
					flag2 = flag;
					num = (((((int)num2 + -2130437817) ^ -1934000828) << 0) + 0 << 0) - 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public doug_spammer()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) ^ 0) << 0) + 0 << 0 >> (0 << 1)) ^ 0u ^ 0u) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) << 0) + 0 << 0 >> 0;
			}
		}
	}
}
