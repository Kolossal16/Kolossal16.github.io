using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class rape_gun
{
	public static float GblSwkxYKyuopBrYhSeQXtblcaXTPeQEnitzhJfhcBzhWIehGFhkswunZaPwmDiGHPahiSQxNWNvUUouVQnjWFlROgAhUIVzsSzhIXZOPKxwIYseMvAvpZJcDjtcsJDebodbvhMYRzumiPiPNvuyhzjtjxDyEXvfgsuuVrJFJCEQEwTNbDoXofWCfJRXDntUdogPvOUwLPOEUsOMDPxbIyRbwSolzLbwjKMpqesmISlyqsHMUfuNQslFxetCzJWZOsvkGz = 0f;

	public static float vzxksPmsKdkCqtroFQygRmKPNZVlKYWxfvJUqGawsetpsXsCIzNELzHjOHwsTbIMhNwUKwYYQcOMSvxPHtDkksLGOAfIjHCrwHiFBxSlBONJLUrtkGLAxxBObQgjqpOjAwqlnSojArIwFcUTjMyCWbTYft;

	public static void DKqJVlZEioEfgrsCagPfjYVnaDRlnyDrfToDSRwxwaUGpdGgkubNjZkFPdIruOqJLmamdOJiKsJiepXWXKaTxPhfIJOOifcHKkUcdtdwKSdRqcAAgMtJNxlVeUDtZUaEpbyUuUTDHEiFMqPGioIwLtUmYYYiPJwPRyCpDGglSQcjpGjOfXlLmETWgmVvWKNXhsNnNzdBhxEVqLXrPjdSyKDnFGir()
	{
		//IL_0f36: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_094e: Unknown result type (might be due to invalid IL or missing references)
		//IL_095a: Unknown result type (might be due to invalid IL or missing references)
		//IL_097d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0982: Unknown result type (might be due to invalid IL or missing references)
		//IL_06af: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_082b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_0852: Unknown result type (might be due to invalid IL or missing references)
		//IL_085c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0861: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a50: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0781: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae5: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0671: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_073c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecc: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default(RaycastHit);
		VRRig componentInParent = default(VRRig);
		GameObject val2 = default(GameObject);
		bool flag = default(bool);
		bool flag2 = default(bool);
		bool flag4 = default(bool);
		bool flag3 = default(bool);
		while (true)
		{
			int num = 1758301832;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) + (0 << 1) + 0 << 0 << 0) - (0 + 0) - 0 - 0)) % 57)
				{
				case 0u:
					break;
				default:
					return;
				case 32u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val);
					num = (((((int)num2 + -182552646) ^ 0x682B09A7) - 0) ^ 0) << 0 << 0;
					continue;
				case 17u:
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)componentInParent).transform.rotation;
					num = ((((((int)num2 + -1052270108) ^ 0xADB9F04) + 0) ^ 0) >> 0) - 0;
					continue;
				case 1u:
					val2 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = ((((int)num2 + -1563535789) ^ -1021934358) - 0 << 0) + 0 >> 0;
					continue;
				case 25u:
					soundspammers.ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(39, 0.15f, 0.05f, 0.9f);
					num = (int)((((((num2 + 445589957) ^ 0x60226DC1) << 0) ^ 0) - 0) ^ 0);
					continue;
				case 48u:
					val2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (((int)num2 + -1829903696) ^ -1102101745) >> 0 << 0 >> 0 << 0;
					continue;
				case 21u:
					((Component)GorillaTagger.Instance.myVRRig.leftHand.rigTarget).transform.rotation = ((Component)componentInParent).transform.rotation;
					num = (int)((((num2 + 1538676277) ^ 0x3ECCBEBA) + 0 - 0) ^ 0) >> 0;
					continue;
				case 2u:
					num = (((int)num2 + -229453252) ^ 0x14EAE614) << 0 >> 0 >> 0 << 0;
					continue;
				case 28u:
					num = (((int)num2 + -1300837070) ^ -1612263015) - 0 - 0 >> 0 << 0;
					continue;
				case 40u:
					val2.transform.position = ((RaycastHit)(ref val)).point;
					num = (((((int)num2 + -1761200462) ^ -1254526500) << 0) ^ 0) << 0 >> 0;
					continue;
				case 19u:
					((Component)GorillaTagger.Instance.myVRRig.leftHand.rigTarget).transform.position = componentInParent.leftHandTransform.position + ((Component)componentInParent).transform.right * -0.2f + ((Component)componentInParent).transform.up * -0.4f;
					num = (((int)num2 + -1264230692) ^ 0x72DA78A7 ^ 0) + 0 + 0 - 0;
					continue;
				case 3u:
					num = ((int)((num2 + 1661375474) ^ 0x2F78E3AA ^ 0) >> 0) - 0 >> 0;
					continue;
				case 23u:
					flag = Time.time - GblSwkxYKyuopBrYhSeQXtblcaXTPeQEnitzhJfhcBzhWIehGFhkswunZaPwmDiGHPahiSQxNWNvUUouVQnjWFlROgAhUIVzsSzhIXZOPKxwIYseMvAvpZJcDjtcsJDebodbvhMYRzumiPiPNvuyhzjtjxDyEXvfgsuuVrJFJCEQEwTNbDoXofWCfJRXDntUdogPvOUwLPOEUsOMDPxbIyRbwSolzLbwjKMpqesmISlyqsHMUfuNQslFxetCzJWZOsvkGz > vzxksPmsKdkCqtroFQygRmKPNZVlKYWxfvJUqGawsetpsXsCIzNELzHjOHwsTbIMhNwUKwYYQcOMSvxPHtDkksLGOAfIjHCrwHiFBxSlBONJLUrtkGLAxxBObQgjqpOjAwqlnSojArIwFcUTjMyCWbTYft;
					num = ((int)((num2 + 1415827559) ^ 0xE0D1F8D9u) >> 0 << 0) + 0 - 0;
					continue;
				case 53u:
					Object.Destroy((Object)(object)val2.GetComponent<BoxCollider>());
					num = ((((int)((num2 + 1270048165) ^ 0xE999C4B4u) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 52u:
					GblSwkxYKyuopBrYhSeQXtblcaXTPeQEnitzhJfhcBzhWIehGFhkswunZaPwmDiGHPahiSQxNWNvUUouVQnjWFlROgAhUIVzsSzhIXZOPKxwIYseMvAvpZJcDjtcsJDebodbvhMYRzumiPiPNvuyhzjtjxDyEXvfgsuuVrJFJCEQEwTNbDoXofWCfJRXDntUdogPvOUwLPOEUsOMDPxbIyRbwSolzLbwjKMpqesmISlyqsHMUfuNQslFxetCzJWZOsvkGz = Time.time;
					num = ((((int)num2 + -2009213796) ^ -1192247568) << 0) + 0 << 0 << 0;
					continue;
				case 4u:
					num = ((((int)((num2 + 364309176) ^ 0x196393FF) >> 0) + 0) ^ 0) >> 0;
					continue;
				case 16u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)componentInParent).transform.position + ((Component)componentInParent).transform.forward * (0f - (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f));
					num = (((((int)num2 + -1553473705) ^ -1169067734) - 0) ^ 0) << 0 >> 0;
					continue;
				case 36u:
					Object.Destroy((Object)(object)val2.GetComponent<Rigidbody>());
					num = (int)((((num2 + 1438922508) ^ 0xED97623Fu) + 0 - 0 - 0) ^ 0);
					continue;
				case 18u:
					((Component)GorillaTagger.Instance.myVRRig).transform.rotation = ((Component)componentInParent).transform.rotation;
					num = (((((int)num2 + -159507211) ^ 0x5B5B39B6) + 0 >> 0) ^ 0) >> 0;
					continue;
				case 5u:
					num = (int)((((num2 + 757804180) ^ 0xCE7A12B9u) << 0 << 0) - 0 + 0);
					continue;
				case 20u:
					((Component)GorillaTagger.Instance.myVRRig.rightHand.rigTarget).transform.position = componentInParent.rightHandTransform.position + ((Component)componentInParent).transform.right * -0.2f + ((Component)componentInParent).transform.up * -0.4f;
					num = (((int)num2 + -808576807) ^ -1207778040 ^ 0) + 0 + 0 << 0;
					continue;
				case 44u:
					Object.Destroy((Object)(object)val2.GetComponent<Collider>());
					num = ((int)((num2 + 403315589) ^ 0x34A2A0E) >> 0 << 0 >> 0) + 0;
					continue;
				case 22u:
					((Component)GorillaTagger.Instance.myVRRig.rightHand.rigTarget).transform.rotation = ((Component)componentInParent).transform.rotation;
					num = ((((int)num2 + -1657935803) ^ -203714770) - 0 << 0) - 0 << 0;
					continue;
				case 6u:
					num = ((((int)num2 + -396906955) ^ 0x7002D9DD) - 0 + 0 >> 0) ^ 0;
					continue;
				case 24u:
				{
					int num5;
					int num6;
					if (!flag2)
					{
						num5 = 672837700;
						num6 = num5;
					}
					else
					{
						num5 = 191414694;
						num6 = num5;
					}
					num = (int)((((uint)(num5 + 0 << 0) ^ (num2 + 1888003287) ^ 0) - 0) ^ 0 ^ 0);
					continue;
				}
				case 50u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val2, Color.black);
					num = (((int)((num2 + 1246932057) ^ 0x6F19FA59) >> 0) + 0 >> 0) + 0;
					continue;
				case 7u:
					num = ((((int)num2 + -100986504) ^ -1436266060) + 0 >> 0) - 0 - 0;
					continue;
				case 27u:
					num = (int)((((num2 + 777884590) ^ 0xC3A08B1Au) << 0) - 0 << 0) >> 0;
					continue;
				case 30u:
					Object.Destroy((Object)(object)val2, Time.deltaTime);
					num = (((int)((num2 + 583561026) ^ 0x660C1CFC) >> 0) + 0 >> 0) - 0;
					continue;
				case 31u:
					num = (((int)num2 + -777708833) ^ 0x14A1B550 ^ 0) - 0 + 0 << 0;
					continue;
				case 8u:
					num = (((((int)num2 + -1536809407) ^ -222050494) + 0 << 0) - 0) ^ 0;
					continue;
				case 33u:
					num = (int)(((num2 + 107741590) ^ 0xC5C7904) << 0) >> 0 >> 0 << 0;
					continue;
				case 34u:
				{
					bool triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (((((int)num2 + -1999758855) ^ -1286673359) >> 0 << 0) ^ 0) + 0;
					continue;
				}
				case 35u:
					num = ((int)((num2 + 2000359224) ^ 0xB8844836u) >> 0) + 0 - 0 - 0;
					continue;
				case 9u:
					num = (((((int)num2 + -1497151632) ^ 0x616A27EF) << 0) - 0) ^ 0 ^ 0;
					continue;
				case 37u:
					num = ((((int)num2 + -844538616) ^ 0x512D09C5) - 0 + 0 << 0) + 0;
					continue;
				case 38u:
					flag4 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val)).collider).GetComponentInParent<VRRig>());
					num = (int)((((num2 + 234277810) ^ 0x52809A8C ^ 0 ^ 0) << 0) - 0);
					continue;
				case 39u:
					num = (int)((((num2 + 346463589) ^ 0xAD356094u) - 0 << 0) - 0) >> 0;
					continue;
				case 10u:
					flag3 = flag4;
					num = ((((int)num2 + -554548610) ^ 0x51C9B996) >> 0 << 0) + 0 >> 0;
					continue;
				case 41u:
					num = ((((int)num2 + -123593846) ^ 0x3C719837 ^ 0) >> 0) + 0 >> 0;
					continue;
				case 42u:
				{
					int num3;
					int num4;
					if (!flag3)
					{
						num3 = -1099089730;
						num4 = num3;
					}
					else
					{
						num3 = -1692612654;
						num4 = num3;
					}
					num = (int)((((uint)((num3 - 0) ^ 0) ^ (num2 + 776420349) ^ 0) + 0 << 0) + 0);
					continue;
				}
				case 43u:
					num = (int)((((num2 + 1312251543) ^ 0xB9926AE8u) + 0 << 0 << 0) ^ 0);
					continue;
				case 11u:
					num = ((int)((((num2 + 476044639) ^ 0x6265D78C) << 0) ^ 0) >> 0) + 0;
					continue;
				case 45u:
					num = (((((int)num2 + -2041068990) ^ -1416276565) + 0) ^ 0) + 0 << 0;
					continue;
				case 46u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = ((((int)num2 + -404739134) ^ 0x42FB61DB) << 0) - 0 + 0 << 0;
					continue;
				case 47u:
					flag2 = flag;
					num = ((int)(((num2 + 45990464) ^ 0x56DB7C5B) + 0 + 0) >> 0) + 0;
					continue;
				case 12u:
					num = (((((int)num2 + -1412658558) ^ 0x102AEC5E) - 0 + 0) ^ 0) - 0;
					continue;
				case 49u:
					num = (int)(((num2 + 595818838) ^ 0xD2039F8Cu) - 0) >> 0 << 0 << 0;
					continue;
				case 13u:
					num = (int)(((num2 + 1216645994) ^ 0xD8420018u) - 0 + 0 << 0) >> 0;
					continue;
				case 26u:
					num = ((int)((num2 + 710975831) ^ 0x785286D3) >> 0 << 0) + 0 - 0;
					continue;
				case 51u:
					componentInParent = ((Component)((RaycastHit)(ref val)).collider).GetComponentInParent<VRRig>();
					num = (0x1A924FB1 ^ 0) + 0 + 0;
					continue;
				case 14u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = (int)(((num2 + 1127294952) ^ 0x29A3AF2F ^ 0) - 0 << 0) >> 0;
					continue;
				case 54u:
					((Component)GorillaTagger.Instance.myVRRig.head.rigTarget).transform.rotation = ((Component)componentInParent).transform.rotation;
					num = (0x1B8110AB ^ 0) >> 0;
					continue;
				case 55u:
					num = ((((int)num2 + -217055685) ^ 0x50390954 ^ 0) << 0) - 0 >> 0;
					continue;
				case 56u:
					num = (int)(((((num2 + 1888985512) ^ 0x9B25BB17u ^ 0) + 0) ^ 0) << 0);
					continue;
				case 15u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)componentInParent).transform.position + ((Component)componentInParent).transform.forward * (0f - (0.2f + Mathf.Sin((float)Time.frameCount / 8f) * 0.1f));
					num = (int)(((num2 + 1573031133) ^ 0xDA60BE8Eu) + 0 << 0) >> 0 >> 0;
					continue;
				case 29u:
					return;
				}
				break;
			}
		}
	}

	public rape_gun()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 << (0 ^ 0) << 0) ^ 0) >> 0) - (0 ^ 0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) ^ 0 ^ 0 ^ 0;
			}
		}
	}

	static rape_gun()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 << -0 << 0 << 0) + 0) ^ 0) << 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_0052;
				case 1u:
					return;
				}
				break;
				IL_0052:
				vzxksPmsKdkCqtroFQygRmKPNZVlKYWxfvJUqGawsetpsXsCIzNELzHjOHwsTbIMhNwUKwYYQcOMSvxPHtDkksLGOAfIjHCrwHiFBxSlBONJLUrtkGLAxxBObQgjqpOjAwqlnSojArIwFcUTjMyCWbTYft = 100f;
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) + 0 - 0 << 0;
			}
		}
	}
}
