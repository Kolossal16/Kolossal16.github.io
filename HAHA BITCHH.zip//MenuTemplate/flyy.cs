using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace MenuTemplate;

internal class flyy
{
	public static void aFpoLTaingqXlnMEvVHAMssRDbmGocHCRtRHoPwKRDCGCAsDgtDRNjEHnyLJGtUlzNfSwfpFzWJiQMpcJJzUzQPIOjuQeNdxJrgOuAgbdXsQAwRAjIZWTZLJYxdmLzBMSlyyFAHjCyQCxYhssTHwNgEJF()
	{
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		bool primaryButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301862;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) - (0 + 0) + 0) ^ 0 ^ 0) << (0 << 1)) - 0 >> 0)) % 11)
				{
				case 6u:
					break;
				default:
					return;
				case 8u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.headCollider).transform.forward * Time.deltaTime * 45f;
					num = ((((int)num2 + -1579710319) ^ -1082318499 ^ 0) >> 0 >> 0) - 0;
					continue;
				}
				case 5u:
					num = (((((int)num2 + -1807018533) ^ -1292754237) - 0 >> 0) + 0) ^ 0;
					continue;
				case 9u:
					primaryButtonDown = EasyInputs.GetPrimaryButtonDown((EasyHand)1);
					num = (((int)((num2 + 1345212153) ^ 0x8D3CD278u) >> 0 >> 0) ^ 0) >> 0;
					continue;
				case 1u:
					((Component)Player.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
					num = (int)((((num2 + 266738246) ^ 0x3ED95C98) << 0) - 0 << 0 << 0);
					continue;
				case 7u:
					num = ((((int)num2 + -640398734) ^ -1505020664) + 0 + 0 - 0) ^ 0;
					continue;
				case 0u:
					flag = primaryButtonDown;
					num = (int)(((num2 + 600520462) ^ 0x4211A45D) - 0 - 0 - 0 + 0);
					continue;
				case 2u:
					num = ((((int)num2 + -1397142901) ^ -1335757928) << 0 << 0 >> 0) + 0;
					continue;
				case 10u:
					num = (((((int)num2 + -1466265009) ^ -1631740082) + 0 + 0) ^ 0) - 0;
					continue;
				case 4u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -764741446;
						num4 = num3;
					}
					else
					{
						num3 = -1283633406;
						num4 = num3;
					}
					num = (((((num3 ^ 0) >> 0) ^ ((int)num2 + -1496278149)) >> 0 << 0) ^ 0) - 0;
					continue;
				}
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public flyy()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 + (0 << 1) + 0 + 0 << 0) + (0 ^ 0) + 0 >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB3) >> 0) + 0) ^ 0) + 0;
			}
		}
	}
}
