using System;
using System.Collections.Generic;
using System.Reflection;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate;

internal class name_change_all
{
	public static void FzAhRhzXSVZmgYHuMmyyNKIZumVNCvZyHelpatcVyAKiwhTBAzjzkUtUQANEmLvxWAFcMrtsjDZmaADmttmclzoMKrzAGxJNfmmWBRPigQpGUgTqXBlSyslwlTruSSMMTmhOnHKBEdWukHRDxjCemQoMaQKIzuqneDNIZfcqQJouw()
	{
		Player current = default(Player);
		bool flag2 = default(bool);
		bool flag = default(bool);
		MethodInfo method = default(MethodInfo);
		string[] array = default(string[]);
		Type typeFromHandle = default(Type);
		int num6 = default(int);
		string nickName = default(string);
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 << (0 >> 1) >> 0) - 0 + 0) ^ 0) << 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				case 2u:
					goto IL_004a;
				default:
				{
					IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerListOthers).GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 961186684;
								num4 = num3;
							}
							else
							{
								num3 = 414745712;
								num4 = num3;
							}
							int num5 = ((num3 << 0) ^ 0) << 0 << 0;
							while (true)
							{
								switch ((num2 = (uint)(((((num5 - 0 + (0 + 0)) ^ 0 ^ 0) >> 0) + -0 << 0) - 0)) % 21)
								{
								case 0u:
									num5 = 414745712;
									continue;
								default:
									return;
								case 17u:
									current = enumerator.Current;
									num5 = ((0x54C7FBDF ^ 0) >> 0) + 0;
									continue;
								case 9u:
									num5 = (0x7D93DCAA ^ 0) >> 0;
									continue;
								case 1u:
									num5 = ((((int)num2 + -1125345364) ^ 0x585636BE ^ 0) + 0 << 0) + 0;
									continue;
								case 7u:
								{
									int num7;
									int num8;
									if (!flag2)
									{
										num7 = -1072282320;
										num8 = num7;
									}
									else
									{
										num7 = -1324393304;
										num8 = num7;
									}
									num5 = (int)(((((uint)((num7 << 0) ^ 0) ^ (num2 + 830770635)) - 0 << 0) + 0) ^ 0);
									continue;
								}
								case 13u:
									set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
									num5 = (int)(((((num2 + 1952503976) ^ 0xF8B961C9u) + 0 + 0) ^ 0) - 0);
									continue;
								case 6u:
									flag = method != null;
									num5 = (int)(((num2 + 1457370637) ^ 0xC15E883Eu) + 0 - 0 - 0 - 0);
									continue;
								case 2u:
									num5 = (((int)num2 + -814951907) ^ 0x674FDF10) << 0 << 0 << 0 << 0;
									continue;
								case 8u:
									method.Invoke(current, new object[0]);
									num5 = ((int)(((num2 + 337346832) ^ 0x71E89B33) << 0) >> 0 << 0) - 0;
									continue;
								case 11u:
									array = new string[12]
									{
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("枝枊枋", 1829201903, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("獋獅獜獌", 1085698857, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("齺齯齸齸齳", 1626971933, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ㆶㆬㆴㆻ", 487535061, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᾛᾞᾚᾒ", 911679479, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䳘䳝䳚䳘䳄䳍", 1017728168, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u0014\r\n\u000f", 529596516, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("첟첃첊첊첉첑", 648465638, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("킚킔킙킛킓", 1806160120, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("넼넡넲넽넴넶", 1583984979, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("窓窆窑窍", 311589620, true),
										ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("텶텩텨텵텤", 1362874625, true)
									};
									num5 = (int)((((num2 + 1665746989) ^ 0x845C37BEu) + 0) ^ 0) >> 0 >> 0;
									continue;
								case 12u:
									method = typeFromHandle.GetMethod(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u0a51੧੶\u0a52੮\u0a63\u0a7b੧\u0a70\u0a4c\u0a63੯੧\u0a52\u0a70੭ੲ੧\u0a70੶\u0a7b", 1541081602, true), BindingFlags.Instance | BindingFlags.Public);
									num5 = ((((((int)num2 + -1008375456) ^ -1841251432) - 0) ^ 0) - 0) ^ 0;
									continue;
								case 3u:
									num6 = new Random().Next(array.Length);
									num5 = (int)(((num2 + 770395556) ^ 0x156BDC1E) - 0 + 0 - 0) >> 0;
									continue;
								case 14u:
									flag2 = flag;
									num5 = (int)(((num2 + 1956669763) ^ 0xB357C438u ^ 0 ^ 0) - 0 + 0);
									continue;
								case 15u:
									nickName = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("揄㮝\ufade\ufadd\ufade遲戴", 1125120689, true) + array[num6] + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("诏词讂讘讋讔诌诂诃识评诈诏讹记讣讼设访讨诟讽设讽译设访讥设计词诞讂讘讋讔诏词诞讒讞讝讞讃诏读讕讘讂讒讞讃讕诟讖讖诞讵讚订讇识访诃讷讦讒", 590121969, true);
									num5 = (int)((((num2 + 1333463150) ^ 0x99267FF0u) + 0 << 0) + 0) >> 0;
									continue;
								case 16u:
									num5 = ((((int)num2 + -1377430272) ^ -2143424556) >> 0 >> 0 << 0) + 0;
									continue;
								case 4u:
									current.NickName = nickName;
									num5 = (((int)num2 + -227232852) ^ 0x173BF3E1) + 0 - 0 >> 0 >> 0;
									continue;
								case 18u:
									num5 = (((((int)num2 + -1160147690) ^ -2081528731) >> 0) ^ 0) - 0 >> 0;
									continue;
								case 19u:
									num5 = (int)(((num2 + 1107201870) ^ 0x1399D3B0 ^ 0) + 0 << 0 << 0);
									continue;
								case 20u:
									break;
								case 5u:
									typeFromHandle = typeof(Player);
									num5 = (int)((((((num2 + 1548432940) ^ 0xB9894794u) << 0) + 0) ^ 0) << 0);
									continue;
								case 10u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_065e:
								int num9 = 1106027215;
								while (true)
								{
									switch ((num2 = (uint)((num9 + 0 + (0 ^ 0) << 0) + 0 + 0 + (0 >> 1) + 0 - 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0663;
									case 3u:
										enumerator.Dispose();
										num9 = ((((int)num2 + -767782975) ^ 0x76996E65 ^ 0) + 0 << 0) - 0;
										continue;
									case 1u:
										num9 = ((int)((num2 + 917659543) ^ 0xF4DA2E62u ^ 0) >> 0) - 0 + 0;
										continue;
									case 2u:
										goto end_IL_0663;
									}
									goto IL_065e;
									continue;
									end_IL_0663:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_004a:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5) >> 0 >> 0 >> 0 << 0;
			}
		}
	}

	public static void QlEbNXIpHAdXuNwWbcjNIqHUjErhmoCCUqjEgHLxIYwdJLFsFtPHeHOAEJSjFBdtXAceDSQuqMfJTEkxZZBTyVynBJZwPBSgUdfjIAONDvqsCeGayukFakUbbPCUStEOUYPQybOykNpdEfKxcZYuqmgKi()
	{
		//IL_0586: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0439: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val2 = default(RaycastHit);
		MethodInfo method = default(MethodInfo);
		Player owner = default(Player);
		GameObject val = default(GameObject);
		bool flag2 = default(bool);
		Type typeFromHandle = default(Type);
		bool flag4 = default(bool);
		bool triggerButtonDown = default(bool);
		bool flag5 = default(bool);
		bool flag3 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) - (0 + 0) >> 0) + 0 << 0) + (0 ^ 0) >> 0 << 0)) % 37)
				{
				case 0u:
					break;
				default:
					return;
				case 32u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = (((((int)num2 + -871797673) ^ 0x111F50B) - 0 << 0) ^ 0) >> 0;
					continue;
				case 17u:
					method.Invoke(owner, new object[0]);
					num = (((int)num2 + -580916186) ^ 0x6EA250A6 ^ 0) - 0 - 0 << 0;
					continue;
				case 1u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((((int)num2 + -1439813256) ^ -998857766 ^ 0) << 0) ^ 0) << 0;
					continue;
				case 27u:
					num = (int)(((num2 + 1866650904) ^ 0xB6BD231Cu) + 0 - 0) >> 0 >> 0;
					continue;
				case 25u:
					val.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
					num = (((int)num2 + -2033110311) ^ -1301572850) - 0 - 0 + 0 - 0;
					continue;
				case 11u:
					owner = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (1468567986 << 0 << 0) - 0 << 0;
					continue;
				case 2u:
					num = (((int)num2 + -1827602905) ^ -1254868460) >> 0 << 0 >> 0 << 0;
					continue;
				case 15u:
					flag2 = method != null;
					num = (int)((((((num2 + 1198527402) ^ 0x31D52170) - 0) ^ 0) << 0) - 0);
					continue;
				case 21u:
					val.transform.position = ((RaycastHit)(ref val2)).point;
					num = (((int)num2 + -509051253) ^ -526599914) >> 0 << 0 << 0 >> 0;
					continue;
				case 10u:
					num = (((((int)num2 + -340251349) ^ 0x4603C7C1) - 0) ^ 0) - 0 << 0;
					continue;
				case 3u:
					num = ((((int)num2 + -1891630081) ^ -213945469 ^ 0) - 0 << 0) + 0;
					continue;
				case 12u:
					num = ((((int)num2 + -1403453257) ^ 0x10A65615 ^ 0) >> 0 >> 0) - 0;
					continue;
				case 28u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (((((int)num2 + -903840450) ^ 0x570ADC01) >> 0 >> 0) ^ 0) + 0;
					continue;
				case 14u:
					typeFromHandle = typeof(Player);
					num = (int)((((num2 + 641832775) ^ 0x34B33FA3 ^ 0) - 0 << 0) - 0);
					continue;
				case 4u:
					num = (int)(((num2 + 1455221297) ^ 0xE6659376u ^ 0) - 0 << 0 << 0);
					continue;
				case 16u:
				{
					int num7;
					int num8;
					if (flag4)
					{
						num7 = 1153142801;
						num8 = num7;
					}
					else
					{
						num7 = 978373861;
						num8 = num7;
					}
					num = (((num7 + 0 << 0) ^ ((int)num2 + -230523280)) - 0 << 0) + 0 << 0;
					continue;
				}
				case 36u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (int)((((num2 + 1473386669) ^ 0xEFE505F3u) + 0) ^ 0 ^ 0) >> 0;
					continue;
				case 18u:
					num = (1333463147 - 0 - 0 << 0) - 0;
					continue;
				case 5u:
					num = (int)(((((num2 + 1376848916) ^ 0x93147222u) + 0) ^ 0 ^ 0) << 0);
					continue;
				case 22u:
					num = (int)(((((num2 + 733616138) ^ 0xCF7F8286u) << 0) + 0 << 0) - 0);
					continue;
				case 23u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (((int)num2 + -182552646) ^ 0x2E3E864B) + 0 + 0 << 0 << 0;
					continue;
				case 24u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((((int)num2 + -1372250924) ^ 0x782E722D) - 0 >> 0) ^ 0) - 0;
					continue;
				case 6u:
					num = ((((int)num2 + -1563535789) ^ 0x2D8BA1D0) - 0 - 0 >> 0) - 0;
					continue;
				case 13u:
					owner.NickName = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䠀䡟䡓䡐䡓䡎䠁䡎䡙䡘䠂䡴䡽䡮䡱䡳䡲䡥䠒䡰䡳䡰䠜䡳䡲䡨䡳䡬䠀䠓䡟䡓䡐䡓䡎䠂", 1974421564, true);
					num = (int)((((num2 + 293113464) ^ 0x762F8E29) << 0) - 0 << 0 << 0);
					continue;
				case 26u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (((int)num2 + -1829903696) ^ -1212350219) - 0 - 0 + 0 - 0;
					continue;
				case 7u:
					flag5 = triggerButtonDown;
					num = (((((int)num2 + -229453252) ^ -1546809165) << 0 << 0) + 0) ^ 0;
					continue;
				case 29u:
					method = typeFromHandle.GetMethod(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf164\uf152\uf143\uf167\uf15b\uf156\uf14e\uf152\uf145\uf179\uf156\uf15a\uf152\uf167\uf145\uf158\uf147\uf152\uf145\uf143\uf14e", 419230007, true), BindingFlags.Instance | BindingFlags.Public);
					num = (int)((((num2 + 435749897) ^ 0xB9100307u) << 0) ^ 0 ^ 0) >> 0;
					continue;
				case 30u:
				{
					int num5;
					int num6;
					if (!flag5)
					{
						num5 = -263616249;
						num6 = num5;
					}
					else
					{
						num5 = -1436715062;
						num6 = num5;
					}
					num = (int)(((uint)(num5 << 0 << 0) ^ (num2 + 1855391286)) - 0 - 0 - 0 - 0);
					continue;
				}
				case 31u:
					flag4 = flag2;
					num = (((((int)num2 + -877465945) ^ 0x2EAF9919) >> 0) - 0 << 0) + 0;
					continue;
				case 8u:
					num = (int)(((num2 + 1919092371) ^ 0xCCC726A6u) - 0) >> 0 >> 0 >> 0;
					continue;
				case 33u:
					num = (int)((((num2 + 1006463140) ^ 0xFAAF803Du ^ 0) << 0 << 0) ^ 0);
					continue;
				case 34u:
					flag3 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>());
					num = ((int)(((num2 + 1363915621) ^ 0xFCCC9699u) - 0) >> 0) - 0 >> 0;
					continue;
				case 35u:
					num = (int)(((num2 + 734168536) ^ 0x440FC755) + 0 << 0 << 0 << 0);
					continue;
				case 9u:
					flag = flag3;
					num = ((((int)((num2 + 823506666) ^ 0xF7D89642u) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 20u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -1924064386;
						num4 = num3;
					}
					else
					{
						num3 = -1303514021;
						num4 = num3;
					}
					num = ((int)((((uint)(num3 - 0 - 0) ^ (num2 + 1168528836)) << 0) - 0) >> 0) - 0;
					continue;
				}
				case 19u:
					return;
				}
				break;
			}
		}
	}

	public name_change_all()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) - (0 << 1) - 0 >> 0) ^ 0) + -0 << 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0 << 0) + 0 << 0;
			}
		}
	}
}
