using MelonLoader;
using Photon.Pun;
using PlayFab;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace CycyWristMenuTemplate;

public class Bypass : MelonMod
{
	private void zadYchlMFRbQcmcvWcWvxxbmCilxvtrjdXidGVQhRSVONZtpwIPXPTsbZRwTWOqlzSMfdYOblPDECmyDPWbMEtujEhePzWkd()
	{
		bool flag13 = default(bool);
		GameObject val = default(GameObject);
		bool flag9 = default(bool);
		GameObject[] array2 = default(GameObject[]);
		bool flag11 = default(bool);
		bool flag6 = default(bool);
		bool flag2 = default(bool);
		bool flag16 = default(bool);
		GameObject[] array = default(GameObject[]);
		bool flag15 = default(bool);
		bool flag14 = default(bool);
		int num5 = default(int);
		bool flag12 = default(bool);
		bool flag10 = default(bool);
		bool flag8 = default(bool);
		bool flag7 = default(bool);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		bool flag3 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301785;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((((num >> 0) ^ 0) << 0) + 0) ^ 0) >> -0) ^ 0) + 0)) % 124)
				{
				case 27u:
					break;
				default:
					return;
				case 29u:
					num = (int)(((((num2 + 1539585716) ^ 0xE76CD093u ^ 0) << 0) + 0) ^ 0);
					continue;
				case 15u:
					flag13 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⏝⏅⏞⏄", 1942627222, true));
					num = (0x509B7AF0 ^ 0) + 0;
					continue;
				case 42u:
					Object.Destroy((Object)(object)val);
					num = (((int)num2 + -790522453) ^ -1946550718) << 0 << 0 << 0 << 0;
					continue;
				case 56u:
					num = (((int)((num2 + 57433052) ^ 0xCF07ED9) >> 0) ^ 0) << 0 << 0;
					continue;
				case 70u:
				{
					int num26;
					int num27;
					if (!flag9)
					{
						num26 = -520967027;
						num27 = num26;
					}
					else
					{
						num26 = -1731878359;
						num27 = num26;
					}
					num = (int)(((uint)(num26 + 0 - 0) ^ (num2 + 1215661000)) - 0 << 0 << 0) >> 0;
					continue;
				}
				case 83u:
					num = ((int)((num2 + 691650460) ^ 0x4E49BAC7) >> 0 >> 0) + 0 << 0;
					continue;
				case 97u:
					num = (int)(((((num2 + 711699715) ^ 0x82A1CE6) + 0) ^ 0) - 0 + 0);
					continue;
				case 111u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("乐乛乖乒乇", 1937329715, true)));
					num = ((((((int)num2 + -1146569570) ^ -1402153411) - 0) ^ 0) - 0) ^ 0;
					continue;
				case 11u:
					num = (((int)num2 + -1562374052) ^ 0x44270F8B) - 0 << 0 >> 0 << 0;
					continue;
				case 12u:
					Object.Destroy((Object)(object)val);
					num = ((int)(((num2 + 1344932091) ^ 0xCB2A17EFu) + 0 - 0) >> 0) - 0;
					continue;
				case 0u:
					num = ((int)(((num2 + 2133633953) ^ 0xC955DD1Bu) + 0) >> 0) + 0 - 0;
					continue;
				case 14u:
					num = (((((int)num2 + -590282087) ^ 0x1982018) << 0 << 0) + 0) ^ 0;
					continue;
				case 13u:
					array2 = Il2CppArrayBase<GameObject>.op_Implicit(Object.FindObjectsOfType<GameObject>());
					num = ((((int)num2 + -1453520766) ^ 0x27ED993B) << 0 >> 0) + 0 + 0;
					continue;
				case 16u:
				{
					int num34;
					int num35;
					if (!flag13)
					{
						num34 = -877138710;
						num35 = num34;
					}
					else
					{
						num34 = -129393246;
						num35 = num34;
					}
					num = (((num34 - 0 + 0) ^ ((int)num2 + -1668616113)) << 0) - 0 + 0 - 0;
					continue;
				}
				case 17u:
					num = ((((int)num2 + -1407614985) ^ -1969443414) - 0 << 0 << 0) ^ 0;
					continue;
				case 18u:
					Object.Destroy((Object)(object)val);
					num = (int)((((num2 + 945608923) ^ 0xE3DFAD72u) << 0) - 0 << 0 << 0);
					continue;
				case 19u:
					num = (((int)num2 + -994114590) ^ 0x43765BC9 ^ 0) - 0 - 0 + 0;
					continue;
				case 20u:
					num = ((int)((num2 + 1199386966) ^ 0x8B06F00Fu) >> 0 >> 0) - 0 + 0;
					continue;
				case 21u:
					flag11 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ìãùäîåèìùâïçèîù", 392560813, true));
					num = (1414165214 << 0 << 0 >> 0) + 0;
					continue;
				case 22u:
				{
					int num24;
					int num25;
					if (!flag11)
					{
						num24 = -1169210636;
						num25 = num24;
					}
					else
					{
						num24 = -1624326886;
						num25 = num24;
					}
					num = (int)(((((uint)((num24 << 0) + 0) ^ (num2 + 844718799)) + 0) ^ 0) + 0 - 0);
					continue;
				}
				case 23u:
					num = ((((int)num2 + -1468729033) ^ -1786056610) >> 0) - 0 + 0 - 0;
					continue;
				case 24u:
					Object.Destroy((Object)(object)val);
					num = (int)((((num2 + 1548950767) ^ 0xCE4872E2u) << 0) + 0 - 0 + 0);
					continue;
				case 25u:
					num = ((int)((num2 + 1585061354) ^ 0xE5477131u ^ 0) >> 0 << 0) - 0;
					continue;
				case 26u:
					num = ((((int)num2 + -1837227721) ^ -148620332) - 0 << 0 << 0) ^ 0;
					continue;
				case 1u:
					flag6 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ఇట\u0c04ఞ\u0c0dఢసథ", 996609100, true));
					num = 0x1A924FB0 ^ 0;
					continue;
				case 28u:
				{
					int num16;
					int num17;
					if (flag6)
					{
						num16 = -946426079;
						num17 = num16;
					}
					else
					{
						num16 = -792772779;
						num17 = num16;
					}
					num = ((((num16 << 0) - 0) ^ ((int)num2 + -1721489520) ^ 0) << 0 >> 0) ^ 0;
					continue;
				}
				case 40u:
					num = ((((((int)num2 + -1520509820) ^ -1062859074) - 0) ^ 0) << 0) + 0;
					continue;
				case 30u:
					Object.Destroy((Object)(object)val);
					num = (int)(((((num2 + 1178387442) ^ 0x32EA729B) << 0) ^ 0) << 0 << 0);
					continue;
				case 31u:
					num = (int)((((num2 + 43990471) ^ 0x67BC56C2) << 0) - 0 << 0) >> 0;
					continue;
				case 32u:
					num = ((((int)num2 + -698306463) ^ 0x6F5841DC) - 0 << 0 << 0) + 0;
					continue;
				case 33u:
					flag2 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("퀖퀾퀾퀑퀺퀷퀱퀹퀷퀠", 36622418, true));
					num = (1709781226 + 0 + 0 << 0) + 0;
					continue;
				case 34u:
				{
					int num8;
					int num9;
					if (flag2)
					{
						num8 = -1969255889;
						num9 = num8;
					}
					else
					{
						num8 = -721390549;
						num9 = num8;
					}
					num = (int)(((uint)(num8 << 0 >> 0) ^ (num2 + 1099667150)) + 0 + 0 + 0 - 0);
					continue;
				}
				case 35u:
					num = (int)(((((num2 + 1892732207) ^ 0x831E0E0Au ^ 0) - 0) ^ 0) + 0);
					continue;
				case 36u:
					Object.Destroy((Object)(object)val);
					num = ((((int)num2 + -339525817) ^ 0x461E5C9A) + 0 >> 0 << 0) ^ 0;
					continue;
				case 37u:
					num = (((int)num2 + -1361039952) ^ -1303225769 ^ 0) + 0 << 0 >> 0;
					continue;
				case 38u:
					num = ((int)((num2 + 895677943) ^ 0xF318D1F6u) >> 0 >> 0) + 0 + 0;
					continue;
				case 39u:
					flag16 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u0368\u0367ͽ\u0360\u0309\u036a\u0361\u036c\u0368ͽ", 604504873, true));
					num = (0x2A2E3156 ^ 0) - 0;
					continue;
				case 2u:
				{
					int num36;
					int num37;
					if (flag16)
					{
						num36 = -1981635009;
						num37 = num36;
					}
					else
					{
						num36 = -1946599377;
						num37 = num36;
					}
					num = ((((num36 ^ 0) + 0) ^ ((int)num2 + -1645348836)) - 0 + 0 >> 0) + 0;
					continue;
				}
				case 41u:
					num = ((int)((num2 + 1009847833) ^ 0x78FEAFD0 ^ 0) >> 0) - 0 << 0;
					continue;
				case 54u:
					array = array2;
					num = ((((int)num2 + -1499634342) ^ -769667492 ^ 0) >> 0 << 0) ^ 0;
					continue;
				case 43u:
					num = ((int)((num2 + 1323852466) ^ 0xB82366F5u) >> 0) - 0 - 0 >> 0;
					continue;
				case 44u:
					num = ((int)((num2 + 1962235126) ^ 0xCBE33A4Bu) >> 0) - 0 >> 0 >> 0;
					continue;
				case 45u:
					flag15 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䑦䑉䑓䑎䐇䑄䑏䑂䑆䑓", 142820391, true));
					num = 0x61A87E7E ^ 0;
					continue;
				case 46u:
				{
					int num32;
					int num33;
					if (!flag15)
					{
						num32 = -1936863070;
						num33 = num32;
					}
					else
					{
						num32 = -555897446;
						num33 = num32;
					}
					num = (((int)(((uint)(num32 >> 0 << 0) ^ (num2 + 643276067)) + 0) >> 0) + 0) ^ 0;
					continue;
				}
				case 47u:
					num = (((((int)num2 + -1045043061) ^ 0x17D39AD2 ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 48u:
					Object.Destroy((Object)(object)val);
					num = ((((int)num2 + -1962307287) ^ -286655436 ^ 0 ^ 0) >> 0) + 0;
					continue;
				case 49u:
					num = ((int)((num2 + 277713780) ^ 0xCF0D815Fu) >> 0 >> 0 << 0) - 0;
					continue;
				case 50u:
					num = ((((int)num2 + -237335916) ^ 0x3F76CCB5 ^ 0) - 0 >> 0) ^ 0;
					continue;
				case 51u:
					flag14 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⚦⚉⚓⚎⚄⚏⚂⚆⚓", 803743463, true));
					num = 0x56BCEA18 ^ 0;
					continue;
				case 52u:
				{
					int num30;
					int num31;
					if (flag14)
					{
						num30 = 1788517991;
						num31 = num30;
					}
					else
					{
						num30 = 1426229391;
						num31 = num30;
					}
					num = ((((num30 >> 0) - 0) ^ ((int)num2 + -1244482502)) << 0) + 0 >> 0 >> 0;
					continue;
				}
				case 53u:
					num = ((((int)((num2 + 727990850) ^ 0xC6AB5A1Cu) >> 0) - 0) ^ 0) << 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val);
					num = ((((int)num2 + -725770167) ^ 0x370EA813 ^ 0) << 0 >> 0) - 0;
					continue;
				case 55u:
					num = (int)((((num2 + 227301697) ^ 0x7B1C65C0) + 0 << 0) + 0 - 0);
					continue;
				case 68u:
					num5 = 0;
					num = (((int)num2 + -837232188) ^ -936583379) + 0 + 0 + 0 - 0;
					continue;
				case 57u:
					flag12 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udd3b\udd34\udd2e\udd33\udd39\udd32\udd3f\udd3b\udd2e", 588373370, true));
					num = (1964930966 << 0 >> 0) + 0 - 0;
					continue;
				case 58u:
				{
					int num28;
					int num29;
					if (!flag12)
					{
						num28 = -81368268;
						num29 = num28;
					}
					else
					{
						num28 = -300155588;
						num29 = num28;
					}
					num = (int)((((uint)(num28 - 0 << 0) ^ (num2 + 2143850309) ^ 0) + 0) ^ 0 ^ 0);
					continue;
				}
				case 59u:
					num = (int)((((num2 + 2086541461) ^ 0xB5954260u) + 0 << 0) - 0) >> 0;
					continue;
				case 60u:
					Object.Destroy((Object)(object)val);
					num = (((((int)num2 + -371167956) ^ 0x505A82F1 ^ 0) << 0) - 0) ^ 0;
					continue;
				case 61u:
					num = (int)(((((num2 + 1657452078) ^ 0xAD531579u) + 0 + 0) ^ 0) + 0);
					continue;
				case 62u:
					num = (((int)((num2 + 233036639) ^ 0x2F10D012) >> 0) ^ 0) >> 0 >> 0;
					continue;
				case 63u:
					flag10 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("᭥\u1b4e\u1b43ᭇ᭒", 769465126, true));
					num = (0x7252D274 ^ 0) + 0 >> 0;
					continue;
				case 64u:
				{
					int num22;
					int num23;
					if (flag10)
					{
						num22 = 1678335169;
						num23 = num22;
					}
					else
					{
						num22 = 1422141049;
						num23 = num22;
					}
					num = (((((num22 ^ 0) - 0) ^ ((int)num2 + -917793096) ^ 0) - 0) ^ 0) << 0;
					continue;
				}
				case 65u:
					num = (((int)num2 + -231305650) ^ 0x46CBF241 ^ 0 ^ 0) - 0 + 0;
					continue;
				case 66u:
					Object.Destroy((Object)(object)val);
					num = ((int)((num2 + 229224798) ^ 0x5933D07F ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 67u:
					num = ((((((int)num2 + -2105174978) ^ 0x63275835) + 0) ^ 0) << 0) ^ 0;
					continue;
				case 4u:
					num = (int)((((num2 + 1511253511) ^ 0xD2403682u) - 0 << 0 << 0) ^ 0);
					continue;
				case 69u:
					flag9 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf337\uf338\uf322\uf33f", 151778134, true));
					num = 0x4BB3657A ^ 0;
					continue;
				case 81u:
					num = ((((int)num2 + -1575253258) ^ -13193844) << 0 >> 0 << 0) ^ 0;
					continue;
				case 71u:
					num = ((int)((num2 + 1230829704) ^ 0x43FCA917) >> 0) - 0 + 0 << 0;
					continue;
				case 72u:
					Object.Destroy((Object)(object)val);
					num = ((((int)num2 + -939024926) ^ -1205345389) << 0) + 0 - 0 << 0;
					continue;
				case 73u:
					num = (int)((((num2 + 1891049432) ^ 0x8394BDDBu) - 0 + 0 << 0) + 0);
					continue;
				case 74u:
					num = (int)((((num2 + 968726257) ^ 0xFB5B8828u ^ 0) - 0 + 0) ^ 0);
					continue;
				case 75u:
					flag8 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("샺샱샼샸샭", 316260505, true));
					num = (0x2D2B2CDC ^ 0) << 0 >> 0;
					continue;
				case 76u:
				{
					int num20;
					int num21;
					if (!flag8)
					{
						num20 = 895477674;
						num21 = num20;
					}
					else
					{
						num20 = 1668880650;
						num21 = num20;
					}
					num = ((((int)((uint)(num20 - 0 >> 0) ^ (num2 + 146654683)) >> 0) - 0) ^ 0) - 0;
					continue;
				}
				case 77u:
					num = ((((int)num2 + -2111725839) ^ -1061580444 ^ 0) >> 0) - 0 >> 0;
					continue;
				case 78u:
					Object.Destroy((Object)(object)val);
					num = (int)(((num2 + 92383625) ^ 0x15FEEB0) - 0) >> 0 >> 0 << 0;
					continue;
				case 79u:
					num = (((int)num2 + -504187414) ^ -1768861759) + 0 >> 0 >> 0 >> 0;
					continue;
				case 80u:
					num = (((int)num2 + -899422606) ^ 0x320C8163) >> 0 << 0 << 0 >> 0;
					continue;
				case 5u:
					flag7 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ufe6f﹠ﹺ\ufe67", 764018190, true));
					num = 0x4A52AC56 ^ 0;
					continue;
				case 82u:
				{
					int num18;
					int num19;
					if (flag7)
					{
						num18 = 516181687;
						num19 = num18;
					}
					else
					{
						num18 = 133939039;
						num19 = num18;
					}
					num = (((((num18 ^ 0) + 0) ^ ((int)num2 + -966133482)) >> 0) ^ 0) + 0 + 0;
					continue;
				}
				case 95u:
					val = array[num5];
					num = 0x54C7FC09 ^ 0;
					continue;
				case 84u:
					Object.Destroy((Object)(object)val);
					num = ((int)((num2 + 756085796) ^ 0xF21402B9u ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 85u:
					num = (((int)((num2 + 220436453) ^ 0x40F3F020) >> 0) + 0 >> 0) ^ 0;
					continue;
				case 86u:
					num = (((int)num2 + -870664420) ^ -106677059 ^ 0) - 0 - 0 - 0;
					continue;
				case 87u:
					flag5 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("덃덌덖덋", 824816386, true));
					num = (0x24662678 ^ 0) - 0 + 0 << 0;
					continue;
				case 88u:
				{
					int num14;
					int num15;
					if (!flag5)
					{
						num14 = -2120984918;
						num15 = num14;
					}
					else
					{
						num14 = -348497042;
						num15 = num14;
					}
					num = (((((num14 << 0) - 0) ^ ((int)num2 + -892485801)) >> 0 << 0) + 0) ^ 0;
					continue;
				}
				case 89u:
					num = ((((int)num2 + -1431278727) ^ -1502334016) >> 0 << 0 >> 0) ^ 0;
					continue;
				case 90u:
					Object.Destroy((Object)(object)val);
					num = (((int)num2 + -642980460) ^ -237992179) + 0 - 0 + 0 + 0;
					continue;
				case 91u:
					num = ((((((int)num2 + -144468349) ^ 0x2DCD492E) << 0) + 0) ^ 0) + 0;
					continue;
				case 92u:
					num = ((int)(((num2 + 1482445195) ^ 0x11B82A36) + 0) >> 0 << 0) + 0;
					continue;
				case 93u:
					flag4 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㥳㥸㥵㥱㥤", 787364144, true));
					num = (234277882 >> 0) + 0 << 0 >> 0;
					continue;
				case 94u:
				{
					int num12;
					int num13;
					if (!flag4)
					{
						num12 = -759288035;
						num13 = num12;
					}
					else
					{
						num12 = -2067499580;
						num13 = num12;
					}
					num = ((((num12 - 0 + 0) ^ ((int)num2 + -434618300)) << 0) ^ 0) - 0 >> 0;
					continue;
				}
				case 6u:
					num = (int)(((num2 + 108385934) ^ 0x29B31230 ^ 0) - 0 + 0 << 0);
					continue;
				case 96u:
					Object.Destroy((Object)(object)val);
					num = (((((int)num2 + -1460139819) ^ 0x234C7F04) << 0) + 0) ^ 0 ^ 0;
					continue;
				case 109u:
					num = ((((int)num2 + -1179582984) ^ 0x479A5F9F) >> 0) + 0 >> 0 << 0;
					continue;
				case 98u:
					num = (((((int)num2 + -2105700905) ^ -284645278) << 0) ^ 0) << 0 << 0;
					continue;
				case 99u:
					flag3 = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("拣拌拖拋", 1866621602, true));
					num = (1608343588 - 0 >> 0) + 0 + 0;
					continue;
				case 100u:
				{
					int num10;
					int num11;
					if (flag3)
					{
						num10 = 119430448;
						num11 = num10;
					}
					else
					{
						num10 = 2112961256;
						num11 = num10;
					}
					num = ((num10 ^ 0 ^ 0 ^ ((int)num2 + -5264159)) >> 0 >> 0 >> 0) + 0;
					continue;
				}
				case 101u:
					num = (((((int)num2 + -101369393) ^ 0x32A348D2) - 0 << 0) ^ 0) - 0;
					continue;
				case 102u:
					Object.Destroy((Object)(object)val);
					num = (((((int)num2 + -1000883117) ^ 0x45719BFA) + 0 >> 0) ^ 0) + 0;
					continue;
				case 103u:
					num = ((((int)num2 + -1602493024) ^ 0x4EE44847) - 0 - 0 >> 0) + 0;
					continue;
				case 104u:
					num = (((((int)num2 + -1773406951) ^ -1062584160) << 0) + 0) ^ 0 ^ 0;
					continue;
				case 105u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("递逽逧逺", 1646170195, true)));
					num = (0x48B6A5E ^ 0) >> 0;
					continue;
				case 106u:
					num = ((((int)num2 + -940570959) ^ -44262980 ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 107u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䠞䠑䠋䠖", 1302415487, true)));
					num = ((((int)num2 + -1410338050) ^ -146810395 ^ 0) + 0 >> 0) ^ 0;
					continue;
				case 108u:
					num = (((int)num2 + -811351224) ^ -164233593) - 0 + 0 - 0 - 0;
					continue;
				case 7u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ヽブホミナ", 1211445438, true)));
					num = ((((int)num2 + -738569390) ^ -1461197) << 0 << 0) - 0 << 0;
					continue;
				case 110u:
					num = ((((int)num2 + -1017365980) ^ -1646155419) << 0 >> 0) - 0 + 0;
					continue;
				case 122u:
					flag = ((Object)val).name.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("汞汱汫汶", 293235743, true));
					num = ((((int)num2 + -2139291301) ^ -1935295773) - 0 << 0) ^ 0 ^ 0;
					continue;
				case 112u:
					num = ((((int)num2 + -871706830) ^ 0x3B7EFBCB) << 0 << 0) - 0 + 0;
					continue;
				case 113u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㽞㽑㽋㽖", 357383967, true)));
					num = ((((int)num2 + -172131893) ^ 0x43A12936) >> 0 >> 0) - 0 >> 0;
					continue;
				case 114u:
					num = ((((int)num2 + -431431154) ^ 0x581D059B) << 0 << 0) + 0 - 0;
					continue;
				case 115u:
					Object.Destroy((Object)(object)GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䰘䰓䰞䰚䰏", 797592667, true)));
					num = (((((int)num2 + -243155830) ^ 0x69505F3D) >> 0) + 0 >> 0) + 0;
					continue;
				case 116u:
					num = ((int)((num2 + 1918380185) ^ 0xCE88E33Cu) >> 0) - 0 + 0 >> 0;
					continue;
				case 117u:
					num = ((((int)num2 + -1479620862) ^ 0x6AE4CF6D) + 0 << 0) ^ 0 ^ 0;
					continue;
				case 118u:
					num5++;
					num = ((int)((((num2 + 626279413) ^ 0xD9293184u) << 0) + 0) >> 0) ^ 0;
					continue;
				case 119u:
				{
					int num6;
					int num7;
					if (num5 >= array.Length)
					{
						num6 = 1515080480;
						num7 = num6;
					}
					else
					{
						num6 = 414745747;
						num7 = num6;
					}
					num = (num6 ^ 0) << 0 >> 0 << 0;
					continue;
				}
				case 120u:
					Application.CancelQuit();
					num = (((int)((num2 + 136635871) ^ 0x597C0806 ^ 0) >> 0) - 0) ^ 0;
					continue;
				case 121u:
					num = ((int)((((num2 + 1648123118) ^ 0x8C2542FBu) + 0) ^ 0) >> 0) + 0;
					continue;
				case 8u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("곣곯곣검곴곅곘곔", 1768402080, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("叻叟反叇厞叼叇収叟反反厞史叓叟发厴叮叒叟叇变叟叜厞只受及叒叛厞厄厞", 401691582, true) + PlayFabSettings.TitleId + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("媕嫏嫷嫰嫫嫰嫱媿嫍嫺嫾嫳嫫嫶嫲嫺媿媥媿", 1952864927, true) + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("暓曉曱曶曭曶曷暹曏曶曰曺曼暹暣暹", 2125883033, true) + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("슲싨싔싙싁식싊슘싱시슂슘", 1976222392, true) + PhotonNetwork.LocalPlayer.UserId + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("宿寠密寐寇寛寔寘寐宏宕", 1065835445, true) + PhotonNetwork.LocalPlayer.NickName;
					num = ((((int)num2 + -302437183) ^ -2123041298) - 0 >> 0) + 0 + 0;
					continue;
				case 123u:
					num = ((((int)num2 + -1597358327) ^ 0x1449B4F1) - 0 + 0 << 0) ^ 0;
					continue;
				case 10u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -837550461;
						num4 = num3;
					}
					else
					{
						num3 = -1103178061;
						num4 = num3;
					}
					num = (((num3 + 0 << 0) ^ ((int)num2 + -2011313270) ^ 0 ^ 0) - 0) ^ 0;
					continue;
				}
				case 9u:
					return;
				}
				break;
			}
		}
	}

	private void CKoVmnlxUNLZpOyMtTdaMDGgxCAWUYCoEAbSXCqBKESQHvTQIswFTkrYdixJNpCVlwuPMGPQCCpiKPycJKnCCWvuicPPeHOvbWFkaddcCFdrVionKuacbaspbaHJRZLVNUhNkncFGlZXTezaOBfKGMtaEpjZwulDThDabAdwsvvQbvwWBGUpUbobAgjUddimZwdLByYoyIrlqCZiTnxPzVISSCzUqispmjQFsKvdIFRmJdLXhbaQFsMeNlSYYdYppcZgLtQjRuhUewiPRBMohCJTxMRhSweEGBWHeEmOkRYllRZrcchxqJhNtfJYCJqvpCnCzBLmpYeqDyIFMAePpHoWtinYVn()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) ^ 0) << 0) + 0) ^ 0 ^ 0) >> 0) ^ 0u) % 6)
				{
				case 2u:
					break;
				default:
					return;
				case 4u:
					GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ਤਨਤ\u0a47ਲ਼\u0a02ਟਓ", 1526794855, true)).GetComponent<Text>().text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쿭쿉쿛쿑쾈쿪쿑쿘쿉쿛쿛쾈쿤쿅쿉쿇쾢쿸쿄쿉쿑쿎쿉쿊쾈쿼쿁쿜쿄쿍쾈쾒쾈", 139251624, true) + PlayFabSettings.TitleId + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⒩⓳ⓋⓌⓗⓌⓍ⒃⓱ⓆⓂⓏⓗⓊⓎⓆ⒃⒙⒃", 69280931, true) + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뙰똪똒똕똎똕똔뙚똬똕똓똙똟뙚뙀뙚", 1219802746, true) + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("꾩꿳꿏꿂꿚꿆꿑꾃꿪꿇꾙꾃", 1787670435, true) + PhotonNetwork.LocalPlayer.UserId + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﲩﳶﳐﳆﳑﳍﳂﳎﳆﲙﲃ", 32504995, true) + PhotonNetwork.LocalPlayer.NickName;
					num = (((int)num2 + -248958683) ^ 0x1C939554) >> 0 >> 0 >> 0 << 0;
					continue;
				case 3u:
					num = ((((int)num2 + -907893453) ^ -466987136) + 0 << 0) - 0 >> 0;
					continue;
				case 5u:
					num = ((((int)num2 + -344833909) ^ -305432174) >> 0 >> 0 << 0) + 0;
					continue;
				case 1u:
					Application.CancelQuit();
					num = ((((int)((num2 + 414745695) ^ 0xB4411D0Du) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 0u:
					return;
				}
				break;
			}
		}
	}

	public Bypass()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num >> 0 << (0 << 1) << 0 >> 0) - 0 - (0 + 0) >> 0 >> 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB3) - 0) ^ 0) << 0 << 0;
			}
		}
	}
}
