using System;
using System.Collections.Generic;
using System.Linq;
using MenuTemplate;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

public class NotificationManager
{
	private static float aUjAXWptPyIRTdwTKXQhJEAfVzOtvGjpMPtJasTUkEdREPmJKQ = 0f;

	public static float fwPYJvudEyhVYiptedJMSreVWfAIBfmfIFANzNfYpWNvNpGUCkLiZYXOsTcEULCzlcmsIBTrYLxWDIiHzGgquegKIMvGLAdDtojLcnmartknAakJKufoFmehVCKVgnFxHUCpzxFltfZaTSkHCMVqvPXhjcPADrUdNMGGyUjnPUVAndndrctuspcSWvfwIeHclVmglDjHCHAAUxUfOLiBXzLyKOJdONFKmSorQgRNSLSKOBXzAZHWWgeLjOwxUgSOcQobiCpHTuIlHbKjQkCOfIOgODicKtTLSdHYnWqYKZdBxSeidmHJEeJtbinFumXzAXtEtMWTTEdgFmIVyZYyMkhOuoWeJLDycDbAzzOrqNQaaCOPzrgunzNqPEkfPRkhaFdclivZlHhYthORzhFrFikDPKKVpJBzDIZuzLDqVhjGrPXIQtFIlTCRuAmByAJCfHuLhtr;

	public static float NDpvxZElaNceWdToKfhaZzcSvxHAKulAxbReWxeSPolNvwNymtKFZtsoBwaareBGBBHUlPrmbpkLnowZJioqJGAeJDCzxeBLMFmUOTmxcxDKiHbmabqiPlWUaDlImSPW;

	public static bool NyYHcCkQWRomcQVbCqzwNsWBJrTkIDkjIHWKItjxQAmYXJRkIjgVstjvCxXLJZisGeEvTltigbFmgYDazJCywpQoxBhlvyOQsTrSfvqxQYPqOWpETXlaxJVrnpYsdhMHnOTmGLUesfIyzAAAmDrxnOtJXaFPxYtIlhdZdcXidhHraxRNPxgzQptzvkpGffGtLamrwAxjFjuggbIziRZaSURWNEESNrcXAoGakzqoZWTGUnstCPxnfGAQiqESWFwohwGRvIpIBLaWalcAllqXUOSU;

	public static GameObject OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA;

	public static GameObject pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj;

	public static GameObject iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs;

	public static Text cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe;

	public static bool kCBnoXSBoHzxQxPGmzsiWomsXHBvOkARxzJzVTbxxyJXFQJlwqNDRPiVqjpGwxNdhIarNqLtyUKxEoNhXqYyxWZHqNiLDubaLGQWQsxgFtfWeKrbviJfypGkIsaZhZPeTKMXyQrESRTdRcDGvgqvKVBwZFoysxZFEaduYtDEQenHwDsFOuDaIttXjqYSCTmuSnyQYiHcDLFFIUZwmIJYUYXkHglIvKcXSSOieBGFMBwWOOooqBGTjoAUqnjRXYGTJHNQgRsLcdlsBawTSWsUejNEsTSQrOINUDngayizjUQgchspRqZbGMPzUjxmYBtnvxxYMpSuNSKjsHBkBCZbPGhhOOmRaWAHBDKFJuDByEoNbFgmInKvBrxOqqjXdauQsdIOWVAhZyClstgiHZjMlf;

	public static bool fjgWptkFyxjxvYXrqMMDwdPmwXjbqdRIEmXyIaGgXtZfbUXhlpJwZIIbuTzsjjpvFBTiazJpgGGceJlBZcPatvIWEVdOAoXNeEzzbOgMGuqtbGXLIYshtockTXEevUPSJSYzjLzkVduZfpUXYsgBVPuPCpGekcrLFyKjIyBWyimqUdfEcHgcOnWTyiXTfuaTLItGELpzRjcNDdUzkbcDVpXrBQKzBHQditEmJyZrrHlFkjquoxJdswXwKbfNaPYjsZEkzHQM;

	public static Color cKlodshsApkdYMLLvhBHtlqCIbmlEfVGHXbIlJssUNnKEVlFnTPrfisRuJFcfWNuuEvaLdzLOjNFXFXMQGXLqDByEjnCdqmXZSqaAkUktdCWvNTPLTmyZcdQcWwBPXHyWPGfoWmFMMrmaEdRqyRkeNXXOzXDOsvwweZFhOAOGGMnKRPySElrgwuiSIqPYIRuqVQWExKBYcDxbKnXJzKjheqaKQNyxLQYPsWPaTTvUJtdSWhhusfzXHnmEQlOKldnmFIJNyWPGppxLmhOJFdfFqaheKkkHfKIFgRnnxuWvpSHsPBsIxefhYHVEBEdnLiBFGSFuTAllhJpytOpiSBkaFBGyWIMT;

	public static string qJKhrcMXWXPXSTaprxlMpUvjXAZflgykNsUxZigqcrmUMnhLArgzxaDvnAkQdHMPzEjAYCqjqVJYIAxKtnEUZYNNOzjyYqnvFwuieHMXaXiCqFMNdzxPcSQAQvMztRlaHoslfoFLAGTcQkxiMwvySxsMGUrJUnEjMhUbmBHOULowZNKFXDMWvMijWFFlXWRnbJqIqwVlOHEgjVNSjLLrAHNZZKeHVwRXUaupxbpBIBhOibaaSMbllAMuVqIFropsQHmiByuhvkJZAYQYKeOjuFMuoatgtKjtlPYBORzurTQaQNUXAKVnzgYkUSUBenOLapNLapjSEuRAOLDAgwGJOWTfQNGWXYpdeeZBZjWkAcIeoxwjotuHHfWevIUmInUGfNwKLcAXzwjMnOQtrxIDDHwZhVfroKBmhbZAbLx;

	public static string[] mTxhkWkQGSAUlFrdxrwCQWjIPUWEmPpsFZvKfAldXeyyNPpHQXCjEjHqJPspZFDRDiomjGYXftFLxKUaEpOpmfNwsfbqhWdrBHVFAdxjYFekDVSYUsKKRoExuSTeFIPjqnkQPpzBREqHbDSwncvPltzmcykIjsEqPUUqLbiFSjSnYWvRZxRCmZYXOXOreRryZZSgICKlTQXbAlnfctJMBbePWXBNnRAbStoZeoiwMFIvcWwCKIoLhEXXVckLaWXcqVjhXobNlmZVsIMZAZdECPTnwqebewvQHGfhNpEvHBzVFbEmplkbSszAcVKHkZJOQjnMCFlluIXbpYIuLRMTmuXphFeREXlISLevOSKJZZGkvykenqVtmPCwmYFXBtGwxpiDTmGTgcTmNMTIuaEncRvcjIjPnNiFsjNfpHkbKcmjVpIzeWCAPsu;

	public static int FTgukdQFtUoTDZNtNPCDaElgTaJKrkHQZPhljmZYTwTpHvezrCPLmPuaIZAktgoinxUOSBjAPEJDLVyxVkt;

	public static int OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB;

	public static int KPrEUqtwbumKjqyMAkBHYVCwxdJUiGNFcpMmBUdqWmiYpwsqllefWVDOmUgRHzovGGHTElkFglKMMDhaKtIWBHJhMXZHOmIxXNrIPyLZazZLkQcJMfgoQrUZXAhGlDRUCnOYlzlmHJVcIXXVUqUIguGFTsKpqfNxIfiWcdxnTUHhvRqZCmLVIiNhGjfTPWVBVyuDPaTQTHOmNzjbbKMetSOzrbpSYEyXYflWxNkCtVcbtBuhZdRekQidKUlOKaSpiRnIomEozjKyPMgPGiTUMtMhWhmDBwStcNSCnMSMzDEbgKnYOvhBgYCPefLgaaMcrrvcTDBUphujOLbmUnOfpqmekdxiaMLzQBKOokekUmlZDtatdzlMmGNaerSQgtUDvVsmbmXJjElcfnARdeeAAYmkOJKWsoeAsIDIaNrQCBDHuKVQRaNbotcw;

	public static string IiyrCarUzLKwKRQpNnYYvEQeOUfrBclYFgZSpZoBkIiIZyfZkxobvebdruDHVatwzMRERYaNZxOMwhepOfhdOkDBeWAUwGGjpLjnHAhlxAbXpoHkqnTPTpIpipzVxfrsQExKYQIoXVGniFlQpqEiNRqZdUeramNsjJgLQWmzEERXJugDeJFhAjEZnyHeLrnLhoezyAZtefDiZspINBnrGGRaegxsoiOnrgPvqHeDKmdvFvaVjYqkdVeBwdurdHeVqpQTDUsgwJGuCvuJgCjqRDkvboYmnMAdihepEhroFkNtpKYbJLlAyNeMfvRoVgTKjDlvreeZkUKHQQgrpXDCBZFudrkjqdszrdkLyDJEG;

	public static float mqDdwWpozZYCrikYRsZUUJhBlqNGuSMnZVpIbrGvVVQetWaUZNHkKJMCjcRgiJTGmLDvTBWAMDZYSchoqTGHlBCpiMzZzznmbjRItEbyQgygKOKgUDQpcmvLiongcXbmqNXJlzVLRiQfcwEucseWIYjOOgAeqUvSfmPXRaVvHexUwqIMJTdJTfEsDiVeZQvXMXZQGHDcxJoDBpsyyNvwQMZaHxuJfQwRJzhyqRfcqblkQaRoPwGlvYgaYZijnUWHmxUbhThGItgPAPjHFfTIjlwKtgArJVPwfEXtfQgVpZCbRrAjPADhaoxbajHbtQXMEKJWRPCPZYtjIuTcGrBirHvQgWsWieBycPxhHEraYOhcVnsGqEvcpPuWoTPUwGGUwUhSWLvbZBjDztVSEMFDJzjmvBTOPwDshnGagzKFjtcNGRwUXWqKackWLUxuRHmDYQvmNVMebaupxvGDfYQSfSrecJplbpNC;

	public static bool hyPPvkhcklJaIUypnTpTQuxfyrjdFAdMmSiYFRiUQOHTjrwhlZXhZTLMbKqeaewKiWNQMzKwLvdbNDWhUbRGCVNsgvXVBeULsXLmDGvLpBwEQJZxNjjZnPhnjuJqBOVGArJPSJDoFgrayiCxwAhsVVyCPydiWfjAGQdzajEdFUtgygOaSlUbHCLFSgZuGvrAWQuIfcwmWeMaCreJJcpLliTdeyGTjkwkCSkIMgVPOHeCQKdAcqLEfGoNWqDHvDcMHCxJhvWDhzWDdqntufRTySfVEwLvCotlFsVnmutGthwFKLJGcjmqLjnOxCeKKBaSgKYKvZhaMkzqvzlTMftsbdAwfgQKpIWShEzaMZkdcmDAJWtXqlXFhIRcjBEpjwKdoHjRakgNUqpOAZNjNStdKqKyMxQluVTGCzlc;

	private static Text MBXgfkLRscBkOvBrcGtYWLeDtVtYwJmaNKxlVnYAFSfKVGwYtCDVgnfbwtMkQMvJQBwdXpvOISsdFuINyuEUfqTzEwPCBOJSxwTujsbegOnnUcvbL;

	public static bool YLwiAEzHXyBATnTjAFjBoEgtANqcGFCaNRCcmKWSuMmTzDnBteuwmAwuFdHNnwbrWBNcLRWPIrgBrmUXAPIBkfNnuhxjdjEXLUXXPkQChENVtVdsiKnyNzhQNAIDtMMzMiQxpWhpZgtFrSTzeebtWgklNgjpCmivSoileFdmCXzHfBzVHiypLtCGYEKjMRMMXYNdJHuybOQYHCflGoItOTJzMCnAVTzLlMKhNwlZOaoWCEYvyyCyjsXdooqguTChpfMUSYykcJFOFNWiERbxrbCTOGSzffEUxhHxReCzarvzNjyBsiCDRfPnDTfmfYfXeKqyfyqzpCxZGcfEhrhWCbcsruUXYpubmxvc;

	private static HashSet<string> TawTScnpHQHANAeORjvcHYhLEtBZivMiGdLhVoezNNKANtjxkFkdctvUTKoyBohldyUKOXTCeVoUnGYkkdOClJfnHQokZFXzFzwozyJnLHYgeAHmMeoyzEausHcYIJDyXOpOkJLLuBRDKYihjcyUrzaazcVSvKEcdzjplTccsCdYNwJtyVOGlIhyOoohOTpJWOzlPSWqZvCPvbmdsBtAWXRvsLBWEUnzmubZWyEFZyHPgrcMclPmzPMZXeSerZLfhcCbangTXNBxqbobIOTsebZxHcbRGzoZMBHdObMPfVpLnpIVQRvCgsagdf;

	public static void tXlonxzCKOukmHceniLnjstgbPeLSuAAaIHODQIRmLETBFENAbfRuPVaEenytOJqoTkDanAxAUbyOAFwkqkRoIgkNGkyDjyxcnFHvaNnAIrAOxmezQncDScFNZQtccTqvDwAUXbjDXqGrFvpugZMVwTjlaUvjtkyObflbLjBPezGBvoiDBZWcguZJmpUdFajMSRqzkoIXxXRXnIPMMRIuovHGgBOwpxjdpUJDXIsnqZFjCcwDzirNrOywjJtIzmHZNOHsZmOdzveoQydeflWhg()
	{
		//IL_1a1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b58: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b80: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ce6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1112: Unknown result type (might be due to invalid IL or missing references)
		//IL_1117: Unknown result type (might be due to invalid IL or missing references)
		//IL_1136: Unknown result type (might be due to invalid IL or missing references)
		//IL_113b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1198: Unknown result type (might be due to invalid IL or missing references)
		//IL_122f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1234: Unknown result type (might be due to invalid IL or missing references)
		//IL_138e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1499: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e33: Unknown result type (might be due to invalid IL or missing references)
		//IL_152c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1536: Expected O, but got Unknown
		//IL_0fc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_1339: Unknown result type (might be due to invalid IL or missing references)
		//IL_133e: Unknown result type (might be due to invalid IL or missing references)
		//IL_10be: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ee: Unknown result type (might be due to invalid IL or missing references)
		int num17 = default(int);
		bool flag7 = default(bool);
		bool flag8 = default(bool);
		bool flag12 = default(bool);
		string text = default(string);
		string[] array = default(string[]);
		bool flag17 = default(bool);
		Quaternion rotation = default(Quaternion);
		Vector3 eulerAngles = default(Vector3);
		bool flag20 = default(bool);
		bool flag19 = default(bool);
		bool flag18 = default(bool);
		bool flag16 = default(bool);
		bool flag15 = default(bool);
		bool flag14 = default(bool);
		bool flag13 = default(bool);
		bool flag11 = default(bool);
		bool inRoom = default(bool);
		bool flag10 = default(bool);
		bool flag9 = default(bool);
		PhotonView componentInParent = default(PhotonView);
		Text current = default(Text);
		bool flag3 = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		bool flag6 = default(bool);
		VRRig componentInParent2 = default(VRRig);
		Text current2 = default(Text);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		while (true)
		{
			int num = 1758301816;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0) - (0 ^ 0) - 0 >> 0) - 0 - (0 >> 1) + 0 << 0)) % 115)
				{
				case 0u:
					break;
				case 36u:
					num = (int)(((((num2 + 704066420) ^ 0x95529458u) << 0) + 0) ^ 0) >> 0;
					continue;
				case 72u:
					num17++;
					num = (int)(((num2 + 1381095852) ^ 0x85A18E1Au) - 0 << 0) >> 0 << 0;
					continue;
				case 53u:
					num = (((int)(((num2 + 229224798) ^ 0x2F56FE1B) - 0) >> 0) ^ 0) - 0;
					continue;
				case 1u:
					flag7 = !fjgWptkFyxjxvYXrqMMDwdPmwXjbqdRIEmXyIaGgXtZfbUXhlpJwZIIbuTzsjjpvFBTiazJpgGGceJlBZcPatvIWEVdOAoXNeEzzbOgMGuqtbGXLIYshtockTXEevUPSJSYzjLzkVduZfpUXYsgBVPuPCpGekcrLFyKjIyBWyimqUdfEcHgcOnWTyiXTfuaTLItGELpzRjcNDdUzkbcDVpXrBQKzBHQditEmJyZrrHlFkjquoxJdswXwKbfNaPYjsZEkzHQM;
					num = (int)((((num2 + 808537251) ^ 0xAD39D4A2u) - 0 << 0) ^ 0 ^ 0);
					continue;
				case 92u:
					num = (((int)num2 + -1464033640) ^ -585458998 ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 24u:
					num = (((int)num2 + -1265694141) ^ 0x1FA63D1C) >> 0 >> 0 << 0 << 0;
					continue;
				case 29u:
					num = (((int)num2 + -1078135537) ^ 0x84D6801) >> 0 >> 0 >> 0 << 0;
					continue;
				case 33u:
					num = (((int)num2 + -1814199395) ^ 0x2C7C063E ^ 0) + 0 + 0 << 0;
					continue;
				case 2u:
					flag8 = flag7;
					num = (((int)((num2 + 2033488390) ^ 0xB5784325u) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 41u:
					((Graphic)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).rectTransform.sizeDelta = new Vector2(260f, 160f);
					num = (int)(((num2 + 1344926170) ^ 0x2BC99CE1) - 0 - 0 - 0) >> 0;
					continue;
				case 44u:
					((Transform)((Graphic)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).rectTransform).localPosition = new Vector3(-2.4f, -1.5f, 0f);
					num = (int)(((((num2 + 1829604441) ^ 0xA5DE8972u) + 0) ^ 0 ^ 0) << 0);
					continue;
				case 48u:
					fjgWptkFyxjxvYXrqMMDwdPmwXjbqdRIEmXyIaGgXtZfbUXhlpJwZIIbuTzsjjpvFBTiazJpgGGceJlBZcPatvIWEVdOAoXNeEzzbOgMGuqtbGXLIYshtockTXEevUPSJSYzjLzkVduZfpUXYsgBVPuPCpGekcrLFyKjIyBWyimqUdfEcHgcOnWTyiXTfuaTLItGELpzRjcNDdUzkbcDVpXrBQKzBHQditEmJyZrrHlFkjquoxJdswXwKbfNaPYjsZEkzHQM = true;
					num = ((int)(((num2 + 1657452078) ^ 0xC949BA95u) - 0) >> 0 << 0) + 0;
					continue;
				case 3u:
				{
					int num24;
					int num25;
					if (flag8)
					{
						num24 = -924797297;
						num25 = num24;
					}
					else
					{
						num24 = -1037907109;
						num25 = num24;
					}
					num = (((((num24 ^ 0) >> 0) ^ ((int)num2 + -1118155190)) + 0 + 0) ^ 0) >> 0;
					continue;
				}
				case 56u:
				{
					int num20;
					int num21;
					if (flag12)
					{
						num20 = 503257097;
						num21 = num20;
					}
					else
					{
						num20 = 1756181838;
						num21 = num20;
					}
					num = (int)(((uint)((num20 << 0) + 0) ^ (num2 + 1230829704)) + 0 + 0 + 0 + 0);
					continue;
				}
				case 60u:
					mTxhkWkQGSAUlFrdxrwCQWjIPUWEmPpsFZvKfAldXeyyNPpHQXCjEjHqJPspZFDRDiomjGYXftFLxKUaEpOpmfNwsfbqhWdrBHVFAdxjYFekDVSYUsKKRoExuSTeFIPjqnkQPpzBREqHbDSwncvPltzmcykIjsEqPUUqLbiFSjSnYWvRZxRCmZYXOXOreRryZZSgICKlTQXbAlnfctJMBbePWXBNnRAbStoZeoiwMFIvcWwCKIoLhEXXVckLaWXcqVjhXobNlmZVsIMZAZdECPTnwqebewvQHGfhNpEvHBzVFbEmplkbSszAcVKHkZJOQjnMCFlluIXbpYIuLRMTmuXphFeREXlISLevOSKJZZGkvykenqVtmPCwmYFXBtGwxpiDTmGTgcTmNMTIuaEncRvcjIjPnNiFsjNfpHkbKcmjVpIzeWCAPsu = cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.text.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();
					num = (int)((((num2 + 564064546) ^ 0x3B3AD6C0) + 0 - 0 + 0) ^ 0);
					continue;
				case 65u:
					text = array[num17];
					num = (0x5691EBBB ^ 0) - 0;
					continue;
				case 68u:
				{
					int num30;
					int num31;
					if (flag17)
					{
						num30 = -1324410879;
						num31 = num30;
					}
					else
					{
						num30 = -935125951;
						num31 = num30;
					}
					num = ((int)((uint)((num30 ^ 0) << 0) ^ (num2 + 1231052557)) >> 0) - 0 >> 0 << 0;
					continue;
				}
				case 4u:
					num = (((((int)num2 + -946770217) ^ -1045148910) - 0 << 0) ^ 0) << 0;
					continue;
				case 76u:
					num = ((((int)num2 + -471734760) ^ -282738986) << 0) - 0 << 0 >> 0;
					continue;
				case 80u:
					num = ((((int)num2 + -1392310534) ^ -902649613 ^ 0) << 0) - 0 + 0;
					continue;
				case 84u:
					pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj.transform.position = new Vector3(iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.x, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.y, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.z);
					num = ((((((int)num2 + -1135381108) ^ -1126578432) >> 0) + 0) ^ 0) - 0;
					continue;
				case 88u:
					num = ((((int)num2 + -218221984) ^ 0x187B95C2) - 0 << 0 << 0) + 0;
					continue;
				case 5u:
					iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs = SqzbqVAqOpxeYUVzQrCoAprAPrRAapTzkhTxfdtGUWHkGbZhKnZbhLwDYYlZeZqyvXTQbyuNYWtEHhUOrJPMpSrzKpzgRuBUFiOIhigmTmckrSWRewHukDjDFtgMZnVEuzYzslGjDCScPgiRtHcvMhJbZlcNcunGryQRUwzSQyQIKgNylosrkARnPWAgiSgjpmLrqrXWijEorbqTyDCObWvRGCbXWsKXrGsyuviTqwiaVCVOFHHEqsisRUKOpaaQzHXKISydvIxFNuVeGnrpLfHZyaHAKtEqwsBnElfNiEiHUDEwYGhbIKetaYmIlXsbehjvTIzviEghXZeVvkCdmDILninGYwBllgDNtjDqhLTdEXwaUrnavoPAzxhLuSxLdVVQwrBlHlWBKFhqLnMG(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㧙㧵㧽㧺㦴㧗㧵㧹㧱㧦㧵", 15874452, true));
					num = ((((int)num2 + -2113229183) ^ -2143360906 ^ 0) << 0) - 0 << 0;
					continue;
				case 96u:
					num = ((((int)num2 + -2118350167) ^ -5367155) - 0 << 0 << 0) - 0;
					continue;
				case 23u:
					num = (int)((((num2 + 557269837) ^ 0x44B1956D) << 0 << 0) ^ 0) >> 0;
					continue;
				case 104u:
					((Transform)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<RectTransform>()).localPosition = new Vector3(0f, 0f, 1.6f);
					num = ((((int)num2 + -1873812145) ^ -561844785) - 0 >> 0) ^ 0 ^ 0;
					continue;
				case 107u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA = jAPWrcoWbSVonhZIbFDDQbtjsnQUqRZhgQCCgZzucFkPqInCFyogJjQhhFEeluFjTOixExCcgjAlQETJZnoSCSyWauvAuujIZaWBAQYiWmaAJEqDLUeXfNGaqlxjbbHLZRlPIsjipgVqSXnveSPzqlDmuVlptOgUFoARtAUtLWHYRqhsXbfjmhvOnZvMgUPBabLExwbDXvOtEFudOSrrIWIxTM();
					num = (((int)num2 + -2072603691) ^ -907484194) + 0 - 0 >> 0 >> 0;
					continue;
				case 25u:
					rotation = ((Transform)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<RectTransform>()).rotation;
					num = (((((int)num2 + -227079681) ^ 0x66AC3831) >> 0 << 0) ^ 0) >> 0;
					continue;
				case 26u:
					eulerAngles = ((Quaternion)(ref rotation)).eulerAngles;
					num = ((((int)num2 + -946157137) ^ 0x22B7C23C) + 0 << 0 << 0) - 0;
					continue;
				case 27u:
					eulerAngles.y = -270f;
					num = ((((int)((num2 + 1641116637) ^ 0xF4C8856Au) >> 0) - 0) ^ 0) - 0;
					continue;
				case 28u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.transform.localScale = new Vector3(1f, 1f, 1f);
					num = (int)((((((num2 + 359358379) ^ 0x1D5D9764) << 0) ^ 0) + 0) ^ 0);
					continue;
				case 6u:
					pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj = jAPWrcoWbSVonhZIbFDDQbtjsnQUqRZhgQCCgZzucFkPqInCFyogJjQhhFEeluFjTOixExCcgjAlQETJZnoSCSyWauvAuujIZaWBAQYiWmaAJEqDLUeXfNGaqlxjbbHLZRlPIsjipgVqSXnveSPzqlDmuVlptOgUFoARtAUtLWHYRqhsXbfjmhvOnZvMgUPBabLExwbDXvOtEFudOSrrIWIxTM();
					num = (int)((((num2 + 1525327414) ^ 0xE65004FEu) + 0 << 0) + 0 - 0);
					continue;
				case 110u:
					((Transform)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<RectTransform>()).rotation = Quaternion.Euler(eulerAngles);
					num = ((((int)((num2 + 614257393) ^ 0x4F2A3438) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 30u:
					num = (int)(((num2 + 1667326257) ^ 0xCE787DF9u ^ 0) - 0 + 0 + 0);
					continue;
				case 31u:
				{
					GameObject val = new GameObject();
					val.transform.parent = OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.transform;
					cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe = val.AddComponent<Text>();
					num = ((((int)num2 + -6506061) ^ 0x31EADD0) << 0) + 0 + 0 >> 0;
					continue;
				}
				case 32u:
					cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.fontSize = 11;
					num = (((int)((num2 + 2123703122) ^ 0xB8EA3C41u) >> 0) + 0 << 0) ^ 0;
					continue;
				case 7u:
					DueimQhfXQFDVBZClQtbkIErYnCxTdsnKLSHyPiXmyHEykXQrfLRdRBVPNjZnKmUxrSkJsdwHvOMaZTNqMfNsAkSjWRLFjJClNghrNhZbojHdPUPTvIBEyBWhZaMAsQyMmAnTMwCFfLeqCPtbbRjAiXNljarNuzJxLVQpHWhZgVzMxFEkGLyAHXEoMbJLePlFcGFGYetfKjumyaODvhgIbiQOrCDGnvVqKTKQaYlCrsQx((Object)(object)pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ㆰㆿㆺㆶㆽㆧㆬㆻㆦㆱㆬㆽㆼㆧㆺㆵㆺㆰㆲㆧㆺㆼㆽㆠㆬㆾㆲㆫ", 1960194547, true));
					num = ((((int)num2 + -992982523) ^ 0x4848F4C9 ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 34u:
					cKlodshsApkdYMLLvhBHtlqCIbmlEfVGHXbIlJssUNnKEVlFnTPrfisRuJFcfWNuuEvaLdzLOjNFXFXMQGXLqDByEjnCdqmXZSqaAkUktdCWvNTPLTmyZcdQcWwBPXHyWPGfoWmFMMrmaEdRqyRkeNXXOzXDOsvwweZFhOAOGGMnKRPySElrgwuiSIqPYIRuqVQWExKBYcDxbKnXJzKjheqaKQNyxLQYPsWPaTTvUJtdSWhhusfzXHnmEQlOKldnmFIJNyWPGppxLmhOJFdfFqaheKkkHfKIFgRnnxuWvpSHsPBsIxefhYHVEBEdnLiBFGSFuTAllhJpytOpiSBkaFBGyWIMT.a = 0.95f;
					num = (((int)((num2 + 913818940) ^ 0x215B79DA) >> 0) ^ 0) << 0 >> 0;
					continue;
				case 35u:
					((Component)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).gameObject.AddComponent<Shadow>();
					num = (((((int)num2 + -327589424) ^ 0x28A6C3FF ^ 0) >> 0) + 0) ^ 0;
					continue;
				case 100u:
					((Component)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).gameObject.GetComponent<Shadow>().effectDistance = Vector2.op_Implicit(new Vector3(0f, -1.5f));
					num = ((((int)((num2 + 853643342) ^ 0x65F9F506) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 8u:
					num = ((((int)num2 + -166613855) ^ 0x4C22F85A) << 0 << 0) ^ 0 ^ 0;
					continue;
				case 37u:
					((Component)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).gameObject.GetComponent<Shadow>().effectColor = cKlodshsApkdYMLLvhBHtlqCIbmlEfVGHXbIlJssUNnKEVlFnTPrfisRuJFcfWNuuEvaLdzLOjNFXFXMQGXLqDByEjnCdqmXZSqaAkUktdCWvNTPLTmyZcdQcWwBPXHyWPGfoWmFMMrmaEdRqyRkeNXXOzXDOsvwweZFhOAOGGMnKRPySElrgwuiSIqPYIRuqVQWExKBYcDxbKnXJzKjheqaKQNyxLQYPsWPaTTvUJtdSWhhusfzXHnmEQlOKldnmFIJNyWPGppxLmhOJFdfFqaheKkkHfKIFgRnnxuWvpSHsPBsIxefhYHVEBEdnLiBFGSFuTAllhJpytOpiSBkaFBGyWIMT;
					num = ((int)(((num2 + 1915627095) ^ 0xC6DA4D6Bu) << 0 << 0) >> 0) ^ 0;
					continue;
				case 38u:
					num = ((int)(((num2 + 371245493) ^ 0x3BAE546A) + 0) >> 0) - 0 << 0;
					continue;
				case 39u:
					cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.font = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ፘፔፘጻፏ\u137e፣፯", 1775178523, true)).GetComponent<Text>().font;
					num = (int)(((((num2 + 354192137) ^ 0x2018BF86) << 0 << 0) ^ 0) - 0);
					continue;
				case 40u:
					num = (int)((((num2 + 430248077) ^ 0x7FC2C551 ^ 0) << 0) - 0) >> 0;
					continue;
				case 9u:
					DueimQhfXQFDVBZClQtbkIErYnCxTdsnKLSHyPiXmyHEykXQrfLRdRBVPNjZnKmUxrSkJsdwHvOMaZTNqMfNsAkSjWRLFjJClNghrNhZbojHdPUPTvIBEyBWhZaMAsQyMmAnTMwCFfLeqCPtbbRjAiXNljarNuzJxLVQpHWhZgVzMxFEkGLyAHXEoMbJLePlFcGFGYetfKjumyaODvhgIbiQOrCDGnvVqKTKQaYlCrsQx((Object)(object)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㸡㸮㸫㸧㸬㸶㸽㸪㸷㸠㸽㸬㸭㸶㸫㸤㸫㸡㸣㸶㸫㸭㸬㸱㸽㸯㸣㸺", 355286626, true));
					num = (int)(((((num2 + 1824108797) ^ 0x8DCCAF44u) << 0) - 0 - 0) ^ 0);
					continue;
				case 102u:
					num = (int)((((num2 + 615895732) ^ 0xD3764115u ^ 0) - 0 << 0) - 0);
					continue;
				case 42u:
					((Transform)((Graphic)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).rectTransform).localScale = new Vector3(0.01f, 0.01f, 1f);
					num = (int)(((((num2 + 1311466562) ^ 0x9CC62A7Fu) << 0 << 0) - 0) ^ 0);
					continue;
				case 43u:
					num = (((((int)num2 + -506151520) ^ -1327603071) >> 0) ^ 0) << 0 >> 0;
					continue;
				case 10u:
					num = ((((int)num2 + -847217407) ^ 0x76DC8B1B) + 0 >> 0) + 0 << 0;
					continue;
				case 45u:
					num = ((((int)num2 + -754750373) ^ 0x6ECA742D ^ 0) - 0 << 0) + 0;
					continue;
				case 46u:
					((Graphic)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).material = new Material(Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᝐᝂ\u175e\u1738ᝃ\u1772ᝯᝣ\u1737ᝄ\u177f\u1776\u1773\u1772ᝥ", 476780311, true)));
					num = (int)(((num2 + 2143850309) ^ 0xCC1BB7C0u ^ 0) - 0) >> 0 >> 0;
					continue;
				case 47u:
					num = (int)((((num2 + 2086541461) ^ 0xC5CE2559u) - 0 << 0 << 0) ^ 0);
					continue;
				case 101u:
					MBXgfkLRscBkOvBrcGtYWLeDtVtYwJmaNKxlVnYAFSfKVGwYtCDVgnfbwtMkQMvJQBwdXpvOISsdFuINyuEUfqTzEwPCBOJSxwTujsbegOnnUcvbL = cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe;
					num = (((((int)num2 + -371167956) ^ 0x627C6E8C) >> 0) ^ 0) << 0 << 0;
					continue;
				case 11u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.AddComponent<Canvas>();
					num = ((((((int)num2 + -2011313270) ^ -799327391) + 0) ^ 0) >> 0) ^ 0;
					continue;
				case 49u:
					num = (int)((((num2 + 233036639) ^ 0x99FEA8B3u) - 0 - 0) ^ 0 ^ 0);
					continue;
				case 50u:
					flag20 = cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.text != ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 735178797, true);
					num = (0x22CE5650 ^ 0) + 0;
					continue;
				case 51u:
					flag19 = flag20;
					num = (int)((((num2 + 1268168873) ^ 0x32914F46) << 0) + 0) >> 0 << 0;
					continue;
				case 52u:
				{
					int num28;
					int num29;
					if (flag19)
					{
						num28 = 1573335684;
						num29 = num28;
					}
					else
					{
						num28 = 1776916400;
						num29 = num28;
					}
					num = ((((num28 >> 0) - 0) ^ ((int)num2 + -231305650)) >> 0) + 0 >> 0 << 0;
					continue;
				}
				case 108u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.AddComponent<CanvasScaler>();
					num = ((((int)num2 + -1562374052) ^ -944808253) >> 0 >> 0) + 0 << 0;
					continue;
				case 99u:
					OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB++;
					num = ((((int)num2 + -2105174978) ^ -535441305) + 0 + 0 >> 0) + 0;
					continue;
				case 54u:
					flag18 = OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB > FTgukdQFtUoTDZNtNPCDaElgTaJKrkHQZPhljmZYTwTpHvezrCPLmPuaIZAktgoinxUOSBjAPEJDLVyxVkt;
					num = (((int)((num2 + 1511253511) ^ 0x93F18E4Cu) >> 0) - 0) ^ 0 ^ 0;
					continue;
				case 55u:
					flag12 = flag18;
					num = (((int)((num2 + 1971570784) ^ 0xC21CC858u) >> 0) + 0 >> 0) - 0;
					continue;
				case 12u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.AddComponent<GraphicRaycaster>();
					num = (int)(((num2 + 1344932091) ^ 0x1B558BD) - 0 + 0 + 0) >> 0;
					continue;
				case 57u:
					num = (((((int)num2 + -939024926) ^ 0x26A5413C) >> 0 << 0) + 0) ^ 0;
					continue;
				case 58u:
					mTxhkWkQGSAUlFrdxrwCQWjIPUWEmPpsFZvKfAldXeyyNPpHQXCjEjHqJPspZFDRDiomjGYXftFLxKUaEpOpmfNwsfbqhWdrBHVFAdxjYFekDVSYUsKKRoExuSTeFIPjqnkQPpzBREqHbDSwncvPltzmcykIjsEqPUUqLbiFSjSnYWvRZxRCmZYXOXOreRryZZSgICKlTQXbAlnfctJMBbePWXBNnRAbStoZeoiwMFIvcWwCKIoLhEXXVckLaWXcqVjhXobNlmZVsIMZAZdECPTnwqebewvQHGfhNpEvHBzVFbEmplkbSszAcVKHkZJOQjnMCFlluIXbpYIuLRMTmuXphFeREXlISLevOSKJZZGkvykenqVtmPCwmYFXBtGwxpiDTmGTgcTmNMTIuaEncRvcjIjPnNiFsjNfpHkbKcmjVpIzeWCAPsu = null;
					num = (int)((((((num2 + 1891049432) ^ 0xBCE7FC8Au) + 0) ^ 0) - 0) ^ 0);
					continue;
				case 59u:
					IiyrCarUzLKwKRQpNnYYvEQeOUfrBclYFgZSpZoBkIiIZyfZkxobvebdruDHVatwzMRERYaNZxOMwhepOfhdOkDBeWAUwGGjpLjnHAhlxAbXpoHkqnTPTpIpipzVxfrsQExKYQIoXVGniFlQpqEiNRqZdUeramNsjJgLQWmzEERXJugDeJFhAjEZnyHeLrnLhoezyAZtefDiZspINBnrGGRaegxsoiOnrgPvqHeDKmdvFvaVjYqkdVeBwdurdHeVqpQTDUsgwJGuCvuJgCjqRDkvboYmnMAdihepEhroFkNtpKYbJLlAyNeMfvRoVgTKjDlvreeZkUKHQQgrpXDCBZFudrkjqdszrdkLyDJEG = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 492364372, true);
					num = ((int)(((num2 + 968726257) ^ 0xE2A48056u) + 0 + 0) >> 0) ^ 0;
					continue;
				case 109u:
					OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB = 0;
					num = ((((int)num2 + -1111106642) ^ 0x5940A98 ^ 0) >> 0 << 0) + 0;
					continue;
				case 13u:
					CrPMnfqWJCETQQowBNSooeBEpXDwWDrIrsmaNQtheYGipQakJObDACixQkwpCTafkWCxEoJKuKjqxtpzWsNhCNhPkOjCudFlXBXtoCGufriQsSawUXsjgSDxOMnPegqreYsWvWkuMsblErxrNMHxKwefYAEBpQqZaRLtzdbXMYwNRrSxpVbsyTGITnYVsJeVcckNFdSKLJKLZqnGHhmtOXAhkcAmffFcUALOhfRldrGPiVJCZsokwKheCcCDDFEGeIRyFzyCqbqwrLZpsXnNQvGjtHmfCoHyNZKAdlXATLUvuKMQcmkGsQPIbIeXmtZbtSJsazmhZN((Behaviour)(object)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<Canvas>(), bool_0: true);
					num = (int)(((num2 + 2133633953) ^ 0xDAA7D0F0u ^ 0) + 0 - 0) >> 0;
					continue;
				case 61u:
					num = (((((int)num2 + -2119595598) ^ -218554610 ^ 0) << 0) - 0) ^ 0;
					continue;
				case 62u:
					array = mTxhkWkQGSAUlFrdxrwCQWjIPUWEmPpsFZvKfAldXeyyNPpHQXCjEjHqJPspZFDRDiomjGYXftFLxKUaEpOpmfNwsfbqhWdrBHVFAdxjYFekDVSYUsKKRoExuSTeFIPjqnkQPpzBREqHbDSwncvPltzmcykIjsEqPUUqLbiFSjSnYWvRZxRCmZYXOXOreRryZZSgICKlTQXbAlnfctJMBbePWXBNnRAbStoZeoiwMFIvcWwCKIoLhEXXVckLaWXcqVjhXobNlmZVsIMZAZdECPTnwqebewvQHGfhNpEvHBzVFbEmplkbSszAcVKHkZJOQjnMCFlluIXbpYIuLRMTmuXphFeREXlISLevOSKJZZGkvykenqVtmPCwmYFXBtGwxpiDTmGTgcTmNMTIuaEncRvcjIjPnNiFsjNfpHkbKcmjVpIzeWCAPsu;
					num = ((((int)num2 + -222958998) ^ 0xD8B62B4 ^ 0) << 0 >> 0) - 0;
					continue;
				case 63u:
					num17 = 0;
					num = ((int)((num2 + 1676047018) ^ 0xCD70EC13u ^ 0) >> 0) + 0 << 0;
					continue;
				case 64u:
					num = ((((int)num2 + -115972637) ^ 0x4F38C498) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 14u:
					num = ((((int)num2 + -590282087) ^ -1185603067 ^ 0) >> 0) - 0 >> 0;
					continue;
				case 103u:
					num = ((((int)num2 + -893335959) ^ 0x3958A99A) - 0 << 0) + 0 + 0;
					continue;
				case 66u:
					flag16 = text != ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 1558372625, true);
					num = (((((int)num2 + -787338951) ^ -171413662) << 0) ^ 0) - 0 - 0;
					continue;
				case 67u:
					flag17 = flag16;
					num = (((int)num2 + -1815073520) ^ -655100205) + 0 + 0 + 0 - 0;
					continue;
				case 15u:
					HXOGzDOgSPCctaKmlqqzToYhOrAIxwnLRSJQIPVJXQnimtchLKHJcLxsZGRhdgJvCQlAqTEwvGCcaPVvptXNODIgvqRcYNGQhRGwiCQRgloviusjLvSKjVGYhefZcCyHaLViiynNCfHDpmYaYHqCVVHllIodwRPENGvwzjbmifidodIVgfbu(OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<Canvas>(), iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.GetComponent<Camera>());
					num = (((((int)num2 + -1963962512) ^ -1230294253) - 0 << 0) ^ 0) + 0;
					continue;
				case 69u:
					num = (int)(((num2 + 1715405772) ^ 0x2CA4B525) << 0) >> 0 << 0 >> 0;
					continue;
				case 70u:
					IiyrCarUzLKwKRQpNnYYvEQeOUfrBclYFgZSpZoBkIiIZyfZkxobvebdruDHVatwzMRERYaNZxOMwhepOfhdOkDBeWAUwGGjpLjnHAhlxAbXpoHkqnTPTpIpipzVxfrsQExKYQIoXVGniFlQpqEiNRqZdUeramNsjJgLQWmzEERXJugDeJFhAjEZnyHeLrnLhoezyAZtefDiZspINBnrGGRaegxsoiOnrgPvqHeDKmdvFvaVjYqkdVeBwdurdHeVqpQTDUsgwJGuCvuJgCjqRDkvboYmnMAdihepEhroFkNtpKYbJLlAyNeMfvRoVgTKjDlvreeZkUKHQQgrpXDCBZFudrkjqdszrdkLyDJEG = IiyrCarUzLKwKRQpNnYYvEQeOUfrBclYFgZSpZoBkIiIZyfZkxobvebdruDHVatwzMRERYaNZxOMwhepOfhdOkDBeWAUwGGjpLjnHAhlxAbXpoHkqnTPTpIpipzVxfrsQExKYQIoXVGniFlQpqEiNRqZdUeramNsjJgLQWmzEERXJugDeJFhAjEZnyHeLrnLhoezyAZtefDiZspINBnrGGRaegxsoiOnrgPvqHeDKmdvFvaVjYqkdVeBwdurdHeVqpQTDUsgwJGuCvuJgCjqRDkvboYmnMAdihepEhroFkNtpKYbJLlAyNeMfvRoVgTKjDlvreeZkUKHQQgrpXDCBZFudrkjqdszrdkLyDJEG + text + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("怐", 2064277530, true);
					num = (((int)((num2 + 1614334669) ^ 0xA4F39C9Au) >> 0) + 0 >> 0) + 0;
					continue;
				case 71u:
					num = (int)(((num2 + 331459248) ^ 0x5BC18790 ^ 0 ^ 0) + 0 << 0);
					continue;
				case 113u:
					num = (1427638132 - 0 >> 0) + 0 - 0;
					continue;
				case 16u:
					num = (int)((((num2 + 427816739) ^ 0x1C37565F) + 0 << 0) - 0 - 0);
					continue;
				case 73u:
				{
					int num26;
					int num27;
					if (num17 >= array.Length)
					{
						num26 = 390535819;
						num27 = num26;
					}
					else
					{
						num26 = 757804180;
						num27 = num26;
					}
					num = ((num26 - 0) ^ 0) + 0 << 0;
					continue;
				}
				case 74u:
					cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.text = IiyrCarUzLKwKRQpNnYYvEQeOUfrBclYFgZSpZoBkIiIZyfZkxobvebdruDHVatwzMRERYaNZxOMwhepOfhdOkDBeWAUwGGjpLjnHAhlxAbXpoHkqnTPTpIpipzVxfrsQExKYQIoXVGniFlQpqEiNRqZdUeramNsjJgLQWmzEERXJugDeJFhAjEZnyHeLrnLhoezyAZtefDiZspINBnrGGRaegxsoiOnrgPvqHeDKmdvFvaVjYqkdVeBwdurdHeVqpQTDUsgwJGuCvuJgCjqRDkvboYmnMAdihepEhroFkNtpKYbJLlAyNeMfvRoVgTKjDlvreeZkUKHQQgrpXDCBZFudrkjqdszrdkLyDJEG;
					num = ((int)((((num2 + 318542327) ^ 0xE258AB3) << 0) ^ 0) >> 0) - 0;
					continue;
				case 75u:
					num = (int)((((num2 + 669023832) ^ 0x484F1A21 ^ 0) << 0 << 0) ^ 0);
					continue;
				case 17u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
					num = (int)(((num2 + 1557715738) ^ 0xE462A9A5u) - 0 - 0 + 0 + 0);
					continue;
				case 77u:
					num = 0x13AA78BB ^ 0;
					continue;
				case 106u:
					num = ((((int)num2 + -1181284747) ^ -1115028201) + 0 << 0 >> 0) + 0;
					continue;
				case 78u:
					num = ((0x6EA7B353 ^ 0) << 0 << 0) + 0;
					continue;
				case 79u:
					OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB = 0;
					num = (((int)((num2 + 148199600) ^ 0x7A8BC7D9) >> 0) - 0) ^ 0 ^ 0;
					continue;
				case 111u:
					num = (((int)num2 + -1090264534) ^ -1310779223) << 0 << 0 << 0 >> 0;
					continue;
				case 81u:
					flag15 = (Object)(object)pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj != (Object)null;
					num = (0x5EF242CD ^ 0) << 0;
					continue;
				case 82u:
					flag14 = flag15;
					num = (((int)num2 + -1915257242) ^ -932186702) + 0 + 0 << 0 << 0;
					continue;
				case 83u:
				{
					int num22;
					int num23;
					if (!flag14)
					{
						num22 = -1660044307;
						num23 = num22;
					}
					else
					{
						num22 = -1766013828;
						num23 = num22;
					}
					num = ((((num22 << 0) - 0) ^ ((int)num2 + -1394539209)) >> 0) - 0 + 0 + 0;
					continue;
				}
				case 114u:
					num = ((int)((((num2 + 969923448) ^ 0xA7BAFA76u) << 0) + 0) >> 0) ^ 0;
					continue;
				case 18u:
					((Transform)OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.GetComponent<RectTransform>()).position = new Vector3(iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.x, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.y, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.z);
					num = (int)((num2 + 2100385416) ^ 0xC8F6A1FAu) >> 0 << 0 >> 0 >> 0;
					continue;
				case 85u:
					num = (((((int)num2 + -442477561) ^ 0x1DEEE3D6) << 0) ^ 0) - 0 >> 0;
					continue;
				case 86u:
					pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj.transform.rotation = iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.rotation;
					num = (((((int)num2 + -182847601) ^ 0x2D8685E8) << 0) ^ 0) + 0 << 0;
					continue;
				case 87u:
					num = ((int)(((num2 + 112298003) ^ 0x72FAFB2) << 0) >> 0) - 0 >> 0;
					continue;
				case 19u:
					num = (int)((num2 + 1657774638) ^ 0x2BD59A96 ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 89u:
					flag13 = !fjgWptkFyxjxvYXrqMMDwdPmwXjbqdRIEmXyIaGgXtZfbUXhlpJwZIIbuTzsjjpvFBTiazJpgGGceJlBZcPatvIWEVdOAoXNeEzzbOgMGuqtbGXLIYshtockTXEevUPSJSYzjLzkVduZfpUXYsgBVPuPCpGekcrLFyKjIyBWyimqUdfEcHgcOnWTyiXTfuaTLItGELpzRjcNDdUzkbcDVpXrBQKzBHQditEmJyZrrHlFkjquoxJdswXwKbfNaPYjsZEkzHQM;
					num = (0x227C37FC ^ 0) - 0;
					continue;
				case 105u:
					flag11 = flag13;
					num = (((((int)num2 + -1018653070) ^ -514874304) + 0 - 0) ^ 0) >> 0;
					continue;
				case 90u:
				{
					int num18;
					int num19;
					if (flag11)
					{
						num18 = -805743362;
						num19 = num18;
					}
					else
					{
						num18 = -249526367;
						num19 = num18;
					}
					num = (((num18 << 0) ^ 0 ^ ((int)num2 + -95202744)) + 0 << 0 >> 0) ^ 0;
					continue;
				}
				case 91u:
					num = ((int)((num2 + 1547314249) ^ 0xA74A0E54u) >> 0 << 0) - 0 << 0;
					continue;
				case 20u:
					pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj.transform.position = new Vector3(iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.x, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.y, iWAnsnXOjcZeuPhlfVCYisllgZEsrLYenSwUDyQvefZWSUZhkNqbIrbPLpgsIFwyeVQBtnHGegTcsosmZxiEuWwVRGiorxMzIBSXdxOWgKWBxYxwXUtlwSdhzUKMetpGtuuQvvjCJlyKaUySjMqxeBcQyLxiNbSMuphcEGaCKQCktsgEwRCs.transform.position.z - 4.6f);
					num = (((int)num2 + -113808718) ^ 0x2D2C2038) - 0 << 0 >> 0 << 0;
					continue;
				case 93u:
					inRoom = PhotonNetwork.InRoom;
					num = (470891054 >> 0 << 0 << 0) + 0;
					continue;
				case 94u:
					flag10 = inRoom;
					num = ((int)((num2 + 181350923) ^ 0x646CB1E9) >> 0 >> 0) + 0 >> 0;
					continue;
				case 95u:
					flag9 = flag10;
					num = ((((int)num2 + -1116091615) ^ 0x525FE476 ^ 0) + 0 >> 0) + 0;
					continue;
				case 112u:
					if (flag9)
					{
						num = (((int)(((num2 + 1222774323) ^ 0xBE218579u) << 0) >> 0) ^ 0) << 0;
						continue;
					}
					return;
				case 21u:
					num = ((int)((num2 + 485455216) ^ 0xA3C9DA6Bu) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 97u:
					num = (((int)((num2 + 1479055819) ^ 0xD67D5D84u) >> 0 >> 0) ^ 0) >> 0;
					continue;
				case 22u:
					OPRUVxsuAFzxHBYTAOMuFEQXodHLpytsELdFRvNdtFvvLETKmwxfcyojZTFSQGfblgTVxscebIbaivlJkXySaoqfxTGXPVnMAujELXmUttetxobEIWHThmbXQNxDLfpfvozOlGXmKDyHkWIjScoSntEnsmOYAJiodYYiOmsbYviEOuNTfoKJQwSbJmvZSZMbukElYzuFJnUSlazYzUTlYzxGfWzCRtjYIhjDQBVFTfZDCZQJMxAXgAcVMXgcaSOqdVjdRViYZnrTAUdggPPtSlShfnQSuTFbqIzHQMRRpCYTjjvSUaVkdvySdcYDfpDgHqCRuwptYYeqmZYVSYYuXvXVkHDOOoLZYSlSGDxxKClfqhFedcKgrijmtHHNSBEJmeruNgppAAKujSEdbzKMDEIQJYyYWJFiYCTmPkqWMvGRxOdAcDMtQRgHwBLPHqsRVCwHZsnRjOZiYQsUVYWsXlrgvlPnzA.transform.parent = pwcPVVsvBKpUjcSXIFiRTJuaTJkplNCZsIyDfjUxCAwlcccooxDkfIHFbcVmKckOiqCBEoRyKLotmiXQHWbNjsUKbSBdoIMzpIdMzBKZGezttntTeeFOawEQvSzLMOkcZPdDekrflchfSBqNzIZjcXyTenrHbZmRUwuDkPOTNzCYpzXTBMlePaZbqkzRTJemPpkwgNCKTfwDvzEFpxfoNicTwtmapXadupjZoBNOjBkJEwFRFTBvEQzGnrZNACuWesifpErOKqelXsoZNvuwvEzEQDMWBanHhnEmoABaCNLnLnIUcZZfiYBATDoMSumKdxeKOcLnTtTITlTDURTCaiyjMesKlOihAakniYganLlPeSGIKLSaBKJUZVXJKbbfkLiSaFuVLTooWJeTxKZAVhGPrponawqmJgEsKOIfqWoHwuYpRelacBjdfsBKqhUpDcEQeLiJbUjYSYtWrYwWkpj.transform;
					num = (int)(((((num2 + 501888951) ^ 0x6BD85411) << 0) + 0 << 0) ^ 0);
					continue;
				default:
				{
					IEnumerator<Text> enumerator = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꕞꕶꕫꕰꕵꕵꕸꕏꕋꕋꕰꕾꕪ", 657499417, true)).GetComponentsInChildren<Text>().GetEnumerator();
					try
					{
						while (true)
						{
							IL_21e3:
							int num3;
							int num4;
							if (enumerator.MoveNext())
							{
								num3 = 766697641;
								num4 = num3;
							}
							else
							{
								num3 = 487553492;
								num4 = num3;
							}
							int num5 = (num3 + 0 >> 0) + 0 >> 0;
							while (true)
							{
								int num8;
								switch ((num2 = (uint)((((((num5 + 0) ^ 0) << 0) + 0 >> 0 >> (0 ^ 0)) ^ 0) - 0)) % 17)
								{
								case 9u:
									num5 = 766697641;
									continue;
								default:
									goto end_IL_1e3f;
								case 11u:
									num5 = (((int)num2 + -754814299) ^ 0x3313B447 ^ 0) - 0 << 0 >> 0;
									continue;
								case 6u:
									if (componentInParent.Controller.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("텮텁텛텆턁텾텚텆텛텺템텊텝턁텵텆텁텗텢텊텁텚턞", 1700319535, true)))
									{
										num5 = (((((int)num2 + -1982167002) ^ -289723485) - 0 - 0) ^ 0) - 0;
										continue;
									}
									goto IL_20c6;
								case 15u:
									num5 = (0x6D4D493 ^ 0) + 0 << 0;
									continue;
								case 4u:
									current = enumerator.Current;
									num5 = 0x5443F519 ^ 0;
									continue;
								case 7u:
									num8 = (componentInParent.Controller.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ua982ꦭ\ua9b7ꦪꧭꦒ\ua9b6ꦪ\ua9b7ꦖꦰꦦꦱꧭꦙꦪꦭ\ua9bbꦎꦦꦭ\ua9b6꧱", 13347267, true)) ? 1 : 0);
									goto IL_20c7;
								case 8u:
									flag3 = flag2;
									num5 = ((((int)num2 + -397089116) ^ 0x8C41270) >> 0) - 0 - 0 + 0;
									continue;
								case 1u:
									flag = flag3;
									num5 = (int)((((num2 + 1949381871) ^ 0xFA7E6184u) + 0 + 0 - 0) ^ 0);
									continue;
								case 10u:
								{
									int num6;
									int num7;
									if (!flag)
									{
										num6 = 1666841219;
										num7 = num6;
									}
									else
									{
										num6 = 2098945402;
										num7 = num6;
									}
									num5 = (((num6 - 0 << 0) ^ ((int)num2 + -410644842)) >> 0 >> 0) ^ 0 ^ 0;
									continue;
								}
								case 13u:
									num5 = (((((int)num2 + -550876412) ^ 0x7EF47107) + 0 + 0) ^ 0) - 0;
									continue;
								case 12u:
									Application.Quit();
									num5 = (int)(((num2 + 42012981) ^ 0x5CCCEF8F ^ 0 ^ 0) + 0 + 0);
									continue;
								case 2u:
									num5 = ((int)(((num2 + 180031177) ^ 0xE353B94Bu) + 0) >> 0) + 0 - 0;
									continue;
								case 14u:
									num5 = (int)((num2 + 1615385679) ^ 0xE8F6AF40u) >> 0 << 0 >> 0 >> 0;
									continue;
								case 0u:
									componentInParent = ((Component)current).gameObject.GetComponentInParent<PhotonView>();
									num5 = (((((int)num2 + -1235319105) ^ 0x6627B2AF) + 0 << 0) ^ 0) + 0;
									continue;
								case 16u:
									break;
								case 5u:
									if (componentInParent.Controller.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("컠컑컑컍컈컂컀컕컈컎컏캏컰컔컈컕컴컒컄컓캏컻컈컏컙컬컄컏컔", 727961249, true) + PhotonNetwork.LocalPlayer.UserId))
									{
										num5 = ((((int)num2 + -478421496) ^ 0x6121EB59) >> 0 >> 0) - 0 - 0;
										continue;
									}
									goto IL_20c6;
								case 3u:
									goto end_IL_1e3f;
									IL_20c7:
									flag2 = (byte)num8 != 0;
									num5 = (1001415234 >> 0) - 0 - 0 << 0;
									continue;
									IL_20c6:
									num8 = 0;
									goto IL_20c7;
								}
								goto IL_21e3;
								continue;
								end_IL_1e3f:
								break;
							}
							break;
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_2264:
								int num9 = 1603814049;
								while (true)
								{
									switch ((num2 = (uint)(((num9 - 0 + (0 << 1) << 0) + 0 >> 0 >> 0 + 0 << 0) + 0)) % 4)
									{
									case 2u:
										break;
									default:
										goto end_IL_2269;
									case 1u:
										enumerator.Dispose();
										num9 = (((int)(((num2 + 352196356) ^ 0x63CBD0EE) << 0) >> 0) ^ 0) - 0;
										continue;
									case 3u:
										num9 = (int)(((num2 + 1637825829) ^ 0x18FA76B0 ^ 0) - 0 << 0 << 0);
										continue;
									case 0u:
										goto end_IL_2269;
									}
									goto IL_2264;
									continue;
									end_IL_2269:
									break;
								}
								break;
							}
						}
					}
					IEnumerator<Text> enumerator2 = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("똕똽똠똻똾똾똳똄똀똀똻똵똡", 1345631826, true)).GetComponentsInChildren<Text>().GetEnumerator();
					try
					{
						while (true)
						{
							int num10;
							int num11;
							if (!enumerator2.MoveNext())
							{
								num10 = 1772381939;
								num11 = num10;
							}
							else
							{
								num10 = 1475950116;
								num11 = num10;
							}
							int num12 = (num10 >> 0 << 0) ^ 0 ^ 0;
							while (true)
							{
								int num13;
								switch ((num2 = (uint)((((num12 >> 0 >> -0) + 0 >> 0) ^ 0 ^ -0) << 0 >> 0)) % 16)
								{
								case 9u:
									num12 = 1475950116;
									continue;
								default:
									return;
								case 11u:
								{
									int num14;
									int num15;
									if (flag6)
									{
										num14 = -425901496;
										num15 = num14;
									}
									else
									{
										num14 = -592081542;
										num15 = num14;
									}
									num12 = (int)(((uint)(num14 ^ 0 ^ 0) ^ (num2 + 1470002489) ^ 0 ^ 0 ^ 0) + 0);
									continue;
								}
								case 6u:
									if (((MonoBehaviourPun)componentInParent2).photonView.Owner.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蒸蒷蒹蒬蒹蒽蒿蒱蒭", 1434223828, true)))
									{
										num12 = ((((int)num2 + -979218388) ^ -2079253691 ^ 0) >> 0 << 0) + 0;
										continue;
									}
									goto IL_260f;
								case 15u:
									break;
								case 4u:
									current2 = enumerator2.Current;
									num12 = (228097917 + 0 >> 0) - 0 << 0;
									continue;
								case 7u:
									if (((MonoBehaviourPun)componentInParent2).photonView.Owner.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("缎缊缈缆缚", 305823587, true)))
									{
										num12 = (((((int)num2 + -1280339681) ^ 0x4C5634DE) << 0) ^ 0) >> 0 >> 0;
										continue;
									}
									goto IL_260f;
								case 8u:
									num13 = (((MonoBehaviourPun)componentInParent2).photonView.Owner.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᄀᅑᅒᄎᅗᅘᅹᄜᅽᄓᄗᅍᅛᅴᅺᅴᅒᄃᅀᄚ두ᅈᅟᅽᅞᅩᅟᅘᅽᅳᅀᅳᅁᅓᅭᅿᅈᅑᅼᅝᅀᄋᄁᅗᅸᅱᅩᄜᅰ", 449188153, true)) ? 1 : 0);
									goto IL_2610;
								case 1u:
									flag5 = flag4;
									num12 = (((((int)num2 + -293353360) ^ 0x1E67B20B) + 0) ^ 0) + 0 >> 0;
									continue;
								case 10u:
									flag6 = flag5;
									num12 = (((int)num2 + -1273537865) ^ 0x6005913A ^ 0) + 0 << 0 << 0;
									continue;
								case 13u:
									num12 = (((int)num2 + -359145908) ^ -1212579623) << 0 << 0 >> 0 << 0;
									continue;
								case 12u:
									num12 = (((((int)num2 + -36046759) ^ 0x1F683C07) + 0 - 0) ^ 0) << 0;
									continue;
								case 2u:
									num12 = (((int)(((num2 + 1954567917) ^ 0xDD2B1CF1u) - 0) >> 0) + 0) ^ 0;
									continue;
								case 14u:
									num12 = 0x3E7CE08F ^ 0;
									continue;
								case 0u:
									componentInParent2 = ((Component)current2).gameObject.GetComponentInParent<VRRig>();
									num12 = ((int)(((num2 + 1768700576) ^ 0xE5C6F715u) + 0) >> 0) + 0 - 0;
									continue;
								case 5u:
									if (((MonoBehaviourPun)componentInParent2).photonView.Owner.NickName.Contains(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꛘ", 377071252, true)))
									{
										num12 = ((int)((num2 + 816971263) ^ 0xA089B382u ^ 0) >> 0) - 0 << 0;
										continue;
									}
									goto IL_260f;
								case 3u:
									return;
									IL_2610:
									flag4 = (byte)num13 != 0;
									num12 = 0x6038FC91 ^ 0;
									continue;
									IL_260f:
									num13 = 0;
									goto IL_2610;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator2 != null)
						{
							while (true)
							{
								IL_2744:
								int num16 = 65724577;
								while (true)
								{
									switch ((num2 = (uint)(((num16 - 0 + (0 + 0) - 0 + 0 >> 0 >> (0 >> 1)) ^ 0) + 0)) % 4)
									{
									case 2u:
										break;
									default:
										goto end_IL_2749;
									case 1u:
										enumerator2.Dispose();
										num16 = ((((int)num2 + -528164536) ^ -1626095090) + 0 << 0 << 0) + 0;
										continue;
									case 3u:
										num16 = (int)((((num2 + 1765054133) ^ 0xCFA84C54u ^ 0) - 0) ^ 0) >> 0;
										continue;
									case 0u:
										goto end_IL_2749;
									}
									goto IL_2744;
									continue;
									end_IL_2749:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public static void wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(string ColorType, string Type, string NotificationText)
	{
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		bool flag6 = default(bool);
		bool iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx = default(bool);
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 << (0 >> 1) << 0) - 0 + 0 << 0 + 0) ^ 0) << 0)) % 5)
				{
				case 2u:
					break;
				case 0u:
					if (flag6)
					{
						num = (((((int)num2 + -956687329) ^ -230459297) << 0 << 0) ^ 0) >> 0;
						continue;
					}
					return;
				case 3u:
					flag6 = iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx;
					num = ((((int)num2 + -725091362) ^ 0x110CE96E) >> 0 << 0 << 0) + 0;
					continue;
				case 4u:
					iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx = Plugin.iGcPYXqaEjoxUptIcidlTIcvFkOMssZyPVXLwYzjwGEyVQbiqdHCCXSzEHkOiDHmjQIYsImeITPndDzOiGwpKxWSdxhONLaSYsoficQIQDTIhFwaivFChsCMTQVUByqWTWoLptGgPOzgDoKxbgFsfyKGQBmrgVgsmWOlrLKPPzMtTvjEgyTuSYRumIUOhoaUHgUGzzgpwQDGLrNvrHlIcLAoftYIQWHAySLMBDfGrDYbvlJVUzwzcsRVGFAfAxyzichSFaTNCFqyMyTUKdOrziygaQgVcZgUfzSsdQpUFIWxbtihMGvwJhaaEaSPTYKDyvtnGAQUNTMQlaeHHZjwEJlXySOcYAbHXtZGaUAlPBIPvjOEWliTOoZOkvPNMOVnSeTSbyGMyYHdavCpdkgNshSJukvEfNzbFvXqpWCxEvvPHWOPSzKBHiULljx;
					num = ((int)((num2 + 377208505) ^ 0x4A8E42AD) >> 0) + 0 + 0 >> 0;
					continue;
				default:
					try
					{
						while (true)
						{
							int num3 = 1802649746;
							while (true)
							{
								switch ((num2 = (uint)((((num3 + 0 >> (0 ^ 0)) ^ 0 ^ 0) >> 0) + (0 << 1)) ^ 0u ^ 0u) % 22)
								{
								case 9u:
									break;
								default:
									return;
								case 11u:
								{
									int num6;
									int num7;
									if (!flag2)
									{
										num6 = 1831748316;
										num7 = num6;
									}
									else
									{
										num6 = 1307156857;
										num7 = num6;
									}
									num3 = (int)(((((uint)((num6 << 0) - 0) ^ (num2 + 1726140)) << 0) - 0 - 0) ^ 0);
									continue;
								}
								case 20u:
									num3 = (int)((((num2 + 1332896518) ^ 0xAB6F6CEBu ^ 0) + 0 << 0) + 0);
									continue;
								case 15u:
									cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe.text += NotificationText;
									num3 = 1022138298 - 0 << 0 << 0 << 0;
									continue;
								case 18u:
									flag3 = Time.time - aUjAXWptPyIRTdwTKXQhJEAfVzOtvGjpMPtJasTUkEdREPmJKQ > fwPYJvudEyhVYiptedJMSreVWfAIBfmfIFANzNfYpWNvNpGUCkLiZYXOsTcEULCzlcmsIBTrYLxWDIiHzGgquegKIMvGLAdDtojLcnmartknAakJKufoFmehVCKVgnFxHUCpzxFltfZaTSkHCMVqvPXhjcPADrUdNMGGyUjnPUVAndndrctuspcSWvfwIeHclVmglDjHCHAAUxUfOLiBXzLyKOJdONFKmSorQgRNSLSKOBXzAZHWWgeLjOwxUgSOcQobiCpHTuIlHbKjQkCOfIOgODicKtTLSdHYnWqYKZdBxSeidmHJEeJtbinFumXzAXtEtMWTTEdgFmIVyZYyMkhOuoWeJLDycDbAzzOrqNQaaCOPzrgunzNqPEkfPRkhaFdclivZlHhYthORzhFrFikDPKKVpJBzDIZuzLDqVhjGrPXIQtFIlTCRuAmByAJCfHuLhtr;
									num3 = ((int)((num2 + 1709781230) ^ 0xF290468Du ^ 0) >> 0) + 0 << 0;
									continue;
								case 7u:
									NotificationText = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("릁맦릹릵릶릵릨맧", 1024768474, true) + ColorType + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udc04", 878173242, true) + Type + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uee23\uee30\uee7c\uee70\uee73\uee70\uee6d\uee21\uee42\uee3f", 1203957279, true) + NotificationText;
									num3 = ((int)(((num2 + 1620250878) ^ 0xCB05F513u) - 0) >> 0 << 0) ^ 0;
									continue;
								case 8u:
									flag5 = !NotificationText.Contains(Environment.NewLine);
									num3 = (((int)((num2 + 232892542) ^ 0x89484DF) >> 0) ^ 0) + 0 + 0;
									continue;
								case 1u:
									flag4 = flag5;
									num3 = ((int)(((num2 + 1133461507) ^ 0x8F380ED2u) - 0) >> 0 >> 0) + 0;
									continue;
								case 10u:
									flag2 = flag4;
									num3 = ((int)((num2 + 1221206141) ^ 0x3B11DA6E ^ 0) >> 0) ^ 0 ^ 0;
									continue;
								case 13u:
									flag = flag3;
									num3 = ((((((int)num2 + -1650322207) ^ -1066839342) - 0) ^ 0) << 0) ^ 0;
									continue;
								case 12u:
									num3 = ((int)((num2 + 277960658) ^ 0x7D965136) >> 0 >> 0 << 0) ^ 0;
									continue;
								case 2u:
									NotificationText += Environment.NewLine;
									num3 = (((int)((num2 + 385831441) ^ 0x13143F35) >> 0) + 0 + 0) ^ 0;
									continue;
								case 14u:
									num3 = ((((int)num2 + -67898082) ^ 0x40CD5AC3 ^ 0) >> 0 << 0) - 0;
									continue;
								case 0u:
								{
									int num4;
									int num5;
									if (flag)
									{
										num4 = -45393477;
										num5 = num4;
									}
									else
									{
										num4 = -1738507415;
										num5 = num4;
									}
									num3 = ((((num4 ^ 0) >> 0) ^ ((int)num2 + -1395914388)) >> 0) - 0 - 0 << 0;
									continue;
								}
								case 16u:
									num3 = ((int)((num2 + 1106027214) ^ 0x644B7551) >> 0) - 0 << 0 << 0;
									continue;
								case 17u:
									qJKhrcMXWXPXSTaprxlMpUvjXAZflgykNsUxZigqcrmUMnhLArgzxaDvnAkQdHMPzEjAYCqjqVJYIAxKtnEUZYNNOzjyYqnvFwuieHMXaXiCqFMNdzxPcSQAQvMztRlaHoslfoFLAGTcQkxiMwvySxsMGUrJUnEjMhUbmBHOULowZNKFXDMWvMijWFFlXWRnbJqIqwVlOHEgjVNSjLLrAHNZZKeHVwRXUaupxbpBIBhOibaaSMbllAMuVqIFropsQHmiByuhvkJZAYQYKeOjuFMuoatgtKjtlPYBORzurTQaQNUXAKVnzgYkUSUBenOLapNLapjSEuRAOLDAgwGJOWTfQNGWXYpdeeZBZjWkAcIeoxwjotuHHfWevIUmInUGfNwKLcAXzwjMnOQtrxIDDHwZhVfroKBmhbZAbLx = NotificationText;
									num3 = ((int)((num2 + 1840812781) ^ 0xFC2A3A5Du) >> 0 >> 0) - 0 << 0;
									continue;
								case 3u:
									((Graphic)cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe).color = Color.white;
									num3 = (int)((((num2 + 907932242) ^ 0x9D371550u) << 0 << 0) + 0) >> 0;
									continue;
								case 19u:
									num3 = ((int)((num2 + 929994502) ^ 0x21D4A4E7) >> 0 >> 0 << 0) ^ 0;
									continue;
								case 5u:
									num3 = ((int)((num2 + 1319775793) ^ 0x8A2A5FE2u ^ 0) >> 0) + 0 + 0;
									continue;
								case 21u:
									num3 = (1665746988 << 0 >> 0) - 0 >> 0;
									continue;
								case 6u:
									aUjAXWptPyIRTdwTKXQhJEAfVzOtvGjpMPtJasTUkEdREPmJKQ = Time.time;
									num3 = (((int)((num2 + 747032882) ^ 0xAE31C79) >> 0) ^ 0) >> 0 << 0;
									continue;
								case 4u:
									return;
								}
								break;
							}
						}
					}
					catch
					{
						while (true)
						{
							int num8 = 1790479597;
							while (true)
							{
								switch ((num2 = (uint)((num8 + 0 << 0 + 0) + 0 << 0 >> 0 << 0 + 0 >> 0 << 0)) % 3)
								{
								case 2u:
									break;
								case 1u:
									goto IL_06a4;
								default:
									throw;
								}
								break;
								IL_06a4:
								num8 = (int)((((num2 + 923559321) ^ 0xCAF5E732u) - 0 << 0) - 0 + 0);
							}
						}
					}
				}
				break;
			}
		}
	}

	public static void PJimgxYCuUPoTtIBgZjZrsDSgcLUBZwKkbJQgxfYKOlHRsUHBJiKXkBwfpfdMeavxedSJRvJUlpChWaNidsRQMNZAmLQrcmGOPjMpcYJnyQMVZpjorUILiELrdrwgFrRYJOrMoygfIDsVbeBXCBahEUFlyvlKBCIhYNmkXwaTODcEmPpZQzEdrKuOignSmwDgVlXnSqZfBhtbSaYIgmTcYFPntycRjiGrZWJbRbgAzzCkrsVihFMaDAipvKUuoiWsAbbVqXQefsDydFWaCTJDwGOzOuFhhMmqDjJqraRkOHUkWJmQOTSuysWUmChWrIXtgmUUVFJCbzPOLECeiPtnURSlmPeOSVSfKBeKOrVikqsYCiiHacNCoKyouJIgBUJfHJekzSpQUldEzTIdGwOPhqQacQpfJOHpGnrTeXhiMXHdGTPAaEzefUXqSeiJCkhfENYlCPZIoGckI()
	{
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 + (0 ^ 0)) ^ 0) >> 0) - 0 - -0 + 0 + 0)) % 6)
				{
				case 2u:
					break;
				default:
					return;
				case 0u:
					TawTScnpHQHANAeORjvcHYhLEtBZivMiGdLhVoezNNKANtjxkFkdctvUTKoyBohldyUKOXTCeVoUnGYkkdOClJfnHQokZFXzFzwozyJnLHYgeAHmMeoyzEausHcYIJDyXOpOkJLLuBRDKYihjcyUrzaazcVSvKEcdzjplTccsCdYNwJtyVOGlIhyOoohOTpJWOzlPSWqZvCPvbmdsBtAWXRvsLBWEUnzmubZWyEFZyHPgrcMclPmzPMZXeSerZLfhcCbangTXNBxqbobIOTsebZxHcbRGzoZMBHdObMPfVpLnpIVQRvCgsagdf.Clear();
					num = (((int)num2 + -248958683) ^ 0x1C939558 ^ 0 ^ 0) + 0 - 0;
					continue;
				case 3u:
					num = (((((int)num2 + -907893453) ^ -466987132) - 0 >> 0) ^ 0) - 0;
					continue;
				case 5u:
					num = ((((int)num2 + -344833909) ^ -305432173 ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 4u:
					MOXhQTfeoItxDSTdQyynTptsXUarBqfQWmSQkUsaRulGQBmBoWanqysxuEkWTODYDCBqacTWfywydMBvIydEpRAyTvwFJwhdRndoaVBlcehSbTtIdPouKYILccwEGomJqtHQJnuMWRClJHwacNBUiMsSFrmYyXFNRyBImCYPvBySwwbuFwBSMsBEaPlrbvnZmOtlfNNAPMyGozwiq(cRCSsDsKXaOHtLpKMvoDLOMnYRxfESLVzzJDNpKbnqEJbVRHdvSbDZHoeoTAgmfepThTcMXwKmpujcldaPciaKrASvyywkUakAuiNXFryvqqJmfccPzrkXdECHbGnyazsokIHdqdjKKFtaQGqwvGLDQnwQGfVZdZuRYvbwuZzwhzmykBRvqRcuOOyWmRxlhkHKkCbuETbwhpvqaXFenAImWackXe, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 467829762, true));
					num = (int)((((num2 + 414745695) ^ 0xB4411CF2u) << 0) - 0 + 0 << 0);
					continue;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	public static void NtibOefoCjMpaaaPyFCQCzTVDYlFRQzRNIfKZHNgcRbDlWCOZTQaAugozmyQSAxMKVBsVpPQRvOLxqKGwxFYayqsBQlMjXnBtpSqvjTJdZieGvQjCRuvUzMlEjQeddGUimrhxtlmDWUapmMfackrDSHUDGMltOFasoWueILiGiRXELWrwKebSprqExEQHZSOqUHbqrbrqbKvaKqRKuPIKEhdXGQHeUBHpcHJeUbeJNLREWpUgNgmkkeMNEeJBumvzdgXcGNQsKZX(int amount)
	{
		string string_ = default(string);
		string[] array = default(string[]);
		string[] array2 = default(string[]);
		string text = default(string);
		int num5 = default(int);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301852;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) ^ -0) - 0 + 0 << 0) ^ -0 ^ 0) + 0)) % 21)
				{
				case 0u:
					break;
				default:
					return;
				case 13u:
					string_ = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 806626337, true);
					num = ((((int)num2 + -733318432) ^ 0x8DF0E94) + 0 << 0 >> 0) ^ 0;
					continue;
				case 8u:
					num = (((int)num2 + -1950096023) ^ -597916243) - 0 + 0 + 0 + 0;
					continue;
				case 1u:
					array = LEWqhllDpzDxrnQvOBxgxHVzHaETNKOzCDhbzLmcKHNlYMlEDoLxIhfdIwIhGsPFLeVNfPVdouvPUKBVPapzYqRuyesccfwrSizUQxzOtIjnLpjYVMrGdqGumApbwTaiYeXLkGerBAgqhDIiUugpNPnBBfHqhxsAHapHrxNpIZfCkqnJRhgcMLviQvkfZOkdiGIhnbQxGRHNKLrlRXyaqpNWFgQWnIpTPbuEHgvPqJwUeHyfdYnbpkNSSMCgkUjXCNYJqNDLBJJHTSRXILSounEFoCLVDpEvzysqJOPqvBAGAgYZUEyzcVCojsvObIhmeohvABoTVCTTNXfhDMaZQftEVehqtaoNunClYDztqEDzbJAlnnkpHivZUCzwtXzVogyAvTjanHJmBUDlDWdgQYflRDrwddZseIlVkaPtekcZzjxaZoSxUtepanISCMXjHqhSIIaD(BoFGwzZgbyylTHsksPIBWKuzBhQGIyFFhcjTXzzpjZPuhaRLPLm(MBXgfkLRscBkOvBrcGtYWLeDtVtYwJmaNKxlVnYAFSfKVGwYtCDVgnfbwtMkQMvJQBwdXpvOISsdFuINyuEUfqTzEwPCBOJSxwTujsbegOnnUcvbL), RscvMazXXIwqHOZozGHcQpSIbdaTUqAtdbjdlDzOUoifrjhXzsPTPfzCAttJZGcHhdnGFVcVgSiBhMrSVduCBHDXBGDSjQOomAXnWBsDpTMWXXvNbBNWlzgAzqeYskLqeUpGOdWuLRmHVHZDlPQIdRcMuxOFwtkfivRdIPYYFtlumyESqBMDtdnmRDlqpqXrGhzzPWVwQScKGHzWTVoVGHLeiEleDIIpvTNfZfcuFqMBbDGjepxtbcKZvuqkLQSikMoNTtWOTUpqVkdFYbaokontiOKEORJPyDqooSpKsJAgMudkrLlJQDYVzUEfJsablARrUOrgLqVBOhHNLzncFZYUFvPtokaaJyVlDMqCufYzIwgrnQtkeXwmBXLyZXRApURqlvkYiKIzbzmioxfxQQVMcIKGbSCwnxjNFQgSGvbuoWlcKCkCRuJzZfnC(DgFQolRTfNmpnlmalEFqBQeRpDLFSXfnIJLRCcLdUfDfthZmAutnladNcNALzlahIZHEzvxiSCwvnZxiDzexDSbHGYPPBZDIevwuAvNfXluJEIzcpshahDEQXZXAFIGSYNqRCdHiLZAsxrcYyNzjRDBBRGwAxmzpECLRrHzmKZoidlsGXZcSjxaumOaWGhLzzkOVFlGQnmySosyGoQDxkHggBqFCHDFDnPJSxxaLslFWYhfTpuIQDnoSeHupGdjKGVFzJGiQQReYbjitlMnnVPZZAQOPdLfpcVpcCGjJlRaMjqQUzadUQVORVFYSRtNeLPWgUfQFCDbePmQkaUqcHlyggygXHqRSdVattJatjyrnUKcJPOSXdKxArPavYTXlLjaTlwQqUWTiTlmvwxiTyUOs())).Skip(amount).ToArray();
					num = (((((int)num2 + -678915685) ^ 0x16CC4319) - 0 << 0) ^ 0) - 0;
					continue;
				case 19u:
					MOXhQTfeoItxDSTdQyynTptsXUarBqfQWmSQkUsaRulGQBmBoWanqysxuEkWTODYDCBqacTWfywydMBvIydEpRAyTvwFJwhdRndoaVBlcehSbTtIdPouKYILccwEGomJqtHQJnuMWRClJHwacNBUiMsSFrmYyXFNRyBImCYPvBySwwbuFwBSMsBEaPlrbvnZmOtlfNNAPMyGozwiq(MBXgfkLRscBkOvBrcGtYWLeDtVtYwJmaNKxlVnYAFSfKVGwYtCDVgnfbwtMkQMvJQBwdXpvOISsdFuINyuEUfqTzEwPCBOJSxwTujsbegOnnUcvbL, string_);
					num = (((int)((num2 + 2101245088) ^ 0xBBF1C8A5u) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 10u:
					num = (((((int)num2 + -1186296972) ^ -990844783) + 0 + 0) ^ 0) - 0;
					continue;
				case 2u:
					array2 = array;
					num = ((((int)num2 + -1701687338) ^ -1129617203) << 0 << 0) - 0 << 0;
					continue;
				case 14u:
					string_ = jkeVUiGHucPHpkQHlncXfWZQSNtiDuddOMITRTcblTCVFjjFCdtTpRznkncgOxeZZLTCCXPskaLmtekJDNGAbkOWnvIDRVmNOCVUqHcFnbIofnTgctCbRDYPXWpgomBpNYxRiqtWKbnaCzQaCCAxslVkEgWtrWqbztAhPbYMaGqQqYnxgpEMLdWCcmnbuaEOKlAiYJkAEOxMVfUGTymcrEqwxYfDOWsabBgexezxfdiWFjGXsGiVNCwfVeLZEGLHwxLtZPiPZPXowtQnshlhOwmyeaitszSyrAziymYCysWXEiICnyHwuET(string_, text, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("했", 1718605186, true));
					num = (int)((((num2 + 660359990) ^ 0x4A239B02) << 0) - 0) >> 0 >> 0;
					continue;
				case 15u:
					num5 = 0;
					num = ((((int)num2 + -1219895373) ^ -713221632) + 0 >> 0 >> 0) + 0;
					continue;
				case 17u:
					num5++;
					num = (((((int)num2 + -11084362) ^ 0x5FD30FF6) - 0 - 0) ^ 0) - 0;
					continue;
				case 12u:
					num = (int)((((num2 + 900749756) ^ 0x57D05B7) << 0) + 0 - 0) >> 0;
					continue;
				case 7u:
					num = (((int)num2 + -649986417) ^ 0x677F0803) >> 0 >> 0 << 0 >> 0;
					continue;
				case 18u:
					text = array2[num5];
					num = 0x49E2A531 ^ 0;
					continue;
				case 9u:
					num = (((int)(((num2 + 1665746989) ^ 0xEBD1F149u) << 0) >> 0) ^ 0) >> 0;
					continue;
				case 16u:
					num = (359659184 + 0 >> 0) + 0 >> 0;
					continue;
				case 5u:
					flag2 = gKcFVfMIfrwOkCyLDVUXrXRrnSsicFrrnoqkqzuVAaMkpiZfSvoNNdliSLscNEFAZfBVloueBZxrkGbfTmpGqEDkdirFhrhWumlkGdTEbkmOFTXmKmjBoZjvCrSdWPXjRAXYvRyQsKFgrOE(text, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("", 1051811831, true));
					num = (int)((((num2 + 770395556) ^ 0x5CC589A) + 0 + 0) ^ 0 ^ 0);
					continue;
				case 3u:
				{
					int num6;
					int num7;
					if (num5 >= array2.Length)
					{
						num6 = 1621957027;
						num7 = num6;
					}
					else
					{
						num6 = 1422392304;
						num7 = num6;
					}
					num = ((num6 - 0 << 0) ^ 0) + 0;
					continue;
				}
				case 11u:
					flag = flag2;
					num = (((int)((num2 + 1333463150) ^ 0x908A777Cu) >> 0 << 0) ^ 0) - 0;
					continue;
				case 20u:
					num = (((((int)num2 + -365853555) ^ 0x76DA4373) << 0 >> 0) ^ 0) << 0;
					continue;
				case 6u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -1715750728;
						num4 = num3;
					}
					else
					{
						num3 = -1571650780;
						num4 = num3;
					}
					num = (int)(((uint)(num3 - 0 + 0) ^ (num2 + 2029155507)) - 0 - 0 - 0 + 0);
					continue;
				}
				case 4u:
					return;
				}
				break;
			}
		}
	}

	private static GameObject SqzbqVAqOpxeYUVzQrCoAprAPrRAapTzkhTxfdtGUWHkGbZhKnZbhLwDYYlZeZqyvXTQbyuNYWtEHhUOrJPMpSrzKpzgRuBUFiOIhigmTmckrSWRewHukDjDFtgMZnVEuzYzslGjDCScPgiRtHcvMhJbZlcNcunGryQRUwzSQyQIKgNylosrkARnPWAgiSgjpmLrqrXWijEorbqTyDCObWvRGCbXWsKXrGsyuviTqwiaVCVOFHHEqsisRUKOpaaQzHXKISydvIxFNuVeGnrpLfHZyaHAKtEqwsBnElfNiEiHUDEwYGhbIKetaYmIlXsbehjvTIzviEghXZeVvkCdmDILninGYwBllgDNtjDqhLTdEXwaUrnavoPAzxhLuSxLdVVQwrBlHlWBKFhqLnMG(string string_0)
	{
		GameObject result = default(GameObject);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 + (0 >> 1)) ^ 0) + 0 + 0 + (0 ^ 0) - 0 + 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = GameObject.Find(string_0);
					num = ((((int)num2 + -1874950498) ^ -859104592) + 0 >> 0 << 0) - 0;
					continue;
				case 1u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) << 0) ^ 0) >> 0 << 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static GameObject jAPWrcoWbSVonhZIbFDDQbtjsnQUqRZhgQCCgZzucFkPqInCFyogJjQhhFEeluFjTOixExCcgjAlQETJZnoSCSyWauvAuujIZaWBAQYiWmaAJEqDLUeXfNGaqlxjbbHLZRlPIsjipgVqSXnveSPzqlDmuVlptOgUFoARtAUtLWHYRqhsXbfjmhvOnZvMgUPBabLExwbDXvOtEFudOSrrIWIxTM()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Expected O, but got Unknown
		GameObject result = default(GameObject);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0 >> (0 >> 1) >> 0) + 0 + 0) ^ 0) << 0) - 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = new GameObject();
					num = (((((int)num2 + -1874950498) ^ -859104592) >> 0 >> 0) - 0) ^ 0;
					continue;
				case 1u:
					num = (((int)((num2 + 414745695) ^ 0x55FC76F6) >> 0 >> 0) ^ 0) >> 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static void DueimQhfXQFDVBZClQtbkIErYnCxTdsnKLSHyPiXmyHEykXQrfLRdRBVPNjZnKmUxrSkJsdwHvOMaZTNqMfNsAkSjWRLFjJClNghrNhZbojHdPUPTvIBEyBWhZaMAsQyMmAnTMwCFfLeqCPtbbRjAiXNljarNuzJxLVQpHWhZgVzMxFEkGLyAHXEoMbJLePlFcGFGYetfKjumyaODvhgIbiQOrCDGnvVqKTKQaYlCrsQx(Object object_0, string string_0)
	{
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num >> 0) - (0 << 1)) ^ 0) + 0 << 0) - (0 + 0)) ^ 0) >> 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					object_0.name = string_0;
					num = ((((int)num2 + -1874950498) ^ -859104592 ^ 0) + 0 - 0) ^ 0;
					continue;
				case 1u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6) - 0) >> 0) + 0 << 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private static void CrPMnfqWJCETQQowBNSooeBEpXDwWDrIrsmaNQtheYGipQakJObDACixQkwpCTafkWCxEoJKuKjqxtpzWsNhCNhPkOjCudFlXBXtoCGufriQsSawUXsjgSDxOMnPegqreYsWvWkuMsblErxrNMHxKwefYAEBpQqZaRLtzdbXMYwNRrSxpVbsyTGITnYVsJeVcckNFdSKLJKLZqnGHhmtOXAhkcAmffFcUALOhfRldrGPiVJCZsokwKheCcCDDFEGeIRyFzyCqbqwrLZpsXnNQvGjtHmfCoHyNZKAdlXATLUvuKMQcmkGsQPIbIeXmtZbtSJsazmhZN(Behaviour behaviour_0, bool bool_0)
	{
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) + (0 << 1) >> 0 << 0) - 0 >> 0 + 0) ^ 0u ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					behaviour_0.enabled = bool_0;
					num = (((((int)num2 + -1874950498) ^ -859104592 ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0 - 0 - 0);
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private static void TfBkOJUvcpebgWjcyuhZnAMScCauQDacGEXKhRTudQrKXrLNiYbRZazttIhmIzEzpbvBZzUGBMWwjcUKQnmSBicGfDryJHMDlRuWWkNIduqneckrOwvvnMXgYOvvhvXTaskr(Canvas canvas_0, RenderMode renderMode_0)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) - (0 + 0) << 0 << 0) - 0) ^ 0) - 0 << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					canvas_0.renderMode = renderMode_0;
					num = ((((int)num2 + -1874950498) ^ -859104592 ^ 0) << 0) - 0 + 0;
					continue;
				case 1u:
					num = (int)((num2 + 414745695) ^ 0x55FC76F6) >> 0 << 0 << 0 << 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private static void HXOGzDOgSPCctaKmlqqzToYhOrAIxwnLRSJQIPVJXQnimtchLKHJcLxsZGRhdgJvCQlAqTEwvGCcaPVvptXNODIgvqRcYNGQhRGwiCQRgloviusjLvSKjVGYhefZcCyHaLViiynNCfHDpmYaYHqCVVHllIodwRPENGvwzjbmifidodIVgfbu(Canvas canvas_0, Camera camera_0)
	{
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num - 0) ^ 0 ^ 0) << 0) + 0) ^ 0) >> 0) + 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					canvas_0.worldCamera = camera_0;
					num = ((((int)num2 + -1874950498) ^ -859104592) >> 0) + 0 >> 0 << 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) - 0 - 0) >> 0 >> 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private static float lWMeeJXAkjqLqdQIRBAPGeuQNDXhZtXrQusQUqrQlAbYOxMlmZdEFlOhBWqBLQARmYUWKZOAjJDfcvbqQLUZpsMEFlpYZQevakLPCQBnlDvVHIffUaLaVACUmqqzKQAtEifSKlOZkHOMWQWXfjdZeeAzHRDlzbCvcbqzCmvIlLPnMPXvtttBMBpAIGkTICzjetKVzwuSNuNtpmNSThRgHbIBMQRWcCaIlGjsfbWXYANrNVkwTsZBLtBdKiiIFyQluehJcuMRlUihnrOQGvcKCzXSfgIWTnrzKCXIOBtzFiqQktPtuscjwfIUhpEWMPYXCIwLtfcecDeujhHLqoCAkhdETcByXwNQjsnCXeZopYhSaoLZISFxnxNuERRrE()
	{
		float time = default(float);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 >> (0 >> 1)) ^ 0) + 0 - 0 >> (0 << 1) << 0) - 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					time = Time.time;
					num = (((((int)num2 + -1874950498) ^ -859104592) + 0) ^ 0) << 0 >> 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) << 0) >> 0 << 0 >> 0;
					continue;
				default:
					return time;
				}
				break;
			}
		}
	}

	private static string DgFQolRTfNmpnlmalEFqBQeRpDLFSXfnIJLRCcLdUfDfthZmAutnladNcNALzlahIZHEzvxiSCwvnZxiDzexDSbHGYPPBZDIevwuAvNfXluJEIzcpshahDEQXZXAFIGSYNqRCdHiLZAsxrcYyNzjRDBBRGwAxmzpECLRrHzmKZoidlsGXZcSjxaumOaWGhLzzkOVFlGQnmySosyGoQDxkHggBqFCHDFDnPJSxxaLslFWYhfTpuIQDnoSeHupGdjKGVFzJGiQQReYbjitlMnnVPZZAQOPdLfpcVpcCGjJlRaMjqQUzadUQVORVFYSRtNeLPWgUfQFCDbePmQkaUqcHlyggygXHqRSdVattJatjyrnUKcJPOSXdKxArPavYTXlLjaTlwQqUWTiTlmvwxiTyUOs()
	{
		string newLine = default(string);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num ^ 0) << -0 << 0 << 0 >> 0 << -0 << 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 3u:
					newLine = Environment.NewLine;
					num = ((((int)num2 + -1874950498) ^ -859104592) >> 0 << 0) - 0 >> 0;
					continue;
				case 1u:
					num = (int)(((((num2 + 414745695) ^ 0x55FC76F6) + 0) ^ 0) << 0 << 0);
					continue;
				default:
					return newLine;
				}
				break;
			}
		}
	}

	private static bool yAcDJEvqBfBKKixsXCdgRoGfDEZALeNRuHvLtmGpBCHOJBLnaPVVQIBjUXafFUFwrKqcNLYKVNFpHSwcSLzViSaMgmQwmBJGXlwZlJAoRladcmCcAYmTuJnzJDWBVBxtdZrwvwRjlkeXRXJUKOVopQlnXWqHMZtpNHZdUfGegcIjFqIMUbRgFjenNdyygkwlROkkYGZEhRhnhbIHoDNLimJDDLpQHh(string string_0, string string_1)
	{
		bool result = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) - -0 - 0 + 0 << 0) - (0 + 0) >> 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0.Contains(string_1);
					num = (((int)num2 + -1874950498) ^ -859104592 ^ 0) - 0 >> 0 << 0;
					continue;
				case 1u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0 + 0) ^ 0);
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static string YWFwsRfyNnbmZObRgLvRkCxLdEfGHnqiXaTlHKJRBQQzJVnUCMEEvPXvzTsNLzRAWSpZVQjvbEquMXcirkeVIMNhdxLNrVfcZpCQFoZLCiCRzCJBRkwBuWRkfiWxfvegznvwvlDcksszjWIANjWhzDHdyrLxsBGhewslhngFHtqcDrbjzvJVzWHVGsYdAfKJMlvNExtAdqAfnFzgqBXWRLIiOwEOpcfBJHpsWnFccjRiwCIbSRNZhNRaDnYhSElalYvGphjcWVUITzLmODVxpgtVPoOJoykxXRXxgcLLIKcmTjhdBLsoJOLfFAQasANyLwKcCngMSjOFdgbFhKhDfVOjfRSGlKtiWEBwye(string string_0, string string_1)
	{
		string result = default(string);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 + -0) ^ 0) + 0 << 0 >> (0 >> 1)) - 0 << 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0 + string_1;
					num = ((((int)num2 + -1874950498) ^ -859104592 ^ 0) - 0 >> 0) + 0;
					continue;
				case 1u:
					num = (((int)(((num2 + 414745695) ^ 0x55FC76F6) << 0) >> 0) ^ 0) - 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static string BoFGwzZgbyylTHsksPIBWKuzBhQGIyFFhcjTXzzpjZPuhaRLPLm(Text text_1)
	{
		string text = default(string);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0) ^ 0) - 0) ^ 0 ^ 0) + (0 ^ 0) + 0 << 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					text = text_1.text;
					num = ((((int)num2 + -1874950498) ^ -859104592 ^ 0) << 0) + 0 + 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 - 0) >> 0 >> 0;
					continue;
				default:
					return text;
				}
				break;
			}
		}
	}

	private static void MOXhQTfeoItxDSTdQyynTptsXUarBqfQWmSQkUsaRulGQBmBoWanqysxuEkWTODYDCBqacTWfywydMBvIydEpRAyTvwFJwhdRndoaVBlcehSbTtIdPouKYILccwEGomJqtHQJnuMWRClJHwacNBUiMsSFrmYyXFNRyBImCYPvBySwwbuFwBSMsBEaPlrbvnZmOtlfNNAPMyGozwiq(Text text_1, string string_0)
	{
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) >> (0 << 1) >> 0 >> 0) + 0 << (0 ^ 0)) + 0 - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 3u:
					text_1.text = string_0;
					num = (((((int)num2 + -1874950498) ^ -859104592) + 0 - 0) ^ 0) >> 0;
					continue;
				case 1u:
					num = (((int)((num2 + 414745695) ^ 0x55FC76F6) >> 0) ^ 0) - 0 - 0;
					continue;
				case 2u:
					return;
				}
				break;
			}
		}
	}

	private static char[] RscvMazXXIwqHOZozGHcQpSIbdaTUqAtdbjdlDzOUoifrjhXzsPTPfzCAttJZGcHhdnGFVcVgSiBhMrSVduCBHDXBGDSjQOomAXnWBsDpTMWXXvNbBNWlzgAzqeYskLqeUpGOdWuLRmHVHZDlPQIdRcMuxOFwtkfivRdIPYYFtlumyESqBMDtdnmRDlqpqXrGhzzPWVwQScKGHzWTVoVGHLeiEleDIIpvTNfZfcuFqMBbDGjepxtbcKZvuqkLQSikMoNTtWOTUpqVkdFYbaokontiOKEORJPyDqooSpKsJAgMudkrLlJQDYVzUEfJsablARrUOrgLqVBOhHNLzncFZYUFvPtokaaJyVlDMqCufYzIwgrnQtkeXwmBXLyZXRApURqlvkYiKIzbzmioxfxQQVMcIKGbSCwnxjNFQgSGvbuoWlcKCkCRuJzZfnC(string string_0)
	{
		char[] result = default(char[]);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0 << -0) + 0 << 0) + 0 - (0 << 1) << 0) + 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0.ToCharArray();
					num = ((((((int)num2 + -1874950498) ^ -859104592) << 0) + 0) ^ 0) << 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) - 0 - 0 - 0) >> 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static string[] LEWqhllDpzDxrnQvOBxgxHVzHaETNKOzCDhbzLmcKHNlYMlEDoLxIhfdIwIhGsPFLeVNfPVdouvPUKBVPapzYqRuyesccfwrSizUQxzOtIjnLpjYVMrGdqGumApbwTaiYeXLkGerBAgqhDIiUugpNPnBBfHqhxsAHapHrxNpIZfCkqnJRhgcMLviQvkfZOkdiGIhnbQxGRHNKLrlRXyaqpNWFgQWnIpTPbuEHgvPqJwUeHyfdYnbpkNSSMCgkUjXCNYJqNDLBJJHTSRXILSounEFoCLVDpEvzysqJOPqvBAGAgYZUEyzcVCojsvObIhmeohvABoTVCTTNXfhDMaZQftEVehqtaoNunClYDztqEDzbJAlnnkpHivZUCzwtXzVogyAvTjanHJmBUDlDWdgQYflRDrwddZseIlVkaPtekcZzjxaZoSxUtepanISCMXjHqhSIIaD(string string_0, char[] char_0)
	{
		string[] result = default(string[]);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 - (0 << 1) + 0 - 0 << 0) - (0 ^ 0) - 0 - 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0.Split(char_0);
					num = (((int)num2 + -1874950498) ^ -859104592) - 0 + 0 >> 0 << 0;
					continue;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 + 0 + 0 - 0);
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static bool gKcFVfMIfrwOkCyLDVUXrXRrnSsicFrrnoqkqzuVAaMkpiZfSvoNNdliSLscNEFAZfBVloueBZxrkGbfTmpGqEDkdirFhrhWumlkGdTEbkmOFTXmKmjBoZjvCrSdWPXjRAXYvRyQsKFgrOE(string string_0, string string_1)
	{
		bool result = default(bool);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) << 0 + 0) ^ 0) - 0 >> 0) ^ 0) - 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0 != string_1;
					num = ((((((int)num2 + -1874950498) ^ -859104592) >> 0) ^ 0) >> 0) + 0;
					continue;
				case 1u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6 ^ 0) << 0) >> 0) ^ 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static string jkeVUiGHucPHpkQHlncXfWZQSNtiDuddOMITRTcblTCVFjjFCdtTpRznkncgOxeZZLTCCXPskaLmtekJDNGAbkOWnvIDRVmNOCVUqHcFnbIofnTgctCbRDYPXWpgomBpNYxRiqtWKbnaCzQaCCAxslVkEgWtrWqbztAhPbYMaGqQqYnxgpEMLdWCcmnbuaEOKlAiYJkAEOxMVfUGTymcrEqwxYfDOWsabBgexezxfdiWFjGXsGiVNCwfVeLZEGLHwxLtZPiPZPXowtQnshlhOwmyeaitszSyrAziymYCysWXEiICnyHwuET(string string_0, string string_1, string string_2)
	{
		string result = default(string);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) >> -0 >> 0) + 0 - 0 << (0 >> 1)) + 0 << 0)) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = string_0 + string_1 + string_2;
					num = (((((int)num2 + -1874950498) ^ -859104592) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 1u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6) + 0 + 0) >> 0) ^ 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	public NotificationManager()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) + (0 ^ 0) + 0) ^ 0 ^ 0) - -0 + 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5) - 0 - 0 - 0 >> 0;
			}
		}
	}

	static NotificationManager()
	{
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301852;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) - (0 << 1) - 0 - 0 << 0) + (0 << 1)) ^ 0) - 0)) % 13)
				{
				case 0u:
					break;
				default:
					return;
				case 8u:
					fwPYJvudEyhVYiptedJMSreVWfAIBfmfIFANzNfYpWNvNpGUCkLiZYXOsTcEULCzlcmsIBTrYLxWDIiHzGgquegKIMvGLAdDtojLcnmartknAakJKufoFmehVCKVgnFxHUCpzxFltfZaTSkHCMVqvPXhjcPADrUdNMGGyUjnPUVAndndrctuspcSWvfwIeHclVmglDjHCHAAUxUfOLiBXzLyKOJdONFKmSorQgRNSLSKOBXzAZHWWgeLjOwxUgSOcQobiCpHTuIlHbKjQkCOfIOgODicKtTLSdHYnWqYKZdBxSeidmHJEeJtbinFumXzAXtEtMWTTEdgFmIVyZYyMkhOuoWeJLDycDbAzzOrqNQaaCOPzrgunzNqPEkfPRkhaFdclivZlHhYthORzhFrFikDPKKVpJBzDIZuzLDqVhjGrPXIQtFIlTCRuAmByAJCfHuLhtr = 0.2f;
					num = (int)(((((num2 + 600520462) ^ 0xB95FCA4Cu) << 0) - 0 << 0) + 0);
					continue;
				case 5u:
					hyPPvkhcklJaIUypnTpTQuxfyrjdFAdMmSiYFRiUQOHTjrwhlZXhZTLMbKqeaewKiWNQMzKwLvdbNDWhUbRGCVNsgvXVBeULsXLmDGvLpBwEQJZxNjjZnPhnjuJqBOVGArJPSJDoFgrayiCxwAhsVVyCPydiWfjAGQdzajEdFUtgygOaSlUbHCLFSgZuGvrAWQuIfcwmWeMaCreJJcpLliTdeyGTjkwkCSkIMgVPOHeCQKdAcqLEfGoNWqDHvDcMHCxJhvWDhzWDdqntufRTySfVEwLvCotlFsVnmutGthwFKLJGcjmqLjnOxCeKKBaSgKYKvZhaMkzqvzlTMftsbdAwfgQKpIWShEzaMZkdcmDAJWtXqlXFhIRcjBEpjwKdoHjRakgNUqpOAZNjNStdKqKyMxQluVTGCzlc = true;
					num = (((int)num2 + -1219895373) ^ -1888826648) - 0 << 0 << 0 >> 0;
					continue;
				case 1u:
					NyYHcCkQWRomcQVbCqzwNsWBJrTkIDkjIHWKItjxQAmYXJRkIjgVstjvCxXLJZisGeEvTltigbFmgYDazJCywpQoxBhlvyOQsTrSfvqxQYPqOWpETXlaxJVrnpYsdhMHnOTmGLUesfIyzAAAmDrxnOtJXaFPxYtIlhdZdcXidhHraxRNPxgzQptzvkpGffGtLamrwAxjFjuggbIziRZaSURWNEESNrcXAoGakzqoZWTGUnstCPxnfGAQiqESWFwohwGRvIpIBLaWalcAllqXUOSU = true;
					num = ((((((int)num2 + -795116775) ^ 0x1DE16856) << 0) ^ 0) + 0) ^ 0;
					continue;
				case 6u:
					TawTScnpHQHANAeORjvcHYhLEtBZivMiGdLhVoezNNKANtjxkFkdctvUTKoyBohldyUKOXTCeVoUnGYkkdOClJfnHQokZFXzFzwozyJnLHYgeAHmMeoyzEausHcYIJDyXOpOkJLLuBRDKYihjcyUrzaazcVSvKEcdzjplTccsCdYNwJtyVOGlIhyOoohOTpJWOzlPSWqZvCPvbmdsBtAWXRvsLBWEUnzmubZWyEFZyHPgrcMclPmzPMZXeSerZLfhcCbangTXNBxqbobIOTsebZxHcbRGzoZMBHdObMPfVpLnpIVQRvCgsagdf = new HashSet<string>();
					num = ((int)(((num2 + 1709781230) ^ 0xDD653F6Au) - 0) >> 0) - 0 - 0;
					continue;
				case 10u:
					kCBnoXSBoHzxQxPGmzsiWomsXHBvOkARxzJzVTbxxyJXFQJlwqNDRPiVqjpGwxNdhIarNqLtyUKxEoNhXqYyxWZHqNiLDubaLGQWQsxgFtfWeKrbviJfypGkIsaZhZPeTKMXyQrESRTdRcDGvgqvKVBwZFoysxZFEaduYtDEQenHwDsFOuDaIttXjqYSCTmuSnyQYiHcDLFFIUZwmIJYUYXkHglIvKcXSSOieBGFMBwWOOooqBGTjoAUqnjRXYGTJHNQgRsLcdlsBawTSWsUejNEsTSQrOINUDngayizjUQgchspRqZbGMPzUjxmYBtnvxxYMpSuNSKjsHBkBCZbPGhhOOmRaWAHBDKFJuDByEoNbFgmInKvBrxOqqjXdauQsdIOWVAhZyClstgiHZjMlf = false;
					num = (((int)((num2 + 1259723679) ^ 0x76A738D2) >> 0) + 0 << 0) ^ 0;
					continue;
				case 2u:
					fjgWptkFyxjxvYXrqMMDwdPmwXjbqdRIEmXyIaGgXtZfbUXhlpJwZIIbuTzsjjpvFBTiazJpgGGceJlBZcPatvIWEVdOAoXNeEzzbOgMGuqtbGXLIYshtockTXEevUPSJSYzjLzkVduZfpUXYsgBVPuPCpGekcrLFyKjIyBWyimqUdfEcHgcOnWTyiXTfuaTLItGELpzRjcNDdUzkbcDVpXrBQKzBHQditEmJyZrrHlFkjquoxJdswXwKbfNaPYjsZEkzHQM = false;
					num = (((int)num2 + -434485547) ^ -534547490 ^ 0 ^ 0) - 0 << 0;
					continue;
				case 9u:
					KPrEUqtwbumKjqyMAkBHYVCwxdJUiGNFcpMmBUdqWmiYpwsqllefWVDOmUgRHzovGGHTElkFglKMMDhaKtIWBHJhMXZHOmIxXNrIPyLZazZLkQcJMfgoQrUZXAhGlDRUCnOYlzlmHJVcIXXVUqUIguGFTsKpqfNxIfiWcdxnTUHhvRqZCmLVIiNhGjfTPWVBVyuDPaTQTHOmNzjbbKMetSOzrbpSYEyXYflWxNkCtVcbtBuhZdRekQidKUlOKaSpiRnIomEozjKyPMgPGiTUMtMhWhmDBwStcNSCnMSMzDEbgKnYOvhBgYCPefLgaaMcrrvcTDBUphujOLbmUnOfpqmekdxiaMLzQBKOokekUmlZDtatdzlMmGNaerSQgtUDvVsmbmXJjElcfnARdeeAAYmkOJKWsoeAsIDIaNrQCBDHuKVQRaNbotcw = 5;
					num = ((((int)num2 + -1701687338) ^ -1567692513) + 0 >> 0) - 0 << 0;
					continue;
				case 3u:
					cKlodshsApkdYMLLvhBHtlqCIbmlEfVGHXbIlJssUNnKEVlFnTPrfisRuJFcfWNuuEvaLdzLOjNFXFXMQGXLqDByEjnCdqmXZSqaAkUktdCWvNTPLTmyZcdQcWwBPXHyWPGfoWmFMMrmaEdRqyRkeNXXOzXDOsvwweZFhOAOGGMnKRPySElrgwuiSIqPYIRuqVQWExKBYcDxbKnXJzKjheqaKQNyxLQYPsWPaTTvUJtdSWhhusfzXHnmEQlOKldnmFIJNyWPGppxLmhOJFdfFqaheKkkHfKIFgRnnxuWvpSHsPBsIxefhYHVEBEdnLiBFGSFuTAllhJpytOpiSBkaFBGyWIMT = Color.black;
					num = (((((int)num2 + -733318432) ^ -226576902) >> 0) + 0) ^ 0 ^ 0;
					continue;
				case 11u:
					YLwiAEzHXyBATnTjAFjBoEgtANqcGFCaNRCcmKWSuMmTzDnBteuwmAwuFdHNnwbrWBNcLRWPIrgBrmUXAPIBkfNnuhxjdjEXLUXXPkQChENVtVdsiKnyNzhQNAIDtMMzMiQxpWhpZgtFrSTzeebtWgklNgjpCmivSoileFdmCXzHfBzVHiypLtCGYEKjMRMMXYNdJHuybOQYHCflGoItOTJzMCnAVTzLlMKhNwlZOaoWCEYvyyCyjsXdooqguTChpfMUSYykcJFOFNWiERbxrbCTOGSzffEUxhHxReCzarvzNjyBsiCDRfPnDTfmfYfXeKqyfyqzpCxZGcfEhrhWCbcsruUXYpubmxvc = false;
					num = (int)(((((num2 + 900749756) ^ 0xF6F7C413u) << 0) - 0 + 0) ^ 0);
					continue;
				case 12u:
					FTgukdQFtUoTDZNtNPCDaElgTaJKrkHQZPhljmZYTwTpHvezrCPLmPuaIZAktgoinxUOSBjAPEJDLVyxVkt = 110;
					num = (((((int)num2 + -678915685) ^ -1534661159) + 0) ^ 0) + 0 + 0;
					continue;
				case 4u:
					OvWDkugDjLPENiLcjBpHPsoVIfRpMAdpjMzMrUJtMYaOaZWvZToVFDEvgaVeDQQJIzvaIYLpSWUQsAVIivpSlhJGieGqZEPVhqfAEVMbiZdJINcGfmWiBXxBQPSEsuqngZJcuuenJoKmdaYubZlNIHujSEKPdiINJQCIeamLhJymnlyQRxCtjDEyFzjQJpjAFXCnxpqaMzFZihWHfUYFFpDglddFRwbSzYGpIksBhCGJXFqxCB = 110;
					num = (((int)num2 + -1186296972) ^ 0x47F02263) - 0 + 0 + 0 >> 0;
					continue;
				case 7u:
					return;
				}
				break;
			}
		}
	}
}
