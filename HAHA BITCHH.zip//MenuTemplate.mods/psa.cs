using GorillaLocomotion;
using UnityEngine;

namespace MenuTemplate.mods;

internal class psa
{
	public static void zOQitbknJTkGbeSyKPOHhgtosHwxhCmHsQlsfzCHChNVVIqZxDAQDfDsvCPMFNggHCokTAskmhfatxsKrxZEcwdmnSXDJPbObGosuffXlpDwaDZXjeviNBekzbXaDOBwgqYMiaqlrctNSGmJTZuEuSazCdSshftwNgqJFmOjOjRKiqrSOohEuWcnpykfhXdmJWZM()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 - (0 << 1) << 0 << 0) - 0 >> (0 ^ 0) << 0) ^ 0u) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = (int)((((num2 + 414745695) ^ 0xB4411D0Bu ^ 0) << 0) - 0 - 0);
					continue;
				case 5u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.forward * Time.deltaTime * 8f;
					num = ((((((int)num2 + -907893453) ^ -466987124) << 0) - 0) ^ 0) << 0;
					continue;
				}
				case 3u:
					num = ((((int)num2 + -344833909) ^ -305432172) << 0) + 0 >> 0 << 0;
					continue;
				case 2u:
					num = ((((int)num2 + -248958683) ^ 0x1C939554 ^ 0) << 0 >> 0) + 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public static void qDeGkkQkbqrmMaETXPcRedtgcJbQgEblqFBljAujfRlZgXsgtjoUUiHnjXEAjZexogVgysKxvSLnRtaeqUxWqhqiYoclWTafMOLacmIazRycwtvPXAjoCiggPMikqyBBSGBdIZcemxwzIoMESmovKMDDHElpeyKbqXkQSrhYyfbfLHyAaDrejfRgcXvdNMZOMviKeWLAeqXFKyRagKoAgGRkgeNVWekLfnsqyNweRQZThlvDfvXdxzHgDY()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0) ^ 0) << 0 >> 0) + 0 + (0 ^ 0) >> 0 << 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((int)(((num2 + 414745695) ^ 0xB4411D0Bu) - 0 - 0) >> 0) + 0;
					continue;
				case 5u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.forward * Time.deltaTime * -8f;
					num = (((((int)num2 + -907893453) ^ -466987124) + 0) ^ 0) >> 0 << 0;
					continue;
				}
				case 3u:
					num = ((((int)num2 + -344833909) ^ -305432172) >> 0) - 0 + 0 << 0;
					continue;
				case 2u:
					num = ((((int)num2 + -248958683) ^ 0x1C939554) << 0) - 0 >> 0 >> 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public static void EaiQEafmAxgBBsokIqGXdUIjPAghnFFlMAjwWblZOULYxEUEPnQrAGUJrYaeUYYUSUOajRnHfHjijKLlFBsZPoLgGzeXageQVRgDPTvXajmSwLAGmPzsFZfDiIuJMpGYCtnrEivLfvZFbTJUZxLlHMkWLCvhzMkKCnpdyicetNmkZzCpYzKoEvrQiqFcMomtkpcODFwQvGRTzZXmafiZcVfhWzUiCareATaJwNLsdTTYDxqjstbGgnrokVReKoouoNsGZnPmuPWicgDyiLPjYKYnBLzBWHIOEyJQeKjeEPmqqimdrsVYyewEOefnOnqMhhDDxNuyCLEiyIXszvkDMJqAcfcZFWqqzziiEIGEYwwNAnffhMOsdNayRdBrKuTGuoJYzOORPFEqmCZOZWSShXnMzKqAg()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) << (0 >> 1) << 0 << 0 << 0 << (0 ^ 0)) + 0 + 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = (((int)((num2 + 414745695) ^ 0xB4411D0Bu) >> 0) + 0 + 0) ^ 0;
					continue;
				case 5u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.up * Time.deltaTime * 8f;
					num = ((((int)num2 + -907893453) ^ -466987124) + 0 + 0 << 0) ^ 0;
					continue;
				}
				case 3u:
					num = ((((int)num2 + -344833909) ^ -305432172) << 0) - 0 - 0 >> 0;
					continue;
				case 2u:
					num = ((((int)num2 + -248958683) ^ 0x1C939554) >> 0) - 0 - 0 - 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public static void pTECQslDhGtYWCyiKmpdMrOCayxbXyPxnKALZNvjOkRqyUluPDPxbwtXfcBsVkGJQVKlcMiWQfpBzydgmcmtJrwQrCGXmdnDEizDkZscuSHVhRxHYvfTYnayzUUzflKNRLXrYzWnKjYQKAJzeZYQXuFqiaepeSXjiTdvUgIyzSjOojOYkvvfmTQxfHiXvGiRmOHQxnFYrArekRbYmffIxRXpdGpnXKcTJrCzCYBXQwOMBLmoFkLqAzuuRsMQXraGxyvToBwoEiSaclNstbHNZMsjWhIjlKZywiodqtZdOwMsHusGFuxWKmGKglWgTmcTitDUWKbabEZCaZCCPcDRmcOkBEWewSjBuSjoQxJVsxVfmeJhJtrRJlGgFtsrNXDivyiiPnLrsIzPgJXwVPvdBsSjmdIxeshvUNKOWBsvIZzaMRZVvWwYBAGcGYWLFnmZAdVtYiAtwZuCSRwudMciVjTtgHiXFGQuMzzIV()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0 << 0 + 0) + 0 >> 0) - 0 + (0 >> 1) + 0 << 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((int)(((num2 + 414745695) ^ 0xB4411D0Bu) - 0 << 0) >> 0) - 0;
					continue;
				case 5u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.right * Time.deltaTime * 8f;
					num = ((((int)num2 + -907893453) ^ -466987124 ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				}
				case 3u:
					num = ((((((int)num2 + -344833909) ^ -305432172) << 0) + 0) ^ 0) >> 0;
					continue;
				case 2u:
					num = ((((int)num2 + -248958683) ^ 0x1C939554) >> 0 << 0 >> 0) ^ 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public static void GXmvcBBfekOCBISleerkBnqaDOQjaPtrOzxPPNSHrobxtveXYiIuiyusGlSoKsepQwNbkcvqlJSmlTHhKSlRgYjqeejDUEXYkMHWHcMVMrjyFhgMEKERhmiRnxXgTSwHMTczmKAHfpfPPKLWYwZkZfRXDPJkfGcUVBMLfHATkWMShtcCMaixSmIHcfVwaqCzmkUnYaRqVfZcsZPkNhyeyFbJTeIZLdTUumFXzODLiRBNmFodpLJSRxaHikuUrSFRmfIgtSLYEMWHdownQFJatacWmYOotJuqlKBgWiJxZLofBsDUNgdLiFxlcMTvdxFVrGwtNqqHWmaILXvTuUAmFIiGmpdkootCgtNUWkgxPvPVEPAfqaajWspJyPhxmgtHSyCsjAWkNcwjSmbwPYUookFN()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0 << (0 << 1)) + 0 + 0 + 0 >> (0 >> 1)) + 0 + 0)) % 6)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = (int)(((num2 + 414745695) ^ 0xB4411D0Bu) + 0 - 0 - 0 << 0);
					continue;
				case 5u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.right * Time.deltaTime * -8f;
					num = ((((int)num2 + -907893453) ^ -466987124) >> 0 << 0) - 0 << 0;
					continue;
				}
				case 3u:
					num = ((((int)num2 + -344833909) ^ -305432172) - 0 >> 0 >> 0) + 0;
					continue;
				case 2u:
					num = ((((int)num2 + -248958683) ^ 0x1C939554) + 0 - 0 << 0) + 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	public psa()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 << (0 << 1) << 0) + 0 - 0 - (0 ^ 0) >> 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) + 0 << 0) - 0 - 0;
			}
		}
	}
}
