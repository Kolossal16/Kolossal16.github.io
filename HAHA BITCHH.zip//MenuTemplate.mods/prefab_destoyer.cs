using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;

namespace MenuTemplate.mods;

internal class prefab_destoyer
{
	public static void bWqVqKpdZencDvbLaYENpFhGIkzgLlxtTYcbGvmqqUygjdxXpPlDCjsvOKmgkirOGTjEtZeELnxvhbwEMBRWaURJFGmWigfh()
	{
		Player current = default(Player);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num ^ 0) + (0 >> 1) - 0 >> 0) ^ 0u ^ 0 ^ 0u ^ 0u) % 3)
				{
				case 0u:
					break;
				case 1u:
					goto IL_0049;
				default:
				{
					IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerListOthers).GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 600520461;
								num4 = num3;
							}
							else
							{
								num3 = 414745696;
								num4 = num3;
							}
							int num5 = (((num3 << 0) - 0) ^ 0) - 0;
							while (true)
							{
								switch ((num2 = (uint)(((num5 ^ 0) << -0 << 0) + 0 - 0 - (0 ^ 0) >> 0) ^ 0u) % 9)
								{
								case 0u:
									num5 = 414745696;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (0x54C7FBE3 ^ 0) - 0;
									continue;
								case 8u:
									num5 = (((((int)num2 + -2130437817) ^ -1674661881) - 0 >> 0) + 0) ^ 0;
									continue;
								case 5u:
									break;
								case 2u:
									PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
									num5 = ((((int)((num2 + 359659174) ^ 0x19A887F2) >> 0) + 0) ^ 0) - 0;
									continue;
								case 3u:
									PhotonNetwork.DestroyPlayerObjects(current);
									num5 = (((int)((num2 + 1621957012) ^ 0xD68E0493u) >> 0 << 0) ^ 0) >> 0;
									continue;
								case 4u:
									num5 = (int)(((num2 + 647071759) ^ 0xC794F635u) << 0) >> 0 << 0 >> 0;
									continue;
								case 7u:
									num5 = (int)((((num2 + 428697817) ^ 0x2C9F755) + 0) ^ 0 ^ 0) >> 0;
									continue;
								case 6u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_0243:
								int num6 = 750340745;
								while (true)
								{
									switch ((num2 = (uint)((((((num6 ^ 0) + -0 - 0) ^ 0) << 0) ^ 0) - 0 >> 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0248;
									case 1u:
										enumerator.Dispose();
										num6 = (((int)num2 + -1284218664) ^ -1231992842) - 0 << 0 >> 0 >> 0;
										continue;
									case 3u:
										num6 = ((((int)num2 + -1127256878) ^ 0x3B16CB27) << 0 >> 0) - 0 - 0;
										continue;
									case 2u:
										goto end_IL_0248;
									}
									goto IL_0243;
									continue;
									end_IL_0248:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_0049:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 << 0 << 0) ^ 0;
			}
		}
	}

	public static void CKzpUSEqKGSoMWoNoItJrvOLczZMNivEipTwBhJTXAltcCXJrzHANvPgVOnvTRCBknfwdRlhYzMQjuJzCqvnAVRMzMANToafYKiOxBFzoABnJZXAfNTDwpbpwtWrqynKzGSzmUcbKVZZuDdAPaIfvwJIJTsdEojPnQOdgxokLRSBpbUSqvBqPhodWjQsBYwwMjMDPZurLxuDDitHYzNiMSZfCKgWHWJMvwPfordqbkFsNL()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 >> -0 << 0) + 0) ^ 0 ^ -0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				case 1u:
					goto IL_0049;
				default:
				{
					IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerListOthers).GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 600520461;
								num4 = num3;
							}
							else
							{
								num3 = 414745696;
								num4 = num3;
							}
							int num5 = (((num3 << 0) ^ 0) >> 0) ^ 0;
							while (true)
							{
								switch ((num2 = (uint)((((num5 >> 0) - (0 << 1) << 0) - 0 >> 0 >> -0 >> 0) + 0)) % 9)
								{
								case 0u:
									num5 = 414745696;
									continue;
								default:
									return;
								case 1u:
								{
									Player current = enumerator.Current;
									num5 = (1422392291 << 0 >> 0) + 0 - 0;
									continue;
								}
								case 8u:
									num5 = ((((int)num2 + -2130437817) ^ -1674661881) + 0 >> 0 >> 0) - 0;
									continue;
								case 5u:
									break;
								case 2u:
									PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
									num5 = (int)(((((num2 + 359659174) ^ 0x19A887F2) - 0 << 0) ^ 0) + 0);
									continue;
								case 3u:
									PhotonNetwork.DestroyPlayerObjects(PhotonNetwork.LocalPlayer);
									num5 = ((int)(((num2 + 1621957012) ^ 0xD68E0493u) - 0) >> 0 << 0) ^ 0;
									continue;
								case 4u:
									num5 = (int)(((num2 + 647071759) ^ 0xC794F635u) + 0 + 0) >> 0 >> 0;
									continue;
								case 7u:
									num5 = (int)(((num2 + 428697817) ^ 0x2C9F755) + 0 - 0 << 0 << 0);
									continue;
								case 6u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_0247:
								int num6 = 750340745;
								while (true)
								{
									switch ((num2 = (uint)(((num6 ^ 0 ^ 0) + 0 >> 0) + 0 - (0 ^ 0) - 0) ^ 0u) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_024c;
									case 1u:
										enumerator.Dispose();
										num6 = (((((int)num2 + -1284218664) ^ -1231992842) + 0 >> 0) + 0) ^ 0;
										continue;
									case 3u:
										num6 = ((((int)num2 + -1127256878) ^ 0x3B16CB27) + 0 << 0) + 0 << 0;
										continue;
									case 2u:
										goto end_IL_024c;
									}
									goto IL_0247;
									continue;
									end_IL_024c:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_0049:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) - 0 - 0 + 0 << 0;
			}
		}
	}

	public prefab_destoyer()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 << (0 >> 1)) + 0 + 0) ^ 0) - -0 >> 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) - 0 << 0 << 0 >> 0;
			}
		}
	}
}
