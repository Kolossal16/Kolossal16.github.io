using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modzs;

internal class spazz_cosmets
{
	public static void qwUvzKtPGBIGYKCXOCcmEyYrSiCCIaHSZZhWPCyErbnhsjIpkNGOfpWSxCCqiRgGTQGZDFhmexUDkQYIAmrVtTNKcpynahwAVHoCDIMFGuKHutHHDTQWAlmadVWohTlWbuIDCwfRAMoYifqIIQKgrzaKunzHMyxMiOGaLdfgNZwOWoRXFoFqjfEBuXjoXxfboCQuzqXELDssdmNgvBcyShCdjeFNUQjqTuzuyxyoqbEGMmyikcSvvHjhZMkvKjJVtcyJMtIXdOhQCWrWFxDRXNVmksuLndDgrJmJOPvQuUsGAsFdunPmGSXGhlyuZWKZkazSJIiQbMxduoMSMqqZoqAzMGBCqbRyktwzTNuMfYlTuTlTzGHIFKLTzZfcgFzaVYSbRmZZWDUpfGeSvHdKuiSAHDZTHsGzylYwbjbmHHMbPvNTVmHyCP()
	{
		GameObject[] array = default(GameObject[]);
		GameObject[] array2 = default(GameObject[]);
		int num6 = default(int);
		int num3 = default(int);
		bool flag2 = default(bool);
		bool flag = default(bool);
		bool flag3 = default(bool);
		bool flag6 = default(bool);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		while (true)
		{
			int num = 1758301863;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0 + (0 >> 1) >> 0) ^ 0) >> 0) + (0 << 1)) ^ 0) << 0)) % 22)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					array = (GameObject[])(object)new GameObject[3]
					{
						GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf61c\uf62a\uf639\uf62f\uf639\uf624\uf629\uf62e\uf602\uf63f\uf62e\uf626\uf609\uf63e\uf63f\uf63f\uf624\uf625", 1859909195, true)),
						GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("푉푿푬푺푬푱푼푻푗푪푻푳표푫푪푪푱푰퐾퐶퐯퐷", 1906693150, true)),
						GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䨗䨡䨲䨤䨲䨯䨢䨥䨉䨴䨥䨭䨂䨵䨴䨴䨯䨮䩠䩨䩲䩩", 636963392, true))
					};
					num = (int)((((num2 + 428697817) ^ 0xB79DF86Du ^ 0) - 0 << 0) ^ 0);
					continue;
				case 11u:
					num = ((((((int)num2 + -649986417) ^ 0x1A456150) << 0) ^ 0) - 0) ^ 0;
					continue;
				case 7u:
					array2[num6].GetComponent<WardrobeFunctionButton>().ButtonActivation();
					num = (int)((((num2 + 202644353) ^ 0xADB73E4) + 0 - 0 + 0) ^ 0);
					continue;
				case 17u:
					num3 = Random.Range(0, array.Length);
					num = (int)(((((num2 + 2106842273) ^ 0xA8D90E2Bu) << 0) - 0 - 0) ^ 0);
					continue;
				case 5u:
					flag2 = Object.op_Implicit((Object)(object)array2[num6].GetComponent<WardrobeFunctionButton>());
					num = ((((int)num2 + -1950096023) ^ -1366620891 ^ 0) >> 0) - 0 - 0;
					continue;
				case 16u:
					flag = flag3;
					num = ((int)(((num2 + 1047830633) ^ 0x9A7FED21u) - 0) >> 0 >> 0) + 0;
					continue;
				case 1u:
					flag6 = Object.op_Implicit((Object)(object)array[num3].GetComponent<GorillaPressableButton>());
					num = (((int)num2 + -1125345364) ^ -934347535) - 0 - 0 + 0 >> 0;
					continue;
				case 8u:
					num = (((int)(((num2 + 1448286972) ^ 0x28AED1E3) + 0) >> 0) ^ 0) << 0;
					continue;
				case 12u:
					flag5 = flag6;
					num = (int)(((num2 + 1952503976) ^ 0x92E4E18Cu) << 0) >> 0 << 0 >> 0;
					continue;
				case 4u:
					array2 = (GameObject[])(object)new GameObject[1] { GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("፬ፚፉ\u135fፉፔፙ\u135e፩ፒ\u135cፓፏ፲ፏ\u135eፖ", 1405293371, true)) };
					num = (1802649741 - 0 >> 0 << 0) + 0;
					continue;
				case 13u:
					num6 = Random.Range(0, array2.Length);
					num = (int)((((num2 + 660359990) ^ 0xB105BCC6u ^ 0) - 0) ^ 0) >> 0;
					continue;
				case 14u:
					flag4 = flag5;
					num = ((((int)num2 + -814951907) ^ -45083519) - 0 >> 0 >> 0) + 0;
					continue;
				case 15u:
					flag3 = flag2;
					num = (((((int)num2 + -11084362) ^ 0x50C18C1F) << 0) + 0 + 0) ^ 0;
					continue;
				case 2u:
				{
					int num7;
					int num8;
					if (flag4)
					{
						num7 = 1406940791;
						num8 = num7;
					}
					else
					{
						num7 = 1463124800;
						num8 = num7;
					}
					num = ((((num7 >> 0 << 0) ^ ((int)num2 + -295483064)) << 0) ^ 0) >> 0 << 0;
					continue;
				}
				case 6u:
				{
					int num4;
					int num5;
					if (flag)
					{
						num4 = -1263230817;
						num5 = num4;
					}
					else
					{
						num4 = -1410659884;
						num5 = num4;
					}
					num = (((num4 >> 0 >> 0) ^ ((int)num2 + -365853555)) << 0) + 0 << 0 >> 0;
					continue;
				}
				case 18u:
					num = (((int)((num2 + 414049813) ^ 0x36ED84A) >> 0 >> 0) - 0) ^ 0;
					continue;
				case 19u:
					num = (((((int)num2 + -517084339) ^ 0x7C17420F) >> 0) ^ 0) + 0 - 0;
					continue;
				case 20u:
					num = (int)(((((num2 + 2008734093) ^ 0xFB44A87Du) + 0 << 0) + 0) ^ 0);
					continue;
				case 3u:
					array[num3].GetComponent<GorillaPressableButton>().ButtonActivation();
					num = ((((int)((num2 + 1464826632) ^ 0xE7C83C0Bu) >> 0) + 0) ^ 0) - 0;
					continue;
				case 10u:
					num = ((int)((num2 + 2029155507) ^ 0xCEC5A1FAu ^ 0) >> 0) + 0 - 0;
					continue;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	public spazz_cosmets()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) + (0 << 1) >> 0) ^ 0) >> 0) + (0 + 0) << 0) + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 - 0 + 0) ^ 0;
			}
		}
	}
}
