using GorillaLocomotion;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace Popeye.Menu.modzs;

internal class Platforms
{
	public static bool KuYteUwjQgvkQVEAAmxtYupjvUWqVezpGTeEqFjjIgWUPgUnvAEkImepeOYkYfnMHgDXRZjUdnKRxvuoaIVvAoGtOOABHZlDSkm = false;

	public static GameObject ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa;

	public static bool BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt;

	public static GameObject AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF;

	public static bool jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ;

	public bool leIYTgzKExvfxPPldHTwLrgLpTCUsvxSOGOrGwvKLdCGCKEeomWWDUfUXXIZEEsjaDrQbxFHliLIPziEpyFfyAoTBUtIOvggKtGZtOdRHoKujxfxOdKfYnKzoxphdWTQcEXvTjlBvOyjPTKdOVUKKahxIgKWyWNKvUsEzJEESjKkPAJuMlsicifbxANNzoczbNOVBgEfrpSBqXHhwpkmEEHnPrhYVQfDhlibMOTFHmQ;

	public bool NpELzSFqjePUwgAgkZFjBjptePGvIwEFrOUXkFHfqzWzrqLUlHIGbcpDakGKmjIMzjDImDVErATbnPcOdMjaNXEpzqXaZXTgRjZhNdIIMepAjnqkiRGzaHZBFniWFVEtGMjdQUbadBoIIdglZMShqtgkkxCzULcQzVUwenunQGwysqTBhXWTcxdmGYStsBfsyyjNjJhMsFrJXHSUEarXPjNcSHQfubUoBd;

	private static Color aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib;

	private static Color bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu;

	private static float MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ;

	private static float gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr;

	public static void jpUcEtxLhxVYojDCwsqCPuQSdbExgdKvngJdgDpEHtRTnBZfGxheCiBPybZDPZEeNAKizzvTcMVvCWEBbyRJVFTfEUEfDMPHOMgNQRFgbocPmgmCwxBriVjhGFDFVqppWnHPQRLjSKIHDeSyIcIgkyyTDYhloalKYMSYywLFMsyynBDCMeWSHjfyPNmRJAVRyXIQlTZmqdtSZaGcuFyjdscPHujKkUWlxHZpSNqTfKBEPmzOhjwdcLNfUTjQJobwhiurbqjHoFetRyZuVvDaxSjLTTuZEAjQIfxHShMQaOOwHuowUOVoLbYoYJyiWkdOvnKLbsCNIMZIdMezEXfPEVeGgiJiJEUQKabtKCuBmiFZcqklEZDYeokAjdFSItedSiXdLKObCDDwpfEQYxEJbVLwPBkGXBSSdBgTsgzUkCvBLNkdyPUlPucWxBokAieaKKtOYLxRYJzyzj()
	{
		//IL_11de: Unknown result type (might be due to invalid IL or missing references)
		//IL_151e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1532: Unknown result type (might be due to invalid IL or missing references)
		//IL_1537: Unknown result type (might be due to invalid IL or missing references)
		//IL_14c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d3: Expected O, but got Unknown
		//IL_0f19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c36: Unknown result type (might be due to invalid IL or missing references)
		//IL_1346: Unknown result type (might be due to invalid IL or missing references)
		//IL_141c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1430: Unknown result type (might be due to invalid IL or missing references)
		//IL_1435: Unknown result type (might be due to invalid IL or missing references)
		//IL_1469: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f86: Unknown result type (might be due to invalid IL or missing references)
		//IL_16a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_16a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_16b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_17e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17f6: Unknown result type (might be due to invalid IL or missing references)
		bool flag8 = default(bool);
		bool flag3 = default(bool);
		bool flag9 = default(bool);
		bool bcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt = default(bool);
		bool flag7 = default(bool);
		bool flag4 = default(bool);
		bool flag6 = default(bool);
		bool flag10 = default(bool);
		bool flag5 = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301851;
			while (true)
			{
				uint num2;
				int num7;
				switch ((num2 = (uint)(((((num + 0 << 0 + 0) ^ 0) >> 0 >> 0) + -0 << 0) - 0)) % 100)
				{
				case 0u:
					break;
				default:
					return;
				case 51u:
					flag8 = !LbqghiHHdIykwRSptbyuRbuweNrdnfVDwnQmTtaVtcGKpOoGZIqxaesJHUcuQDuYNVNjaGvabCaOuKgpzKeEOxDrUgEZrGfQHIXubfFsnqvyeDpWNMUfzQjpsvoUbwIvwkgMNMoueLqybenqQIlELZrRzHcGQLrRHabTxDjbyAaNzKonhYdtleJwTpnfKIDtuzQactTnyjfkZDrOtOySHYFCqFahqdrQWGtaTnkNeQUbZyxpYyMVjLMwToKxtLXuSpnskrUfELNQdEDRhLjRqvHlUWgFDMutTziKleeGEGryYVspKSqHCgdxHcynloCRquXDwTGcHCmKeimYERULwNQMwLciGQvpezhEXOSRlnZZTttyPzJttRvDDkhLRyvRhWFEbIaPYdziNRTcsDsggbWmeEbMHhZMRiRWNOxhzUvprmQLrftogpKfatAxGniQeNrFZXoDfkHmGGVRNqvCOLGCxMVunaAlMFl((EasyHand)0);
					num = (((((int)num2 + -661434340) ^ 0x74A7D140) << 0 >> 0) ^ 0) << 0;
					continue;
				case 21u:
					Object.Destroy((Object)(object)AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF);
					num = (int)(((((num2 + 423662557) ^ 0x28878B60) - 0) ^ 0) - 0 + 0);
					continue;
				case 17u:
					gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr = 0f;
					num = (int)(((num2 + 1641116637) ^ 0xAD0C57DAu ^ 0 ^ 0) - 0) >> 0;
					continue;
				case 99u:
				{
					int num18;
					int num19;
					if (flag8)
					{
						num18 = 573235386;
						num19 = num18;
					}
					else
					{
						num18 = 442643470;
						num19 = num18;
					}
					num = (int)(((uint)((num18 >> 0) ^ 0) ^ (num2 + 65139428) ^ 0) << 0) >> 0 << 0;
					continue;
				}
				case 29u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.transform.position = Player.Instance.rightHandTransform.position + new Vector3(0f, -0.02f, 0f);
					num = ((int)(((num2 + 1795250812) ^ 0xE5212E3Cu) + 0 - 0) >> 0) - 0;
					continue;
				case 84u:
					flag3 = gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr >= MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ;
					num = (((int)(((num2 + 1289406471) ^ 0x93CDDEB5u) - 0) >> 0) ^ 0) + 0;
					continue;
				case 1u:
					num = (int)(((num2 + 480410679) ^ 0x2818D82A) << 0 << 0) >> 0 >> 0;
					continue;
				case 19u:
				{
					int num22;
					int num23;
					if (flag9)
					{
						num22 = 1247783409;
						num23 = num22;
					}
					else
					{
						num22 = 604191507;
						num23 = num22;
					}
					num = (int)((((uint)(num22 - 0 << 0) ^ (num2 + 801094901)) + 0 + 0) ^ 0) >> 0;
					continue;
				}
				case 70u:
					bcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt = BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt;
					num = ((int)(((num2 + 1127294952) ^ 0x4514119C) + 0 - 0) >> 0) - 0;
					continue;
				case 24u:
					flag7 = !jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ;
					num = ((((((int)num2 + -1597822473) ^ -1620721106) >> 0) ^ 0) << 0) + 0;
					continue;
				case 26u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (((((int)num2 + -1375998384) ^ 0x1A9512E0) >> 0) - 0 << 0) + 0;
					continue;
				case 82u:
				{
					int num14;
					int num15;
					if (bcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt)
					{
						num14 = 1222003462;
						num15 = num14;
					}
					else
					{
						num14 = 4227532;
						num15 = num14;
					}
					num = ((int)(((uint)(num14 + 0 << 0) ^ (num2 + 972230654)) - 0) >> 0 >> 0) - 0;
					continue;
				}
				case 31u:
					num = (int)(((num2 + 1445458486) ^ 0xB4B3C69Fu) - 0 << 0) >> 0 << 0;
					continue;
				case 2u:
					num = (int)((((num2 + 1281213068) ^ 0x31D1BD38) + 0 << 0) - 0 << 0);
					continue;
				case 36u:
					num = (147724790 >> 0 << 0) - 0 >> 0;
					continue;
				case 38u:
					num = ((((((int)num2 + -31637279) ^ 0x7CDF7690) >> 0) - 0) ^ 0) - 0;
					continue;
				case 46u:
					Object.Destroy((Object)(object)ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa);
					num = (int)((((num2 + 1892787482) ^ 0x8C7B0407u) << 0 << 0) - 0) >> 0;
					continue;
				case 45u:
					num = (1638432318 >> 0 << 0 >> 0) + 0;
					continue;
				case 3u:
					num = (int)((((num2 + 1285777375) ^ 0xD07C10F0u ^ 0) - 0 << 0) + 0);
					continue;
				case 50u:
					flag4 = jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ;
					num = ((((int)num2 + -1335664287) ^ -32631453) << 0) + 0 + 0 + 0;
					continue;
				case 58u:
					BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt = false;
					num = ((((int)num2 + -1845072895) ^ -1473660572) - 0 << 0 << 0) ^ 0;
					continue;
				case 22u:
					jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ = false;
					num = ((((int)num2 + -1306596231) ^ -1618022093) + 0 - 0 << 0) - 0;
					continue;
				case 57u:
					num = (1964931023 << 0) + 0 + 0 >> 0;
					continue;
				case 63u:
					num = (int)(((num2 + 1254180769) ^ 0xE4372731u) + 0 + 0 - 0 - 0);
					continue;
				case 62u:
					num = ((int)(((num2 + 690828566) ^ 0x33DA7A55) + 0) >> 0) - 0 - 0;
					continue;
				case 4u:
					num = (0x6B7240AF ^ 0) - 0 << 0 >> 0;
					continue;
				case 67u:
					num = ((((int)num2 + -102181810) ^ 0x1483983A ^ 0) << 0) - 0 >> 0;
					continue;
				case 28u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.transform.localScale = new Vector3(0.28f, 0.015f, 0.38f);
					num = (int)(((num2 + 223300307) ^ 0x55EFFBC0 ^ 0) - 0 + 0 - 0);
					continue;
				case 75u:
					num = (int)((((num2 + 951933518) ^ 0xF2F22CEAu) + 0 - 0 - 0) ^ 0);
					continue;
				case 74u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.transform.rotation = Player.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					num = ((((int)num2 + -321972126) ^ 0x36490A12) >> 0) + 0 >> 0 << 0;
					continue;
				case 5u:
					num = 0x104197F ^ 0;
					continue;
				case 79u:
				{
					int num24;
					int num25;
					if (flag6)
					{
						num24 = -549053388;
						num25 = num24;
					}
					else
					{
						num24 = -1075861446;
						num25 = num24;
					}
					num = (((((num24 ^ 0) + 0) ^ ((int)num2 + -1707244019)) + 0 << 0) ^ 0) + 0;
					continue;
				}
				case 33u:
					num = ((((int)num2 + -403027851) ^ 0x3C341F05) - 0 - 0 + 0) ^ 0;
					continue;
				case 87u:
					flag10 = !BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt;
					num = (((((int)num2 + -680051953) ^ -1998573662) + 0) ^ 0 ^ 0) + 0;
					continue;
				case 35u:
					gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr = 0f;
					num = (((int)((num2 + 1063192765) ^ 0x72C00484) >> 0) + 0 << 0) + 0;
					continue;
				case 92u:
				{
					int num20;
					int num21;
					if (!flag10)
					{
						num20 = -1695268489;
						num21 = num20;
					}
					else
					{
						num20 = -361592888;
						num21 = num20;
					}
					num = (((((num20 >> 0) + 0) ^ ((int)num2 + -1367214466)) << 0 >> 0) ^ 0) - 0;
					continue;
				}
				case 91u:
					if (EasyInputs.GetThumbStickButtonDown((EasyHand)0))
					{
						num = (0x26C34785 ^ 0) >> 0;
						continue;
					}
					num7 = 0;
					goto IL_1853;
				case 6u:
					num = (((int)num2 + -1814704727) ^ -498065552) + 0 - 0 + 0 << 0;
					continue;
				case 96u:
					num = ((((int)num2 + -893335959) ^ 0xD153D6A ^ 0) + 0 >> 0) + 0;
					continue;
				case 40u:
					num = (int)(((((num2 + 1616842019) ^ 0xD8CD6FD6u) << 0) ^ 0) + 0) >> 0;
					continue;
				case 43u:
					aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib.a = 0.5f;
					num = ((((int)num2 + -1506364251) ^ -1847490129) << 0) - 0 << 0 >> 0;
					continue;
				case 44u:
					num = (int)(((num2 + 359358379) ^ 0x6B9934E2) + 0 << 0 << 0 << 0);
					continue;
				case 7u:
					bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu.a = 0.5f;
					num = (int)((((num2 + 1241846950) ^ 0xCCA86931u) << 0) + 0 + 0 + 0);
					continue;
				case 18u:
					num = ((0x56DDB617 ^ 0) << 0) + 0 - 0;
					continue;
				case 47u:
					flag9 = !EasyInputs.GetGripButtonDown((EasyHand)1);
					num = (0xF4003CF ^ 0) << 0;
					continue;
				case 48u:
					ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa = EVlLtQPiVHyzuyJJqSFbsgOhnbUqfJwAbuqVCEbMZDLVZnAWEqktgDTxhdyrWyclkXxahNgMQTcPvTiZBYLOzduyATOzgJQAAzKbPzORkxCmAeboUyQXNoLhDZAoYH((PrimitiveType)3);
					num = (((((int)num2 + -1398681650) ^ 0x342D910E) >> 0) - 0 >> 0) ^ 0;
					continue;
				case 49u:
					num = (int)(((num2 + 1193581778) ^ 0xF1E57B09u) - 0) >> 0 << 0 << 0;
					continue;
				case 8u:
					HTcrfOxSHwNcrTviSakHBBuDquVoWacKrWXdggebLXccBcEPQfreLBTfyzaLSjVHudLuWsbMVjVDzsboPfxQIXZQdREHftiCbvIyqkTydFiBFpGgxMWMLeYweVqeNtHCbsBdJDXEmZMdOxkOlxkswvRWxmuuTPKJYGAmNCxTPsALsUHGLCTpjogFBFGxjCLxpcfiWXaIaqCeVgECENJqVuAJzV(GgdBoVihjcjUDbAhXwRAEHTSNlNDxQZASDRvjZPffNpOOSKJGwcdwxcYnlOchFJtcIbakeXXGLuRredUBeWbNVdvASiYlNXAdVLfRJzCyexKdkGihTBdIIFgFGzrWZMTNUNwtYdREtCJxsrplZQrlURvqEAlkiGzrEXjxkPjQJzofWJmojfWiv(ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa.GetComponent<Renderer>()), Color.cyan);
					num = ((((int)num2 + -1325533022) ^ -2084179077) << 0 >> 0) - 0 >> 0;
					continue;
				case 20u:
				{
					int num16;
					int num17;
					if (flag4)
					{
						num16 = -1405542228;
						num17 = num16;
					}
					else
					{
						num16 = -1559700407;
						num17 = num16;
					}
					num = (((num16 << 0) ^ 0 ^ ((int)num2 + -168296548)) - 0 >> 0) + 0 - 0;
					continue;
				}
				case 52u:
					num = ((int)((((num2 + 482442901) ^ 0x156B68B8) - 0) ^ 0) >> 0) + 0;
					continue;
				case 53u:
					num = (int)(((num2 + 2097241014) ^ 0xC8C6A644u) - 0 - 0 - 0 + 0);
					continue;
				case 54u:
					num = (((((int)num2 + -1414252937) ^ 0x18075F83) + 0) ^ 0) + 0 - 0;
					continue;
				case 55u:
					QqXmwqOnXyaPUfvtMxNxVAcUTBlUKzBEzxFvDyeypvyacIZYVnlxhGmpndsVfTCxWvqwzZQotpiAbbRlBnYwoewTlqiAfjsvSbeGsDyWxXdSyMollhtSVfjRZxljQpjkWMHaXkSYObZqaDuycWoXPAAMRmHVsofhOTWLennbpvdTgSRvcMhUaluvmVjKCXFAWRCgHJuOInIuxHGYvmSGhlhCyAyieDysPDXopKOsrslMDaYFpkpqeZsKKaIgklKfPqETKrJLxAoOauYxCTTTohnPkmEpbIifHfXnweVYBDTELEKpbkDqsQRHcPJxNtJPrjgUxLbyYVsKoJeGConReRMRoplGuxkhTdmCxPSqi(ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa.GetComponent<Renderer>(), SrWkriDvpuuemRuBSuFyCvUxGLMRTESFaEvVzuABhVxZCBDWBWsvplrxxzEFvLBKBOdIwycyUerHYVVeh(LiWaKmHcvpOzKNCkoTLcJuadSwSuBUCwIbmSMaFqxSKpNfcWOLfHXxlqiShotmBBMsQIBKyonvERKKqMtWGQOVylQVJT(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䞦䞅䞇䞜䞁䞐䞆䟚䞱䞐䞓䞔䞀䞙䞁", 1684228085, true))));
					num = ((((((int)num2 + -880128457) ^ -1298192813) >> 0) - 0) ^ 0) << 0;
					continue;
				case 56u:
					num = ((((int)num2 + -151375135) ^ 0x16D660E8) + 0 - 0 << 0) + 0;
					continue;
				case 9u:
					num = ((int)(((num2 + 274505005) ^ 0x1A76F206) + 0) >> 0) + 0 << 0;
					continue;
				case 23u:
					num = ((((int)((num2 + 863302996) ^ 0xBB3915B0u) >> 0) + 0) ^ 0) << 0;
					continue;
				case 59u:
					num = (583947824 << 0) + 0 + 0 - 0;
					continue;
				case 60u:
					fsxxgtsKdVygRLzwpGhzudBKlRlxCiMwXJYzpthWTWrBLabrMfijLQNcQNmphUiVjcjiMahVykGyLZYkPTKwaCLgWWIBhSPYNwsIRTFMYmLAjoqRObzokLUGrcmQrFOGvIKpGptWoYxNRkXHFQNgsBOcBLrPGPutyffBDbkyHDZlohPhfEkBRHnUTINUYEpzEepMevdEFoyPBDOuWjJcETBQRlHVnqAdnAHjRdcJAGVDjxtqUtYOUnULCzUTNiqpOvCaVECThaBXYYGuSraUsLiZFWHsijVrqFPOUsuqQeHUMWMESzbwivXcmCuZXjKYfjHsiSzzWKdneonJjcAJhyjUHMBrYvtHtJOCpuvZaBAysKYYpLQUJbQGaNLvrhBB(ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa).localScale = new Vector3(0.28f, 0.015f, 0.38f);
					num = (int)(((((num2 + 150701655) ^ 0xBFC5E9D9u) - 0) ^ 0 ^ 0) + 0);
					continue;
				case 61u:
				{
					int num12;
					int num13;
					if (!flag7)
					{
						num12 = -836863;
						num13 = num12;
					}
					else
					{
						num12 = -183188799;
						num13 = num12;
					}
					num = (((num12 >> 0 << 0) ^ ((int)num2 + -1962615182)) + 0 >> 0) - 0 + 0;
					continue;
				}
				case 10u:
					num = (((((int)num2 + -1415490461) ^ -670611444) + 0 - 0) ^ 0) << 0;
					continue;
				case 25u:
					aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib.a = 0.5f;
					num = (int)((((num2 + 1948966421) ^ 0xF1BE9986u) - 0 << 0) - 0 << 0);
					continue;
				case 64u:
					bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu.a = 0.5f;
					num = ((((int)num2 + -1806980071) ^ 0x5909481B) << 0) + 0 + 0 + 0;
					continue;
				case 65u:
					ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa.transform.position = Player.Instance.leftHandTransform.position + new Vector3(0f, -0.02f, 0f);
					num = ((int)(((num2 + 43582141) ^ 0x2517CA46) - 0) >> 0 << 0) ^ 0;
					continue;
				case 66u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.GetComponent<Renderer>().material.color = Color.cyan;
					num = ((((((int)num2 + -55775708) ^ 0x6E2F1369) + 0) ^ 0) >> 0) - 0;
					continue;
				case 68u:
					num = (int)((num2 + 1332775076) ^ 0x1E6200D3) >> 0 >> 0 << 0 >> 0;
					continue;
				case 27u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.GetComponent<Renderer>().material = new Material(Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("铽铞铜铇铚铋铝钁铪铋铈铏铛铂铚", 30315694, true)));
					num = ((((int)num2 + -629445151) ^ 0x52D84E25) << 0) - 0 << 0 << 0;
					continue;
				case 69u:
					num = (int)(((num2 + 1974943085) ^ 0xAEA2E96Eu) - 0 << 0) >> 0 << 0;
					continue;
				case 11u:
					ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa.transform.rotation = Player.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					num = (((((int)num2 + -148667527) ^ 0x5CCD8450) >> 0) ^ 0) - 0 << 0;
					continue;
				case 71u:
					num = ((int)((num2 + 2133717631) ^ 0x99ADD49Bu ^ 0) >> 0) + 0 - 0;
					continue;
				case 72u:
					num = (((((int)num2 + -619016407) ^ 0x5D08BCD9) + 0 + 0) ^ 0) >> 0;
					continue;
				case 73u:
					num = (int)(((num2 + 1970981865) ^ 0x8ED0006Cu) - 0) >> 0 >> 0 << 0;
					continue;
				case 12u:
					EasyInputs.Vibration((EasyHand)0, 0.15f, 0.15f);
					num = (((((int)num2 + -500539231) ^ 0x4276B70) - 0 >> 0) ^ 0) >> 0;
					continue;
				case 30u:
					num = (((((int)num2 + -1208788723) ^ 0x1E6B23F ^ 0) >> 0) + 0) ^ 0;
					continue;
				case 76u:
					jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ = true;
					num = ((((((int)num2 + -1884305077) ^ -364175756) << 0) - 0) ^ 0) - 0;
					continue;
				case 77u:
					BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt = true;
					num = (int)(((num2 + 1451769300) ^ 0xEF71DF81u) + 0 - 0 << 0) >> 0;
					continue;
				case 78u:
					flag6 = gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr < MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ;
					num = ((0x1CD42BBF ^ 0) >> 0) - 0;
					continue;
				case 80u:
					num = (((int)num2 + -1574019693) ^ 0x609E956A) - 0 + 0 - 0 - 0;
					continue;
				case 32u:
					num = (((int)((num2 + 1246000002) ^ 0xB22B340Fu) >> 0 >> 0) - 0) ^ 0;
					continue;
				case 81u:
					AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF.GetComponent<Renderer>().material.color = Color.Lerp(aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib, bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu, gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr / MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ);
					num = (((int)num2 + -1939090086) ^ -948943218 ^ 0) - 0 << 0 << 0;
					continue;
				case 13u:
					flag5 = gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr < MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ;
					num = (0x2DEB4DC1 ^ 0) << 0;
					continue;
				case 83u:
					gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr += Time.deltaTime;
					num = (int)(((((num2 + 1010977116) ^ 0x334024AF) + 0 << 0) ^ 0) << 0);
					continue;
				case 85u:
				{
					int num10;
					int num11;
					if (flag5)
					{
						num10 = 2029262065;
						num11 = num10;
					}
					else
					{
						num10 = 83787273;
						num11 = num10;
					}
					num = ((int)((uint)(num10 >> 0 << 0) ^ (num2 + 929739382)) >> 0 >> 0 >> 0) ^ 0;
					continue;
				}
				case 34u:
				{
					int num8;
					int num9;
					if (flag3)
					{
						num8 = -280222468;
						num9 = num8;
					}
					else
					{
						num8 = -913443346;
						num9 = num8;
					}
					num = ((int)(((uint)(num8 - 0 >> 0) ^ (num2 + 2020361328)) - 0 << 0) >> 0) ^ 0;
					continue;
				}
				case 86u:
					num = ((int)(((num2 + 1611650873) ^ 0x959F5C80u) + 0 << 0) >> 0) - 0;
					continue;
				case 14u:
					num = (((((int)num2 + -277516137) ^ 0x426C8DC8) >> 0) + 0 << 0) + 0;
					continue;
				case 88u:
					num = ((((int)num2 + -566722015) ^ 0x69716FD) + 0 << 0 >> 0) - 0;
					continue;
				case 89u:
					ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa.GetComponent<Renderer>().material.color = Color.Lerp(aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib, bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu, gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr / MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ);
					num = (((((int)num2 + -365447244) ^ 0x75BBAC52) << 0 << 0) - 0) ^ 0;
					continue;
				case 90u:
					num = (329939091 + 0 + 0 >> 0) - 0;
					continue;
				case 15u:
					num = ((((int)((num2 + 927157583) ^ 0xF1380AC0u) >> 0) ^ 0) >> 0) + 0;
					continue;
				case 37u:
					num7 = (EasyInputs.GetGripButtonDown((EasyHand)1) ? 1 : 0);
					goto IL_1853;
				case 93u:
				{
					int num5;
					int num6;
					if (flag2)
					{
						num5 = -558221912;
						num6 = num5;
					}
					else
					{
						num5 = -1936612973;
						num6 = num5;
					}
					num = ((int)((uint)((num5 ^ 0) << 0) ^ (num2 + 1688554245)) >> 0) - 0 << 0 << 0;
					continue;
				}
				case 94u:
					gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr += Time.deltaTime;
					num = ((((int)((num2 + 1340428102) ^ 0xE874338Du) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 95u:
					Object.Destroy((Object)(object)ICXwvqKhuBnRIuJkqkSltAkiczInechYmjLMclzePglSBXRgXOVsaYSisOtWIwdstoEzJXheKNwnorGfHBpphPYoqCuoSDwtcSynssxaGQImCFTaiopghNlEqqigCTlhrdkwTsMoepJqhLLLJtfEoploHUXcjqxMFBVzuxhPBabSeUxEFxxiOHScRVOYvKfORWLGQlqlmpcontkNxsxMToYXISIzJiuRVnaijROtglWyEEOxLa);
					num = ((int)(((num2 + 1723856586) ^ 0x897933B1u) << 0 << 0) >> 0) - 0;
					continue;
				case 97u:
					flag = gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr >= MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ;
					num = ((((int)num2 + -1895152813) ^ -121177144) + 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 39u:
					Object.Destroy((Object)(object)AWPikUREpQFvfwMEaHinFpgExDWyTEjKTVIyaEikdaxftLFnDZvgcWNkQkKGYtKLGVCkNoEwzYjFRalMXIUUidHXhyHPTBmKqMyyjvzpuZGeMisPZYJpzPCDoFdpGOCYLzpeBNDCjEAjwCkZfSQVRXlAkVkEskJFwIsmTnnmvhgUpsgLudjNYHgOoOUGCZkZVUMOkYfREEzKRqlROzjoaVHPCEYetHJwXhZvFsBwXrjuhvXXDdRdPVYZmXmFZbyXUdNKrPlwYNqIMnHgHbBqPFGbiZiIgVwWTlzdHmFNRvfcFqnZqfYYAihpwMBsGDpcqtPANDyuvNyuzEwRLjrbXywKejHVLnhofdMlBNlNGDCMKMPSqKGxmofRXevDWDJiGkpwSlqYXEutWJZrtPFaGJcQXUnwrIQcUugAxtZftHzHUMVnedjgYIBWiyyXXUGpNsyBDzUaPAHZjuWlZZrnyKemSjrYVbhzakUCntKF);
					num = ((((int)num2 + -787338951) ^ -1299996626) << 0 << 0 >> 0) ^ 0;
					continue;
				case 98u:
					num = (((((int)num2 + -1815073520) ^ -37942854) + 0 << 0) ^ 0) - 0;
					continue;
				case 16u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 2005987366;
						num4 = num3;
					}
					else
					{
						num3 = 849652681;
						num4 = num3;
					}
					num = ((num3 - 0) ^ 0 ^ ((int)num2 + -227079681) ^ 0 ^ 0) - 0 >> 0;
					continue;
				}
				case 42u:
					num = ((((((int)num2 + -946157137) ^ -1843344744) << 0) ^ 0) - 0) ^ 0;
					continue;
				case 41u:
					return;
					IL_1853:
					flag2 = (byte)num7 != 0;
					num = 1856484193 - 0 + 0 + 0 + 0;
					continue;
				}
				break;
			}
		}
	}

	private static bool LbqghiHHdIykwRSptbyuRbuweNrdnfVDwnQmTtaVtcGKpOoGZIqxaesJHUcuQDuYNVNjaGvabCaOuKgpzKeEOxDrUgEZrGfQHIXubfFsnqvyeDpWNMUfzQjpsvoUbwIvwkgMNMoueLqybenqQIlELZrRzHcGQLrRHabTxDjbyAaNzKonhYdtleJwTpnfKIDtuzQactTnyjfkZDrOtOySHYFCqFahqdrQWGtaTnkNeQUbZyxpYyMVjLMwToKxtLXuSpnskrUfELNQdEDRhLjRqvHlUWgFDMutTziKleeGEGryYVspKSqHCgdxHcynloCRquXDwTGcHCmKeimYERULwNQMwLciGQvpezhEXOSRlnZZTttyPzJttRvDDkhLRyvRhWFEbIaPYdziNRTcsDsggbWmeEbMHhZMRiRWNOxhzUvprmQLrftogpKfatAxGniQeNrFZXoDfkHmGGVRNqvCOLGCxMVunaAlMFl(EasyHand easyHand_0)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) >> (0 >> 1) >> 0) - 0 + 0) ^ -0 ^ 0) << 0)) % 4)
				{
				case 0u:
					break;
				case 2u:
					gripButtonDown = EasyInputs.GetGripButtonDown(easyHand_0);
					num = (((((int)num2 + -1874950498) ^ -859104589) >> 0 << 0) ^ 0) << 0;
					continue;
				case 3u:
					num = (int)(((((num2 + 414745695) ^ 0x55FC76F7) << 0) + 0) ^ 0) >> 0;
					continue;
				default:
					return gripButtonDown;
				}
				break;
			}
		}
	}

	private static GameObject EVlLtQPiVHyzuyJJqSFbsgOhnbUqfJwAbuqVCEbMZDLVZnAWEqktgDTxhdyrWyclkXxahNgMQTcPvTiZBYLOzduyATOzgJQAAzKbPzORkxCmAeboUyQXNoLhDZAoYH(PrimitiveType primitiveType_0)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		GameObject result = default(GameObject);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) ^ 0 ^ 0) << 0 << 0) - -0 - 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 2u:
					result = GameObject.CreatePrimitive(primitiveType_0);
					num = ((((int)num2 + -1874950498) ^ -859104589) - 0 << 0) + 0 << 0;
					continue;
				case 3u:
					num = (((int)((num2 + 414745695) ^ 0x55FC76F7) >> 0) ^ 0) - 0 >> 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static Material GgdBoVihjcjUDbAhXwRAEHTSNlNDxQZASDRvjZPffNpOOSKJGwcdwxcYnlOchFJtcIbakeXXGLuRredUBeWbNVdvASiYlNXAdVLfRJzCyexKdkGihTBdIIFgFGzrWZMTNUNwtYdREtCJxsrplZQrlURvqEAlkiGzrEXjxkPjQJzofWJmojfWiv(Renderer renderer_0)
	{
		Material material = default(Material);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0 >> -0 << 0) - 0 + 0 >> (0 << 1) >> 0) - 0)) % 4)
				{
				case 0u:
					break;
				case 2u:
					material = renderer_0.material;
					num = ((((int)num2 + -1874950498) ^ -859104589) >> 0 >> 0) - 0 << 0;
					continue;
				case 3u:
					num = (int)(((((num2 + 414745695) ^ 0x55FC76F7) << 0 << 0) - 0) ^ 0);
					continue;
				default:
					return material;
				}
				break;
			}
		}
	}

	private static void HTcrfOxSHwNcrTviSakHBBuDquVoWacKrWXdggebLXccBcEPQfreLBTfyzaLSjVHudLuWsbMVjVDzsboPfxQIXZQdREHftiCbvIyqkTydFiBFpGgxMWMLeYweVqeNtHCbsBdJDXEmZMdOxkOlxkswvRWxmuuTPKJYGAmNCxTPsALsUHGLCTpjogFBFGxjCLxpcfiWXaIaqCeVgECENJqVuAJzV(Material material_0, Color color_2)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) - (0 << 1) << 0) - 0 << 0 >> (0 ^ 0)) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					material_0.color = color_2;
					num = ((((int)num2 + -1874950498) ^ -859104589) >> 0 >> 0) - 0 - 0;
					continue;
				case 3u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F7) + 0) >> 0) + 0 + 0;
					continue;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private static Shader LiWaKmHcvpOzKNCkoTLcJuadSwSuBUCwIbmSMaFqxSKpNfcWOLfHXxlqiShotmBBMsQIBKyonvERKKqMtWGQOVylQVJT(string string_0)
	{
		Shader result = default(Shader);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) ^ 0) >> 0 >> 0) + 0 - (0 + 0) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 2u:
					result = Shader.Find(string_0);
					num = (((int)num2 + -1874950498) ^ -859104589) - 0 << 0 >> 0 >> 0;
					continue;
				case 3u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F7) << 0 << 0) >> 0 << 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static Material SrWkriDvpuuemRuBSuFyCvUxGLMRTESFaEvVzuABhVxZCBDWBWsvplrxxzEFvLBKBOdIwycyUerHYVVeh(Shader shader_0)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected O, but got Unknown
		Material result = default(Material);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0) + (0 ^ 0) + 0) ^ 0) + 0 >> (0 ^ 0)) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 2u:
					result = new Material(shader_0);
					num = ((((int)num2 + -1874950498) ^ -859104589) - 0 >> 0) - 0 >> 0;
					continue;
				case 3u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F7) - 0 << 0) - 0 - 0);
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static void QqXmwqOnXyaPUfvtMxNxVAcUTBlUKzBEzxFvDyeypvyacIZYVnlxhGmpndsVfTCxWvqwzZQotpiAbbRlBnYwoewTlqiAfjsvSbeGsDyWxXdSyMollhtSVfjRZxljQpjkWMHaXkSYObZqaDuycWoXPAAMRmHVsofhOTWLennbpvdTgSRvcMhUaluvmVjKCXFAWRCgHJuOInIuxHGYvmSGhlhCyAyieDysPDXopKOsrslMDaYFpkpqeZsKKaIgklKfPqETKrJLxAoOauYxCTTTohnPkmEpbIifHfXnweVYBDTELEKpbkDqsQRHcPJxNtJPrjgUxLbyYVsKoJeGConReRMRoplGuxkhTdmCxPSqi(Renderer renderer_0, Material material_0)
	{
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0 ^ 0 ^ 0) << 0) + 0 + (0 + 0) << 0 << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					renderer_0.material = material_0;
					num = ((((((int)num2 + -1874950498) ^ -859104589) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 3u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F7 ^ 0 ^ 0) - 0 << 0);
					continue;
				case 1u:
					return;
				}
				break;
			}
		}
	}

	private static Transform fsxxgtsKdVygRLzwpGhzudBKlRlxCiMwXJYzpthWTWrBLabrMfijLQNcQNmphUiVjcjiMahVykGyLZYkPTKwaCLgWWIBhSPYNwsIRTFMYmLAjoqRObzokLUGrcmQrFOGvIKpGptWoYxNRkXHFQNgsBOcBLrPGPutyffBDbkyHDZlohPhfEkBRHnUTINUYEpzEepMevdEFoyPBDOuWjJcETBQRlHVnqAdnAHjRdcJAGVDjxtqUtYOUnULCzUTNiqpOvCaVECThaBXYYGuSraUsLiZFWHsijVrqFPOUsuqQeHUMWMESzbwivXcmCuZXjKYfjHsiSzzWKdneonJjcAJhyjUHMBrYvtHtJOCpuvZaBAysKYYpLQUJbQGaNLvrhBB(GameObject gameObject_0)
	{
		Transform transform = default(Transform);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 << 0 + 0 >> 0) - 0 << 0) + (0 + 0) >> 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 2u:
					transform = gameObject_0.transform;
					num = (((((int)num2 + -1874950498) ^ -859104589) << 0 << 0) ^ 0) - 0;
					continue;
				case 3u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F7) + 0 << 0) - 0 << 0);
					continue;
				default:
					return transform;
				}
				break;
			}
		}
	}

	public Platforms()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) + (0 ^ 0)) ^ 0) + 0) ^ 0 ^ 0) + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) ^ 0) << 0 >> 0;
			}
		}
	}

	static Platforms()
	{
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301860;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 + (0 << 1) + 0 >> 0 << 0) + (0 ^ 0)) ^ 0) - 0)) % 8)
				{
				case 0u:
					break;
				default:
					return;
				case 4u:
					BcmsVCXNXXCQCdVltascEGEdFHsAsdekOIHrECrykvTRRpISCtlNfIwUyjNnkxuTSscTwDGQJURiMNmpYzXZSqffmMTuPenMaZYynOwZMuekRniKXxoKAvbBmWHJJmbEGeiMONbkcYnxmVoYEixrPCmFYwmrhNpAtzDMfvWkveHChDprIJeBOJPdSCNsAKdpINeMrCTjmnWKVKxvhVIxIOLJJATCHDJKbsTuzCafPVoBNfihfslFcFHUbucQIqCIDlJCQcWEVCINzjWErLxosdIwLYtezjxysFXBvFrcwHKzWTuSxxzWTnqADmRRJReLfjuUlvjLuvSLtjzREBHbJBFfoxXjOzsECYtNzzGcoNByuFhuNanikccEEoFOxZXVcoiuPMseVEMVZgLJqDvNljt = false;
					num = ((((int)num2 + -907893453) ^ 0x7773C20) << 0 >> 0 << 0) - 0;
					continue;
				case 6u:
					MWdeLJuBqqqTYSzvuFsTUTThlBUtNYGHClHvFLFqUniJfHMzaLMHoozTdWSjPaOsKIqNleQJZbYHLjcDPutclYtoLNrJSvBTzPZwqYoVVcInpSiTTouvHLgLpbcxMgRDzeiVkFmRfxhjqgZSFxPDbgmNInhpWQjOleNkKmJncCpjEXvibjRornCtSunWyXVoosXltPitOCBzQciLRYnMZUxXBtrpZMPeHaVlajPmbyzOMdCQlCeAJiptVZJZxSucNwRQ = 3f;
					num = (int)(((((num2 + 359659174) ^ 0x3353313E ^ 0) << 0) ^ 0) + 0);
					continue;
				case 5u:
					bWehYOsVPMnQosLyCToYASjWTNtCePROJDMWfGfvcwszcTbHmiRphkBjMiokvQQZVyhLGPtWOSVdzKTaMLpWXBHzbDkWsUZlGsDDLqbxOVBpoxJbpnyKBTbtRIJdFwETSKxhgpowJRhcarkETiHewpKMqjMdGYSsqHwDaCUZZbaJLYtzxfjwOzwDaLQXDlPLYPLsVHErnIeuoaarQmFAOwDRkTDoLXwOlpKWnaEQBSigvboZKygqFpWCmUibepFqmqjZpeePHPYWnwviFDEmQfjWsiKsSDLmmSUeSoKFtrJPrapPyZvAKszggmGhu = new Color(112f, 0f, 255f);
					num = (((int)num2 + -2130437817) ^ -2026299046 ^ 0) << 0 >> 0 << 0;
					continue;
				case 7u:
					jjryaCNNCnYXDtRdomJthWfNsiYZAuXGoMeosFlqwEvHdjWHtQnbKrxmeDgSENniprIQoCKIasWDAxJimqFJgWWXpRkOzsMIqnsLBfsRfFaruTLGUXGniDbtvLBwrWjHGnnnfXHgXODBVECvgDUBMyAMlZqPDWzjvsLgGyBWqzqtaAxRigqNbHVhNAbgHRDbotfDSwPHcYlnihMLByHxFMiOxDtfxvoyVpeGvTYMqILdwHZFNqEjkfvClqgocJkGJMrTcfpIzVhWberPENrgRfoPTCveNKKGyeuJqgDIaWJpYyBgZqKosdPDyBZzKkUPlAyWKHzykJfVwYQvbofxavoupRlOgeYQbTeyaEwrQ = false;
					num = (((((int)num2 + -248958683) ^ 0x3D73A3BD) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 2u:
					gXKIiaLAuIkyQBdxHpvzKCqbAQPiexbqlMKoRwrIwOYnOliVOWuyasfDHJhslDwXGUmeRPFkXMcVEcmpHTthcDpTHgHhoYxTsbGUYeeZrjAopjZExSLr = 0f;
					num = ((int)((num2 + 1621957012) ^ 0x2DA26635 ^ 0) >> 0) - 0 + 0;
					continue;
				case 1u:
					aThfsyQkBxftoYgYOrkhDoKgVBTbrrKciTGYNyIThEIqWztRZvmDetALjakREOSjNdkurhlqJqaYGujvib = new Color(112f, 0f, 255f);
					num = ((((((int)num2 + -344833909) ^ 0x16C8A5B1) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}
}
