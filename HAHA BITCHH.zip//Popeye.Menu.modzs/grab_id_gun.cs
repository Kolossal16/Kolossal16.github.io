using GorillaLocomotion;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace Popeye.Menu.modzs;

internal class grab_id_gun
{
	public static void TmfLKzUNwVFwLURtcGpZIdAPnqFsNeRxQGMTeziBNnQERohEuuvKKVbPMpxtUCaseiGeiXoDxOlvnWYZjaYtIgNUFWhPbPHlnxzIHcwwfSmVKGBQrxjTEHJXvMzlQzBIgZiPwpsgEBnQTRjZvrxDFNHFOCnVDlGGqEOKxLtbfcpctTeECAPybXctsCbTcwDtUHzocyBJXwyDxEmVxJsdviEtCvsVJzZIzWhMtPBdYgAFzzWOpgwsdAYMcgMHgGZxxPeBwABIhpeoHZTdzEFDdGEYYuJncUXrgdiJuurPFNlOvJfcmJhBbwtQkfDbQoFmrNhDRkIenPXqvQDopHbtNvpKJrzpRpZrhYwIBBkcadomydu()
	{
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0884: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val2 = default(RaycastHit);
		bool triggerButtonDown = default(bool);
		GameObject val = default(GameObject);
		bool flag = default(bool);
		GameObject val3 = default(GameObject);
		VRRig componentInParent = default(VRRig);
		while (true)
		{
			int num = 1758301869;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0 >> (0 >> 1) >> 0) ^ 0) << 0 << -0) ^ 0) + 0)) % 36)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = ((int)((num2 + 1333463150) ^ 0x8D8F871Au ^ 0) >> 0) + 0 + 0;
					continue;
				case 23u:
					num = (((((int)num2 + -1372250924) ^ -1874193350) - 0 << 0) ^ 0) >> 0;
					continue;
				case 7u:
				{
					int num5;
					int num6;
					if (triggerButtonDown)
					{
						num5 = 2132819970;
						num6 = num5;
					}
					else
					{
						num5 = 77075000;
						num6 = num5;
					}
					num = ((((num5 >> 0) - 0) ^ ((int)num2 + -1198723765)) >> 0 << 0) + 0 - 0;
					continue;
				}
				case 17u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((((int)num2 + -227232852) ^ 0x33B82128) >> 0 << 0) ^ 0) + 0;
					continue;
				case 12u:
					num = (int)(((num2 + 1115582667) ^ 0xA45B1B17u ^ 0) + 0 - 0 + 0);
					continue;
				case 16u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (int)(((((num2 + 1603745309) ^ 0xA55D47A3u) + 0) ^ 0 ^ 0) + 0);
					continue;
				case 1u:
					val.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((int)((num2 + 1107201870) ^ 0x4DBCF762 ^ 0) >> 0) - 0 >> 0;
					continue;
				case 8u:
					flag = Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>());
					num = (((((int)num2 + -1804281275) ^ -280227653) + 0 - 0) ^ 0) >> 0;
					continue;
				case 29u:
					num = ((int)(((num2 + 1548432940) ^ 0x7AF20207) - 0 - 0) >> 0) + 0;
					continue;
				case 10u:
					val3.GetComponent<Renderer>().material.color = Color.green;
					num = (int)(((((num2 + 1866650904) ^ 0x9461F7B5u) << 0) ^ 0) << 0 << 0);
					continue;
				case 28u:
					componentInParent = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<VRRig>();
					num = ((int)((num2 + 435749897) ^ 0x40EB8B42) >> 0 << 0) + 0 >> 0;
					continue;
				case 34u:
					val.transform.position = ((RaycastHit)(ref val2)).point;
					num = (((int)num2 + -1008375456) ^ -1025921924 ^ 0 ^ 0) + 0 >> 0;
					continue;
				case 33u:
					num = (1709781241 << 0 << 0) - 0 - 0;
					continue;
				case 2u:
					num = (int)(((num2 + 1457370637) ^ 0x3B51C180 ^ 0) - 0 - 0 << 0);
					continue;
				case 6u:
					num = ((((int)num2 + -40093842) ^ 0x5819F5A6) << 0 >> 0) + 0 - 0;
					continue;
				case 18u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (int)((((num2 + 1868189554) ^ 0xDADD329Fu) - 0 + 0 << 0) + 0);
					continue;
				case 19u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = (int)(((num2 + 1956669763) ^ 0x808AC005u ^ 0) - 0) >> 0 >> 0;
					continue;
				case 20u:
					num = ((int)(((num2 + 207985003) ^ 0x54EE683B) + 0 + 0) >> 0) ^ 0;
					continue;
				case 3u:
					num = ((((int)num2 + -2071082168) ^ -2004194177) + 0 - 0) ^ 0 ^ 0;
					continue;
				case 22u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 1984078164;
						num4 = num3;
					}
					else
					{
						num3 = 210141622;
						num4 = num3;
					}
					num = (int)(((((uint)(num3 >> 0 >> 0) ^ (num2 + 461723281)) << 0) - 0 << 0) - 0);
					continue;
				}
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = ((((int)num2 + -434831334) ^ 0x5C262D14) - 0 >> 0) + 0 << 0;
					continue;
				case 9u:
					val3 = val;
					num = ((((int)num2 + -1403453257) ^ 0x7E724EE1) + 0 + 0 >> 0) ^ 0;
					continue;
				case 25u:
				{
					Player owner = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (int)(((((num2 + 293113464) ^ 0xB646E07Fu ^ 0) << 0) - 0) ^ 0);
					continue;
				}
				case 26u:
					num = (((int)((num2 + 461443217) ^ 0xDC840F4Fu) >> 0 >> 0) ^ 0) << 0;
					continue;
				case 27u:
					num = (int)(((num2 + 641832775) ^ 0x79BC60DE) + 0 + 0 - 0) >> 0;
					continue;
				case 4u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = ((((int)num2 + -645064961) ^ 0x42C92578) >> 0) - 0 + 0 << 0;
					continue;
				case 11u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䡩䡅䡃䡁䡊䡐䡅", 2073577508, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("扚承扦扦扯扮截扃扎截扭承扤戫", 1193763338, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䝷䝺䜄", 1984775998, true) + ((MonoBehaviourPun)componentInParent).photonView.Owner.UserId);
					num = (int)(((num2 + 1198527402) ^ 0x8C9933E7u) + 0 - 0) >> 0 << 0;
					continue;
				case 30u:
					num = ((((int)num2 + -877465945) ^ 0x4D901C41) + 0 >> 0) - 0 + 0;
					continue;
				case 31u:
					num = (int)(((((num2 + 452787187) ^ 0xA5A40A8Fu) << 0 << 0) ^ 0) - 0);
					continue;
				case 32u:
					num = (((int)num2 + -43473754) ^ 0x1EF3B3DD) - 0 - 0 >> 0 << 0;
					continue;
				case 5u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.red);
					num = (int)(((num2 + 1559511532) ^ 0x81BB6196u) - 0 + 0 + 0 << 0);
					continue;
				case 13u:
					num = (int)((((((num2 + 590235451) ^ 0x94B56CDAu) << 0) ^ 0) << 0) ^ 0);
					continue;
				case 35u:
					num = 0x1DA214EE ^ 0;
					continue;
				case 15u:
					num = ((((((int)num2 + -1883148872) ^ -1067516901) + 0) ^ 0) - 0) ^ 0;
					continue;
				case 14u:
					return;
				}
				break;
			}
		}
	}

	public grab_id_gun()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 << -0) + 0 - 0 + 0) ^ 0) - 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) - 0) ^ 0) - 0 - 0;
			}
		}
	}
}
