using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace Popeye.Menu.modzs;

internal class wallwalk
{
	public static void FMfsuonfrDXuRUIIRlFRdNwRKlPgXvLhXJFlqJPNZBpieuETlmuvSKMRqoHizghWSPxiowsivSRByoMpHWULappmXOVbbHnStspoXvEPUmaZSktbBsADmwVDAklAArgOEZifYyrlrfRNpptMuTzJgKGWwMONkeoCgmvTboddaplgFiolQyfGRxHUtlImJDanQoHdUALgQ()
	{
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		RaycastHit val = default(RaycastHit);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301847;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0) - (0 ^ 0) - 0 >> 0) ^ 0) + (0 ^ 0)) ^ 0u ^ 0u) % 19)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = ((((int)num2 + -434485547) ^ 0x7B20DA99 ^ 0) << 0) - 0 - 0;
					continue;
				case 11u:
					((Collider)Player.Instance.bodyCollider).attachedRigidbody.useGravity = false;
					num = ((((int)num2 + -1280521207) ^ 0x74FBB3DF) - 0 << 0 >> 0) + 0;
					continue;
				case 3u:
				{
					int num5;
					int num6;
					if (!flag2)
					{
						num5 = -954437630;
						num6 = num5;
					}
					else
					{
						num5 = -780331205;
						num6 = num5;
					}
					num = (int)((((uint)(num5 + 0 - 0) ^ (num2 + 1302619625)) - 0 << 0) - 0 - 0);
					continue;
				}
				case 17u:
					flag3 = gripButtonDown;
					num = (((((int)num2 + -733318432) ^ 0x11926076 ^ 0) >> 0) + 0) ^ 0;
					continue;
				case 5u:
					num = ((int)(((num2 + 1767936784) ^ 0x8C2FD377u) + 0) >> 0 >> 0) - 0;
					continue;
				case 16u:
					((Collider)Player.Instance.bodyCollider).attachedRigidbody.useGravity = true;
					num = (0x156FF6A8 ^ 0) << 0;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (flag3)
					{
						num3 = -1385828962;
						num4 = num3;
					}
					else
					{
						num3 = -571051355;
						num4 = num3;
					}
					num = ((num3 + 0 >> 0) ^ ((int)num2 + -1579710319)) + 0 >> 0 << 0 >> 0;
					continue;
				}
				case 10u:
					num = ((int)(((num2 + 141467042) ^ 0x3E4188E7) - 0 - 0) >> 0) ^ 0;
					continue;
				case 12u:
					num = ((((int)num2 + -1397142901) ^ -1433636874 ^ 0) << 0) + 0 + 0;
					continue;
				case 4u:
					num = ((((int)num2 + -1890670034) ^ -1274103416) + 0 >> 0) - 0 << 0;
					continue;
				case 13u:
				{
					Rigidbody attachedRigidbody = ((Collider)Player.Instance.bodyCollider).attachedRigidbody;
					attachedRigidbody.velocity -= ((RaycastHit)(ref val)).normal * (6.8f * Time.deltaTime);
					num = ((((int)((num2 + 908887761) ^ 0x8255F079u) >> 0) ^ 0) >> 0) + 0;
					continue;
				}
				case 14u:
					Physics.Raycast(Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.right, ref val, 100f, 512);
					num = ((((int)num2 + -1466265009) ^ -1481714368 ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 15u:
					num = (((((int)num2 + -1240604248) ^ -410353177) + 0) ^ 0 ^ 0) << 0;
					continue;
				case 2u:
					flag = ((RaycastHit)(ref val)).distance < 25f;
					num = (int)(((((num2 + 498551263) ^ 0x62A835E4) + 0) ^ 0) << 0 << 0);
					continue;
				case 6u:
					num = (int)(((num2 + 1766035264) ^ 0x35A65E44) - 0 - 0 << 0) >> 0;
					continue;
				case 18u:
					num = ((((int)num2 + -884422112) ^ 0x76F3BC5D) >> 0) + 0 + 0 - 0;
					continue;
				case 8u:
					flag2 = flag;
					num = ((int)(((num2 + 758493273) ^ 0xC81F091Cu) + 0 + 0) >> 0) ^ 0;
					continue;
				case 7u:
					return;
				}
				break;
			}
		}
	}

	public wallwalk()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0) ^ 0) >> 0) - 0 - 0 << (0 ^ 0)) ^ 0u ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) - 0 >> 0) - 0;
			}
		}
	}
}
