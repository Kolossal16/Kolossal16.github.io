using System;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modzs;

internal class owner_nmaetag
{
	public static void uCoMjmlzWxxUAKtnXQGixtUNNwZtJgdmFWeNCDPeVyAkeHKrHQrvRVXbHBZMnSPPukoDFFKtaCmYSKIfMHLTPIuKZdfbDdQdILQTshLbfXupIZiWSTaGgWaLQEDCAIPWMjphUPNEVKORnfbZUijKdkWMKedODjBxhyDzJacdgvKwiiyKCDHrzfTBmCwQLYaMjrKPCBqTgfEIzAECFsmZCjXcEbnhElrhuYmQyJianNktBkcLXUktLbkZtHkBojpUOwnBnNdWkmLOZDAuYBjJbYwtNnxQyGLexpFfWAykQoizpvaQgQCNZFTQaUOaqnxDAHqJXvxxdZTNPWdrnGJIeYfRvPecMyTDQFZIfqSKteJaMgbdRwNJDPzBCyniquLFfqWkWvmWOYpZoefpNblqKjZbfxgGc()
	{
		string[] array = default(string[]);
		string userId = default(string);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301853;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 << -0 << 0) + 0 >> 0) + (0 ^ 0) + 0 >> 0)) % 13)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					array = new string[5]
					{
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("矋瞔瞘瞛瞘瞅矊瞅瞒瞓矉瞻瞴瞺瞏瞧瞶瞾瞳矗瞸瞠瞹瞲瞥矋矘瞔瞘瞛瞘瞅矉矽瞓瞞瞄瞔瞘瞅瞓矙瞐瞐矘瞤瞭瞰瞟瞠瞡瞵瞎瞟瞶", 1752397815, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㕕㔊㔆㔅㔆㔛㕔㔐㔌㔅㔅㔆㔞㕗㔥㔪㔤㔑㔹㔨㔠㔭㕉㔦㔾㔧㔬㔻㕕㕆㔊㔆㔅㔆㔛㕗㕣㔍㔀㔚㔊㔆㔛㔍㕇㔎㔎㕆㔺㔳㔮㔁㔾㔿㔫㔐㔁㔨", 1872639337, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("篹箦箪箩箪箷篸箢箷箠箠箫篻箉箆箈箽箕箄箌箁篥箊箒箋简算篹篪箦箪箩箪箷篻篏管箬箶箦箪箷管篫箢箢篪箖箟箂箭箒箓箇箼箭箄", 1645312965, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㛳㚬㚠㚣㚠㚽㛲㚭㚣㚺㚪㛱㚃㚌㚂㚷㚟㚎㚆㚋㛯㚀㚘㚁㚊㚝㛳㛠㚬㚠㚣㚠㚽㛱㛅㚫㚦㚼㚬㚠㚽㚫㛡㚨㚨㛠㚜㚕㚈㚧㚘㚙㚍㚶㚧㚎", 1635268303, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("腊脕脙脚脙脄腋脛脗脑脓脘脂脗腈脺脵脻脎脦脷脿脲腖脹脡脸脳脤腊腙脕脙脚脙脄腈腼脒脟脅脕脙脄脒腘脑脑腙脥脬脱脞脡脠脴脏脞脷", 557089142, true)
					};
					num = ((int)(((num2 + 600520462) ^ 0xB95FCA47u) - 0 + 0) >> 0) + 0;
					continue;
				case 11u:
					PhotonNetwork.LocalPlayer.UserId = userId;
					num = (int)(((((num2 + 900749756) ^ 0xF6F7C411u) - 0) ^ 0) + 0 + 0);
					continue;
				case 3u:
					num = (((((int)num2 + -1701687338) ^ -1567692514) + 0 << 0) ^ 0) + 0;
					continue;
				case 7u:
					num3 = new Random().Next(array.Length);
					num = ((((((int)num2 + -795116775) ^ 0x1DE169A5) >> 0) ^ 0) + 0) ^ 0;
					continue;
				case 2u:
					num = (((((int)num2 + -678915685) ^ -1534661089) << 0) ^ 0 ^ 0) << 0;
					continue;
				case 8u:
					PlayerPrefs.SetString(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㻍㻥㻸㻣㻦㻦㻫㻆㻥㻩㻥㻧㻥㻾㻣㻥㻤㺤㻚㻦㻫㻳㻯㻸㻄㻫㻧㻯", 869088906, true), array[num3]);
					num = ((((int)num2 + -1186296972) ^ 0x47F0227D) << 0 >> 0 >> 0) + 0;
					continue;
				case 1u:
					PhotonNetwork.LocalPlayer.NickName = array[num3];
					num = (((int)((num2 + 1259723679) ^ 0x76A7389B) >> 0) + 0 >> 0) - 0;
					continue;
				case 10u:
					userId = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("痖痔痛痁疵痗痔痛疵痘痐疵痗痚痏痚疟疟疟疟疟疟疟疟疟疟疟疟", 460223893, true);
					num = (((((int)num2 + -1219895373) ^ -1888826635) >> 0 << 0) ^ 0) - 0;
					continue;
				case 12u:
					num = ((((int)num2 + -434485547) ^ -534547507) << 0) - 0 + 0 << 0;
					continue;
				case 4u:
					num = (int)(((num2 + 1709781230) ^ 0xDD653F56u ^ 0) + 0 + 0 << 0);
					continue;
				case 6u:
					GorillaComputer.instance.currentName = array[num3];
					num = ((((int)num2 + -733318432) ^ -226576907) - 0 + 0 << 0) - 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public owner_nmaetag()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 >> 0 + 0) ^ 0 ^ 0) >> 0) + (0 + 0)) ^ 0u ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) - 0 >> 0 >> 0) - 0;
			}
		}
	}
}
