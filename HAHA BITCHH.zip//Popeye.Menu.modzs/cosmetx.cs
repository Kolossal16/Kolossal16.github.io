using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnityEngine;

namespace Popeye.Menu.modzs;

internal class cosmetx
{
	public static void UTMMIJtCpNwJiKMGGRYJBxKATyaliylXOJQdqDlKwJEokGvjwHNLXFSxjmSjJhuQCzUzUJqcGonSSvqndQOALzajQsTeKbaopOLLLWpMrKfIrZENWFgStTfcyKIBQmsEnZDeKEBgBbjaurRQOgheViVvIImboNWfsAvswzcreZqrKeIgSRMKenIfeivcszSOfeHTWzupdPZWRDLEafixamafSqnodaZEhCmFxOktwxHpnLnAwRcmrvNSdCbFlglcPuPprfhlVPaDFLRgcNRmYNnMPtCUMEhqmEzSWYjqKQqCujnrKUDyoZechdzXDmzqHKqamZkdDACiwKrFgkkSbIbnAwLTylNxrZUK()
	{
		Enumerator<CosmeticItem> enumerator = default(Enumerator<CosmeticItem>);
		CosmeticsController val = default(CosmeticsController);
		string concatStringCosmeticsAllowed = default(string);
		CosmeticItem val2 = default(CosmeticItem);
		CosmeticsController instance = default(CosmeticsController);
		CosmeticItem current = default(CosmeticItem);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301869;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0) - -0 << 0 >> 0) ^ 0) >> -0) - 0 << 0)) % 24)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					num = (int)(((((num2 + 2106842273) ^ 0xD3A67B4Fu) << 0 << 0) ^ 0) + 0);
					continue;
				case 23u:
				{
					int num5;
					int num6;
					if (enumerator.MoveNext())
					{
						num5 = 272533140;
						num6 = num5;
					}
					else
					{
						num5 = 1468567953;
						num6 = num5;
					}
					num = (((num5 << 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 7u:
					val.concatStringCosmeticsAllowed = concatStringCosmeticsAllowed + ((val2 != null) ? ((ValueType)val2).ToString() : null);
					num = (0x661A46D4 ^ 0) + 0;
					continue;
				case 17u:
					enumerator = CosmeticsController.instance.allCosmetics.GetEnumerator();
					num = (((((int)num2 + -1125345364) ^ -382712516) << 0 >> 0) ^ 0) - 0;
					continue;
				case 5u:
					num = ((int)((num2 + 232892542) ^ 0x30A8C644) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 16u:
					val = instance;
					num = ((int)((num2 + 1221206141) ^ 0x8C0A6D03u) >> 0 << 0) - 0 + 0;
					continue;
				case 1u:
					num = (int)((((num2 + 1952503976) ^ 0x9669D3D6u) << 0) + 0) >> 0 << 0;
					continue;
				case 8u:
					num = (((((int)num2 + -202039689) ^ 0x4ECCD461) + 0 + 0) ^ 0) + 0;
					continue;
				case 12u:
					current = enumerator.Current;
					num = 0x167BBEC6 ^ 0;
					continue;
				case 4u:
					num = (int)((((num2 + 747032882) ^ 0x17C760A3) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 13u:
					CosmeticsController.instance.unlockedCosmetics.Add(current);
					num = (((int)((num2 + 1620250878) ^ 0xEFCE677Eu ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 14u:
					num = ((((int)num2 + -1219895373) ^ -713221589) << 0) - 0 - 0 >> 0;
					continue;
				case 15u:
					instance = CosmeticsController.instance;
					num = ((int)(((num2 + 1133461507) ^ 0x1408225A) - 0) >> 0) ^ 0 ^ 0;
					continue;
				case 2u:
					flag2 = (Object)(object)CosmeticsController.instance != (Object)null;
					num = (int)((((((num2 + 900749756) ^ 0x1AAF25E5) << 0) - 0) ^ 0) << 0);
					continue;
				case 6u:
					concatStringCosmeticsAllowed = instance.concatStringCosmeticsAllowed;
					num = (int)((((((num2 + 441892074) ^ 0x64D36822) << 0) - 0) ^ 0) - 0);
					continue;
				case 18u:
					val2 = current;
					num = ((((int)num2 + -1856515560) ^ -1128221651) >> 0) - 0 + 0 >> 0;
					continue;
				case 19u:
					flag = flag2;
					num = (int)(((num2 + 1709781230) ^ 0xF35389F2u ^ 0) - 0 + 0 - 0);
					continue;
				case 20u:
					num = ((((int)num2 + -11398900) ^ 0x43FDDFF0) + 0 << 0) + 0 - 0;
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -25535715;
						num4 = num3;
					}
					else
					{
						num3 = -322292263;
						num4 = num3;
					}
					num = ((int)((uint)(num3 - 0 - 0) ^ (num2 + 1855824404)) >> 0) + 0 >> 0 >> 0;
					continue;
				}
				case 22u:
					num = (428697839 >> 0) - 0 + 0 >> 0;
					continue;
				case 10u:
					num = ((((int)num2 + -1395914388) ^ -2098260843) + 0 - 0 >> 0) ^ 0;
					continue;
				case 11u:
					CosmeticsController.instance.UnlockItem(current.itemName);
					num = (int)((((num2 + 1319775793) ^ 0xEFFD11B8u ^ 0 ^ 0) << 0) ^ 0);
					continue;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	public cosmetx()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) ^ 0 ^ 0) - 0 - 0 << 0 + 0) + 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0 ^ 0 ^ 0) >> 0;
			}
		}
	}
}
