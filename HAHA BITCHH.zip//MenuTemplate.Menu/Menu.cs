using GorillaLocomotion;
using Photon.Pun;
using Popeye.Menu;
using Popeye.Menu.mods;
using Popeye.Menu.modsss;
using Popeye.Menu.modzs;
using REAK.Menu.mods;
using UnityEngine;
using UnityEngine.UI;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace MenuTemplate.Menu;

public class Menu
{
	private static bool[] hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb = new bool[10];

	private static bool[] fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU;

	public static bool[] rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt;

	public bool JHiGxxwUOYRXuTauztzqyoowOZasVLDVvWFrlhtmVRAwWRdaFjrFncVvtMRxxeYcuWBynJisamvHNRzXWZMMtYHtbkYzqVPQTxcZqFMVaZEbGnHBmTBxrlJwohwdLJcewFOqPzHqmQLttGNOCwmwuszHOFLiiJkrXAEbzrMMmkkAzpcIuIApwFKefhBjOzhDGuvTbMokJAkjhYhzDcNAjUUsQzVrQDXMcHUfTjGItpFWuAXhZcFLLHtLAd;

	private static GameObject dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu;

	private static GameObject zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke;

	private static GameObject sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX;

	public static string eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt;

	public static Material mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb;

	public static string sPbkSsnJhTPpqWqAzXuoLSgHPhOJqlggKrjEUKXGGwNvQKixwhWmjKqAItuLEDsWMIEYNMFPaNIoeLRfYrnjpUWZaIVBqlccdRIhfjKJBhlwccvXBoMnqjGSMEXeReyOLFkncKZPGDIiIAXYmXZbzOMUkPvAlFSwIxKxRhVQoWGMBykmHYRTexpWSqdmpzDaLlAlPAheciNCiatMFjTmOYrlhNEBeIBPtFapYZwhRMRVKMOSWrHgFrmNTpdbWGatHXjCZdOFMMvbgvAuZLENbvjbtnvJWuklMxoMDlTSDbtTWlGyOIckcnslNhjMIeJsBkoIgOROSLkacqfhGXVosaizfdYvbhkyrbsMWXrZQosrcrjxccfLjvZBbPDdQvMLAMIaXtkJFVxeHRwOTAtZbzoWbQKhunjvCHQqIiAIRwfoXVTjsPkpbMJbxMZhIcosLcCabffKaLiFtZYfWAOFcUtPYOTWjsZOhNCV;

	private static float tTinJAoqDdIxOUkinJpRJMcmmjBHLtxGxdLcsBVCFclUgvhoiRAyxKlHRWbAYHFkGbaKihPMNMmHAhfRbmzTSZiMRekwAuEYwboeuwfacOKKxEgJQjzLhMsGTnTeXtltiokzTawEhzRdoxpmXAGqVSQKJHlhDbcICrBjuHQPNVEHUosvYGgwNVyqyzPmPpafwiBWWgSpKQDanjP;

	private static float uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS;

	public static float rOwOsEgmsnqGMeHOThUoEICZObAONoBDEPBDUvKqSccUfDJCuDXfAloJlxZrerzdMMcXCdUyxEvCFHTlrYtkrvdsARrwvtlADZisALZrIzIVPMeEENZgXpM;

	private static float qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp;

	private static Color MjdnoRxnpPZBDYxKonsFcwQsHaCfiPqQAxkXbeCLKJyomypFpjcuzknptLFnoseAziagOAJjLGUsYCgjKXPYMVqqjUEpzoxsEXPdxjRPzTJTpUrQEwCqCfNESKWTVuKwjCOaNdLBgaySlxaoDNKdMgPykklMnXTfjnJMgqdBKbkCHUsuKHqiJGKdNqQCRYnjgtJYNoimJisLVnRpRQcFGLwCDFZPABKMNavnluGvzeyAoYhzzBKbVICvWgvhptLiyGYVSDexjHgCmVoEyzpZQJQeyZreZzgfsqbHamHWxmRoCajaSQJPdMrPPTwSlZyKAajWUGElRtCERCCxQqmi;

	private static Color PqcGZmSgPPKxOgNBQnglmyYKkNXnrYcVNqVjYDWHOxvcIePLOaHCjaVrsswloFOQMPKylEDmqyxPcWbfXmyrrzLMuDRGhLtjIFpTurAkxumLDgpwqqocgxzmeXdHMXeFfngxGhKGMnUWnainovpQwqckfdPxnSxzqHFpaSP;

	private static Color jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak;

	private static Color DksrKhdtfTLOMOmnRaZcspducViMdYQzoSCoZRvlDKdFAfvqsnNMQXSohYpPYqqhclzTmXnZFNzHlyTWzStPkeJraohbCGnmuWCpFBevZOhdykcIespfXAXXCiTXQmwYAnnpVEqYOYQvXGTQlyWkrhpUZEMxIgFMsjClWNMAbrrZJBZWpdLrplGsXsqqRTpHsddOdITyMwiaQqkxFQiEvoxgCknEwvIibJGGylSGjmETdGCHhSLaKKmeGWmTvpbqNaZgJDZtXBviJDdWHFwEJHxqwBaBZZlUlofcGvXETsdjpevcSplPSxGgCIKiDxuYpAXuxapmISKrEoasgXJJOwbNIZzXLPawXfTPgaFRZZhaNoBoIrcFOLjTyjMyBrBTRouzullfsRJPpbatylptMvImVaqWohqIyojyTcUwgWmWbuDxjsZqchgwGiEtUo;

	private static float RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo;

	public static float eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv;

	public static void soqBhujDWoivlbKrBUrSZlrzHlzfoYwBQoMQtVBCxwDXqhrtIAiAZevgXQTWUdoXSHFWpTYFsPvDItjzUgxNQVCMSFTDbFHtiFfJCueOCChkISyEGubOGBhWeTeJauENhbucnAXAcJloOsdZgpWHDSNHyjEJquOhXucHxvqfwBMXqSiMPeCLyXkonNEeWokHVdqtpwCLZQkbgQqFbRTlRcJakOtJQljhrfcmCOwtCRMIMihxwZdevYPSupjBcSUNGdKbOecmuzJaqbobGVnRheMtpjSmFVqJXYbIygJsXQKVoPCtahVhFdFCrqLElPHziZcrZFDzmUTruQezHzmxZjeUsyrhueghjkNoNktuDwUKjohAmlW()
	{
		//IL_07c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1d: Expected O, but got Unknown
		//IL_0cfb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0833: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2f: Unknown result type (might be due to invalid IL or missing references)
		Text val = default(Text);
		RectTransform component = default(RectTransform);
		GameObject val5 = default(GameObject);
		Canvas val4 = default(Canvas);
		CanvasScaler val3 = default(CanvasScaler);
		while (true)
		{
			int num = 1758301843;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 + (0 ^ 0) >> 0 >> 0) ^ 0) << -0) + 0 >> 0)) % 58)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (int)((((num2 + 452787187) ^ 0xB60D8569u) << 0 << 0) - 0 << 0);
					continue;
				case 51u:
					Object.Destroy((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.GetComponent<Rigidbody>());
					num = (int)(((num2 + 1559511532) ^ 0x8938B359u) + 0 - 0 + 0) >> 0;
					continue;
				case 37u:
					num = (((((int)num2 + -1582795527) ^ 0x506F6D94) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 2u:
					num = ((((((int)num2 + -1883148872) ^ -1149512013) << 0) - 0) ^ 0) - 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.GetComponent<BoxCollider>());
					num = (int)((((num2 + 1603745309) ^ 0x79AE022E) + 0 << 0) - 0 + 0);
					continue;
				case 4u:
					num = ((((int)num2 + -40093842) ^ 0xCAF7191) >> 0 << 0 << 0) + 0;
					continue;
				case 30u:
					val.alignment = (TextAnchor)4;
					num = (int)(((num2 + 1472348834) ^ 0xA71D86FFu) - 0 - 0 - 0 << 0);
					continue;
				case 57u:
					Object.Destroy((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.GetComponent<Renderer>());
					num = (int)(((num2 + 1868189554) ^ 0xDCD52874u) + 0 + 0) >> 0 >> 0;
					continue;
				case 5u:
					num = (((((int)num2 + -1930605743) ^ -1470635024) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 49u:
					component = ((Component)val).GetComponent<RectTransform>();
					num = (((((int)num2 + -1588119460) ^ 0x5FD7DCF4) - 0) ^ 0) - 0 + 0;
					continue;
				case 6u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.localScale = new Vector3(0.1f, 0.29f, 0.4f);
					num = ((int)(((num2 + 1704553265) ^ 0xE9860C72u) - 0) >> 0) - 0 >> 0;
					continue;
				case 47u:
					num = (int)(((((num2 + 1960461734) ^ 0xCAFD50DAu) - 0) ^ 0) - 0) >> 0;
					continue;
				case 7u:
					val5 = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (int)(((num2 + 1452403640) ^ 0x97955229u ^ 0) - 0 - 0 - 0);
					continue;
				case 52u:
					component.sizeDelta = new Vector2(0.28f, 0.05f);
					num = ((((int)num2 + -852338334) ^ 0x45FA4387) - 0 << 0) - 0 >> 0;
					continue;
				case 8u:
					Object.Destroy((Object)(object)val5.GetComponent<Rigidbody>());
					num = ((int)(((num2 + 483666874) ^ 0x6703ADD) + 0) >> 0 << 0) - 0;
					continue;
				case 9u:
					num = ((int)(((num2 + 11998589) ^ 0x4FE262E0) - 0 << 0) >> 0) - 0;
					continue;
				case 32u:
					num = (((((int)num2 + -1529358628) ^ 0x505DE087) << 0 << 0) + 0) ^ 0;
					continue;
				case 50u:
					Object.Destroy((Object)(object)val5.GetComponent<BoxCollider>());
					num = (((((int)num2 + -1904678002) ^ -1287635994 ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 10u:
					num = (((int)num2 + -719845573) ^ -2037949584) - 0 << 0 << 0 << 0;
					continue;
				case 11u:
					val5.transform.parent = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform;
					num = ((((int)num2 + -1756947900) ^ -225614945) + 0 + 0 >> 0) ^ 0;
					continue;
				case 40u:
					num = (((int)num2 + -1721489520) ^ -2014361307) - 0 - 0 + 0 << 0;
					continue;
				case 44u:
					num = (int)((((num2 + 67747431) ^ 0x526C6E55 ^ 0) - 0 << 0) - 0);
					continue;
				case 12u:
					val5.transform.rotation = Quaternion.identity;
					num = (int)(((num2 + 329939053) ^ 0x3E6D4A76) - 0 + 0 + 0 << 0);
					continue;
				case 34u:
					num = (int)(((num2 + 700820505) ^ 0x4DA5D970) - 0 - 0 + 0) >> 0;
					continue;
				case 13u:
					num = ((((int)num2 + -290999538) ^ 0x294E8A49) + 0 >> 0) + 0 >> 0;
					continue;
				case 14u:
					val5.transform.localScale = new Vector3(0.1f, 1.05f, 1.21f);
					num = (int)(((num2 + 1892383293) ^ 0xF074493Eu) - 0 - 0 + 0 + 0);
					continue;
				case 55u:
					num = (((((int)num2 + -1532611491) ^ -1619145019) + 0 + 0) ^ 0) >> 0;
					continue;
				case 56u:
					((Transform)component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
					num = (int)((((((num2 + 244481569) ^ 0x392E9D59) << 0) + 0) ^ 0) + 0);
					continue;
				case 15u:
					val5.GetComponent<Renderer>().material = mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb;
					num = (int)(((num2 + 649143086) ^ 0x6376FD2B ^ 0) - 0 << 0 << 0);
					continue;
				case 16u:
					num = ((((int)num2 + -661434340) ^ -1515706010) >> 0 << 0) - 0 - 0;
					continue;
				case 45u:
					val.resizeTextForBestFit = true;
					num = ((((int)num2 + -1111342977) ^ 0x600FD760 ^ 0) >> 0) + 0 + 0;
					continue;
				case 46u:
					val5.transform.position = new Vector3(0.05f, 0f, 0f);
					num = (((int)num2 + -504175385) ^ 0x44E8AA1A ^ 0) - 0 - 0 >> 0;
					continue;
				case 17u:
					num = ((((int)num2 + -1568917589) ^ 0x195A9FB2) >> 0 >> 0 << 0) ^ 0;
					continue;
				case 18u:
					zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke = new GameObject();
					num = ((int)((num2 + 824698952) ^ 0x569EE447) >> 0 << 0) + 0 >> 0;
					continue;
				case 35u:
					((Transform)component).localPosition = Vector3.zero;
					num = (((((int)num2 + -727923521) ^ 0x1A308922) << 0) ^ 0) >> 0 << 0;
					continue;
				case 19u:
					zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.transform.parent = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform;
					num = (int)(((((num2 + 268319629) ^ 0x56789CE6 ^ 0) << 0) ^ 0) - 0);
					continue;
				case 54u:
					num = (((((int)num2 + -1030955589) ^ -1451231967) - 0) ^ 0) << 0 << 0;
					continue;
				case 39u:
					num = (((((int)num2 + -1956742627) ^ -187791742) << 0) ^ 0) - 0 - 0;
					continue;
				case 20u:
					val4 = zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.AddComponent<Canvas>();
					num = (((((int)num2 + -1524965430) ^ 0x2E3267D7) + 0) ^ 0) + 0 >> 0;
					continue;
				case 21u:
					val3 = zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.AddComponent<CanvasScaler>();
					num = (int)(((((num2 + 1742690051) ^ 0xD045E487u) << 0) ^ 0) << 0) >> 0;
					continue;
				case 43u:
					zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.AddComponent<GraphicRaycaster>();
					num = (int)(((((num2 + 1812043280) ^ 0x8EDE318Bu) - 0) ^ 0) + 0) >> 0;
					continue;
				case 31u:
					num = (int)((((((num2 + 1674602320) ^ 0x35040CFC) - 0) ^ 0) << 0) + 0);
					continue;
				case 22u:
					val4.renderMode = (RenderMode)2;
					num = (int)((num2 + 1201792116) ^ 0x1E1B7627 ^ 0 ^ 0) >> 0 << 0;
					continue;
				case 23u:
					num = ((((int)((num2 + 990853309) ^ 0xFBB1B006u) >> 0) - 0) ^ 0) << 0;
					continue;
				case 33u:
					val.resizeTextMinSize = 0;
					num = (int)((((num2 + 2035719306) ^ 0xDF74568Bu) + 0 << 0) - 0) >> 0;
					continue;
				case 24u:
					val3.dynamicPixelsPerUnit = 1000f;
					num = (((int)((num2 + 2115827143) ^ 0xC9ED6B77u ^ 0) >> 0) - 0) ^ 0;
					continue;
				case 48u:
					num = ((((int)num2 + -1453520766) ^ -890617193) + 0 << 0) + 0 << 0;
					continue;
				case 25u:
				{
					GameObject val2 = new GameObject();
					val2.transform.parent = zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.transform;
					val = val2.AddComponent<Text>();
					num = ((((int)num2 + -1520509820) ^ -1938032363) + 0 + 0 >> 0) ^ 0;
					continue;
				}
				case 36u:
					num = (((int)num2 + -1817294979) ^ -830408475 ^ 0) - 0 >> 0 << 0;
					continue;
				case 26u:
					val.font = Resources.GetBuiltinResource<Font>(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﳭﳞﳅﳍﳀﲂﳘﳘﳊ", 90963116, true));
					num = (((((int)num2 + -1499634342) ^ -1173290507) >> 0) + 0 - 0) ^ 0;
					continue;
				case 53u:
					num = (((int)num2 + -837232188) ^ 0x6856F590 ^ 0 ^ 0 ^ 0) + 0;
					continue;
				case 38u:
					((Transform)component).position = new Vector3(0.06f, 0f, 0.205f);
					num = (((((int)num2 + -715369700) ^ 0x36AF7B4F) - 0) ^ 0) - 0 + 0;
					continue;
				case 27u:
					val.text = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("荸茐茹茪茵茷茶茡荶茔茗茔荸荸", 1163559768, true);
					num = ((((int)num2 + -1575253258) ^ 0x3EBE0FC7) - 0 << 0) + 0 >> 0;
					continue;
				case 28u:
					num = ((((int)num2 + -1235864212) ^ -1585780343) + 0 - 0 + 0) ^ 0;
					continue;
				case 29u:
					val.fontSize = 1;
					num = (int)(((num2 + 928946125) ^ 0x7F8C15DE) + 0 << 0) >> 0 >> 0;
					continue;
				case 42u:
					num = (int)((((num2 + 770196872) ^ 0x68F24EA2) << 0 << 0) + 0) >> 0;
					continue;
				case 41u:
					return;
				}
				break;
			}
		}
	}

	public static void MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(string Text, float textypos, float buttonypos, string Pagenum, ref bool Button, int index)
	{
		//IL_0a49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fcf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fed: Unknown result type (might be due to invalid IL or missing references)
		//IL_1069: Unknown result type (might be due to invalid IL or missing references)
		//IL_1078: Unknown result type (might be due to invalid IL or missing references)
		//IL_1226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0931: Unknown result type (might be due to invalid IL or missing references)
		//IL_100a: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = default(GameObject);
		bool flag3 = default(bool);
		float num6 = default(float);
		Text val2 = default(Text);
		bool flag = default(bool);
		RectTransform component = default(RectTransform);
		Quaternion rotation = default(Quaternion);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301841;
			while (true)
			{
				uint num2;
				int num5;
				switch ((num2 = (uint)((((num << 0) + (0 + 0) >> 0) - 0 << 0 << (0 ^ 0) << 0) - 0)) % 80)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					val = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (int)((((num2 + 11998589) ^ 0x5C43B419) + 0 - 0 + 0) ^ 0);
					continue;
				case 71u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (((((int)num2 + -1904678002) ^ -541320761) + 0 << 0) + 0) ^ 0;
					continue;
				case 73u:
					val.GetComponent<Renderer>().material.color = PqcGZmSgPPKxOgNBQnglmyYKkNXnrYcVNqVjYDWHOxvcIePLOaHCjaVrsswloFOQMPKylEDmqyxPcWbfXmyrrzLMuDRGhLtjIFpTurAkxumLDgpwqqocgxzmeXdHMXeFfngxGhKGMnUWnainovpQwqckfdPxnSxzqHFpaSP;
					num = (((int)num2 + -1113568775) ^ 0x76FD8216 ^ 0) - 0 >> 0 >> 0;
					continue;
				case 2u:
					num = ((((int)num2 + -719845573) ^ -526029026) - 0 >> 0 << 0) - 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val.GetComponent<BoxCollider>());
					num = (((int)num2 + -1756947900) ^ -1308746141) - 0 + 0 - 0 - 0;
					continue;
				case 4u:
					num = (int)(((num2 + 67747431) ^ 0x23DF994 ^ 0) - 0 - 0 + 0);
					continue;
				case 59u:
					flag3 = num6 > eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv;
					num = (0x22CE566A ^ 0) - 0 + 0;
					continue;
				case 79u:
					val.transform.parent = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform;
					num = (((int)((num2 + 329939053) ^ 0x78A506B9 ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 5u:
					num = ((((int)num2 + -290999538) ^ 0xA8D0BD5) << 0) - 0 - 0 + 0;
					continue;
				case 47u:
					num = (int)((((((num2 + 719197468) ^ 0xCB7CD88Bu) << 0) + 0) ^ 0) << 0);
					continue;
				case 6u:
					val.transform.rotation = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.rotation;
					num = (((int)((num2 + 1892383293) ^ 0xFC540342u) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 65u:
					num = (((((int)num2 + -1532611491) ^ -1702272695 ^ 0) << 0) ^ 0) >> 0;
					continue;
				case 7u:
					val.transform.localScale = new Vector3(0.05f, 0.8f, 0.08f);
					num = (((int)((num2 + 649143086) ^ 0xC7F41AEDu) >> 0 << 0) ^ 0) >> 0;
					continue;
				case 50u:
					num = (((int)num2 + -388739541) ^ -655706661 ^ 0 ^ 0 ^ 0) << 0;
					continue;
				case 8u:
					num = (((int)num2 + -661434340) ^ 0x43B3DE8D ^ 0) << 0 << 0 << 0;
					continue;
				case 9u:
					val.transform.localPosition = new Vector3(0.54f, 0f, buttonypos - tTinJAoqDdIxOUkinJpRJMcmmjBHLtxGxdLcsBVCFclUgvhoiRAyxKlHRWbAYHFkGbaKihPMNMmHAhfRbmzTSZiMRekwAuEYwboeuwfacOKKxEgJQjzLhMsGTnTeXtltiokzTawEhzRdoxpmXAGqVSQKJHlhDbcICrBjuHQPNVEHUosvYGgwNVyqyzPmPpafwiBWWgSpKQDanjP / 1.2f);
					num = (((((int)num2 + -504175385) ^ 0x6EAE1255) - 0) ^ 0) - 0 >> 0;
					continue;
				case 63u:
					hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[index] = Button;
					num = (((int)num2 + -1020659917) ^ -1598441745 ^ 0) - 0 + 0 << 0;
					continue;
				case 69u:
					num = (((((int)num2 + -1568917589) ^ -951879734) >> 0) ^ 0) - 0 >> 0;
					continue;
				case 10u:
				{
					GameObject val3 = new GameObject();
					val3.transform.parent = zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.transform;
					val2 = val3.AddComponent<Text>();
					num = (int)((((num2 + 824698952) ^ 0x62B77B89) - 0 + 0 << 0) + 0);
					continue;
				}
				case 11u:
					val2.font = Resources.GetBuiltinResource<Font>(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﱞﱭﱶﱾﱳﰱﱫﱫﱹ", 1125907487, true));
					num = ((int)((num2 + 268319629) ^ 0x75F640C5) >> 0 >> 0) - 0 - 0;
					continue;
				case 55u:
					Object.Destroy((Object)(object)val2, Time.deltaTime);
					num = (((int)((num2 + 412454015) ^ 0x2C4B8C5E) >> 0) ^ 0) - 0 + 0;
					continue;
				case 61u:
					num = ((((int)num2 + -1030955589) ^ -1662447820) << 0 >> 0 >> 0) ^ 0;
					continue;
				case 12u:
					val2.text = Text;
					num = ((((((int)num2 + -1524965430) ^ -1868717493) << 0) + 0) ^ 0) + 0;
					continue;
				case 66u:
				{
					int num9;
					int num10;
					if (flag)
					{
						num9 = 967277501;
						num10 = num9;
					}
					else
					{
						num9 = 1368237665;
						num10 = num9;
					}
					num = ((int)(((uint)(num9 - 0 - 0) ^ (num2 + 758453792) ^ 0) << 0) >> 0) + 0;
					continue;
				}
				case 13u:
					num = (int)(((num2 + 1742690051) ^ 0xAE9636BEu ^ 0) + 0 + 0 - 0);
					continue;
				case 14u:
					((Graphic)val2).color = new Color(255f, 255f, 255f);
					num = ((int)(((num2 + 1812043280) ^ 0xF48A54D2u) + 0) >> 0) - 0 << 0;
					continue;
				case 76u:
					num = (int)((((((num2 + 1201792116) ^ 0x3A791E5F) << 0) ^ 0) << 0) - 0);
					continue;
				case 77u:
					num = (((((int)num2 + -1891284979) ^ -35837795) - 0) ^ 0) << 0 << 0;
					continue;
				case 15u:
					val2.fontSize = 1;
					num = (int)((((num2 + 990853309) ^ 0x96D4C32Cu) - 0 + 0 << 0) + 0);
					continue;
				case 16u:
					num = (int)((((num2 + 2115827143) ^ 0xC022CFC7u) << 0) - 0 + 0 - 0);
					continue;
				case 44u:
					Button = false;
					num = ((((int)num2 + -97328752) ^ 0x2E1A9F3) - 0 - 0 >> 0) + 0;
					continue;
				case 64u:
					val2.alignment = (TextAnchor)4;
					num = ((((((int)num2 + -1453520766) ^ 0x7D7646A3) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 17u:
					num = (((int)num2 + -1520509820) ^ 0x1BB83277 ^ 0) + 0 - 0 >> 0;
					continue;
				case 18u:
					val2.resizeTextForBestFit = true;
					num = ((((int)num2 + -1499634342) ^ -485791953) - 0 >> 0) + 0 - 0;
					continue;
				case 49u:
					num = (((((int)num2 + -68267991) ^ 0x20FBFA4C) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 19u:
					num = ((((int)num2 + -837232188) ^ 0x11973E8C) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 75u:
					val2.resizeTextMinSize = 0;
					num = (((int)num2 + -1575253258) ^ -926088619 ^ 0) >> 0 >> 0 >> 0;
					continue;
				case 54u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = ((0x5691EBDD ^ 0) >> 0) - 0 >> 0;
					continue;
				case 20u:
					num = ((((int)num2 + -1235864212) ^ 0x1DFED255) << 0 >> 0 << 0) + 0;
					continue;
				case 21u:
					component = ((Component)val2).GetComponent<RectTransform>();
					num = (int)(((num2 + 928946125) ^ 0x21C4A56E ^ 0) + 0 << 0 << 0);
					continue;
				case 60u:
					((Transform)component).localPosition = Vector3.zero;
					num = (((int)(((num2 + 770196872) ^ 0x48E54E22) << 0) >> 0) ^ 0) - 0;
					continue;
				case 42u:
				{
					int num7;
					int num8;
					if (!flag3)
					{
						num7 = -2003568639;
						num8 = num7;
					}
					else
					{
						num7 = -1947169756;
						num8 = num7;
					}
					num = ((num7 >> 0 << 0) ^ ((int)num2 + -1271498811) ^ 0) >> 0 << 0 >> 0;
					continue;
				}
				case 22u:
					num = (int)(((((num2 + 1472348834) ^ 0xEE3BD40Fu) + 0) ^ 0) - 0 + 0);
					continue;
				case 23u:
					component.sizeDelta = new Vector2(0.2f, 0.03f);
					num = (int)(((num2 + 1674602320) ^ 0xA2F09F9Fu) - 0 + 0 - 0 << 0);
					continue;
				case 45u:
					num = (((((int)num2 + -562942426) ^ 0xF52366D) - 0 + 0) ^ 0) - 0;
					continue;
				case 24u:
					num = ((((int)num2 + -1111342977) ^ 0xE403CA4) - 0 + 0 >> 0) - 0;
					continue;
				case 67u:
					((Transform)component).localPosition = new Vector3(0.064f, 0f, textypos - tTinJAoqDdIxOUkinJpRJMcmmjBHLtxGxdLcsBVCFclUgvhoiRAyxKlHRWbAYHFkGbaKihPMNMmHAhfRbmzTSZiMRekwAuEYwboeuwfacOKKxEgJQjzLhMsGTnTeXtltiokzTawEhzRdoxpmXAGqVSQKJHlhDbcICrBjuHQPNVEHUosvYGgwNVyqyzPmPpafwiBWWgSpKQDanjP / 3.05f);
					num = ((((((int)num2 + -1529358628) ^ -815714202) >> 0) ^ 0) >> 0) + 0;
					continue;
				case 25u:
					num = ((int)(((num2 + 2035719306) ^ 0xD983B9E9u) + 0 - 0) >> 0) + 0;
					continue;
				case 70u:
					num = (((((int)num2 + -1393679179) ^ -196296231) << 0) ^ 0) << 0 << 0;
					continue;
				case 26u:
					rotation = val.transform.rotation * Quaternion.Euler(180f, 90f, 90f);
					num = (int)((((((num2 + 700820505) ^ 0x3549D8E9) << 0) + 0) ^ 0) << 0);
					continue;
				case 74u:
					((Transform)component).rotation = rotation;
					num = (((((int)num2 + -1588119460) ^ -1626073155) >> 0 << 0) - 0) ^ 0;
					continue;
				case 52u:
					num = ((((int)num2 + -1940307494) ^ -1765327525) >> 0) + 0 >> 0 >> 0;
					continue;
				case 27u:
					num = ((((((int)num2 + -727923521) ^ 0x6D3F4976) << 0) ^ 0) << 0) - 0;
					continue;
				case 28u:
					num6 = Vector3.Distance(val.transform.position, sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.transform.position);
					num = ((((int)num2 + -1817294979) ^ -64817276) >> 0) + 0 + 0 - 0;
					continue;
				case 29u:
					if (num6 <= eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv)
					{
						num = (((int)num2 + -852338334) ^ 0x9E1DA75) + 0 + 0 + 0 - 0;
						continue;
					}
					num5 = 0;
					goto IL_10f3;
				case 41u:
					num = ((int)(((num2 + 823007552) ^ 0xF9BBA6D7u) + 0) >> 0 << 0) ^ 0;
					continue;
				case 58u:
					num5 = ((Time.time - uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS > rOwOsEgmsnqGMeHOThUoEICZObAONoBDEPBDUvKqSccUfDJCuDXfAloJlxZrerzdMMcXCdUyxEvCFHTlrYtkrvdsARrwvtlADZisALZrIzIVPMeEENZgXpM) ? 1 : 0);
					goto IL_10f3;
				case 30u:
				{
					int num3;
					int num4;
					if (flag2)
					{
						num3 = -520347475;
						num4 = num3;
					}
					else
					{
						num3 = -384817815;
						num4 = num3;
					}
					num = (((((num3 ^ 0) + 0) ^ ((int)num2 + -1751013260)) + 0) ^ 0) - 0 + 0;
					continue;
				}
				case 43u:
					num = (int)(((num2 + 518814049) ^ 0x690D59D0) << 0) >> 0 >> 0 << 0;
					continue;
				case 31u:
					num = (((int)num2 + -1261085613) ^ -2080164868 ^ 0) - 0 - 0 - 0;
					continue;
				case 62u:
					Button = true;
					num = ((int)(((num2 + 1334533754) ^ 0xF2D8B998u) + 0 << 0) >> 0) ^ 0;
					continue;
				case 32u:
					hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[index] = Button;
					num = ((int)((num2 + 1175360126) ^ 0xF16AA53Fu) >> 0 << 0 >> 0) ^ 0;
					continue;
				case 46u:
					flag = Button;
					num = (386283186 + 0 >> 0 >> 0) - 0;
					continue;
				case 33u:
					eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt = Pagenum;
					num = ((int)((num2 + 1402561575) ^ 0xA53719FAu) >> 0) + 0 + 0 + 0;
					continue;
				case 34u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(14, false, 0.05f);
					num = ((int)(((num2 + 1448854582) ^ 0x113BA1AC) + 0) >> 0) + 0 - 0;
					continue;
				case 48u:
					val.GetComponent<Renderer>().material.color = MjdnoRxnpPZBDYxKonsFcwQsHaCfiPqQAxkXbeCLKJyomypFpjcuzknptLFnoseAziagOAJjLGUsYCgjKXPYMVqqjUEpzoxsEXPdxjRPzTJTpUrQEwCqCfNESKWTVuKwjCOaNdLBgaySlxaoDNKdMgPykklMnXTfjnJMgqdBKbkCHUsuKHqiJGKdNqQCRYnjgtJYNoimJisLVnRpRQcFGLwCDFZPABKMNavnluGvzeyAoYhzzBKbVICvWgvhptLiyGYVSDexjHgCmVoEyzpZQJQeyZreZzgfsqbHamHWxmRoCajaSQJPdMrPPTwSlZyKAajWUGElRtCERCCxQqmi;
					num = ((((int)((num2 + 1269569957) ^ 0xC1E8E224u) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 68u:
					num = (((((int)num2 + -1740227389) ^ 0x46C6DB54) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 35u:
					Object.Destroy((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu);
					num = ((int)((num2 + 2080546621) ^ 0xC2AED714u) >> 0 >> 0 >> 0) - 0;
					continue;
				case 36u:
					num = ((((int)num2 + -606707536) ^ -1227308644) << 0 >> 0) + 0 >> 0;
					continue;
				case 51u:
					num = 0x65996B39 ^ 0;
					continue;
				case 72u:
					Object.Destroy((Object)(object)sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX);
					num = (int)((((num2 + 1099667150) ^ 0xFE5C7EC3u) + 0 - 0 << 0) ^ 0);
					continue;
				case 37u:
					num = ((int)((num2 + 1892732207) ^ 0x8137D592u) >> 0 << 0) - 0 >> 0;
					continue;
				case 53u:
					num = ((int)((((num2 + 1817959541) ^ 0xCC1D0EACu) + 0) ^ 0) >> 0) + 0;
					continue;
				case 38u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu = null;
					num = ((((int)num2 + -339525817) ^ 0x5814475A) - 0 - 0 - 0) ^ 0;
					continue;
				case 39u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX = null;
					num = (((((int)num2 + -1361039952) ^ -1737477527) - 0 >> 0) ^ 0) << 0;
					continue;
				case 78u:
					uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS = Time.time;
					num = (((int)((num2 + 895677943) ^ 0xDEF914CDu) >> 0) - 0 >> 0) + 0;
					continue;
				case 56u:
					num = (int)((((num2 + 1831646315) ^ 0xE2574E2Au) << 0 << 0) + 0 - 0);
					continue;
				case 40u:
					num = ((((int)num2 + -302506815) ^ 0x329B4400) - 0 >> 0 >> 0) + 0;
					continue;
				case 57u:
					return;
					IL_10f3:
					flag2 = (byte)num5 != 0;
					num = 1548432910 + 0 >> 0 >> 0 << 0;
					continue;
				}
				break;
			}
		}
	}

	public static void vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(string Text, float textypos, float buttonypos, ref bool ButtonRange, ref bool Mod, int index)
	{
		//IL_09e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1056: Unknown result type (might be due to invalid IL or missing references)
		//IL_1065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b94: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee2: Unknown result type (might be due to invalid IL or missing references)
		GameObject val2 = default(GameObject);
		Text val = default(Text);
		bool flag = default(bool);
		bool flag3 = default(bool);
		RectTransform component = default(RectTransform);
		Quaternion rotation = default(Quaternion);
		float num3 = default(float);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301854;
			while (true)
			{
				uint num2;
				int num6;
				switch ((num2 = (uint)((((((num + 0 << -0) ^ 0) + 0 >> 0) ^ 0) >> 0) - 0)) % 77)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					val2 = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (int)((((num2 + 403315589) ^ 0xB510BA0Du ^ 0) << 0) - 0) >> 0;
					continue;
				case 71u:
					Object.Destroy((Object)(object)val2.GetComponent<Rigidbody>());
					num = ((((((int)num2 + -396906955) ^ 0x59D5C0C) + 0) ^ 0) << 0) + 0;
					continue;
				case 73u:
					Object.Destroy((Object)(object)val2, Time.deltaTime);
					num = ((((int)num2 + -68267991) ^ 0x34438CAC) - 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 2u:
					num = ((int)((((num2 + 1246932057) ^ 0x75E808BE) - 0) ^ 0) >> 0) ^ 0;
					continue;
				case 3u:
					Object.Destroy((Object)(object)val2.GetComponent<BoxCollider>());
					num = (((((int)num2 + -100986504) ^ 0x1C42296D ^ 0) << 0) ^ 0) + 0;
					continue;
				case 4u:
					num = (((int)((num2 + 583561026) ^ 0x21FCA9A5) >> 0 >> 0) ^ 0) >> 0;
					continue;
				case 59u:
					num = (int)((((num2 + 1379230453) ^ 0x4FFC0941) << 0) + 0 << 0) >> 0;
					continue;
				case 57u:
					val2.transform.parent = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform;
					num = ((((int)num2 + -1536809407) ^ -371633795) << 0 >> 0 << 0) + 0;
					continue;
				case 5u:
					num = (((int)num2 + -1999758855) ^ -1804291782) >> 0 << 0 >> 0 >> 0;
					continue;
				case 47u:
					num = 0x630693E0 ^ 0;
					continue;
				case 6u:
					val2.transform.rotation = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.rotation;
					num = (((((int)num2 + -1497151632) ^ -1235226605) + 0 << 0) ^ 0) - 0;
					continue;
				case 65u:
					num = ((((int)((num2 + 234277810) ^ 0x25D9D6F1) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 7u:
					val2.transform.localScale = new Vector3(0.05f, 0.8f, 0.08f);
					num = ((((int)num2 + -554548610) ^ 0x353D46) << 0) - 0 + 0 + 0;
					continue;
				case 50u:
					fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[index] = ButtonRange;
					num = 0x15B6EAEB ^ 0;
					continue;
				case 8u:
					num = ((((int)((num2 + 1195113832) ^ 0xFC180C5Bu) >> 0) + 0) ^ 0) + 0;
					continue;
				case 9u:
					val2.transform.localPosition = new Vector3(0.54f, 0f, buttonypos - tTinJAoqDdIxOUkinJpRJMcmmjBHLtxGxdLcsBVCFclUgvhoiRAyxKlHRWbAYHFkGbaKihPMNMmHAhfRbmzTSZiMRekwAuEYwboeuwfacOKKxEgJQjzLhMsGTnTeXtltiokzTawEhzRdoxpmXAGqVSQKJHlhDbcICrBjuHQPNVEHUosvYGgwNVyqyzPmPpafwiBWWgSpKQDanjP / 1.2f);
					num = (int)(((num2 + 1608343532) ^ 0xE8849704u) - 0 << 0) >> 0 << 0;
					continue;
				case 63u:
					((Graphic)val).color = new Color(0.5f, 0f, 0.5f);
					num = (int)((((((num2 + 1641079189) ^ 0x3C09D49) + 0) ^ 0) + 0) ^ 0);
					continue;
				case 69u:
					num = ((((int)num2 + -534003067) ^ 0x2F2E0E5) << 0 >> 0) - 0 >> 0;
					continue;
				case 10u:
					val2.GetComponent<Renderer>().material.color = Color.black;
					num = (((int)num2 + -863337981) ^ -1659510742) + 0 + 0 - 0 + 0;
					continue;
				case 11u:
					num = ((((int)num2 + -2071238116) ^ -1068952590 ^ 0) >> 0 >> 0) + 0;
					continue;
				case 40u:
					num = ((int)((num2 + 837534527) ^ 0xFE66ADA7u) >> 0) - 0 - 0 + 0;
					continue;
				case 61u:
				{
					GameObject val3 = new GameObject();
					val3.transform.parent = zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke.transform;
					val = val3.AddComponent<Text>();
					num = (int)(((((num2 + 707265091) ^ 0x74822265) + 0 << 0) ^ 0) + 0);
					continue;
				}
				case 12u:
					val.font = Resources.GetBuiltinResource<Font>(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("♽♎♕♝♐☒♈♈♚", 2125801020, true));
					num = ((int)((num2 + 470890995) ^ 0x78A0C07) >> 0) + 0 + 0 >> 0;
					continue;
				case 66u:
					num = (int)(((num2 + 643276067) ^ 0x31B098AB ^ 0 ^ 0) - 0 << 0);
					continue;
				case 13u:
					num = (int)(((num2 + 1381583965) ^ 0xD51C2374u) - 0 + 0) >> 0 >> 0;
					continue;
				case 14u:
					val.text = Text;
					num = ((((int)num2 + -646352687) ^ 0x19023FC6) << 0) + 0 << 0 << 0;
					continue;
				case 76u:
					num = (int)(((((num2 + 808537251) ^ 0x288A609) << 0) - 0 - 0) ^ 0);
					continue;
				case 56u:
				{
					int num9;
					int num10;
					if (flag)
					{
						num9 = 437046264;
						num10 = num9;
					}
					else
					{
						num9 = 1632602755;
						num10 = num9;
					}
					num = ((((num9 << 0) - 0) ^ ((int)num2 + -244264755)) + 0 - 0 << 0) - 0;
					continue;
				}
				case 15u:
					((Graphic)val).color = new Color(255f, 255f, 255f);
					num = (int)((((num2 + 2033488390) ^ 0xD4F26C13u ^ 0 ^ 0) << 0) + 0);
					continue;
				case 16u:
					num = ((int)(((num2 + 1515080385) ^ 0x2453226A) + 0) >> 0 << 0) + 0;
					continue;
				case 44u:
					num = ((((((int)num2 + -985911026) ^ -672432566) - 0) ^ 0) << 0) ^ 0;
					continue;
				case 64u:
					val.fontSize = 1;
					num = ((((int)num2 + -1855006857) ^ -1788562134 ^ 0) >> 0 << 0) - 0;
					continue;
				case 17u:
					num = (int)(((num2 + 179208694) ^ 0xB108D51Bu) + 0 - 0) >> 0 >> 0;
					continue;
				case 18u:
					val.alignment = (TextAnchor)4;
					num = ((int)(((num2 + 1989400013) ^ 0x9332F6A0u ^ 0) << 0) >> 0) + 0;
					continue;
				case 49u:
					num = (int)((((((num2 + 758453792) ^ 0xD73C0029u) - 0) ^ 0) - 0) ^ 0);
					continue;
				case 19u:
					num = ((((int)num2 + -358205772) ^ 0x3D00819B ^ 0) - 0 >> 0) - 0;
					continue;
				case 75u:
					val.resizeTextForBestFit = true;
					num = (((((int)num2 + -800455404) ^ -1631810169) >> 0) ^ 0) - 0 + 0;
					continue;
				case 54u:
					num = (int)((((num2 + 2070798804) ^ 0xFE08E5C1u ^ 0) << 0) - 0 - 0);
					continue;
				case 20u:
					num = (int)((((num2 + 296526287) ^ 0xB144A518u) - 0) ^ 0 ^ 0 ^ 0);
					continue;
				case 21u:
					val.resizeTextMinSize = 0;
					num = (((int)num2 + -1179582984) ^ -1080684766) - 0 >> 0 >> 0 >> 0;
					continue;
				case 60u:
					num = (((((int)num2 + -2139291301) ^ -94795228) >> 0) ^ 0) - 0 - 0;
					continue;
				case 42u:
					flag3 = Mod;
					num = (1559511535 >> 0 << 0 << 0) - 0;
					continue;
				case 22u:
					component = ((Component)val).GetComponent<RectTransform>();
					num = ((int)(((num2 + 499878478) ^ 0x3032ABEC) << 0) >> 0) - 0 - 0;
					continue;
				case 23u:
					((Transform)component).localPosition = Vector3.zero;
					num = ((((int)num2 + -535798627) ^ 0x26B095A6) << 0 << 0 >> 0) + 0;
					continue;
				case 45u:
					num = ((((((int)num2 + -1873876894) ^ 0x5D368CA7) >> 0) ^ 0) << 0) + 0;
					continue;
				case 24u:
					num = (((int)(((num2 + 705231750) ^ 0xA2196169u) + 0) >> 0) ^ 0) - 0;
					continue;
				case 67u:
					component.sizeDelta = new Vector2(0.2f, 0.03f);
					num = ((int)(((num2 + 749445460) ^ 0x4734FBC7) + 0) >> 0) + 0 + 0;
					continue;
				case 25u:
					num = ((((((int)num2 + -788358910) ^ -1579178624) - 0) ^ 0) >> 0) - 0;
					continue;
				case 70u:
					num = (int)((((num2 + 719197468) ^ 0x7A7C3070 ^ 0) + 0 << 0) + 0);
					continue;
				case 26u:
					((Transform)component).localPosition = new Vector3(0.064f, 0f, textypos - tTinJAoqDdIxOUkinJpRJMcmmjBHLtxGxdLcsBVCFclUgvhoiRAyxKlHRWbAYHFkGbaKihPMNMmHAhfRbmzTSZiMRekwAuEYwboeuwfacOKKxEgJQjzLhMsGTnTeXtltiokzTawEhzRdoxpmXAGqVSQKJHlhDbcICrBjuHQPNVEHUosvYGgwNVyqyzPmPpafwiBWWgSpKQDanjP / 3.05f);
					num = ((((((int)num2 + -263229304) ^ 0x73C31475) >> 0) ^ 0) + 0) ^ 0;
					continue;
				case 74u:
					num = (((int)((num2 + 2146902915) ^ 0xBE7423CEu ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 52u:
					num = ((((((int)num2 + -1393679179) ^ 0x76681E05) + 0) ^ 0) << 0) + 0;
					continue;
				case 27u:
					rotation = val2.transform.rotation * Quaternion.Euler(180f, 90f, 90f);
					num = ((((((int)num2 + -656729457) ^ 0x6161FF3C) << 0) ^ 0) >> 0) - 0;
					continue;
				case 28u:
					((Transform)component).rotation = rotation;
					num = (int)(((num2 + 65153632) ^ 0x6FEED4AE) - 0 - 0 - 0 - 0);
					continue;
				case 29u:
					num = (int)((num2 + 827754557) ^ 0x758424B1 ^ 0) >> 0 << 0 << 0;
					continue;
				case 41u:
					ButtonRange = false;
					num = ((((int)num2 + -1280384979) ^ 0x3231ABC6) - 0 + 0 << 0) ^ 0;
					continue;
				case 58u:
					num3 = Vector3.Distance(val2.transform.position, sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.transform.position);
					num = (((int)num2 + -811454883) ^ -1976019077) + 0 - 0 - 0 - 0;
					continue;
				case 30u:
					if (num3 <= eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv)
					{
						num = (int)(((((num2 + 929739382) ^ 0x80A516A0u) << 0) ^ 0) << 0) >> 0;
						continue;
					}
					goto IL_1110;
				case 43u:
				{
					int num7;
					int num8;
					if (!flag3)
					{
						num7 = -1660020602;
						num8 = num7;
					}
					else
					{
						num7 = -226505355;
						num8 = num7;
					}
					num = ((((num7 - 0 << 0) ^ ((int)num2 + -2086801928)) - 0 >> 0) ^ 0) + 0;
					continue;
				}
				case 31u:
					if (!ButtonRange)
					{
						num = ((((int)num2 + -277516137) ^ 0x4163079B ^ 0 ^ 0) >> 0) - 0;
						continue;
					}
					goto IL_1110;
				case 62u:
					num6 = ((Time.time - uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS > rOwOsEgmsnqGMeHOThUoEICZObAONoBDEPBDUvKqSccUfDJCuDXfAloJlxZrerzdMMcXCdUyxEvCFHTlrYtkrvdsARrwvtlADZisALZrIzIVPMeEENZgXpM) ? 1 : 0);
					goto IL_1111;
				case 32u:
				{
					int num4;
					int num5;
					if (!flag2)
					{
						num4 = 1679009425;
						num5 = num4;
					}
					else
					{
						num4 = 693043253;
						num5 = num4;
					}
					num = (int)((((uint)((num4 >> 0) - 0) ^ (num2 + 501888951)) << 0 << 0) - 0 - 0);
					continue;
				}
				case 46u:
					num = (((int)((num2 + 863302996) ^ 0x840A1D29u ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 33u:
					num = (int)((((num2 + 557269837) ^ 0x7754FAAE) + 0 << 0 << 0) - 0);
					continue;
				case 34u:
					ButtonRange = true;
					num = (((((int)num2 + -1873812145) ^ -349208555) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 48u:
					((Graphic)val).color = new Color(255f, 255f, 255f);
					num = (((int)((num2 + 81687086) ^ 0x8BF49AD) >> 0) ^ 0) + 0 + 0;
					continue;
				case 68u:
					Mod = !Mod;
					num = ((((int)num2 + -1265694141) ^ 0x630F0EDF) + 0 >> 0 >> 0) + 0;
					continue;
				case 35u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(14, false, 0.05f);
					num = (((((int)num2 + -227079681) ^ 0x381A4C2F ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 36u:
					num = ((((int)num2 + -946157137) ^ -1701544145) + 0 - 0 >> 0) + 0;
					continue;
				case 51u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[index] = Mod;
					num = ((int)((num2 + 1269569957) ^ 0x4FA6FCC ^ 0) >> 0) + 0 - 0;
					continue;
				case 72u:
					uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS = Time.time;
					num = ((int)(((num2 + 1641116637) ^ 0xDE9AA1ECu) - 0 << 0) >> 0) ^ 0;
					continue;
				case 37u:
					num = (int)(((num2 + 359358379) ^ 0x2C52473C) + 0 << 0 << 0) >> 0;
					continue;
				case 53u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (((((int)num2 + -388739541) ^ 0x7085B894) + 0 >> 0) ^ 0) - 0;
					continue;
				case 38u:
					num = (((((int)num2 + -1078135537) ^ 0x35415BF8) - 0 + 0) ^ 0) + 0;
					continue;
				case 39u:
					flag = (num3 > eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv) & ButtonRange;
					num = (1376848914 - 0 >> 0 >> 0) - 0;
					continue;
				case 55u:
					return;
					IL_1110:
					num6 = 0;
					goto IL_1111;
					IL_1111:
					flag2 = (byte)num6 != 0;
					num = ((0x61A87E6E ^ 0) << 0) - 0;
					continue;
				}
				break;
			}
		}
	}

	public static void gHSaVqheNUSMSfHLcsPHkzYaMgIAogCoqkeQwChirxKmkRPLNIVaYKNGIRoOIGPGrEvIaRoAlHqMOMQUrWNFkCpGxxhFotzLHdVFvgLWuvPruaSWbtwLTkwPpPlCKJmShFfLQkyklRlPNYlwFkDUWORxHfqGVimLjXjPUggRUlzcYHcrEOWzfrVtNHdKUSodEAGPPvCzeMaLpP()
	{
		//IL_4fcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_8d8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_a311: Unknown result type (might be due to invalid IL or missing references)
		//IL_a316: Unknown result type (might be due to invalid IL or missing references)
		//IL_a528: Unknown result type (might be due to invalid IL or missing references)
		//IL_a52d: Unknown result type (might be due to invalid IL or missing references)
		//IL_a543: Unknown result type (might be due to invalid IL or missing references)
		//IL_4f76: Unknown result type (might be due to invalid IL or missing references)
		//IL_47e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_47f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_6d98: Unknown result type (might be due to invalid IL or missing references)
		//IL_7305: Unknown result type (might be due to invalid IL or missing references)
		//IL_8d0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_9260: Unknown result type (might be due to invalid IL or missing references)
		//IL_93b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_9772: Unknown result type (might be due to invalid IL or missing references)
		//IL_a345: Unknown result type (might be due to invalid IL or missing references)
		//IL_a34a: Unknown result type (might be due to invalid IL or missing references)
		//IL_a3d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_a3de: Unknown result type (might be due to invalid IL or missing references)
		//IL_a3ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_a4b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_a4b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_a5fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_a5ff: Unknown result type (might be due to invalid IL or missing references)
		bool flag6 = default(bool);
		bool flag48 = default(bool);
		bool flag32 = default(bool);
		bool flag28 = default(bool);
		bool flag16 = default(bool);
		bool flag19 = default(bool);
		bool flag29 = default(bool);
		bool flag23 = default(bool);
		bool flag21 = default(bool);
		bool flag63 = default(bool);
		bool flag11 = default(bool);
		bool flag3 = default(bool);
		bool flag58 = default(bool);
		bool flag52 = default(bool);
		bool flag49 = default(bool);
		bool flag39 = default(bool);
		bool flag27 = default(bool);
		bool flag31 = default(bool);
		bool flag17 = default(bool);
		bool flag67 = default(bool);
		bool flag66 = default(bool);
		bool flag65 = default(bool);
		bool flag64 = default(bool);
		bool flag62 = default(bool);
		bool flag61 = default(bool);
		bool flag60 = default(bool);
		bool flag59 = default(bool);
		bool flag57 = default(bool);
		bool flag56 = default(bool);
		bool flag55 = default(bool);
		bool flag54 = default(bool);
		bool flag53 = default(bool);
		bool flag51 = default(bool);
		bool flag50 = default(bool);
		bool flag47 = default(bool);
		bool flag46 = default(bool);
		bool flag45 = default(bool);
		bool flag44 = default(bool);
		bool flag43 = default(bool);
		bool flag42 = default(bool);
		Rigidbody val = default(Rigidbody);
		bool flag41 = default(bool);
		Rigidbody val2 = default(Rigidbody);
		bool flag40 = default(bool);
		bool flag38 = default(bool);
		bool flag37 = default(bool);
		bool flag36 = default(bool);
		bool flag35 = default(bool);
		bool flag34 = default(bool);
		bool flag33 = default(bool);
		bool flag30 = default(bool);
		bool flag26 = default(bool);
		bool flag25 = default(bool);
		bool flag24 = default(bool);
		bool flag22 = default(bool);
		bool flag20 = default(bool);
		bool flag18 = default(bool);
		bool flag15 = default(bool);
		bool flag14 = default(bool);
		bool flag13 = default(bool);
		bool flag12 = default(bool);
		bool flag10 = default(bool);
		bool flag9 = default(bool);
		bool flag8 = default(bool);
		bool flag7 = default(bool);
		bool flag5 = default(bool);
		bool flag4 = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301427;
			while (true)
			{
				uint num2;
				int num55;
				int num124;
				int num111;
				int num104;
				int num8;
				int num5;
				switch ((num2 = (uint)((((num << 0) + (0 >> 1) >> 0) ^ 0) + 0 + -0 << 0) ^ 0u) % 625)
				{
				case 368u:
					break;
				default:
					return;
				case 370u:
					num = (int)(((num2 + 112041109) ^ 0x1CACEC80) - 0 + 0) >> 0 << 0;
					continue;
				case 179u:
					num = (int)(((num2 + 525055413) ^ 0x16178BE5) - 0 - 0 << 0) >> 0;
					continue;
				case 547u:
					num = ((((int)num2 + -1302773464) ^ -555754825) - 0 >> 0 << 0) + 0;
					continue;
				case 56u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.RotateAround(dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.position, dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.forward, 180f);
					num = (((int)num2 + -115636187) ^ 0x12A186CD ^ 0) - 0 - 0 << 0;
					continue;
				case 70u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("讼讙讟讘诖讦讃讔讚讟讕", 240421878, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[3], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[3], 3);
					num = ((((int)num2 + -1717886923) ^ -375140357) << 0) + 0 << 0 << 0;
					continue;
				case 83u:
					num = ((int)((num2 + 1596161359) ^ 0x146779A4 ^ 0) >> 0) + 0 - 0;
					continue;
				case 97u:
					num = (((((int)num2 + -1872098726) ^ -232013690) << 0) + 0 + 0) ^ 0;
					continue;
				case 111u:
					num = ((((int)num2 + -932824771) ^ 0x58AA5ECE) + 0 + 0 - 0) ^ 0;
					continue;
				case 124u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쉩쉸쉸쉸쉸", 1508557397, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("믏", 310492157, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((int)((num2 + 2147315204) ^ 0xA3F6E9BCu) >> 0 >> 0 << 0) ^ 0;
					continue;
				case 138u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쁴쁛쁗쁟쀚쁙쁒쁛쁔쁝쁟쀚쁛쁖쁖쀚쁎쁕쀚쀆쁙쁕쁖쁕쁈쀇쁈쁟쁞쀄쁡쁳쁷쀚쁷쁵쁾쁾쁳쁴쁽쀚쁶쁵쁶쁧쀆쀕쁙쁕쁖쁕쁈쀄쀚", 331071546, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[23], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[23], 23);
					num = ((((int)num2 + -444023995) ^ 0x2EBC0719) >> 0) + 0 + 0 >> 0;
					continue;
				case 151u:
					flag6 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue3da", 1924719599, true);
					num = 0x58DB196E ^ 0;
					continue;
				case 165u:
					num = (int)((((num2 + 1092082240) ^ 0x7B351ED4 ^ 0) << 0 << 0) ^ 0);
					continue;
				case 177u:
					if (EasyInputs.GetSecondaryButtonDown((EasyHand)1))
					{
						num = (((((int)num2 + -1129786320) ^ 0x10B170ED ^ 0) + 0) ^ 0) + 0;
						continue;
					}
					num55 = 0;
					goto IL_4c43;
				case 192u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⺜⺜⺜⺜⺏", 163983025, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㑴", 935474243, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((int)num2 + -279153920) ^ 0x728A1C10) << 0) - 0 << 0 >> 0;
					continue;
				case 206u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㠰㠗㠓㠑㠝㠜㠁", 1906129010, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[42], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[42], 42);
					num = (((int)((num2 + 2010813258) ^ 0x88A0B45Eu) >> 0) ^ 0) - 0 - 0;
					continue;
				case 220u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⧈⧥⧿⧯⧣⧢⧢⧩⧯⧸", 1359620492, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = ((int)((num2 + 250447483) ^ 0x2851393C) >> 0) - 0 << 0 >> 0;
					continue;
				case 233u:
					num = (int)(((num2 + 840433494) ^ 0xB96134DDu ^ 0 ^ 0 ^ 0) << 0);
					continue;
				case 247u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = ((((int)num2 + -1098273855) ^ 0x733D14A0) + 0 - 0) ^ 0 ^ 0;
					continue;
				case 260u:
					PhotonNetwork.JoinRandomRoom();
					num = (((int)((num2 + 511404833) ^ 0xE81B3CBAu) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 274u:
				{
					int num98;
					int num99;
					if (!flag48)
					{
						num98 = 1944389715;
						num99 = num98;
					}
					else
					{
						num98 = 1207606824;
						num99 = num98;
					}
					num = (int)(((uint)((num98 << 0) + 0) ^ (num2 + 246215561)) << 0) >> 0 << 0 << 0;
					continue;
				}
				case 288u:
					freeze_rig_in_menu.RQvshcmrMvGvOLpvGFYQflDEdNdyDAWJLcWXSekYSmrzxreYVqDJkqeFmRpuZOOlzWKMPsDBvZYSTegLJeCmWnzvXqLbPPZdygaBHrjDNcnkslLhKDLUmBolwoOyGCMFaVuNeFdrVYzUZpcMEDqlefQWROesDKWlpIjxRYdfAuZoctlgmbTdlBBVexWpAKNkbnFrfFUGAlKKf();
					num = ((int)((num2 + 865576847) ^ 0x4BC7493 ^ 0) >> 0) + 0 + 0;
					continue;
				case 301u:
					num = (((((int)num2 + -794626678) ^ -1622803971) - 0 >> 0) + 0) ^ 0;
					continue;
				case 315u:
				{
					int num60;
					int num61;
					if (!flag32)
					{
						num60 = 1638424671;
						num61 = num60;
					}
					else
					{
						num60 = 1704240605;
						num61 = num60;
					}
					num = (((((num60 - 0) ^ 0 ^ ((int)num2 + -298738852)) + 0) ^ 0) + 0) ^ 0;
					continue;
				}
				case 329u:
					Collider_gun.VYBBEXjOAeNbzgcVAFPrLPEDEgaxiuASeVhjarPrKHRQYFXWgKjwIFwgtXXyWLGgDUWEZSVjPyHdXOFY();
					num = (((int)num2 + -523501109) ^ 0x702892F6 ^ 0 ^ 0) - 0 >> 0;
					continue;
				case 342u:
					num = (((int)num2 + -1407268161) ^ -1006000215) + 0 - 0 + 0 + 0;
					continue;
				case 356u:
					flag28 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[18];
					num = 0x28110B9 ^ 0;
					continue;
				case 545u:
					num55 = (((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu == (Object)null) ? 1 : 0);
					goto IL_4c43;
				case 383u:
					num = ((((int)num2 + -1064593592) ^ -345560988) + 0 << 0 << 0) - 0;
					continue;
				case 397u:
					flag16 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[24];
					num = (1667365398 - 0 >> 0) + 0 << 0;
					continue;
				case 410u:
					flag19 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[26];
					num = 1219172911 + 0 - 0 + 0 << 0;
					continue;
				case 424u:
					anti_crash.fHRjvNhbVmklMDYIKxqxVbNzWufduxcVwpxNFSgwcXigfDPKuEJGgroeUsmbHdGxjoOwglcRqUvXTGttFvJQNvPfbsSnGeOYqKWQOsDiBRqlWqlnYTwltPJNzJvNsOllfwGjKDEmRBpWfDiKhFpNICEBairfWQPMGegzJbDvojuSANIVALGN();
					num = ((int)((num2 + 1491532027) ^ 0xCC6A660Eu) >> 0 << 0) + 0 << 0;
					continue;
				case 438u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⠉⠅⠃⠁⠊⠐⠅", 148318308, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쩫쩄쩞쩃쨊쩦쩋쩍", 1698089514, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("猛猴献猳獺猖猻猽", 1794732890, true));
					num = (int)(((num2 + 1910228146) ^ 0xF69A117) + 0 << 0) >> 0 << 0;
					continue;
				case 451u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (int)((((num2 + 1205423964) ^ 0xFC03ACB2u) + 0 << 0) - 0 << 0);
					continue;
				case 465u:
					num = ((((int)num2 + -241191659) ^ 0x688DB0D3 ^ 0) << 0) + 0 + 0;
					continue;
				case 479u:
					flag29 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[32];
					num = 0xEF6D61 ^ 0;
					continue;
				case 492u:
					num = (int)(((num2 + 895723957) ^ 0x8DCBEF5Eu) + 0 - 0 << 0) >> 0;
					continue;
				case 506u:
					flag23 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[36];
					num = ((1234297382 >> 0) - 0 >> 0) - 0;
					continue;
				case 519u:
				{
					int num137;
					int num138;
					if (flag21)
					{
						num137 = 229695039;
						num138 = num137;
					}
					else
					{
						num137 = 1092665570;
						num138 = num137;
					}
					num = (((int)(((uint)(num137 ^ 0 ^ 0) ^ (num2 + 1427326928)) - 0) >> 0) - 0) ^ 0;
					continue;
				}
				case 533u:
					spazmonk.fFTpkucMvEHNQvtKahElfYgmGgfLkOWvTJWMyHyPdumnaCFXsYLRRrqhzGIdprCGIlTgyGltIOhLLSmeBhtldeECsPnRYvAMRFFPJyzLNsjcjFwGuDCiXqDDGrNJttunovTfnxvdHHyKVCsNtGwuTrOAcbisKQrtXVONLqtXiyAqSSIeYa();
					num = (int)(((((num2 + 1121566163) ^ 0x6F727CA2) - 0 << 0) - 0) ^ 0);
					continue;
				case 54u:
				{
					int num131;
					int num132;
					if (flag63)
					{
						num131 = 883832653;
						num132 = num131;
					}
					else
					{
						num131 = 1025366353;
						num132 = num131;
					}
					num = (int)((((uint)((num131 << 0) - 0) ^ (num2 + 151834850) ^ 0) + 0) ^ 0 ^ 0);
					continue;
				}
				case 560u:
					flag11 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[45];
					num = (0x77EFB98F ^ 0) >> 0;
					continue;
				case 574u:
					num = (((int)((num2 + 2002675978) ^ 0xCE019761u) >> 0) - 0 << 0) ^ 0;
					continue;
				case 588u:
					num = (int)(((((num2 + 1819003593) ^ 0xB9783780u) + 0) ^ 0) + 0) >> 0;
					continue;
				case 601u:
					flag3 = qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp < RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo;
					num = ((int)(((num2 + 367490737) ^ 0x3959F268) << 0 << 0) >> 0) ^ 0;
					continue;
				case 615u:
					qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp += Time.deltaTime;
					num = (((int)((num2 + 343545758) ^ 0x14BDC942) >> 0) + 0 >> 0) ^ 0;
					continue;
				case 48u:
					if (EasyInputs.GetSecondaryButtonDown((EasyHand)1))
					{
						num = (1956669424 << 0) - 0 + 0 - 0;
						continue;
					}
					num124 = 0;
					goto IL_4f05;
				case 49u:
					num124 = (((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu != (Object)null) ? 1 : 0);
					goto IL_4f05;
				case 50u:
				{
					int num120;
					int num121;
					if (!flag58)
					{
						num120 = 932333868;
						num121 = num120;
					}
					else
					{
						num120 = 702773583;
						num121 = num120;
					}
					num = ((((num120 << 0) - 0) ^ ((int)num2 + -481413453)) << 0 << 0 >> 0) + 0;
					continue;
				}
				case 51u:
					num = (((int)num2 + -678785999) ^ -1968915216) >> 0 >> 0 << 0 << 0;
					continue;
				case 52u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.position = Player.Instance.rightHandTransform.position;
					num = (((int)((num2 + 237252431) ^ 0x2F5E71D ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 53u:
					num = (((int)((num2 + 1373578376) ^ 0xE026342Du) >> 0) ^ 0) >> 0 >> 0;
					continue;
				case 3u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.transform.rotation = Player.Instance.rightHandTransform.rotation;
					num = ((int)((num2 + 29846861) ^ 0x42189436) >> 0) - 0 << 0 << 0;
					continue;
				case 55u:
					num = ((((int)num2 + -1005380316) ^ -1920653770) + 0 >> 0 << 0) ^ 0;
					continue;
				case 68u:
					num = ((((((int)num2 + -1198112497) ^ -558925226) << 0) ^ 0) << 0) ^ 0;
					continue;
				case 57u:
					num = (((int)((num2 + 338954066) ^ 0x18DF6A23) >> 0) ^ 0) - 0 << 0;
					continue;
				case 58u:
					num = ((((((int)num2 + -391308095) ^ 0x473769CA) << 0) + 0) ^ 0) - 0;
					continue;
				case 59u:
					if (EasyInputs.GetSecondaryButtonDown((EasyHand)1))
					{
						num = (0x22CE5528 ^ 0) << 0;
						continue;
					}
					num111 = 0;
					goto IL_5088;
				case 60u:
					num111 = (((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu != (Object)null) ? 1 : 0);
					goto IL_5088;
				case 61u:
				{
					int num107;
					int num108;
					if (!flag52)
					{
						num107 = -261380436;
						num108 = num107;
					}
					else
					{
						num107 = -1427764336;
						num108 = num107;
					}
					num = ((int)((uint)((num107 ^ 0) << 0) ^ (num2 + 1528277550)) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				}
				case 62u:
					num = (int)(((num2 + 1654640209) ^ 0x7A4CC298) + 0 + 0 << 0) >> 0;
					continue;
				case 63u:
					flag49 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udb1e", 1243929391, true);
					num = (int)(((((num2 + 826756167) ^ 0x335A685D) + 0) ^ 0) + 0 - 0);
					continue;
				case 64u:
				{
					int num100;
					int num101;
					if (!flag49)
					{
						num100 = -224435903;
						num101 = num100;
					}
					else
					{
						num100 = -133148359;
						num101 = num100;
					}
					num = (int)(((uint)(num100 >> 0 << 0) ^ (num2 + 892637984) ^ 0) - 0 - 0 + 0);
					continue;
				}
				case 65u:
					num = ((((int)num2 + -1489850159) ^ 0x11CFD34D) - 0 - 0) ^ 0 ^ 0;
					continue;
				case 66u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쾓쾾쾤쾴쾸쾹쾹쾲쾴쾣", 1800785879, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = (((((int)num2 + -629230375) ^ -1944527470) << 0) - 0 << 0) ^ 0;
					continue;
				case 67u:
					num = (((int)num2 + -1203913514) ^ 0x56DF60C4) + 0 >> 0 >> 0 >> 0;
					continue;
				case 4u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("龘龼龠龽鿩龈龹龹龥龠龪龨龽龠龦龧", 866557897, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[2], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[2], 2);
					num = ((((int)num2 + -2035751834) ^ -2030749306 ^ 0) - 0 << 0) + 0;
					continue;
				case 69u:
					num = (int)((((((num2 + 2049341211) ^ 0xA233A3DCu) - 0) ^ 0) << 0) ^ 0);
					continue;
				case 81u:
					soqBhujDWoivlbKrBUrSZlrzHlzfoYwBQoMQtVBCxwDXqhrtIAiAZevgXQTWUdoXSHFWpTYFsPvDItjzUgxNQVCMSFTDbFHtiFfJCueOCChkISyEGubOGBhWeTeJauENhbucnAXAcJloOsdZgpWHDSNHyjEJquOhXucHxvqfwBMXqSiMPeCLyXkonNEeWokHVdqtpwCLZQkbgQqFbRTlRcJakOtJQljhrfcmCOwtCRMIMihxwZdevYPSupjBcSUNGdKbOecmuzJaqbobGVnRheMtpjSmFVqJXYbIygJsXQKVoPCtahVhFdFCrqLElPHziZcrZFDzmUTruQezHzmxZjeUsyrhueghjkNoNktuDwUKjohAmlW();
					num = ((((int)num2 + -1502690174) ^ -1538128280) >> 0) + 0 - 0 - 0;
					continue;
				case 71u:
					num = ((int)((num2 + 1456231014) ^ 0x760F753F) >> 0 >> 0) + 0 >> 0;
					continue;
				case 72u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u088aࢶࢻࢮࢼ\u08b5ࢨࢷࢩ", 457378010, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[4], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[4], 4);
					num = (((int)((num2 + 1409653633) ^ 0xC25EE39) >> 0) ^ 0) << 0 << 0;
					continue;
				case 73u:
					num = (((((int)num2 + -514558307) ^ 0x1329D6C5) << 0) ^ 0) + 0 + 0;
					continue;
				case 74u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蝂蝨蝽", 34965252, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[5], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[5], 5);
					num = (int)(((num2 + 719304223) ^ 0xF479A960u) << 0) >> 0 >> 0 >> 0;
					continue;
				case 75u:
					num = (int)(((((num2 + 1397850132) ^ 0xE500EF13u) + 0 << 0) - 0) ^ 0);
					continue;
				case 76u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udbcf\udbe0\udbe7\udbfb\udbfc\udba8\udbc5\udbe7\udbe6\udbe3\udbed\udbf1", 232643464, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[6], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[6], 6);
					num = ((((int)num2 + -655955806) ^ 0x5083F9D6) << 0 >> 0 >> 0) + 0;
					continue;
				case 77u:
					num = (((((int)num2 + -553983618) ^ 0x2D86D206) - 0) ^ 0) + 0 + 0;
					continue;
				case 78u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue74a\ue77e\ue769\ue769\ue776\ue769\ue72c\ue75e\ue765\ue76b\ue72c\ue745\ue762\ue72c\ue741\ue769\ue762\ue779", 2028857100, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[7], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[7], 7);
					num = ((int)((num2 + 1936246805) ^ 0x97A6C802u) >> 0) + 0 >> 0 << 0;
					continue;
				case 79u:
					num = (((int)num2 + -700378486) ^ -1690136343) - 0 - 0 << 0 >> 0;
					continue;
				case 80u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᰀ\u1c2c\u1c30\u1c2e\u1c26\u1c37ᰛ", 1898781763, true), -0.1f, -0.255f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[8], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[8], 8);
					num = (int)(((((num2 + 1753865328) ^ 0xD0569A88u) - 0) ^ 0) - 0 - 0);
					continue;
				case 5u:
					num = (((int)num2 + -1073282701) ^ -1964196144 ^ 0) - 0 - 0 - 0;
					continue;
				case 82u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue3ca\ue3ca\ue3ca\ue3ca\ue3d9", 1674044391, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᑎ", 808850556, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (((((int)num2 + -593300419) ^ 0x288D4BFE) - 0) ^ 0) - 0 + 0;
					continue;
				case 95u:
					num = ((((int)num2 + -1009218923) ^ -2007566915) >> 0) + 0 << 0 >> 0;
					continue;
				case 84u:
					num = (int)((((num2 + 257789568) ^ 0xDC409A6Eu) << 0) - 0 + 0 - 0);
					continue;
				case 85u:
					flag39 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ट", 285935917, true);
					num = (583560711 + 0 << 0) + 0 - 0;
					continue;
				case 86u:
				{
					int num78;
					int num79;
					if (flag39)
					{
						num78 = 381031104;
						num79 = num78;
					}
					else
					{
						num78 = 819392265;
						num79 = num78;
					}
					num = (((((num78 >> 0) - 0) ^ ((int)num2 + -550987047)) << 0) ^ 0) - 0 >> 0;
					continue;
				}
				case 87u:
					num = (((((int)num2 + -1073019275) ^ -214694853) >> 0) ^ 0) + 0 << 0;
					continue;
				case 88u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뺍뺠뺺뺪뺦뺧뺧뺬뺪뺽", 1124908745, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = ((int)(((num2 + 63918695) ^ 0x2C3CCB81) - 0) >> 0 >> 0) - 0;
					continue;
				case 89u:
					num = (int)(((num2 + 903050772) ^ 0x31132A19 ^ 0) << 0) >> 0 << 0;
					continue;
				case 90u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㡀㡢㡨㡠㠫㡌㡾㡥㠫㠷㡨㡤㡧㡤㡹㠶㡹㡮㡯㠵㡐㡛㡙㡂㡝㡊㡟㡎㡘㠫㡊㡅㡏㠫㡘㡟㡞㡆㡛㡖㠷㠤㡨㡤㡧㡤㡹㠵", 282277899, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[9], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[9], 9);
					num = (int)((num2 + 417019578) ^ 0x320338F2 ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 91u:
					num = (int)((((num2 + 492490569) ^ 0x17C601DD) << 0 << 0) + 0 << 0);
					continue;
				case 92u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("൧\u0d51\u0d46\u0d41ഄ\u0d63\u0d51\u0d4a", 262868260, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[10], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[10], 10);
					num = ((((int)num2 + -1480935069) ^ -1596345695) + 0 >> 0) ^ 0 ^ 0;
					continue;
				case 93u:
					num = (((int)num2 + -1087865447) ^ 0x2026E546 ^ 0 ^ 0 ^ 0) + 0;
					continue;
				case 94u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䝷䝂䝑䝄䝆䝗䜃䝤䝖䝍", 153372451, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[11], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[11], 11);
					num = (int)((((num2 + 1753584820) ^ 0x6B72615) << 0) - 0 - 0) >> 0;
					continue;
				case 6u:
					num = ((int)((((num2 + 174764255) ^ 0x25C468C2) << 0) - 0) >> 0) ^ 0;
					continue;
				case 96u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꡁꡰꡣꡱꡪꠢꡅ꡷ꡬ", 1805821954, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[12], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[12], 12);
					num = (((int)((num2 + 86765568) ^ 0x40B8011C) >> 0) ^ 0) - 0 - 0;
					continue;
				case 109u:
					flag27 = (Object)(object)sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX == (Object)null;
					num = (int)((((num2 + 782433223) ^ 0xCA88529Du) + 0 << 0 << 0) + 0);
					continue;
				case 98u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꑎꑢꑡꑡꑤꑩꑨꑿꐭꑊꑸꑣ", 813147149, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[13], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[13], 13);
					num = (((((int)num2 + -1523865621) ^ -891911132) >> 0) - 0 + 0) ^ 0;
					continue;
				case 99u:
					num = (((int)num2 + -10849744) ^ 0x79D6CDCE) - 0 + 0 >> 0 >> 0;
					continue;
				case 100u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("텗텭텸텽텺텰텱텦턴텓텡텺", 1586745620, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[14], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[14], 14);
					num = ((((int)num2 + -440264609) ^ 0x1D0C394B) - 0 + 0 >> 0) - 0;
					continue;
				case 101u:
					num = (int)((((num2 + 1000408160) ^ 0xF41F9215u) - 0 << 0) + 0 + 0);
					continue;
				case 102u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("檺檫檫檫檫", 854944390, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㟢", 1157380051, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (int)(((((num2 + 855968928) ^ 0xF2C22982u) << 0) + 0 << 0) ^ 0);
					continue;
				case 103u:
					num = (int)((((num2 + 403582250) ^ 0x368B93AF) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 104u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㖴㖴㖴㖴㖧", 843789721, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ử", 1774198494, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((int)num2 + -1940919077) ^ -89761410) - 0 << 0 << 0) + 0;
					continue;
				case 105u:
					num = (int)(((num2 + 703267218) ^ 0x48EC5F86) + 0 << 0) >> 0 << 0;
					continue;
				case 106u:
					num = ((((int)num2 + -1607437147) ^ -1784923394) - 0 >> 0 << 0) + 0;
					continue;
				case 107u:
					flag31 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쩆", 926206581, true);
					num = (0x2A280254 ^ 0) >> 0;
					continue;
				case 108u:
				{
					int num58;
					int num59;
					if (flag31)
					{
						num58 = -1199830400;
						num59 = num58;
					}
					else
					{
						num58 = -1860217927;
						num59 = num58;
					}
					num = ((num58 - 0 - 0) ^ ((int)num2 + -1923469886) ^ 0) + 0 - 0 >> 0;
					continue;
				}
				case 7u:
					num = (((((int)num2 + -1105401460) ^ -771089203) >> 0) + 0 >> 0) - 0;
					continue;
				case 110u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uec4f\uec62\uec78\uec68\uec64\uec65\uec65\uec6e\uec68\uec7f", 510913547, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = ((((int)num2 + -2046394662) ^ -526685134 ^ 0) + 0 >> 0) + 0;
					continue;
				case 122u:
				{
					int num51;
					int num52;
					if (!flag27)
					{
						num51 = 45983712;
						num52 = num51;
					}
					else
					{
						num51 = 1658207410;
						num52 = num51;
					}
					num = ((((((num51 ^ 0) - 0) ^ ((int)num2 + -632718362)) << 0) - 0) ^ 0) >> 0;
					continue;
				}
				case 112u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("꽴꽓꽆꽋꽌꽂꽕꼇꽠꽒꽉", 1865723687, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[15], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[15], 15);
					num = (((int)num2 + -1105284133) ^ 0x356D200F) - 0 + 0 >> 0 >> 0;
					continue;
				case 113u:
					num = (int)(((((num2 + 1908116545) ^ 0xCFAF03ECu) + 0) ^ 0) - 0 << 0);
					continue;
				case 114u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue51d\ue520\ue524\ue524\ue530\ue569\ue50e\ue53c\ue527", 921101641, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[16], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[16], 16);
					num = (int)((((num2 + 1817998587) ^ 0xA20AB3ADu) << 0) - 0 + 0) >> 0;
					continue;
				case 115u:
					num = (((((int)num2 + -1375609361) ^ 0x25D07EAD) << 0 << 0) ^ 0) - 0;
					continue;
				case 116u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᴌᴩᴰᴰᵼᴌᴰᴽᴥᴹᴮᵼᴕᴘᵼᴻᴩᴲᵼ", 1793269084, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[17], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[17], 17);
					num = (int)(((((num2 + 142609843) ^ 0x54B0CCB8) << 0) - 0 - 0) ^ 0);
					continue;
				case 117u:
					num = ((((int)num2 + -993515215) ^ 0x49FD2E68) >> 0 << 0) - 0 << 0;
					continue;
				case 118u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ﱖﱳﱪﱪﰦﱈﱯﱥﱭﱨﱧﱫﱣﰦﱁﱳﱨ", 862845958, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[18], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[18], 18);
					num = (int)((((num2 + 1676500258) ^ 0x9A800D6Fu ^ 0) << 0) ^ 0) >> 0;
					continue;
				case 119u:
					num = (int)(((num2 + 1568677110) ^ 0xFF6C4948u ^ 0 ^ 0 ^ 0) - 0);
					continue;
				case 120u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u02d3\u02e6ˠʧˀ\u02f2\u02e9", 1281688199, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[19], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[19], 19);
					num = (((((int)num2 + -285197244) ^ 0x7241BD82) << 0) - 0 - 0) ^ 0;
					continue;
				case 121u:
					num = (((((int)num2 + -511712431) ^ 0xDE1CEAD) + 0 + 0) ^ 0) << 0;
					continue;
				case 8u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue1bc\ue191\ue18b\ue199\ue19a\ue194\ue19d\ue1d8\ue1b6\ue19d\ue18c\ue18f\ue197\ue18a\ue193\ue1d8\ue18c\ue18a\ue191\ue19f\ue19f\ue19d\ue18a\ue18b\ue1d8\ue1ab\ue1ab", 1155195384, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[20], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[20], 20);
					num = (int)(((((num2 + 180865158) ^ 0x622A68DE) << 0) + 0 - 0) ^ 0);
					continue;
				case 123u:
					num = (((((int)num2 + -358974086) ^ 0x6219F289) + 0) ^ 0) + 0 << 0;
					continue;
				case 136u:
					num = ((((int)num2 + -1913761580) ^ -1514061222) << 0) - 0 >> 0 << 0;
					continue;
				case 125u:
					num = (int)(((num2 + 1083923407) ^ 0x1F6BB56E ^ 0 ^ 0 ^ 0) - 0);
					continue;
				case 126u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㍁㍁㍁㍁㍒", 1301951340, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("丨", 1177046556, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((((int)num2 + -195197488) ^ 0x4FAF80BB) << 0) ^ 0) >> 0) + 0;
					continue;
				case 127u:
					num = (((int)num2 + -1192715675) ^ -1260305754) - 0 << 0 >> 0 << 0;
					continue;
				case 128u:
					num = (int)(((num2 + 1589010637) ^ 0xEFC1F526u) + 0 + 0 - 0 + 0);
					continue;
				case 129u:
					flag17 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("斓", 1755800999, true);
					num = (1347028255 + 0 >> 0 << 0) - 0;
					continue;
				case 130u:
				{
					int num35;
					int num36;
					if (!flag17)
					{
						num35 = -1282982876;
						num36 = num35;
					}
					else
					{
						num35 = -732278810;
						num36 = num35;
					}
					num = ((int)(((uint)((num35 ^ 0) >> 0) ^ (num2 + 1241026932) ^ 0) - 0) >> 0) ^ 0;
					continue;
				}
				case 131u:
					num = (int)(((num2 + 65908614) ^ 0x43AA2AD5 ^ 0 ^ 0) - 0) >> 0;
					continue;
				case 132u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䖭䖀䖚䖊䖆䖇䖇䖌䖊䖝", 1544111593, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = (((int)num2 + -1645203564) ^ -1920509897 ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 133u:
					num = (((((int)num2 + -493029393) ^ 0x3D087FB3) + 0 - 0) ^ 0) - 0;
					continue;
				case 134u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue79a\ue7b5\ue7b9\ue7b1\ue7f4\ue797\ue7bc\ue7b5\ue7ba\ue7b3\ue7b1\ue7f4\ue7b5\ue7b8\ue7b8\ue7f4\ue7a7\ue7a7", 1844897748, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[21], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[21], 21);
					num = (((int)num2 + -1134677279) ^ -1067907954) >> 0 >> 0 >> 0 << 0;
					continue;
				case 135u:
					num = (int)(((((num2 + 704373431) ^ 0x602EE7E1) << 0) ^ 0) - 0) >> 0;
					continue;
				case 9u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("靉靪靥霫靊靧靧霫霷靨靤靧靤靹霶靹靮靯霵靐靟靃靂靘霫靄靅靇青霫靜靄静靀靘霫靄靅霫靌靊靆靎靘霫靜靂靟靃霫靉靊靅靊靉靇靎霫靅靊靆靎靘霪靖霷霤靨靤靧靤靹霵", 1383175947, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[22], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[22], 22);
					num = ((((int)num2 + -2139220319) ^ -1213890481) << 0 << 0) + 0 >> 0;
					continue;
				case 137u:
					num = (int)(((((num2 + 1611284498) ^ 0x8AA35F03u) << 0) - 0 + 0) ^ 0);
					continue;
				case 149u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX = GameObject.CreatePrimitive((PrimitiveType)3);
					num = (((int)num2 + -2040793444) ^ -1481938802) + 0 + 0 >> 0 >> 0;
					continue;
				case 139u:
					num = (int)((((num2 + 696618691) ^ 0x377D8F7C) - 0 << 0 << 0) + 0);
					continue;
				case 140u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("츃츠츿츿츶칰츔츱츤츱", 232509008, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[24], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[24], 24);
					num = (((((int)num2 + -636228455) ^ 0x6DE60B76) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 141u:
					num = ((((int)num2 + -1490971363) ^ -722784808 ^ 0) - 0 << 0) - 0;
					continue;
				case 142u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("噘噜嘬噋噹噢", 1052661260, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[25], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[25], 25);
					num = ((int)((num2 + 332519195) ^ 0x5E0AB719) >> 0 >> 0 >> 0) ^ 0;
					continue;
				case 143u:
					num = ((int)((num2 + 1812686947) ^ 0xE3706E9Du ^ 0) >> 0 >> 0) ^ 0;
					continue;
				case 144u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf2fb\uf2d0\uf2d9\uf2d6\uf2df\uf2dd\uf298\uf2f1\uf2dc\uf2dd\uf2d6\uf2d1\uf2cc\uf2c1", 1832121016, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[26], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[26], 26);
					num = (((int)num2 + -304827274) ^ 0x2742146C) >> 0 >> 0 >> 0 << 0;
					continue;
				case 145u:
					num = ((((int)((num2 + 282614638) ^ 0x1F980479) >> 0) ^ 0) >> 0) - 0;
					continue;
				case 146u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("歎歟歟歟歟", 698051442, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䖞", 257705389, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((int)num2 + -1526842318) ^ -757660928) - 0 >> 0 >> 0) + 0;
					continue;
				case 147u:
					num = (int)(((((num2 + 549109352) ^ 0x35DDFB09) << 0) + 0 << 0) + 0);
					continue;
				case 148u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⤀⤀⤀⤀⤓", 456796461, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("꿅", 891531248, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (((int)num2 + -420502848) ^ 0x2E698BE2) - 0 - 0 + 0 >> 0;
					continue;
				case 10u:
					num = (int)((((num2 + 729851429) ^ 0xDB2062F7u) + 0) ^ 0 ^ 0 ^ 0);
					continue;
				case 150u:
					num = ((((((int)num2 + -240797747) ^ 0x585970F0) + 0) ^ 0) >> 0) - 0;
					continue;
				case 163u:
					Object.Destroy((Object)(object)sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.GetComponent<SphereCollider>());
					num = (((int)num2 + -1717579079) ^ -2101600736 ^ 0) + 0 + 0 >> 0;
					continue;
				case 152u:
				{
					int num15;
					int num16;
					if (!flag6)
					{
						num15 = 529641553;
						num16 = num15;
					}
					else
					{
						num15 = 2029667590;
						num16 = num15;
					}
					num = (int)(((((uint)(num15 + 0 + 0) ^ (num2 + 13785291)) << 0) ^ 0) + 0 << 0);
					continue;
				}
				case 153u:
					num = (int)(((((num2 + 1384612736) ^ 0x703C9240) - 0) ^ 0) << 0 << 0);
					continue;
				case 154u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ua7e7ꟊ\ua7d0\ua7c0\ua7cc\ua7cd\ua7cdꟆ\ua7c0\ua7d7", 520005539, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = (int)((((((num2 + 1199112190) ^ 0x1FC7EC26) - 0) ^ 0) << 0) - 0);
					continue;
				case 155u:
					num = ((((int)num2 + -37291769) ^ 0x633535C1) - 0 + 0 >> 0) ^ 0;
					continue;
				case 156u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鐆鐩鐳鐮鑧鐄鐵鐦鐴鐯", 766284871, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[27], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[27], 27);
					num = ((((int)num2 + -1113124624) ^ -44835607 ^ 0) - 0 << 0) - 0;
					continue;
				case 157u:
					num = ((((int)num2 + -1809880501) ^ -395338071) + 0 >> 0 << 0) + 0;
					continue;
				case 158u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("띝띲띨띵뜼띐락띻뜼뜠띿띳띰띳띮뜡띮띹띸뜢띇띕띨띯뜼락뜼띾띵띨뜼띺띩띿띷띹띸띁뜠뜳띿띳띰띳띮뜢뜼", 2056042268, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[28], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[28], 28);
					num = (int)(((num2 + 56599076) ^ 0x1E3389D7) - 0 + 0) >> 0 >> 0;
					continue;
				case 159u:
					num = ((((int)num2 + -1014091919) ^ 0x27AA3B37 ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 160u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf22b\uf200\uf209\uf206\uf20f\uf20d\uf248\uf20f\uf209\uf205\uf20d\uf205\uf207\uf20c\uf20d\uf248\uf21c\uf207\uf248\uf20b\uf209\uf21b\uf21d\uf209\uf204", 848556648, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[29], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[29], 29);
					num = (int)(((num2 + 1233399459) ^ 0xA146929Fu) - 0 - 0 << 0 << 0);
					continue;
				case 161u:
					num = ((int)(((num2 + 2143360423) ^ 0xCE1CF9FAu) + 0 + 0) >> 0) - 0;
					continue;
				case 162u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("응읺읳일익읷윲익읳읿읷읿읽읶읷윲읦읽윲읻일이읷읱읦읻읽일윳", 1092405010, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[30], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[30], 30);
					num = ((((((int)num2 + -1882828687) ^ -1436052482) << 0) + 0) ^ 0) << 0;
					continue;
				case 11u:
					num = ((((int)num2 + -1097375718) ^ 0x79C405C5 ^ 0) << 0) + 0 >> 0;
					continue;
				case 164u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("橚橩橰橰樼橞橮橵橻橴橨", 469133852, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[31], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[31], 31);
					num = (int)((((num2 + 1867823681) ^ 0xD2D208C9u) - 0) ^ 0) >> 0 << 0;
					continue;
				case 0u:
					num = (((((int)num2 + -52416047) ^ 0x4B99450E ^ 0) + 0) ^ 0) >> 0;
					continue;
				case 166u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udc4f\udc62\udc78\udc6a\udc69\udc67\udc6e\udc2b\udc4c\udc64\udc79\udc62\udc67\udc67\udc6a\udc45\udc64\udc7f\udc2b\udc37\udc68\udc64\udc67\udc64\udc79\udc36\udc79\udc6e\udc6f\udc35\udc50\udc44\udc5b\udc56\udc37\udc24\udc68\udc64\udc67\udc64\udc79\udc35", 155900939, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[32], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[32], 32);
					num = (int)(((num2 + 1270383347) ^ 0x8C69AD1Cu) - 0 + 0) >> 0 << 0;
					continue;
				case 167u:
					num = (int)((((num2 + 1339070241) ^ 0x1186593E) - 0 << 0) - 0 - 0);
					continue;
				case 168u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鸷鸦鸦鸦鸦", 68722187, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf61a", 474871342, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((int)num2 + -1356518924) ^ -428977865) >> 0 << 0) + 0 - 0;
					continue;
				case 169u:
					num = (int)((((num2 + 1247754451) ^ 0x6CC91CB9 ^ 0) - 0) ^ 0) >> 0;
					continue;
				case 170u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u1977\u1977\u1977\u1977ᥤ", 923605338, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("嵬", 536501594, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((int)((num2 + 929678242) ^ 0x1DB031C9 ^ 0) >> 0) - 0 << 0;
					continue;
				case 171u:
					num = (int)(((((num2 + 177913287) ^ 0x11570BB9) - 0 << 0) ^ 0) + 0);
					continue;
				case 172u:
					num = ((((int)num2 + -90264663) ^ 0x37946973) << 0 << 0) - 0 << 0;
					continue;
				case 173u:
					flag67 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("믐", 2017246182, true);
					num = 449425174 - 0 - 0 >> 0 >> 0;
					continue;
				case 174u:
				{
					int num141;
					int num142;
					if (flag67)
					{
						num141 = -654247873;
						num142 = num141;
					}
					else
					{
						num141 = -1188177565;
						num142 = num141;
					}
					num = (((num141 >> 0) ^ 0 ^ ((int)num2 + -1059711606) ^ 0) >> 0 >> 0) - 0;
					continue;
				}
				case 175u:
					num = ((((int)num2 + -68398574) ^ -1342680467) + 0 >> 0 << 0) + 0;
					continue;
				case 176u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("佹佔低佞佒体体佘佞佉", 2127974205, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = ((int)(((num2 + 1821060265) ^ 0xEB9FA6B2u) + 0) >> 0 >> 0) - 0;
					continue;
				case 12u:
					num = (int)((((num2 + 1625397831) ^ 0xDC1DE28Bu) - 0 + 0 << 0) + 0);
					continue;
				case 178u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("췣췅췖췔췒췅췄", 938134967, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[33], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[33], 33);
					num = (((((int)num2 + -1228733852) ^ 0x29B460FE) << 0) - 0 - 0) ^ 0;
					continue;
				case 190u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.transform.parent = Player.Instance.leftHandTransform;
					num = (int)(((num2 + 1695854654) ^ 0x89DBFF79u ^ 0) - 0 - 0 << 0);
					continue;
				case 180u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("粿粔粝粑粏", 2131852540, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[34], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[34], 34);
					num = ((((((int)num2 + -1235322124) ^ -1549878591) + 0) ^ 0) << 0) - 0;
					continue;
				case 181u:
					num = (int)(((num2 + 209550875) ^ 0x41985F07) + 0) >> 0 >> 0 << 0;
					continue;
				case 182u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("တဢဢ\u1036", 723718208, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[35], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[35], 35);
					num = (((((int)num2 + -1061358812) ^ -1632591181) >> 0) ^ 0 ^ 0) + 0;
					continue;
				case 183u:
					num = (((int)(((num2 + 1456731262) ^ 0xFB720BD2u) << 0) >> 0) ^ 0) >> 0;
					continue;
				case 184u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("젨젠졇젫젆저졇젆젋젋졇졏적정절젊졇젋전젊젟젗젆젎젃졎", 358598759, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[36], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[36], 36);
					num = ((int)((num2 + 1773706497) ^ 0xAB347EDCu) >> 0 << 0 >> 0) - 0;
					continue;
				case 185u:
					num = (int)((((((num2 + 1474779809) ^ 0xA4ACB828u) << 0) ^ 0) << 0) ^ 0);
					continue;
				case 186u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㶰㶝㶛㷜㶽㶐㶐", 1588674044, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[37], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[37], 37);
					num = ((int)((num2 + 1261644266) ^ 0x5192551) >> 0 >> 0 << 0) + 0;
					continue;
				case 187u:
					num = (int)(((num2 + 350749211) ^ 0x62FEA8E7) + 0) >> 0 >> 0 << 0;
					continue;
				case 188u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ዐዥዣኤዥየየ", 1880691332, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[38], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[38], 38);
					num = (int)(((num2 + 1824087645) ^ 0xF9C0709Eu ^ 0) - 0 - 0 - 0);
					continue;
				case 189u:
					num = ((int)(((num2 + 474355699) ^ 0xC9E14477u) << 0 << 0) >> 0) ^ 0;
					continue;
				case 13u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("缩缸缸缸缸", 1876393749, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("✪", 1638344479, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (int)((((num2 + 335362487) ^ 0x7F9995C6) << 0) ^ 0 ^ 0) >> 0;
					continue;
				case 191u:
					num = (int)((((num2 + 992523383) ^ 0x3E84CFD8) << 0) - 0 << 0) >> 0;
					continue;
				case 204u:
					num = ((int)((num2 + 1378805621) ^ 0x3A8793E ^ 0) >> 0) + 0 - 0;
					continue;
				case 193u:
					num = ((int)(((num2 + 1065197029) ^ 0x2C489F5B) + 0) >> 0) - 0 << 0;
					continue;
				case 194u:
					num = ((((int)num2 + -274769097) ^ 0xBB3373D) - 0 << 0 >> 0) ^ 0;
					continue;
				case 195u:
					flag66 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蘯", 1747748376, true);
					num = (1636847071 - 0 >> 0 >> 0) + 0;
					continue;
				case 196u:
				{
					int num139;
					int num140;
					if (!flag66)
					{
						num139 = 367143339;
						num140 = num139;
					}
					else
					{
						num139 = 883157022;
						num140 = num139;
					}
					num = (num139 ^ 0 ^ 0 ^ ((int)num2 + -20659081)) + 0 + 0 + 0 >> 0;
					continue;
				}
				case 197u:
					num = (((((int)num2 + -850294741) ^ 0x557BF624) + 0 << 0) ^ 0) >> 0;
					continue;
				case 198u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("遽遐遊遚遖遗遗遜遚遍", 548507705, true), 0.26f, 0.65f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[1], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1], 1);
					num = ((((int)num2 + -460104830) ^ 0x78660C8D) >> 0) + 0 >> 0 << 0;
					continue;
				case 199u:
					num = ((((int)num2 + -1795800502) ^ -1766763679) + 0 - 0 + 0) ^ 0;
					continue;
				case 200u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⡮⡘⡕⡕⡎⡘⡕⡒", 1413097529, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[39], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[39], 39);
					num = ((int)((num2 + 534940387) ^ 0x450C3C04) >> 0) - 0 + 0 - 0;
					continue;
				case 201u:
					num = ((int)(((num2 + 1625691511) ^ 0x4B2B46DE ^ 0) - 0) >> 0) + 0;
					continue;
				case 202u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("愐愳愢愹愮愬愭愨", 526803267, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[40], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[40], 40);
					num = ((((int)num2 + -364706729) ^ 0x22298DF2 ^ 0) << 0) + 0 << 0;
					continue;
				case 203u:
					num = ((int)((num2 + 1208440114) ^ 0x6DBF81FE ^ 0) >> 0) - 0 << 0;
					continue;
				case 14u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("勇練敏渚懲艹碑晴侀艹艹", 19003954, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[41], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[41], 41);
					num = (((int)num2 + -1851492995) ^ -637165546) + 0 >> 0 >> 0 << 0;
					continue;
				case 205u:
					num = ((((int)num2 + -1910525939) ^ 0x275A0274) - 0 << 0 << 0) ^ 0;
					continue;
				case 218u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.transform.localPosition = new Vector3(0f, 0f, 0.1f);
					num = ((((int)num2 + -945291814) ^ 0xD2C82BB ^ 0) + 0 >> 0) - 0;
					continue;
				case 207u:
					num = (((((int)num2 + -1153656608) ^ -428237315 ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 208u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㬳㬝㬂㬑㭔㬧㬜㬝㬚㬍㬦㬛㬗㬟㬇", 1439120244, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[43], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[43], 43);
					num = (((int)(((num2 + 1514024575) ^ 0xA9CBE661u) - 0) >> 0) ^ 0) << 0;
					continue;
				case 209u:
					num = (int)(((num2 + 385098110) ^ 0x7122BC94) << 0) >> 0 << 0 << 0;
					continue;
				case 210u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뗬뗋뗋뗝", 1315812782, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[44], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[44], 44);
					num = ((((int)num2 + -614675372) ^ 0x6D839268) >> 0 << 0 >> 0) - 0;
					continue;
				case 211u:
					num = ((int)((num2 + 1340459545) ^ 0xE7F6F56Du) >> 0) - 0 - 0 - 0;
					continue;
				case 212u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("툅툔툔툔툔", 1921438265, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("눎", 842904120, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (int)(((((num2 + 1705055034) ^ 0xE8ED87B8u) - 0) ^ 0) + 0 << 0);
					continue;
				case 213u:
					num = ((int)((((num2 + 1177607974) ^ 0x94A42E46u) + 0) ^ 0) >> 0) ^ 0;
					continue;
				case 214u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("듳듳듳듳든", 1084339422, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("皷", 1599895183, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (((((int)num2 + -1693502712) ^ -1246249081) << 0 << 0) ^ 0) << 0;
					continue;
				case 215u:
					num = ((((int)num2 + -19502762) ^ 0x54DD8EC0) >> 0) - 0 + 0 << 0;
					continue;
				case 216u:
					num = ((((int)num2 + -1881945101) ^ -388554832) - 0 >> 0 << 0) - 0;
					continue;
				case 217u:
					flag65 = eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꕞ", 1467131238, true);
					num = (57432515 >> 0 >> 0) + 0 << 0;
					continue;
				case 15u:
				{
					int num135;
					int num136;
					if (flag65)
					{
						num135 = -1874221376;
						num136 = num135;
					}
					else
					{
						num135 = -153897970;
						num136 = num135;
					}
					num = (((num135 + 0 >> 0) ^ ((int)num2 + -1717923080)) >> 0 << 0) ^ 0 ^ 0;
					continue;
				}
				case 219u:
					num = ((int)((((num2 + 779654996) ^ 0x7348A4A5) + 0) ^ 0) >> 0) ^ 0;
					continue;
				case 231u:
					num = (int)((((num2 + 665974159) ^ 0x7634311E ^ 0) << 0) ^ 0) >> 0;
					continue;
				case 221u:
					num = ((((int)num2 + -1774475953) ^ 0x4B710E35) + 0 >> 0) + 0 << 0;
					continue;
				case 222u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("悒悽悽悼悪想悒悿悿", 1181507795, true), 0.14f, 0.35f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[45], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[45], 45);
					num = ((int)((((num2 + 1892480165) ^ 0xA5E4D062u) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 223u:
					num = (int)((((num2 + 1207485154) ^ 0xD29730AEu) - 0) ^ 0) >> 0 << 0;
					continue;
				case 224u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("൏൨ൾ൹ഭ൮ൿ൬ൾ\u0d65൨ൿഭ൨ൻ൨ൿഭൠ൬൩൨", 980815117, true), 0.1f, 0.25f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[46], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[46], 46);
					num = (((((int)num2 + -2000763345) ^ -1672398536) - 0) ^ 0) + 0 << 0;
					continue;
				case 225u:
					num = (int)(((num2 + 1792078993) ^ 0xAAFD90D3u ^ 0) + 0 + 0) >> 0;
					continue;
				case 226u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u2456⑧③⑷\u2432⑀⑻⑵②", 1750737938, true), 0.06f, 0.15f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[47], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[47], 47);
					num = (((int)num2 + -228664635) ^ 0x51DA10D9) << 0 >> 0 >> 0 << 0;
					continue;
				case 227u:
					num = (((((int)num2 + -808447247) ^ 0x5F447533) >> 0) + 0 >> 0) - 0;
					continue;
				case 228u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("밖방밪밲뱥밄방방", 1318763589, true), 0.02f, 0.05f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[48], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[48], 48);
					num = ((((int)num2 + -1700992591) ^ -913633270) << 0) - 0 - 0 + 0;
					continue;
				case 229u:
					num = ((((int)num2 + -1859076743) ^ -543376238) >> 0) - 0 >> 0 >> 0;
					continue;
				case 230u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꨟꨠꨣ\uaa3bꩬꨋ\uaa39ꨢ", 1108716108, true), -0.02f, -0.055f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[49], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[49], 49);
					num = (((((int)num2 + -590638403) ^ -64226551) >> 0 << 0) ^ 0) >> 0;
					continue;
				case 16u:
					num = (((((int)num2 + -1724800787) ^ -1498461007) - 0 + 0) ^ 0) << 0;
					continue;
				case 232u:
					vHvcILgiSolkTMpApqXZaHhzuDPdyKdNVrJQcNSQVwZqfaFvogMXfdqOzVIeWdJhlxoCcyyCyhdEHRutYtOsX(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u1934ᤗᤆᤐᤉ᥇\u1925ᤆᤋᤋ", 478550375, true), -0.06f, -0.155f, ref fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU[50], ref rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[50], 50);
					num = (int)(((((num2 + 2010852049) ^ 0xD00EBEBAu) << 0) - 0) ^ 0 ^ 0);
					continue;
				case 245u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
					num = ((int)(((num2 + 30002754) ^ 0x2C72B2A1) + 0 - 0) >> 0) ^ 0;
					continue;
				case 234u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⍵⍤⍤⍤⍤", 1240277833, true), -0.1f, -0.255f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udf9d", 1225252778, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = ((((int)num2 + -949198208) ^ -984800014) << 0 << 0) - 0 >> 0;
					continue;
				case 235u:
					num = (int)(((((num2 + 1772509505) ^ 0xB31271A4u) << 0 << 0) ^ 0) + 0);
					continue;
				case 236u:
					MDjzYVhYBowehNMhjcQMxgRUDptLerRUiiuEZLOtFlRggrNXxgYxwzzFMpVJBwUjxCWZtiixoxhloKNmBwnXstyJIORJPfRirIJEuNEpXAjYrnrbBJhfjWRddmqEqzIiFYUGajROSYZSjzrvwPhgXMZuQFBhxZYySatstLbsRtnkWYUDVVhArBlTZzPuHKqSZAaigYcLOOpEzOySLXmCRyhqPztTVGLhculvYLwWTwLClGukbXJJxOaBtJsGEiPidiBeDcTZApJvMEejfjSYXbJotJcptQrKGDydepGZdJjhfEOOEjBvqQlcynKTZEGKYYOjgbePDSVnSBiOVoKkpWuPrwEREMZycyjgQEICeLSxVXkWfWYLUwvbEZRJxnlQSwltsbYqFhfDdWUtlHMIOoEGdhCQNYfRAbFzMQEdXHfMrRXIexxQBCcERFqkzhDHcndcr(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㳥㳥㳥㳥㳶", 1566588104, true), -0.14f, -0.355f, ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("옸", 743228937, true), ref hpmVOfwwFeYVMjHXCuMovpbeCtcDQLmdhPIXiomhrvLsIeAvZOCcNkqSnhtvdTGTRUNWAJOniEWZDJvxTGDbjkqXzQKaVReyPRAOqEVpapTioqoEMVBwpEKHDQxJZNrrzyjMiHhpKnbUqhIiCfoZpHilhTkzglqmXCIPhBwfOmMbCPrvhphUysbSpYFoxHiyXOXNzTaaJjlcVgIrCOsRewNEAQzjWhIheneOSDWoohkphYWjpnMIpquBbsnItRdBBdYHcUyZRdDXlyxBTqTIuZSOTCMApoVwdINdapgvPNRlMxqDULOcYuhCljOzhYJCihTCKuAEkyTGiGcvmjFEASxIBlRRBGnReocFDOSAkkSABAtEhsnYsecqJlazCJcDkbCUEwRxreupaXgbRnJjspyalMVsNtYAhopzYzaKAPGoKMpLeZHpaTlVDCISByKXfTiMHHdrnYJCIkpywjoOLJAnduWvQhjb[2], 2);
					num = (int)(((num2 + 1944311913) ^ 0xCC526E57u ^ 0) - 0 - 0) >> 0;
					continue;
				case 237u:
					num = (int)((((((num2 + 405677235) ^ 0x3AA676FA) - 0) ^ 0) << 0) + 0);
					continue;
				case 238u:
					num = (int)(((((num2 + 847028215) ^ 0xF35129F7u) << 0 << 0) + 0) ^ 0);
					continue;
				case 239u:
					num = (0x48604D91 ^ 0) + 0;
					continue;
				case 240u:
					flag64 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1];
					num = ((0x7A48755F ^ 0) >> 0) - 0;
					continue;
				case 241u:
				{
					int num133;
					int num134;
					if (!flag64)
					{
						num133 = -577655089;
						num134 = num133;
					}
					else
					{
						num133 = -582098513;
						num134 = num133;
					}
					num = (int)((((((uint)(num133 ^ 0 ^ 0) ^ (num2 + 1524889102)) << 0) - 0) ^ 0) - 0);
					continue;
				}
				case 242u:
					num = (((int)(((num2 + 311400385) ^ 0x58B87EBA) - 0) >> 0) ^ 0) << 0;
					continue;
				case 243u:
					PhotonNetwork.Disconnect();
					num = (int)(((num2 + 962448437) ^ 0x193764D4) - 0 + 0 + 0 - 0);
					continue;
				case 244u:
					num = ((((int)num2 + -31914535) ^ 0x3A61574D) << 0) - 0 + 0 << 0;
					continue;
				case 17u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("잷잻잽잿잴잮잻", 557238234, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ፘ፵፯\u137f፳፲፲፹\u137f፨", 1975522076, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("쭙쭴쭮쭾쭲쭳쭳쭸쭾쭩쭸쭹쬼", 1192413981, true));
					num = (((int)num2 + -822295254) ^ 0x7102F934 ^ 0) - 0 - 0 + 0;
					continue;
				case 246u:
					num = (int)((((((num2 + 981409219) ^ 0xD735F84Cu) + 0) ^ 0) - 0) ^ 0);
					continue;
				case 258u:
					num = (((((int)num2 + -1764924434) ^ -1855965065) >> 0) - 0 << 0) - 0;
					continue;
				case 248u:
					num = (int)(((num2 + 1479958170) ^ 0x9EC468E2u) << 0) >> 0 >> 0 >> 0;
					continue;
				case 249u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[1] = false;
					num = ((int)((num2 + 106158281) ^ 0x734EC836) >> 0) + 0 >> 0 << 0;
					continue;
				case 250u:
					num = (int)(((((num2 + 1347790477) ^ 0x77A4C052) + 0) ^ 0 ^ 0) - 0);
					continue;
				case 251u:
					flag62 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[2];
					num = 579223377 << 0 << 0 << 0 << 0;
					continue;
				case 252u:
				{
					int num129;
					int num130;
					if (flag62)
					{
						num129 = -140625030;
						num130 = num129;
					}
					else
					{
						num129 = -1806888631;
						num130 = num129;
					}
					num = (((((num129 - 0 + 0) ^ ((int)num2 + -751212942)) - 0) ^ 0) >> 0) ^ 0;
					continue;
				}
				case 253u:
					num = ((((int)num2 + -96562434) ^ -822547413) >> 0) + 0 >> 0 >> 0;
					continue;
				case 254u:
					Application.Quit();
					num = (((int)num2 + -864010052) ^ -90655028) + 0 + 0 + 0 << 0;
					continue;
				case 255u:
					num = ((((int)num2 + -279412108) ^ -1631678823) >> 0) + 0 + 0 - 0;
					continue;
				case 256u:
					num = (((int)num2 + -1711816731) ^ 0x65AED1FC) + 0 - 0 >> 0 << 0;
					continue;
				case 257u:
					flag61 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[3];
					num = 0x2AFE1B8C ^ 0;
					continue;
				case 18u:
				{
					int num127;
					int num128;
					if (!flag61)
					{
						num127 = 788258625;
						num128 = num127;
					}
					else
					{
						num127 = 1192222595;
						num128 = num127;
					}
					num = (((num127 - 0) ^ 0 ^ ((int)num2 + -496099637)) >> 0 << 0) + 0 >> 0;
					continue;
				}
				case 259u:
					num = (int)(((num2 + 5506168) ^ 0x29D12AFD) + 0 + 0 + 0 + 0);
					continue;
				case 272u:
					num = (int)((((num2 + 1991328212) ^ 0xFA5A0050u ^ 0) - 0 << 0) ^ 0);
					continue;
				case 261u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꟉꟅꟃ\ua7c1ꟊ\ua7d0Ʂ", 450799524, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꑨꑍꑋꑌꐂꑰꑃꑌꑆꑍꑏꐂꑲꑗꑀꑎꑋꑁ", 387163170, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("垆埫城埈埏埈埏埆垏垏垏", 1035294625, true));
					num = (int)((((num2 + 1427093534) ^ 0xCDC20F50u ^ 0) << 0) + 0 + 0);
					continue;
				case 262u:
					num = (int)(((((num2 + 534715869) ^ 0xAB164336u) - 0 - 0) ^ 0) << 0);
					continue;
				case 263u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (((int)(((num2 + 1371169934) ^ 0xF8AB1039u) + 0) >> 0) ^ 0) - 0;
					continue;
				case 264u:
					num = (((int)(((num2 + 1916715683) ^ 0xF6FBF17Fu) << 0) >> 0) - 0) ^ 0;
					continue;
				case 265u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[3] = false;
					num = (((int)num2 + -754519631) ^ -311895627) + 0 << 0 << 0 << 0;
					continue;
				case 266u:
					num = (int)((((num2 + 734975703) ^ 0x19F540BB ^ 0) << 0) - 0 << 0);
					continue;
				case 267u:
					flag60 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[4];
					num = (1231052768 << 0) + 0 - 0 - 0;
					continue;
				case 268u:
				{
					int num125;
					int num126;
					if (flag60)
					{
						num125 = 610192746;
						num126 = num125;
					}
					else
					{
						num125 = 1435556378;
						num126 = num125;
					}
					num = (((num125 - 0 - 0) ^ ((int)num2 + -175540461) ^ 0) >> 0) + 0 << 0;
					continue;
				}
				case 269u:
					num = (int)(((((num2 + 1164537350) ^ 0x61F8DD8) - 0 << 0) ^ 0) << 0);
					continue;
				case 270u:
					Platforms.jpUcEtxLhxVYojDCwsqCPuQSdbExgdKvngJdgDpEHtRTnBZfGxheCiBPybZDPZEeNAKizzvTcMVvCWEBbyRJVFTfEUEfDMPHOMgNQRFgbocPmgmCwxBriVjhGFDFVqppWnHPQRLjSKIHDeSyIcIgkyyTDYhloalKYMSYywLFMsyynBDCMeWSHjfyPNmRJAVRyXIQlTZmqdtSZaGcuFyjdscPHujKkUWlxHZpSNqTfKBEPmzOhjwdcLNfUTjQJobwhiurbqjHoFetRyZuVvDaxSjLTTuZEAjQIfxHShMQaOOwHuowUOVoLbYoYJyiWkdOvnKLbsCNIMZIdMezEXfPEVeGgiJiJEUQKabtKCuBmiFZcqklEZDYeokAjdFSItedSiXdLKObCDDwpfEQYxEJbVLwPBkGXBSSdBgTsgzUkCvBLNkdyPUlPucWxBokAieaKKtOYLxRYJzyzj();
					num = ((int)(((num2 + 274382273) ^ 0x49CE93A2) + 0 + 0) >> 0) - 0;
					continue;
				case 271u:
					num = (int)((((num2 + 1091511378) ^ 0xE05EBC46u ^ 0) << 0 << 0) - 0);
					continue;
				case 19u:
					num = ((int)((num2 + 220062593) ^ 0x62FA1D2) >> 0) + 0 << 0 << 0;
					continue;
				case 273u:
					flag48 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[5];
					num = 331459024 - 0 - 0 >> 0 >> 0;
					continue;
				case 286u:
					num = 1414165299 - 0 + 0 << 0 << 0;
					continue;
				case 275u:
					num = (((int)num2 + -1942201100) ^ -1551779400 ^ 0) << 0 >> 0 << 0;
					continue;
				case 276u:
					flyy.aFpoLTaingqXlnMEvVHAMssRDbmGocHCRtRHoPwKRDCGCAsDgtDRNjEHnyLJGtUlzNfSwfpFzWJiQMpcJJzUzQPIOjuQeNdxJrgOuAgbdXsQAwRAjIZWTZLJYxdmLzBMSlyyFAHjCyQCxYhssTHwNgEJF();
					num = ((((int)num2 + -1812526996) ^ -255092958 ^ 0) - 0 + 0) ^ 0;
					continue;
				case 277u:
					num = ((int)(((num2 + 1686121060) ^ 0x7926868) << 0) >> 0 << 0) ^ 0;
					continue;
				case 278u:
					num = (((((int)num2 + -2058989724) ^ 0x5053D201) >> 0) + 0 + 0) ^ 0;
					continue;
				case 279u:
					flag59 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[6];
					num = (0x607E57EC ^ 0) << 0 >> 0 >> 0;
					continue;
				case 280u:
				{
					int num122;
					int num123;
					if (flag59)
					{
						num122 = 774531736;
						num123 = num122;
					}
					else
					{
						num122 = 1061875665;
						num123 = num122;
					}
					num = (int)((((uint)(num122 ^ 0 ^ 0) ^ (num2 + 160695979)) - 0 - 0) ^ 0 ^ 0);
					continue;
				}
				case 281u:
					num = (((int)num2 + -1212628688) ^ -1709773786) + 0 << 0 >> 0 >> 0;
					continue;
				case 282u:
					ghost_monke.UlvbdMUDurDOkybMNXsGEsGwYgURDqCjOhihNtfbZzgkrvqiLkSTMwFBFZcWSca();
					num = (((int)((num2 + 670495948) ^ 0x87E190C5u) >> 0) - 0 - 0) ^ 0;
					continue;
				case 283u:
					num = (int)(((num2 + 1489222035) ^ 0x70062229) + 0 + 0 + 0) >> 0;
					continue;
				case 284u:
					num = (int)(((((num2 + 1516808216) ^ 0x2437ADF4) - 0) ^ 0) + 0 + 0);
					continue;
				case 285u:
					flag57 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[7];
					num = (0x72A8F5FD ^ 0) - 0 + 0 >> 0;
					continue;
				case 20u:
				{
					int num118;
					int num119;
					if (!flag57)
					{
						num118 = -131156819;
						num119 = num118;
					}
					else
					{
						num118 = -31494367;
						num119 = num118;
					}
					num = (((num118 - 0 + 0) ^ ((int)num2 + -1972330609)) >> 0 >> 0) - 0 - 0;
					continue;
				}
				case 287u:
					num = (((((int)num2 + -49113083) ^ 0x2033F9D3) + 0 << 0) - 0) ^ 0;
					continue;
				case 299u:
					num = (((((int)num2 + -1657689987) ^ -29615675) << 0 >> 0) ^ 0) + 0;
					continue;
				case 289u:
					num = ((int)(((num2 + 734474651) ^ 0xF3C7E95Cu ^ 0) + 0) >> 0) + 0;
					continue;
				case 290u:
					num = (((((int)num2 + -514997071) ^ 0x54E76272) + 0 >> 0) ^ 0) >> 0;
					continue;
				case 291u:
					flag56 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[8];
					num = 2142219667 - 0 - 0 << 0 << 0;
					continue;
				case 292u:
				{
					int num116;
					int num117;
					if (!flag56)
					{
						num116 = -1478130076;
						num117 = num116;
					}
					else
					{
						num116 = -1150421471;
						num117 = num116;
					}
					num = (int)((((uint)(num116 - 0 << 0) ^ (num2 + 1617286067)) + 0) ^ 0) >> 0 << 0;
					continue;
				}
				case 293u:
					num = ((((((int)num2 + -2101726935) ^ -1480093588) + 0) ^ 0) + 0) ^ 0;
					continue;
				case 294u:
					cosmetx.UTMMIJtCpNwJiKMGGRYJBxKATyaliylXOJQdqDlKwJEokGvjwHNLXFSxjmSjJhuQCzUzUJqcGonSSvqndQOALzajQsTeKbaopOLLLWpMrKfIrZENWFgStTfcyKIBQmsEnZDeKEBgBbjaurRQOgheViVvIImboNWfsAvswzcreZqrKeIgSRMKenIfeivcszSOfeHTWzupdPZWRDLEafixamafSqnodaZEhCmFxOktwxHpnLnAwRcmrvNSdCbFlglcPuPprfhlVPaDFLRgcNRmYNnMPtCUMEhqmEzSWYjqKQqCujnrKUDyoZechdzXDmzqHKqamZkdDACiwKrFgkkSbIbnAwLTylNxrZUK();
					num = ((int)((num2 + 1666924873) ^ 0xA8DCD609u ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 295u:
					num = (int)((((num2 + 206517807) ^ 0xC58C5913u) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 296u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("懯懣懥懧懬懶懣", 798450050, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("耡耍耑耏耇耖耚", 683835490, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鐨鐄鐘鐆鐎鐟鐳鑋鐆鐄鐏鑋鐃鐊鐘鑋鐉鐎鐎鐅鑋鐎鐅鐊鐉鐇鐎鐏鑊", 1311478891, true));
					num = (int)(((((num2 + 1675022820) ^ 0xFC291941u) - 0) ^ 0) + 0 - 0);
					continue;
				case 297u:
					num = ((((((int)num2 + -346691057) ^ 0x1F269A46) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 298u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (((int)num2 + -150911263) ^ 0x60F25A4F) - 0 - 0 + 0 - 0;
					continue;
				case 21u:
					num = ((int)((((num2 + 1338123923) ^ 0xD11A6C81u) << 0) - 0) >> 0) + 0;
					continue;
				case 300u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[8] = false;
					num = (((((int)num2 + -891724645) ^ -382314380) >> 0) - 0 >> 0) - 0;
					continue;
				case 313u:
					num = (0x57889113 ^ 0) >> 0;
					continue;
				case 302u:
					flag55 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[9];
					num = (845209053 >> 0) + 0 - 0 - 0;
					continue;
				case 303u:
				{
					int num114;
					int num115;
					if (!flag55)
					{
						num114 = 1498068943;
						num115 = num114;
					}
					else
					{
						num114 = 559879325;
						num115 = num114;
					}
					num = ((((num114 + 0 - 0) ^ ((int)num2 + -665843864)) + 0 - 0) ^ 0) - 0;
					continue;
				}
				case 304u:
					num = ((((int)num2 + -1007644113) ^ -107840431 ^ 0) + 0 + 0) ^ 0;
					continue;
				case 305u:
					kick_gun.qqWeZEZOAwUVHTvgLwSWOwjAPGZhDdPYIfHplXfSHtfXWzBLuGBAdivTgvosESkxHWnClfVNqZpvrmEpfnMWCoVAJOjPJNoOiIpZmZAoLNkdSZCTQYnqfnUsaMSxWfeDLAmIWEdgNylPeRHKlpYKAXJUOXZAhcsFIGssMUWlVgCHcenjeimGhtdNRrUZFDZLfFgyypXrsMPtvbSJJQwYQLyoDFAuaXGshRBwXPKOkUnuDKrPzkpPgaVugSUTOCrvgxlEAvMUfHNVxeKTnLVPHQlhVhpfURZIDSogyNpdyvKzmZWchbFdGBNpmdIsfGZoHfrFPEuAvRrmgLVWlmYTlWccfYUufWYSvvShIqnCHfIOkAjAiMhSHgdLdpzRKZuyTzRLTOnUZvlgonREPtmtPfkoshetQwSHKjVLJxHuymTlUWwPxUbqNbJOoCsMKUdDDEvergVrMSUCmYuvKoVVu();
					num = ((((int)num2 + -1635165252) ^ -77621689) - 0 + 0 << 0) ^ 0;
					continue;
				case 306u:
					num = (int)(((num2 + 1158560968) ^ 0xDC646E41u ^ 0) - 0 - 0 + 0);
					continue;
				case 307u:
					num = (((int)((num2 + 1962927062) ^ 0xEE2F27B8u) >> 0) - 0) ^ 0 ^ 0;
					continue;
				case 308u:
					flag54 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[10];
					num = (1240538434 + 0 << 0 << 0) - 0;
					continue;
				case 309u:
				{
					int num112;
					int num113;
					if (!flag54)
					{
						num112 = -2143639746;
						num113 = num112;
					}
					else
					{
						num112 = -1888726088;
						num113 = num112;
					}
					num = ((((num112 + 0 + 0) ^ ((int)num2 + -2109781048)) - 0) ^ 0 ^ 0) << 0;
					continue;
				}
				case 310u:
					num = ((int)((num2 + 1771965222) ^ 0xB4C08B6Au) >> 0) - 0 - 0 - 0;
					continue;
				case 311u:
					cubegun.ibxvJqDROzVSlPnGytOilSRBvfyuRwEBZLLsFOUAFvGYHIqWHtBrFjZpkVaDRiasUuSzeVbJzoDQmSTMPBNxUnVQLwhJOqIwuoenPQSLsSSrFjcrcoOqvDxHycOIOsViFgvYOGWZJbecvDkCtPHzCsbRQwONckXaXJLzOeDvsOGuyvmURloYKvGnfDirSiXzdeeLSLOpmlgNLHsvkTWQVZpBcytkVlDkRhquqAcfxYLzoSBxkNhYmhDeODJtrDtbIWWErYeJRQsWoQ();
					num = (((((int)num2 + -1556614837) ^ -2133195917) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 312u:
					num = (int)(((((num2 + 1898030586) ^ 0xA772D044u) - 0 + 0) ^ 0) << 0);
					continue;
				case 22u:
					num = ((((((int)num2 + -1368811756) ^ -165115948) << 0) ^ 0) + 0) ^ 0;
					continue;
				case 314u:
					flag32 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[11];
					num = 569917815 - 0 - 0 - 0 + 0;
					continue;
				case 327u:
					if (!EasyInputs.GetSecondaryButtonDown((EasyHand)1))
					{
						num = ((((((int)num2 + -18908162) ^ 0x2BFBD176) + 0) ^ 0) + 0) ^ 0;
						continue;
					}
					num104 = 0;
					goto IL_7fb6;
				case 316u:
					num = ((int)((num2 + 1509781464) ^ 0xFCD530EFu ^ 0) >> 0) + 0 >> 0;
					continue;
				case 317u:
					targetgun.hupwabduNsUDvnpEaLPYlqrTfWDoPvQUAuQaGzHlSwXHBANtGNFpVchRcvqeyPErCacaxoXAdDgOsKsFikHcQBYynYXkiDNcRFfAxMVsPelrVszsdLWoiCBabENzqMrAQdWMERhvopmMqGCVyFhxGzUpeezTZwbdMKBSvNNlDAZSqOKubSaLEUTqjHHzso();
					num = (((((int)num2 + -1092527968) ^ -1810247608) - 0) ^ 0) >> 0 << 0;
					continue;
				case 318u:
					num = ((((((int)num2 + -848448837) ^ 0x1ACDDC26) << 0) - 0) ^ 0) - 0;
					continue;
				case 319u:
					num = ((int)((((num2 + 1049662512) ^ 0x198A5F66) << 0) - 0) >> 0) ^ 0;
					continue;
				case 320u:
					flag53 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[12];
					num = 1264860321 + 0 + 0 - 0 << 0;
					continue;
				case 321u:
				{
					int num109;
					int num110;
					if (flag53)
					{
						num109 = -605571663;
						num110 = num109;
					}
					else
					{
						num109 = -1930700410;
						num110 = num109;
					}
					num = (int)((((uint)((num109 ^ 0) - 0) ^ (num2 + 1583046642)) << 0) + 0 + 0) >> 0;
					continue;
				}
				case 322u:
					num = (int)(((((num2 + 1837407894) ^ 0x9C39E42Bu) << 0) + 0 - 0) ^ 0);
					continue;
				case 323u:
					crash_gun.wblmpssENAwSdXmNRJJGkDQnziNsilMKYynQnhPYSKEireqnfPcUSANSkXMhEavBOMUEKvzJUKNzZIWvRAmsjRRyKuGquHtSoctEkMCJqtahMoTCbrqeNcsXVvTqPjpnrVkWoslfXCcPQJLwAdodrpfmJwJOSmUgdNQRdWoJfkg();
					num = (((int)num2 + -1904910415) ^ -174832532 ^ 0) - 0 << 0 << 0;
					continue;
				case 324u:
					num = (int)((((num2 + 485377452) ^ 0x5C10BE8B) << 0 << 0) + 0 << 0);
					continue;
				case 325u:
					num = ((int)(((num2 + 1242855583) ^ 0x47966FEB) + 0) >> 0) ^ 0 ^ 0;
					continue;
				case 326u:
					flag51 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[13];
					num = (1993185648 - 0 << 0 << 0) + 0;
					continue;
				case 23u:
				{
					int num105;
					int num106;
					if (!flag51)
					{
						num105 = 967621788;
						num106 = num105;
					}
					else
					{
						num105 = 1684382614;
						num106 = num105;
					}
					num = ((((num105 >> 0) - 0) ^ ((int)num2 + -911023271)) + 0 << 0) - 0 << 0;
					continue;
				}
				case 328u:
					num = (((int)((num2 + 185819316) ^ 0x44513A2D ^ 0) >> 0) - 0) ^ 0;
					continue;
				case 340u:
					num104 = (((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu != (Object)null) ? 1 : 0);
					goto IL_7fb6;
				case 330u:
					num = (int)(((num2 + 378824685) ^ 0x474AE792 ^ 0 ^ 0) - 0 << 0);
					continue;
				case 331u:
					num = (int)(((num2 + 747371338) ^ 0x3B6B6C9D) + 0 << 0) >> 0 >> 0;
					continue;
				case 332u:
					flag50 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[14];
					num = 0x6D5A8D4E ^ 0;
					continue;
				case 333u:
				{
					int num102;
					int num103;
					if (flag50)
					{
						num102 = -106974780;
						num103 = num102;
					}
					else
					{
						num102 = -1107168774;
						num103 = num102;
					}
					num = (int)(((((uint)((num102 << 0) ^ 0) ^ (num2 + 1179004548)) - 0) ^ 0) - 0 << 0);
					continue;
				}
				case 334u:
					num = (((int)num2 + -1430421857) ^ -128084163 ^ 0 ^ 0) + 0 >> 0;
					continue;
				case 335u:
					Enemey_gun.gQSvRGUJAnIugZxkeHRixUvZeZkEaewAeghZeymlqGlyjZpQjTAtxsJmvTqSvqIvQhpaSxfGvGRRIWPfKuugEdcMwUElitQZXQIbJoXMOTXRASEydkhaWCQNfDDXTTybQSTRoNwvwHrKflmEqghXmPduaUWfLaTVvWaIYMjqOMDpkfHTrZGNLAPaOyRtRqKwOwojkEFEWRjzmOkUncOMtgjVgaTzUQyxcgANQyINtcQTrpOaoWgOCXdHntckKfJgsLxfnxeOtbsrppERmSlXJKVedSAwwycnsKBFSINRSsuAFLsXPlYSULwIQtbuWHsVZeYEOYYDeufrpuyrACHkzjtGoSPyGtUkayBANNjQmvOzFfsvUKTuahwPLsqVjzXLAVqQTYEMsRYevUaiztEWzzjScLPuxnGMycZKOCBWfhbjiruQrhwPValaLyNhijofkmGsVqtXRIQsxaKLrYcqRQRxRYY();
					num = ((((int)num2 + -1712805725) ^ -1552505965) - 0 >> 0) - 0 - 0;
					continue;
				case 336u:
					num = ((int)((num2 + 842851123) ^ 0x2AD53A1B ^ 0) >> 0 >> 0) + 0;
					continue;
				case 337u:
					num = (int)((((num2 + 1261740101) ^ 0x53BF5F1D) << 0) ^ 0) >> 0 << 0;
					continue;
				case 338u:
					flag47 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[15];
					num = (0x5A86D5AC ^ 0) - 0 >> 0;
					continue;
				case 339u:
				{
					int num96;
					int num97;
					if (!flag47)
					{
						num96 = 2026968377;
						num97 = num96;
					}
					else
					{
						num96 = 1962072565;
						num97 = num96;
					}
					num = (int)((((uint)((num96 >> 0) + 0) ^ (num2 + 367591730)) - 0 << 0 << 0) + 0);
					continue;
				}
				case 24u:
					num = (int)((((num2 + 915923519) ^ 0x53EBDBB4) << 0) - 0 + 0 + 0);
					continue;
				case 341u:
					stalker_gun.qNWauWHtdlocsRqeNZNEbcmzluRyIjtdtKAExWBSgsmiIfgJZOeIruYnBxOafjLTSlJIqMHQyVxJPeQfnhyTeKMZLmcZiBNXHtpxwxsnhokvWpxwHIMXKROizJXdJHIWiAbwOtJQOkMQzqdwPFszOPmQEhXNApEzFnnvnbInZWjzeXJjGBodoiisnlRHvWpzGnllcHiNXeASGMMHxOgZaBlxfUickaSdGJTRMxgZsAfjHpMAzkjGPq();
					num = (((int)num2 + -315898204) ^ 0x69ABDF20) - 0 - 0 - 0 + 0;
					continue;
				case 354u:
				{
					int num94;
					int num95;
					if (flag46)
					{
						num94 = 1442967952;
						num95 = num94;
					}
					else
					{
						num94 = 1009832110;
						num95 = num94;
					}
					num = (int)(((((uint)(num94 - 0 - 0) ^ (num2 + 832756594)) + 0) ^ 0) - 0 + 0);
					continue;
				}
				case 343u:
					num = ((int)((((num2 + 596759240) ^ 0x5BF6F277) << 0) - 0) >> 0) ^ 0;
					continue;
				case 344u:
					flag45 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[16];
					num = ((0x70E37BF3 ^ 0) << 0) - 0;
					continue;
				case 345u:
				{
					int num92;
					int num93;
					if (!flag45)
					{
						num92 = -477563958;
						num93 = num92;
					}
					else
					{
						num92 = -1433901320;
						num93 = num92;
					}
					num = (int)((((uint)((num92 - 0) ^ 0) ^ (num2 + 462422847) ^ 0) - 0) ^ 0) >> 0;
					continue;
				}
				case 346u:
					num = (((((int)num2 + -468782383) ^ 0x4183D663 ^ 0) - 0) ^ 0) - 0;
					continue;
				case 347u:
					timmy_gun.vRoiZFfKzLSWTfzbYpueRhwqySQlINfnSpeiEhPfpqsoSIbORhIrfowovXKhOUbLGEeDarwRApOAOhxQQctBfOhDSQMHwHqvpGInExNAKRQQAWzoAUqLAAGRwALkEPuTYsliyjmtpTQnXrdWqygCqFVOZQQdMCVVwXRhKrPqIXwGKsUfwOTfISCtxwiIsiHMYVRZzWlYJQUtioeHWLHXJQmEvyJnjgXzqJIOBUFACUvSXjkisBMHBJdiJnEbmYPCSudzGqfbgguOutGmoBVHuqYGGAfnqEnEfTZDfLBbvKBuppOpHsMLchhCwxSgkSKBTQJAtdgDZTmJPEqrMPGYRCCXLxgISvRDaZAzGnVDl();
					num = ((((int)num2 + -500636083) ^ 0x8D44FE8) + 0 >> 0) + 0 >> 0;
					continue;
				case 348u:
					num = (int)(((num2 + 1770537304) ^ 0x9106863Fu ^ 0) - 0 + 0) >> 0;
					continue;
				case 349u:
					num = (int)(((((num2 + 1900087015) ^ 0xE1D2D1D9u) << 0) - 0) ^ 0) >> 0;
					continue;
				case 350u:
					flag44 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[17];
					num = 0x5174308D ^ 0;
					continue;
				case 351u:
				{
					int num90;
					int num91;
					if (flag44)
					{
						num90 = 1189520737;
						num91 = num90;
					}
					else
					{
						num90 = 784445823;
						num91 = num90;
					}
					num = (int)((((uint)((num90 >> 0) ^ 0) ^ (num2 + 17482432)) << 0) + 0) >> 0 >> 0;
					continue;
				}
				case 352u:
					num = (int)((((num2 + 1201375853) ^ 0x3BB5EF26) + 0) ^ 0 ^ 0 ^ 0);
					continue;
				case 353u:
					grab_id_gun.TmfLKzUNwVFwLURtcGpZIdAPnqFsNeRxQGMTeziBNnQERohEuuvKKVbPMpxtUCaseiGeiXoDxOlvnWYZjaYtIgNUFWhPbPHlnxzIHcwwfSmVKGBQrxjTEHJXvMzlQzBIgZiPwpsgEBnQTRjZvrxDFNHFOCnVDlGGqEOKxLtbfcpctTeECAPybXctsCbTcwDtUHzocyBJXwyDxEmVxJsdviEtCvsVJzZIzWhMtPBdYgAFzzWOpgwsdAYMcgMHgGZxxPeBwABIhpeoHZTdzEFDdGEYYuJncUXrgdiJuurPFNlOvJfcmJhBbwtQkfDbQoFmrNhDRkIenPXqvQDopHbtNvpKJrzpRpZrhYwIBBkcadomydu();
					num = (int)((((num2 + 241941658) ^ 0x2274957D) - 0 << 0 << 0) + 0);
					continue;
				case 25u:
					num = ((int)(((num2 + 506156956) ^ 0x26B2C171) - 0) >> 0 >> 0) + 0;
					continue;
				case 355u:
					num = (((int)num2 + -830187216) ^ 0x5D3988D3) - 0 + 0 + 0 >> 0;
					continue;
				case 1u:
					num = (((int)((num2 + 1219224038) ^ 0x9F0A29E3u) >> 0) ^ 0) + 0 << 0;
					continue;
				case 357u:
				{
					int num88;
					int num89;
					if (flag28)
					{
						num88 = 1896504921;
						num89 = num88;
					}
					else
					{
						num88 = 357160624;
						num89 = num88;
					}
					num = (((int)((uint)((num88 - 0) ^ 0) ^ (num2 + 1492775351)) >> 0) ^ 0) + 0 + 0;
					continue;
				}
				case 358u:
					num = (int)(((num2 + 1592141263) ^ 0x83EC8FF0u) - 0) >> 0 >> 0 << 0;
					continue;
				case 359u:
					grab_nickname_gun.XYXZqFPrFOwWpWvKGbPmgDgkpbUcAdGehisTvDtzIxhUNSJGyADIIDKtSNJpKMQChsPh();
					num = (((((int)num2 + -1329608051) ^ -248609351) >> 0) ^ 0) + 0 << 0;
					continue;
				case 360u:
					num = (int)((((num2 + 984445933) ^ 0xE549049Bu) - 0 << 0) + 0 + 0);
					continue;
				case 361u:
					num = (((int)((num2 + 522403719) ^ 0x315EC1C9) >> 0) ^ 0) - 0 - 0;
					continue;
				case 362u:
					flag43 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[19];
					num = (0xCD4056D ^ 0) - 0;
					continue;
				case 363u:
				{
					int num86;
					int num87;
					if (flag43)
					{
						num86 = 597894397;
						num87 = num86;
					}
					else
					{
						num86 = 558152901;
						num87 = num86;
					}
					num = (int)(((((uint)(num86 + 0 >> 0) ^ (num2 + 789414468)) - 0) ^ 0) - 0 << 0);
					continue;
				}
				case 364u:
					num = ((((int)((num2 + 604020417) ^ 0x61CA0E86) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 365u:
					tagggun.dMWcIlxUokUymFzjxTkjWroHaAulMxmHiSUxwPgQFzxfJjNyOfIdhOjLypbiRlhQXnpuKcNHMtDwTiYRNWxGOjAuIiZgOYZtsGivTsOLsbrNkNRprkvUOAcONVLBcGTOukemaCYuiLoNRMjVrJODCeFREtIXHmILiCsZIEpPmbMcmpWaMPktSplpEnIGUaMWcCFoujmMuYrBsDEpxIlRbpTSrdvvWIVloQZKKHGCDyYTXKXbItjlPVVNJMXqORPLdgmBEUEPbIoCrZVHftMDzJvtVmaXKpNMImQRxvxOO();
					num = (((((int)num2 + -1562510857) ^ 0x6D7874B) << 0) ^ 0) - 0 - 0;
					continue;
				case 366u:
					num = ((((((int)num2 + -687065819) ^ -1549012027) + 0) ^ 0) >> 0) - 0;
					continue;
				case 367u:
					num = (int)((((num2 + 340797832) ^ 0x88C215C7u) << 0) - 0 - 0) >> 0;
					continue;
				case 26u:
					flag42 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[20];
					num = 524100994 - 0 << 0 << 0 << 0;
					continue;
				case 369u:
				{
					int num84;
					int num85;
					if (!flag42)
					{
						num84 = -1028719620;
						num85 = num84;
					}
					else
					{
						num84 = -1084317749;
						num85 = num84;
					}
					num = ((((num84 << 0 << 0) ^ ((int)num2 + -619363741)) - 0 - 0) ^ 0) >> 0;
					continue;
				}
				case 381u:
					val = dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu.AddComponent<Rigidbody>();
					num = (int)((((num2 + 224353012) ^ 0x5391755A) + 0 + 0 << 0) + 0);
					continue;
				case 371u:
					disable_network.akmoYGPwAWzWWUIPfjJJvApUWrGgURwdNHzXlXZVJWvafmMHEJCmLUxzVssGaIBIAvjouLDhkNazeoPKF();
					num = ((((((int)num2 + -478800049) ^ 0x43BAAAD4) << 0) ^ 0) >> 0) + 0;
					continue;
				case 372u:
					num = (int)((num2 + 1414533412) ^ 0xD5F94DEBu) >> 0 << 0 >> 0 << 0;
					continue;
				case 373u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ue3ea\ue3e6\ue3e0\ue3e2\ue3e9\ue3f3\ue3e6", 2137318279, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㛛㛖㛌㛞㛝㛓㛚㚟㛑㛚㛋㛈㛐㛍㛔㚟㛋㛍㛖㛘㛘㛘㛚㛍㛌", 1211446975, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⢢⢏⢕⢇⢄⢊⢃⢂⣆⢨⢃⢒⢑⢉⢔⢍⣆⢒⢔⢏⢁⢁⢃⢔⢕⣇", 1531783398, true));
					num = (int)(((num2 + 1624109742) ^ 0x70907DC4 ^ 0) + 0 + 0 + 0);
					continue;
				case 374u:
					num = (int)((((num2 + 992482697) ^ 0x75E58D20) << 0) - 0 + 0 + 0);
					continue;
				case 375u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = ((int)((num2 + 739100348) ^ 0x37834D60 ^ 0) >> 0 >> 0) + 0;
					continue;
				case 376u:
					num = ((((int)num2 + -1556896036) ^ 0x1206D8AF) << 0 << 0 >> 0) + 0;
					continue;
				case 377u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[20] = false;
					num = ((int)(((num2 + 1672605122) ^ 0x9A5BE108u) - 0) >> 0) + 0 << 0;
					continue;
				case 378u:
					num = (int)(((((num2 + 614903323) ^ 0x6560CD1) - 0 << 0) + 0) ^ 0);
					continue;
				case 379u:
					flag41 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[21];
					num = (0x5B770E6A ^ 0) - 0 - 0 << 0;
					continue;
				case 380u:
				{
					int num82;
					int num83;
					if (!flag41)
					{
						num82 = -21549106;
						num83 = num82;
					}
					else
					{
						num82 = -183021361;
						num83 = num82;
					}
					num = (int)(((((uint)((num82 - 0) ^ 0) ^ (num2 + 652252194)) - 0 + 0) ^ 0) + 0);
					continue;
				}
				case 27u:
					num = (int)(((((num2 + 1729800267) ^ 0xD6AFEFA5u) << 0) ^ 0 ^ 0) << 0);
					continue;
				case 382u:
					name_change_all.FzAhRhzXSVZmgYHuMmyyNKIZumVNCvZyHelpatcVyAKiwhTBAzjzkUtUQANEmLvxWAFcMrtsjDZmaADmttmclzoMKrzAGxJNfmmWBRPigQpGUgTqXBlSyslwlTruSSMMTmhOnHKBEdWukHRDxjCemQoMaQKIzuqneDNIZfcqQJouw();
					num = (((int)(((num2 + 1693163121) ^ 0x6730C2F6) - 0) >> 0) - 0) ^ 0;
					continue;
				case 395u:
					val2 = sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX.AddComponent<Rigidbody>();
					num = (int)(((num2 + 2066094223) ^ 0xD8CF1155u) - 0 - 0 << 0) >> 0;
					continue;
				case 384u:
					num = ((((int)num2 + -866012773) ^ -1870889165) + 0 << 0) + 0 >> 0;
					continue;
				case 385u:
					flag40 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[22];
					num = 0x2466F2EC ^ 0;
					continue;
				case 386u:
				{
					int num80;
					int num81;
					if (!flag40)
					{
						num80 = -1849052973;
						num81 = num80;
					}
					else
					{
						num80 = -1209401937;
						num81 = num80;
					}
					num = (int)(((((uint)((num80 << 0) - 0) ^ (num2 + 2077277705)) - 0) ^ 0) - 0 - 0);
					continue;
				}
				case 387u:
					num = (((int)num2 + -569212473) ^ -272634296 ^ 0) - 0 - 0 << 0;
					continue;
				case 388u:
					ban_all.uOLxFQmoTAHLaofAFrzKudweEiKjiZQHtnFSkuHvfOSMkktaTJDssRGrsHSxfdgUKarMJnqkJdFGkJTuPKpzvxoCGnzCCkqbIYbkTGqFssIpmahINyIvNHymLPfvNOIzNDXlIIAitJhcPZpFgROeCUnaAPzeAVSDKjBIcVaeXAceAwxLzApWZEXSpXLSjwHxRDsGxHDkRKgbSjAdrNFaGVEflIsfkhVBSEmWeRoRXeepyVafwHBwQGRVZmuOoxaKOEjnXEZAzNdBRoHqHmJCGyKmNqXRxzDzetATMNiRIaXdCpeKEdhbNxeqUWAGGhdajDxxOOEUeRUFBGJxmnntsBMGpkYPnBl();
					num = (int)((((num2 + 261221667) ^ 0x45DBAF8B) - 0 << 0) + 0 + 0);
					continue;
				case 389u:
					num = (int)(((((num2 + 487454468) ^ 0xA2246FE3u ^ 0) - 0) ^ 0) + 0);
					continue;
				case 390u:
					num = ((int)((num2 + 1807938025) ^ 0xA6D1E9F7u) >> 0 >> 0 << 0) - 0;
					continue;
				case 391u:
					flag38 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[23];
					num = (163182892 - 0 << 0 >> 0) + 0;
					continue;
				case 392u:
				{
					int num76;
					int num77;
					if (flag38)
					{
						num76 = -1799392013;
						num77 = num76;
					}
					else
					{
						num76 = -1255724910;
						num77 = num76;
					}
					num = ((((num76 + 0 >> 0) ^ ((int)num2 + -1389010753)) << 0) ^ 0) >> 0 >> 0;
					continue;
				}
				case 393u:
					num = ((((int)num2 + -1917398101) ^ -1350464033) - 0 - 0 - 0) ^ 0;
					continue;
				case 394u:
					im_mooder.AXWTYRGWPzmXVDyOnncutTKHIRRiDPOHCGtIEMKGFqxTfEQdQvKCkhRGmplhaysZLFvpjQjBDwOcwQCdaNriemwuPNvpACFhYyiziBUaljYOtOkwMhgmhjUyjbzvuUaaQHeXHcVzTqWUnHabCZDswsZODJqhcyFrjYYMKmOKmHtQnZkBaySvqHDxHpuXMNxuLELpJoqqkTgPZjBDzOhDFkaCuAeuRQYyjZfIoVSLhCkxAOyyNRyXGTOADiUijWyuVHFadSoDWvwcZDbGcGGaraSpkEfgbJBleQCTiyuVDVbkxLBagogDpycUOpPzNiCmTkY();
					num = ((((((int)num2 + -717290851) ^ -615214382) << 0) ^ 0) << 0) - 0;
					continue;
				case 28u:
					num = ((int)((num2 + 1132938942) ^ 0x1C71A776) >> 0) - 0 - 0 >> 0;
					continue;
				case 396u:
					num = (((((int)num2 + -1937246976) ^ -130430682) << 0) + 0 - 0) ^ 0;
					continue;
				case 408u:
					val.useGravity = false;
					num = ((int)((num2 + 112149509) ^ 0x7295F562 ^ 0) >> 0 >> 0) ^ 0;
					continue;
				case 398u:
				{
					int num74;
					int num75;
					if (!flag16)
					{
						num74 = -1738072220;
						num75 = num74;
					}
					else
					{
						num74 = -1537190032;
						num75 = num74;
					}
					num = ((((int)((uint)((num74 << 0) - 0) ^ (num2 + 1339615098)) >> 0) ^ 0) << 0) - 0;
					continue;
				}
				case 399u:
					num = (int)(((num2 + 1303643194) ^ 0x1B1C70DB) - 0 - 0 << 0 << 0);
					continue;
				case 400u:
					Spoof_Data.NCUrVnLMhRBUsGdSOdXbAdATEOYnAgSOagrQEscsaHYaRndwPsukDujKcaNgpymaZMTmonnvbEaTezbrLBxiMHkGXHNDFVcCvYaetQiCfYjZtpGCZwvObdosCnpGzJQfByyfzWXUsUcNxknIbkEiAoArKICfBBcviexUQAdcyAvgaBUraHFpeHEnXhvQuStRSHEtNsRAgCKZTuqjOkfTVNrAzkXIemHGgEotWAEIPfiCXEuDRmckMzVepeTDuiwUUeSogWnnGxeQEPCUPuRRjxTHIjdRHanHIoHSLfwUZPEpvfAABYNaqEKwllGXSvFFjwhqhJjKXWSuTDlCJCpInmqeEkHAyzcDjYfYXjtRPcduMpDHZdnpgXrXg();
					num = ((((int)num2 + -167701490) ^ 0x12A923F) >> 0) - 0 - 0 >> 0;
					continue;
				case 401u:
					num = ((((int)num2 + -52150118) ^ 0x64BD860) - 0 + 0) ^ 0 ^ 0;
					continue;
				case 402u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[24] = false;
					num = (((int)num2 + -933514764) ^ 0x44EB5A7C) >> 0 >> 0 >> 0 >> 0;
					continue;
				case 403u:
					num = ((int)(((num2 + 1812111734) ^ 0xCF060AECu ^ 0) + 0) >> 0) - 0;
					continue;
				case 404u:
					flag37 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[25];
					num = ((0x56ED087C ^ 0) << 0) - 0 - 0;
					continue;
				case 405u:
				{
					int num72;
					int num73;
					if (!flag37)
					{
						num72 = -933096160;
						num73 = num72;
					}
					else
					{
						num72 = -1877140076;
						num73 = num72;
					}
					num = (int)(((uint)(num72 >> 0 << 0) ^ (num2 + 699162991) ^ 0) + 0 - 0 - 0);
					continue;
				}
				case 406u:
					num = (((int)num2 + -854572233) ^ -152060230) - 0 + 0 + 0 >> 0;
					continue;
				case 407u:
					tp_gun.ZMsIYElodwVIYUqNduncYgiAeSPFTmPibnVdijgBDzZVdtrblKyQKCKSDSDfPFuQHNGKZnFUnMzzhnwKAOujOYxzDczpFaLXejoqNHcYfDDYckLqvSFbllbJpggWNpomaCvYYgXTLvdluzwsrjUMvKLShFaGAglQprYAPMrpVMpPiQoQKOEDuBQpQCQtfqsFknVdBVCESFRJvVKrrkWMBHvNAIKmWXjEtJFUUkoOlZKPKhUUSzcUuGeCSiCSlpIUvmqLqPwgViABXFdtNPuxVpkMEccMHwCVrPuxRiDccVYlfCFmfjfvVlZgcDgoNKyzFFjhkFCFlruZqYGcxPGyrgZgQounbpprxyGAtxczHzjEQZPeWeQYeaizFdrWloDWcdCRsfIZNhQRWvqQypqWzqnwqhVqffosVnCMxYMRvQlXjrCjMBxVYHxLQfBkksUHSxVJTDsACzAIeqnYFLDEIsuoQQWswBGdWEeLvS();
					num = (int)(((((num2 + 642369133) ^ 0x71D718F6) + 0) ^ 0) - 0 - 0);
					continue;
				case 29u:
					num = (int)(((((num2 + 1022571930) ^ 0x3B04E644 ^ 0) << 0) ^ 0) + 0);
					continue;
				case 409u:
					num = ((((int)num2 + -582395626) ^ 0xBB63848) << 0) + 0 << 0 >> 0;
					continue;
				case 422u:
					num = ((((((int)num2 + -372712337) ^ 0xC85F7B4) << 0) + 0) ^ 0) >> 0;
					continue;
				case 411u:
				{
					int num70;
					int num71;
					if (!flag19)
					{
						num70 = 1868377809;
						num71 = num70;
					}
					else
					{
						num70 = 1442085796;
						num71 = num70;
					}
					num = (((num70 ^ 0 ^ 0 ^ ((int)num2 + -110500935)) >> 0 >> 0) ^ 0) - 0;
					continue;
				}
				case 412u:
					num = (int)((((num2 + 1171519953) ^ 0x689E4508) - 0 + 0 << 0) ^ 0);
					continue;
				case 413u:
					change_idenity.FJNyuqwlbCfcWaJSWPVsqLEqbTBPNAfMbqvmXjOOkEpLycdAThrAKZJUfwxAOGyAwsaGFxUNbghLwSSYQaWFjEcbGAgAMnZEgOofbxUvmEyDRYxmEyKNKSrRq();
					num = (((int)num2 + -786759984) ^ 0x5E2CF758) << 0 << 0 << 0 >> 0;
					continue;
				case 414u:
					num = ((int)((num2 + 1517621310) ^ 0xADE96C87u) >> 0 << 0) + 0 << 0;
					continue;
				case 415u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("旋旇旁旃旈旒旇", 1863673254, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㊺㊱㊸㊷㊾㊼㋹㊰㊽㊼㊷㊰㊭㊠", 1146303193, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("天夂夋处复夏夎奊夣夎夏处夃夞夓奋", 2088982890, true));
					num = (int)((((num2 + 323386177) ^ 0x5083334D) + 0 + 0) ^ 0 ^ 0);
					continue;
				case 416u:
					num = (int)((((num2 + 1128589596) ^ 0xF6FBC4F4u) << 0) + 0 - 0 - 0);
					continue;
				case 417u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (((int)num2 + -2105034118) ^ -1313097271) - 0 + 0 - 0 << 0;
					continue;
				case 418u:
					num = (((((int)num2 + -1827971307) ^ -1518133188) << 0 >> 0) ^ 0) + 0;
					continue;
				case 419u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[26] = false;
					num = (((((int)num2 + -1958799900) ^ -781605595) + 0 + 0) ^ 0) + 0;
					continue;
				case 420u:
					num = ((((int)num2 + -205950486) ^ 0x2E2DB1E6) + 0 << 0) + 0 >> 0;
					continue;
				case 421u:
					flag36 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[27];
					num = (0x120278E1 ^ 0) << 0;
					continue;
				case 30u:
				{
					int num68;
					int num69;
					if (flag36)
					{
						num68 = -1463660724;
						num69 = num68;
					}
					else
					{
						num68 = -338423934;
						num69 = num68;
					}
					num = ((((num68 << 0) - 0) ^ ((int)num2 + -1212166779)) << 0 << 0) + 0 >> 0;
					continue;
				}
				case 423u:
					num = ((((int)num2 + -879851259) ^ 0x7E0CF27E) + 0 << 0) + 0 >> 0;
					continue;
				case 436u:
					val.mass = 0.06f;
					num = ((((int)num2 + -1820138916) ^ -1434815181) << 0 >> 0) + 0 << 0;
					continue;
				case 425u:
					num = ((((int)num2 + -1170724002) ^ 0x751645A5 ^ 0) >> 0) - 0 + 0;
					continue;
				case 426u:
					num = ((int)((((num2 + 940454708) ^ 0xAE2D2BDDu) - 0) ^ 0) >> 0) + 0;
					continue;
				case 427u:
					flag35 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[28];
					num = (1463023553 >> 0) + 0 << 0 >> 0;
					continue;
				case 428u:
				{
					int num66;
					int num67;
					if (!flag35)
					{
						num66 = 2143708389;
						num67 = num66;
					}
					else
					{
						num66 = 1541912733;
						num67 = num66;
					}
					num = (((num66 ^ 0) - 0) ^ ((int)num2 + -1291402091)) - 0 - 0 << 0 << 0;
					continue;
				}
				case 429u:
					num = ((int)((((num2 + 1306955751) ^ 0xE94EEB57u) << 0) ^ 0) >> 0) + 0;
					continue;
				case 430u:
					RenderSettings.ambientIntensity = 0f;
					num = (int)(((num2 + 128986018) ^ 0x123CDB93) - 0 + 0) >> 0 >> 0;
					continue;
				case 431u:
					num = (int)(((num2 + 1874297009) ^ 0xAF503EE3u ^ 0 ^ 0) - 0 - 0);
					continue;
				case 432u:
					RenderSettings.ambientLight = Color.white;
					num = ((int)((num2 + 247440845) ^ 0x8BF8B6E1u) >> 0) - 0 >> 0 << 0;
					continue;
				case 433u:
					num = (((((int)num2 + -1723271147) ^ -525014602) << 0) + 0 >> 0) - 0;
					continue;
				case 434u:
					RenderSettings.fog = false;
					num = ((((int)num2 + -1093405259) ^ 0x385F0A82 ^ 0) << 0) + 0 << 0;
					continue;
				case 435u:
					num = ((int)((num2 + 1254864355) ^ 0x8D8CBB41u) >> 0 << 0) + 0 << 0;
					continue;
				case 31u:
					RenderSettings.fogColor = Color.white;
					num = (((((int)num2 + -761174331) ^ -495641975) >> 0) ^ 0) - 0 + 0;
					continue;
				case 437u:
					num = (int)((((num2 + 649463067) ^ 0x2C2B255E ^ 0 ^ 0) - 0) ^ 0);
					continue;
				case 449u:
					num = ((((int)num2 + -775866503) ^ 0x50E3B095) << 0) - 0 << 0 << 0;
					continue;
				case 439u:
					num = ((((int)num2 + -443921920) ^ 0x4B86F9F9 ^ 0) >> 0 << 0) ^ 0;
					continue;
				case 440u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = ((((int)num2 + -1515647518) ^ -836605115) - 0 << 0) + 0 << 0;
					continue;
				case 441u:
					num = ((int)((num2 + 2028252045) ^ 0xDC6835DCu ^ 0) >> 0 << 0) - 0;
					continue;
				case 442u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[26] = false;
					num = (int)((((num2 + 1946625427) ^ 0xD7F9E777u) + 0 << 0) - 0 + 0);
					continue;
				case 443u:
					num = (((int)num2 + -466019987) ^ 0x22EF4ADB) - 0 + 0 - 0 >> 0;
					continue;
				case 444u:
					flag34 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[29];
					num = 0x74218693 ^ 0;
					continue;
				case 445u:
				{
					int num64;
					int num65;
					if (!flag34)
					{
						num64 = 985720306;
						num65 = num64;
					}
					else
					{
						num64 = 1547502860;
						num65 = num64;
					}
					num = (int)((((uint)((num64 + 0) ^ 0) ^ (num2 + 101668697) ^ 0) - 0 - 0) ^ 0);
					continue;
				}
				case 446u:
					num = (int)((((((num2 + 1361258460) ^ 0x1E3544E6) - 0) ^ 0) << 0) ^ 0);
					continue;
				case 447u:
					CASUAL.VmVKloqrutqKyceGHsaFKZyxfiFPzgkisonbbmywbFqZymEGebfSeBqWNxEcJBSnjisjPcFvTEDfJzZTDZLxbrdQXrnDHwNANdQpUuQbwKZAXlnoyLzKQulReBmyPcNxRdsFIKZiiKbrsDTMeZfWWdKsRYktismuWBJTTHFOLrBgtUzBHAuQWRBOtZOKzGZQxGuQUZSxtrkFBEYWy();
					num = (((((int)num2 + -1815659959) ^ -307463884) - 0) ^ 0) - 0 >> 0;
					continue;
				case 448u:
					num = (int)(((num2 + 1725556564) ^ 0x400D934F) << 0) >> 0 >> 0 >> 0;
					continue;
				case 32u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("➌➀➆➄➏➕➀", 368781281, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uf4c6\uf4e4\uf4f6\uf4f0\uf4e4\uf4e9", 1369371781, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䱳䱕䱙䱑䱙䱛䱐䱑䰔䱝䱇䰔䱗䱕䱇䱁䱕䱘䰕", 2144160820, true));
					num = (((int)((num2 + 581368855) ^ 0x6F795F7D) >> 0 >> 0) - 0) ^ 0;
					continue;
				case 450u:
					num = (int)((((((num2 + 679689939) ^ 0x20D01DFE) << 0) - 0) ^ 0) << 0);
					continue;
				case 463u:
					val2.mass = 0.06f;
					num = (int)(((((num2 + 1942437954) ^ 0xF45B3DF7u) << 0 << 0) ^ 0) - 0);
					continue;
				case 452u:
					num = (((int)((num2 + 294817558) ^ 0x4FB383EE ^ 0) >> 0) ^ 0) - 0;
					continue;
				case 453u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[29] = false;
					num = (((int)((num2 + 1096924785) ^ 0x2534985D) >> 0) + 0 << 0) ^ 0;
					continue;
				case 454u:
					num = (((((int)num2 + -1118082152) ^ 0x5D612301) + 0 + 0) ^ 0) + 0;
					continue;
				case 455u:
					flag33 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[30];
					num = (0x23109727 ^ 0) << 0;
					continue;
				case 456u:
				{
					int num62;
					int num63;
					if (flag33)
					{
						num62 = -1400482775;
						num63 = num62;
					}
					else
					{
						num62 = -1217241108;
						num63 = num62;
					}
					num = (int)((((((uint)(num62 ^ 0 ^ 0) ^ (num2 + 1899186281)) - 0) ^ 0) << 0) ^ 0);
					continue;
				}
				case 457u:
					num = ((int)(((num2 + 1532317347) ^ 0xF73B056Cu) + 0) >> 0) + 0 - 0;
					continue;
				case 458u:
					infection.xoxEtsMsHqOhEFtCjAYrrCjlejpeLFUegZUKqrqgfzRbCxTHEcOEzFdUflAjcHHbwJbELImSkSlSLhJGqHAJRqFAVZF();
					num = ((((((int)num2 + -527263126) ^ 0x120A3975) << 0) - 0) ^ 0) >> 0;
					continue;
				case 459u:
					num = (((((int)num2 + -47346988) ^ 0xB4CF937) - 0 >> 0) ^ 0) - 0;
					continue;
				case 460u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uefda\uefd6\uefd0\uefd2\uefd9\uefc3\uefd6", 232976311, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("靅靂靊靉靏靘靅靃靂", 460494636, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᙘᙾᙲᙺᙲᙰᙻᙺᘿᙶᙬᘿᙖᙱᙹᙺᙼᙫᙶᙰᙱᘾ", 244127263, true));
					num = ((((int)num2 + -578234304) ^ 0x2F24254F ^ 0) >> 0 << 0) - 0;
					continue;
				case 461u:
					num = (int)(((num2 + 1286591901) ^ 0x4956F64A) - 0 + 0 + 0 << 0);
					continue;
				case 462u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (((((int)num2 + -1503519038) ^ -613147665 ^ 0) - 0) ^ 0) >> 0;
					continue;
				case 33u:
					num = ((((((int)num2 + -1746828059) ^ 0x75775B79) - 0) ^ 0) + 0) ^ 0;
					continue;
				case 464u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[30] = false;
					num = (int)(((num2 + 229081915) ^ 0x24A12C4E) - 0 + 0 - 0 + 0);
					continue;
				case 477u:
					num = (((int)num2 + -788912758) ^ -481860397) + 0 >> 0 >> 0 >> 0;
					continue;
				case 466u:
					flag30 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[31];
					num = (0x754CEC2B ^ 0) + 0 - 0;
					continue;
				case 467u:
				{
					int num56;
					int num57;
					if (flag30)
					{
						num56 = 1315748213;
						num57 = num56;
					}
					else
					{
						num56 = 1106867963;
						num57 = num56;
					}
					num = ((((num56 + 0) ^ 0 ^ ((int)num2 + -1497720661) ^ 0) >> 0) ^ 0) << 0;
					continue;
				}
				case 468u:
					num = (((int)(((num2 + 1316050359) ^ 0xD74AC02Fu) + 0) >> 0) ^ 0) + 0;
					continue;
				case 469u:
					RenderSettings.fog = false;
					num = ((int)((num2 + 552325598) ^ 0xCC0020A2u) >> 0 >> 0) + 0 >> 0;
					continue;
				case 470u:
					num = (int)((((num2 + 672594117) ^ 0x68367C5E ^ 0) << 0 << 0) ^ 0);
					continue;
				case 471u:
					RenderSettings.ambientLight = Color.white;
					num = (((int)(((num2 + 971039757) ^ 0x55043AA1) + 0) >> 0) ^ 0) + 0;
					continue;
				case 472u:
					num = ((((((int)num2 + -1742695930) ^ -1686880770) >> 0) - 0) ^ 0) << 0;
					continue;
				case 473u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㳏㳃㳅㳇㳌㳖㳃", 1553480866, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鍣鍐鍉鍉錅鍇鍗鍌鍂鍍鍑", 1627820837, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꬩ\uab19ꬂꬌꬃ\uab1fꬅꬎ\uab18\uab18ꭊ", 1306831723, true));
					num = ((int)(((num2 + 2056780806) ^ 0xC1D9E601u) + 0) >> 0 << 0) - 0;
					continue;
				case 474u:
					num = (((((int)num2 + -1971203015) ^ -688615264) >> 0 << 0) + 0) ^ 0;
					continue;
				case 475u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = (int)(((num2 + 2068319255) ^ 0xC3B9603Eu) - 0 - 0 << 0) >> 0;
					continue;
				case 476u:
					num = (((int)num2 + -1463937443) ^ 0x6694351A) << 0 >> 0 >> 0 << 0;
					continue;
				case 34u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[31] = false;
					num = ((((int)num2 + -82107842) ^ 0x3FE70898) + 0 << 0) + 0 << 0;
					continue;
				case 478u:
					num = ((((int)num2 + -1910996344) ^ -1964619205) >> 0) - 0 >> 0 >> 0;
					continue;
				case 490u:
					val.velocity = new Vector3((float)Random.Range(-1, 1), (float)Random.Range(-1, 1), (float)Random.Range(-1, 1));
					num = (((int)((num2 + 2117634747) ^ 0xD4A1AA8Au) >> 0) + 0 >> 0) + 0;
					continue;
				case 480u:
				{
					int num53;
					int num54;
					if (!flag29)
					{
						num53 = 2002115546;
						num54 = num53;
					}
					else
					{
						num53 = 1750922690;
						num54 = num53;
					}
					num = ((int)(((uint)((num53 << 0) - 0) ^ (num2 + 1772522450)) + 0) >> 0) - 0 + 0;
					continue;
				}
				case 481u:
					num = ((((int)num2 + -297181590) ^ -911988904) << 0) - 0 + 0 << 0;
					continue;
				case 482u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ԎԂԄԆԍԗԂ", 1829373283, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("눙눴눮눼눿눱눸뉽눚눲눯눴눱눱눼눓눲눩", 943895133, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("깐깽깧깵깶깸깱깰긴깳깻깦깽깸깸깵긴깺깻깠긵", 1350872596, true));
					num = (int)(((num2 + 2105880369) ^ 0xE1D053C5u) + 0 - 0 - 0 + 0);
					continue;
				case 483u:
					num = (((((int)num2 + -1912516747) ^ -236081475) >> 0) ^ 0) + 0 - 0;
					continue;
				case 484u:
					GorillaTagger.Instance.offlineVRRig.PlayHandTap(49, false, 0.2f);
					num = ((((int)num2 + -1308033196) ^ -167914351) >> 0 << 0) ^ 0 ^ 0;
					continue;
				case 485u:
					num = (((int)num2 + -1158261548) ^ -333482728) - 0 - 0 << 0 >> 0;
					continue;
				case 486u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[32] = false;
					num = ((int)((num2 + 1013496949) ^ 0x29C6EDC0) >> 0) - 0 - 0 >> 0;
					continue;
				case 487u:
					num = (((((int)num2 + -1679016414) ^ -1354214520) >> 0) + 0 - 0) ^ 0;
					continue;
				case 488u:
					flag26 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[33];
					num = (0x37FCEE6D ^ 0) >> 0 << 0;
					continue;
				case 489u:
				{
					int num49;
					int num50;
					if (!flag26)
					{
						num49 = -1956911709;
						num50 = num49;
					}
					else
					{
						num49 = -1472333943;
						num50 = num49;
					}
					num = ((int)((((uint)(num49 >> 0 >> 0) ^ (num2 + 1901976708)) - 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 35u:
					num = ((((int)num2 + -274757488) ^ -1125826419) - 0 >> 0 >> 0) - 0;
					continue;
				case 491u:
					tracers.djohyYJPzFIXVzHdxeScVLPqHomjjcfvOgCzMEdDzQQIgzpJJjASsNXruYAjMAGxAnjOXhqSboCfVgjhZCAa();
					num = (int)((((num2 + 1291843631) ^ 0xFECA356Cu) - 0 << 0) - 0) >> 0;
					continue;
				case 504u:
					num = ((((int)num2 + -2056409276) ^ -1730030225 ^ 0) << 0 << 0) + 0;
					continue;
				case 493u:
					num = (((int)(((num2 + 350315452) ^ 0xB2951DD) + 0) >> 0) - 0) ^ 0;
					continue;
				case 494u:
					flag25 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[34];
					num = ((0x55742E3A ^ 0) << 0 >> 0) + 0;
					continue;
				case 495u:
				{
					int num47;
					int num48;
					if (flag25)
					{
						num47 = -203104188;
						num48 = num47;
					}
					else
					{
						num47 = -300420120;
						num48 = num47;
					}
					num = (((num47 - 0 - 0) ^ ((int)num2 + -1959631283)) << 0) + 0 << 0 << 0;
					continue;
				}
				case 496u:
					num = (int)(((((num2 + 1283789044) ^ 0x32AF7B8B) << 0) - 0 << 0) ^ 0);
					continue;
				case 497u:
					chams.JLIYvxfaVATSVofrLIMzJHIHXwFGVmPbSlPUrScjpQZzZEyceoPWmwPccbaZRyeIKSaJzlZTFDkTHjHsYDBHwTPvwNRqRcrQLqOhEOCToVqImWuTtIaoXwlRdFnMtJcClthrvAOjaItADgizsYWjcdTofXeYBQAETNxSOdySTQnocKnWwNtvMTAhASlywPIkiPHQIqLpzeplQEluJhCNweRampsWRawdidgndxngceVIDpqVGROpnVNdXHDtYPxzHldNyYrlTwLsjiwXYwpZlhQnqdpwTUinGvbrlDxIACvRjuTPkGuBzxnAvQxvIVsYoyLNhfLvZHzILZdVjAlnAGNii();
					num = (((int)(((num2 + 1118177725) ^ 0xFA7A296Eu) << 0) >> 0) - 0) ^ 0;
					continue;
				case 498u:
					num = (((int)num2 + -366678784) ^ 0x3D3BA66D ^ 0 ^ 0 ^ 0) + 0;
					continue;
				case 499u:
					num = (int)((((num2 + 1043257318) ^ 0x4961F28F) + 0 << 0 << 0) + 0);
					continue;
				case 500u:
					flag24 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[35];
					num = (0x20F8E4A8 ^ 0) - 0;
					continue;
				case 501u:
				{
					int num45;
					int num46;
					if (flag24)
					{
						num45 = 1215030455;
						num46 = num45;
					}
					else
					{
						num45 = 1784036205;
						num46 = num45;
					}
					num = ((((num45 << 0) + 0) ^ ((int)num2 + -110076878)) - 0 - 0 << 0) ^ 0;
					continue;
				}
				case 502u:
					num = ((int)(((num2 + 106593866) ^ 0x4D732086) - 0) >> 0) + 0 >> 0;
					continue;
				case 503u:
					pbbv.LrPXieMCwScoGBNKnLHiqqqPcOnVAOgREeeyctqrlGDfDPYbisSdjlOvbaVtRQbILlKCxpHUvqWJMllmQlNhWcIspJxbxWAvEVusewESLXHSpeIPOJDFcULICsmORFxzPAeRRThtGVwYuPdlbHnOtUsKjLQMkQafAidOZQYVBjYhyNnMoaMksIfUhuIfcuiQUqxlMolkIrmjWllwxdyjdQMRdiGEhTShainipbaaOBBbwWYWjmIYWZMdDGiDIHdPyfiNXdhvdxvBoLvgkKvVkTkbvjEISwshyLCqNkYfemVyDkOSkctXlhEEVgsNzyCHfncCiesZLpQYYLykvMyQduVrhYvHS();
					num = (int)(((num2 + 1800123191) ^ 0x9A04F83Bu ^ 0) + 0 - 0 + 0);
					continue;
				case 36u:
					num = (int)((((num2 + 1287180896) ^ 0x635CD0A) << 0) - 0 - 0 + 0);
					continue;
				case 505u:
					num = ((((((int)num2 + -1467430011) ^ 0x79B3E589) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 517u:
					val.angularVelocity = new Vector3((float)Random.Range(-33, 33), (float)Random.Range(-33, 33), (float)Random.Range(-33, 33));
					num = (int)(((num2 + 371781460) ^ 0x1046E946 ^ 0) - 0 + 0 + 0);
					continue;
				case 507u:
				{
					int num43;
					int num44;
					if (flag23)
					{
						num43 = 1462637854;
						num44 = num43;
					}
					else
					{
						num43 = 908468439;
						num44 = num43;
					}
					num = (((num43 - 0) ^ 0 ^ ((int)num2 + -415886628)) >> 0 >> 0 << 0) ^ 0;
					continue;
				}
				case 508u:
					num = ((int)(((num2 + 866345590) ^ 0x9D4E62ECu) << 0) >> 0) + 0 << 0;
					continue;
				case 509u:
					cube_s_tump.jjnZYwCFnCCySNSfNCBVpjHCnndrPLzCpNbkfIJibWIHrTMNnmoycEVaCKLLslPBcaieMIaeTsUtAZktAqdDxbzKRaHuXXPPghErL();
					num = ((((int)num2 + -1553112045) ^ -1436520393 ^ 0) << 0) ^ 0 ^ 0;
					continue;
				case 510u:
					num = (int)(((((num2 + 480522030) ^ 0x42E8B8B8) << 0) + 0 - 0) ^ 0);
					continue;
				case 511u:
					num = (int)(((((num2 + 570042112) ^ 0x86F617B9u) << 0) + 0 << 0) - 0);
					continue;
				case 512u:
					flag22 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[37];
					num = (759252388 - 0 + 0 >> 0) + 0;
					continue;
				case 513u:
				{
					int num41;
					int num42;
					if (flag22)
					{
						num41 = -970610298;
						num42 = num41;
					}
					else
					{
						num41 = -1363916812;
						num42 = num41;
					}
					num = (((num41 + 0 << 0) ^ ((int)num2 + -1193254935)) << 0 >> 0) - 0 << 0;
					continue;
				}
				case 514u:
					num = (int)(((((num2 + 1852707108) ^ 0xA3B3019Cu) - 0) ^ 0 ^ 0) + 0);
					continue;
				case 515u:
					SIGMA_NEW_LAG_METHOD.kGGJntqilJfJtmVqGFjIhsMaMDLrLvjJLhAJjoKsicjcshKhaaAslYLSTGXKHYwPzwYlMmgsURAeiKHETDrKVRxMwHPDqaKjGtCWiyvNThxuyGJjYsRdGLUIYlPexDcUgqyPiLwuiERNtdoPYGEXjHDUzTXXIqqqfDohiUamWwUbUgpUWagQYeLzNDpoOyLSoBHQPhGdFsaMMBasEcaIkzrbROtEEMyxLcNszyfPtclGeZMlCXKLycIPjGYaNcyTTCaKOHTfXkphoLWScibHcNZItXjS();
					num = (((int)num2 + -451550948) ^ 0x6CB2FDE ^ 0) - 0 >> 0 << 0;
					continue;
				case 516u:
					num = (((int)(((num2 + 600174400) ^ 0x5E4C3BE7) + 0) >> 0) ^ 0) + 0;
					continue;
				case 37u:
					num = (int)((((num2 + 165989362) ^ 0x3B0124D1) + 0 << 0) ^ 0 ^ 0);
					continue;
				case 518u:
					flag21 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[38];
					num = (0x11402B23 ^ 0) - 0;
					continue;
				case 531u:
					num = ((((int)num2 + -37013066) ^ 0x5A11C138) - 0 >> 0) - 0 - 0;
					continue;
				case 520u:
					num = (((((int)num2 + -1933088798) ^ -2112059420) - 0 + 0) ^ 0) + 0;
					continue;
				case 521u:
					tag_all.WLYRYoDrqIJrNEJMznIowrJgjBLBaDOHnvwjiJvPrKoLfoUiwOOqiZkEcSHwDcqMTceshzEPRSWMdXaUHDelOyynlRhpbZmptBScjCaXkZypcxBfSNPaXeXuDRgqsoOSGHsBfXLeChbPajkOpbxojmsoExysvKEVkFJveaZUbKxPdiuuGsaqRAItpeXHysISDfFuAOJpcCmzOClwdeLdKneKWpgadsvJbFmYCZTSILoonjEMTBEuHFipbUxlIJlKhCxjpnTdkTvZZPwNK();
					num = ((int)((num2 + 1545644724) ^ 0xAF55EB69u) >> 0 << 0) + 0 + 0;
					continue;
				case 522u:
					num = (int)((((num2 + 1489382166) ^ 0xEB3C504Au) + 0 << 0 << 0) ^ 0);
					continue;
				case 523u:
					num = ((((int)num2 + -1779268726) ^ -399939744) << 0 >> 0) - 0 >> 0;
					continue;
				case 524u:
					flag20 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[39];
					num = (940207400 + 0 + 0 >> 0) - 0;
					continue;
				case 525u:
				{
					int num39;
					int num40;
					if (!flag20)
					{
						num39 = -523160967;
						num40 = num39;
					}
					else
					{
						num39 = -105561891;
						num40 = num39;
					}
					num = (((num39 >> 0 >> 0) ^ ((int)num2 + -1770638289)) << 0) + 0 >> 0 << 0;
					continue;
				}
				case 526u:
					num = (((((int)num2 + -131019218) ^ 0x4E7CF6D1) + 0) ^ 0) + 0 << 0;
					continue;
				case 527u:
					wallwalk.FMfsuonfrDXuRUIIRlFRdNwRKlPgXvLhXJFlqJPNZBpieuETlmuvSKMRqoHizghWSPxiowsivSRByoMpHWULappmXOVbbHnStspoXvEPUmaZSktbBsADmwVDAklAArgOEZifYyrlrfRNpptMuTzJgKGWwMONkeoCgmvTboddaplgFiolQyfGRxHUtlImJDanQoHdUALgQ();
					num = (((((int)num2 + -2035131923) ^ -1546895444) >> 0) - 0 >> 0) ^ 0;
					continue;
				case 528u:
					num = (((int)(((num2 + 245075061) ^ 0x2400BEC2) << 0) >> 0) ^ 0) >> 0;
					continue;
				case 529u:
					num = (int)((num2 + 251141112) ^ 0xABC5508Bu ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 530u:
					flag18 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[40];
					num = 0x734DA443 ^ 0;
					continue;
				case 38u:
				{
					int num37;
					int num38;
					if (!flag18)
					{
						num37 = -696557618;
						num38 = num37;
					}
					else
					{
						num37 = -384334047;
						num38 = num37;
					}
					num = (int)(((uint)(num37 ^ 0 ^ 0) ^ (num2 + 478249446)) + 0) >> 0 >> 0 >> 0;
					continue;
				}
				case 532u:
					num = ((((int)num2 + -1664892304) ^ 0x311B7C46) + 0 << 0 << 0) ^ 0;
					continue;
				case 2u:
					Object.Destroy((Object)(object)dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu, 3f);
					num = (int)((((num2 + 1255471470) ^ 0x34FDA670 ^ 0 ^ 0) + 0) ^ 0);
					continue;
				case 534u:
					num = (int)(((num2 + 1913631270) ^ 0xAC317FEBu) << 0 << 0 << 0 << 0);
					continue;
				case 535u:
					num = (int)(((num2 + 1786972396) ^ 0xD3224CF9u) - 0 - 0 << 0) >> 0;
					continue;
				case 536u:
					flag15 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[41];
					num = ((0x5FDC7D61 ^ 0) >> 0) + 0;
					continue;
				case 537u:
				{
					int num33;
					int num34;
					if (!flag15)
					{
						num33 = -747991518;
						num34 = num33;
					}
					else
					{
						num33 = -264499540;
						num34 = num33;
					}
					num = (((num33 + 0 << 0) ^ ((int)num2 + -1734409724)) << 0 >> 0 << 0) ^ 0;
					continue;
				}
				case 538u:
					num = ((int)(((num2 + 634424473) ^ 0xA14232D ^ 0) << 0) >> 0) - 0;
					continue;
				case 539u:
					frez_gamne_all.xPXwUqEwGYoXsVIaPuvijlaqKTRSeYLHOShLKMIimfRZSuaXYvXMiBwmOGMbyMrHmGizOWqdLmWdtbxqTUTJbZynwUXdaHJzOkNllAjcfUaWEtSNjwhDSHFniVdTZmdeDwpjnlesLREhYCJdckUEzfHgEAdqxpdTRWshdIzXrPSbdyoFlaROryFxPiFNiNVvOKqckBZtKXmJnGcflyewyoCsqVsVdMPEUwmsimvKbyetmVkjfzBJIyXziXLoidpXiHPQtJWYcuvZkifvLjPDlfWwz();
					num = (((((int)num2 + -354480654) ^ 0x73DD8874) - 0) ^ 0) - 0 + 0;
					continue;
				case 540u:
					num = ((int)(((num2 + 687815017) ^ 0xEAE4DF9Eu ^ 0) - 0) >> 0) ^ 0;
					continue;
				case 541u:
					num = (((((int)num2 + -1036133054) ^ 0x2409D105) >> 0) ^ 0 ^ 0) << 0;
					continue;
				case 542u:
					flag14 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[42];
					num = 554641168 >> 0 << 0 << 0 >> 0;
					continue;
				case 543u:
				{
					int num31;
					int num32;
					if (flag14)
					{
						num31 = 543789384;
						num32 = num31;
					}
					else
					{
						num31 = 1346084434;
						num32 = num31;
					}
					num = (int)(((((uint)(num31 << 0 << 0) ^ (num2 + 276320470)) + 0 << 0) ^ 0) << 0);
					continue;
				}
				case 544u:
					num = (int)(((num2 + 2052202756) ^ 0xF6CFFFE5u ^ 0) + 0 << 0 << 0);
					continue;
				case 39u:
					Beacons.vIRyzroyDXMYILJEAzPFRtxoYprAlqpMZQwOQvUUtNgGopiDYytaVBYblCAjaNnmIZYSpUOeFVldnRaJhNCMXo();
					num = ((((((int)num2 + -1344851594) ^ 0x5DD181B4) - 0) ^ 0) + 0) ^ 0;
					continue;
				case 546u:
					num = ((((int)num2 + -1060945142) ^ 0x35731A58 ^ 0) >> 0) - 0 >> 0;
					continue;
				case 558u:
					num = ((((int)num2 + -1559966452) ^ -472749987) >> 0 >> 0) - 0 << 0;
					continue;
				case 548u:
					flag13 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[43];
					num = (0x408EE860 ^ 0) + 0 << 0;
					continue;
				case 549u:
				{
					int num29;
					int num30;
					if (!flag13)
					{
						num29 = 241728147;
						num30 = num29;
					}
					else
					{
						num29 = 958323183;
						num30 = num29;
					}
					num = (int)(((((uint)(num29 >> 0 << 0) ^ (num2 + 423795958)) - 0) ^ 0) + 0 + 0);
					continue;
				}
				case 550u:
					num = ((((int)num2 + -1774317197) ^ -1127953245) - 0 << 0 << 0) ^ 0;
					continue;
				case 551u:
					give_shiny_rocks.jkLXzLDeMgzXHGfVaFZJHodQKbVQDptpfKPyBpOhefzptCFKiNRECuMVhUnyQNAwMjSWQHuKRRFCPOxhwlIQxON();
					num = (((((int)num2 + -678197903) ^ 0x37A128A) >> 0 >> 0) ^ 0) + 0;
					continue;
				case 552u:
					num = (((int)num2 + -1364825593) ^ -1305295845) + 0 + 0 << 0 >> 0;
					continue;
				case 553u:
					num = ((((int)num2 + -1974840164) ^ 0x50F04AE3) >> 0) - 0 + 0 - 0;
					continue;
				case 554u:
					flag12 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[44];
					num = (0x6CBC707 ^ 0) - 0 << 0;
					continue;
				case 555u:
				{
					int num27;
					int num28;
					if (!flag12)
					{
						num27 = 876650570;
						num28 = num27;
					}
					else
					{
						num27 = 737549946;
						num28 = num27;
					}
					num = ((int)(((uint)((num27 >> 0) - 0) ^ (num2 + 1526948771)) + 0 << 0) >> 0) - 0;
					continue;
				}
				case 556u:
					num = (((((int)num2 + -1839132363) ^ -1779196073) + 0 << 0) + 0) ^ 0;
					continue;
				case 557u:
					bees.zyDCRfjBlypbLCpbxIafcUyyiLamAwEljbniADHESbjPTshXyGxRKALEZfugeWaPTeRJohBUbwmaLIEPEcOUYNBIqJiuiBzWbtVPAyJqfDQooLTqBEBbigRgCjtFZgLzWqZrNOpgtxPuWmuEPRTEZyNUCOmredrYSrsXMCDMpvHLrwkqOOPhnhzxDeOYCXbpfQCFUwSnngoDQbDgEWCqnjLKRUuHNFkrurFBTEvsVCTgSWHBAItFuLcVeSOabkAIWWjyvcnaAkuLqFRVmThfmEXJpKwbQvqLcljWMjfyutekqqFzaSNiduwrZAiLGmjfUIJevVic();
					num = ((int)((num2 + 1329204599) ^ 0xA4321E3Eu) >> 0) - 0 + 0 << 0;
					continue;
				case 40u:
					num = (int)(((num2 + 1965557946) ^ 0xA8CE0FA9u ^ 0 ^ 0) - 0 << 0);
					continue;
				case 559u:
					num = (((int)num2 + -1688123847) ^ -514138447) - 0 << 0 >> 0 << 0;
					continue;
				case 572u:
					Object.Destroy((Object)(object)sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX, 3f);
					num = ((((int)num2 + -268976326) ^ -1434204731) + 0 << 0) - 0 << 0;
					continue;
				case 561u:
				{
					int num25;
					int num26;
					if (flag11)
					{
						num25 = 193330192;
						num26 = num25;
					}
					else
					{
						num25 = 2004592470;
						num26 = num25;
					}
					num = ((num25 << 0 << 0) ^ ((int)num2 + -491436561)) << 0 >> 0 >> 0 << 0;
					continue;
				}
				case 562u:
					num = ((((int)num2 + -964259700) ^ 0x272500F2) << 0) - 0 << 0 << 0;
					continue;
				case 563u:
					bees.nkekpyNlbOCCaZSepkbCRaXsgzDIZTTXpASLbMhOcwMdzoUDIiEIpoQmnLePVeliVFnAghcDdmAunTTRFZaRokIbJGxqHrSXkEhTbuxBfbEcNwYuSmkWeuTLXlQAJMVMtCkJLZQkByMnFFn();
					num = ((((int)num2 + -1144785573) ^ -1684925867 ^ 0) + 0 - 0) ^ 0;
					continue;
				case 564u:
					num = ((int)((num2 + 2064590614) ^ 0xC81DA3F8u) >> 0) - 0 - 0 << 0;
					continue;
				case 565u:
					num = ((((((int)num2 + -144079672) ^ 0x1FB8BF54) >> 0) - 0) ^ 0) >> 0;
					continue;
				case 566u:
					flag10 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[46];
					num = (0x630C957 ^ 0) << 0;
					continue;
				case 567u:
				{
					int num23;
					int num24;
					if (!flag10)
					{
						num23 = 1195384343;
						num24 = num23;
					}
					else
					{
						num23 = 1221459661;
						num24 = num23;
					}
					num = (int)((((uint)(num23 - 0 + 0) ^ (num2 + 740382615)) + 0 - 0) ^ 0) >> 0;
					continue;
				}
				case 568u:
					num = (((((int)num2 + -567395523) ^ 0x53C37105) >> 0) + 0 - 0) ^ 0;
					continue;
				case 569u:
					bees.OIKSAMsZeXaXHiHHPRWmbtSijYqHGBdeKKuuJDRmhiGIlmyMbcoEYWbuQCJBwKsDUVnWNmXmaKeSNjWXADGEnyfNIaEhTqPxQdOpYBYOebEoRjHGGMaSdOqvPznNIQtJUHcJvGYZFSzlURVztXBhqXtcNtzznkfoIUtkhXlZNanloeAYDOuKoltXnaWchzLuMlDaxLsvMCupJiNISBVzQvZwAwXgaiSnpSycBAASvYXMRenfmojFEmErlgzbOlvDJgZRJLgsaddRxnFwiRULZmJdnhRvazekDucLewwBiREAiMTYAdSWrJExwWDBTKrBZTodkUrMusDhHjUBoSUXGhTTPFohTVHxzdBoyPNGLgBYfxPnbcmaQuVRauoFFjTzLgHEHGcyfnlzFUNrPbfQIGHfiKoeBibBncmZPlGvZNVCivmfGWPDecQeyBvXrYXWmKmDHOC();
					num = ((((int)num2 + -1904894752) ^ -1611681181) << 0 >> 0 >> 0) ^ 0;
					continue;
				case 570u:
					num = (int)((((((num2 + 935696331) ^ 0x25D70D2B) << 0) + 0) ^ 0) + 0);
					continue;
				case 571u:
					num = (((int)num2 + -1563010493) ^ -878075676) >> 0 << 0 << 0 << 0;
					continue;
				case 41u:
					flag9 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[47];
					num = (0x65B861B0 ^ 0) - 0;
					continue;
				case 573u:
				{
					int num21;
					int num22;
					if (!flag9)
					{
						num21 = 850588048;
						num22 = num21;
					}
					else
					{
						num21 = 2133973027;
						num22 = num21;
					}
					num = ((((num21 ^ 0 ^ 0 ^ ((int)num2 + -441094373)) + 0) ^ 0) << 0) ^ 0;
					continue;
				}
				case 586u:
					num = (int)((((num2 + 395647085) ^ 0x60F14F23) << 0) ^ 0 ^ 0) >> 0;
					continue;
				case 575u:
					rigdupe.KKphcfbWTVaFTJDOaYFvoEFMHUzwPzIhrLRxiwSlJbyUiyZOhOnHaNcgeCAiGEhtmToiSgGDfuLnfLDiVKpalbhDIKsFWJFfUeHpkQWahKBGbPbtYrnVpgilLKzhOaHvPGtaeoYeNpSBzABTJZHEwJPNWvEzrOmgdfQvvaoKsiiaoGMkjFyOtcZfQGeJKzMYcLyuKfxIKXlnAPzpJtqLqxNagKFPVFaTwkXCirAdhPevQLFagOZqjbIFXynZAIMfXsRqSWgrSnDAtrjvfEIhFJKuBsEKeBCzcZyyToikHIyVxhmFoSTWZFznIwOzrwnqKextTLBQwyzWkOXtgYvlIGzxzkPwAISlviksKSMDqczBg();
					num = (int)((((num2 + 71172578) ^ 0x7E17D348 ^ 0) << 0) ^ 0 ^ 0);
					continue;
				case 576u:
					num = (int)((((((num2 + 1758126183) ^ 0x8B78A892u) - 0) ^ 0) << 0) + 0);
					continue;
				case 577u:
					num = (int)(((((num2 + 1059961103) ^ 0x33304D1E) + 0 << 0) ^ 0) - 0);
					continue;
				case 578u:
					flag8 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[48];
					num = 0x51E2354 ^ 0;
					continue;
				case 579u:
				{
					int num19;
					int num20;
					if (!flag8)
					{
						num19 = 555652583;
						num20 = num19;
					}
					else
					{
						num19 = 1078057173;
						num20 = num19;
					}
					num = (((int)((uint)(num19 - 0 - 0) ^ (num2 + 26448012)) >> 0) ^ 0) >> 0 >> 0;
					continue;
				}
				case 580u:
					num = (int)(((((num2 + 1144086434) ^ 0x95D7154Au ^ 0) + 0) ^ 0) + 0);
					continue;
				case 581u:
					slow_all.iaixEmLwwZHSydeZNCYWGOIeSIUhvtOqmNsaYQCqDbFVhxrwIiOJVosurdEWrDbdkqFLLeaWaIsEiMXvryzmEfvYuXIUlGYZZCLQSFKEhSInWNmFgjETePyeVGqNwgLuJsFFbhCLNUeMwicGLdObbfUkdGUlpXibgoDDiGDZGTfkKMIMEJbsrJtDyuBvmrwQMdFiEzxfzPvhaKzrXiGFVPKxUaeOeiNpxpxHhAiflWTComDNVkxeKQUXtinEuJarcgJKmSkxZAtZVhjIwrSTLJEG();
					num = ((((int)num2 + -1888588799) ^ -2129429869) << 0 << 0 << 0) + 0;
					continue;
				case 582u:
					num = ((int)((num2 + 2083971120) ^ 0xEED9F648u) >> 0 >> 0) + 0 << 0;
					continue;
				case 583u:
					num = (((((int)num2 + -1494472508) ^ -875678146) >> 0 << 0) ^ 0) - 0;
					continue;
				case 584u:
					flag7 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[49];
					num = (1051028085 + 0 - 0 << 0) + 0;
					continue;
				case 585u:
				{
					int num17;
					int num18;
					if (flag7)
					{
						num17 = 918216292;
						num18 = num17;
					}
					else
					{
						num17 = 381338105;
						num18 = num17;
					}
					num = ((int)((uint)(num17 + 0 + 0) ^ (num2 + 80961871)) >> 0) - 0 - 0 + 0;
					continue;
				}
				case 42u:
					num = ((((int)num2 + -1919402760) ^ 0x1C2EB368) >> 0 << 0 << 0) ^ 0;
					continue;
				case 587u:
					slowgun.mkbtULiJWtDLtxOYQcWiwmtTHsTvHYehjSWPAaEjLVnqPoFACZTSkwjaRiLBRNcYowBAAZyQyNxBYddsNsTHemWMIWYrocrXSobsMeZDBctxZIbOesNyUuTcAOREagBvvzIKbKFJsqgcSzNaVkmWoSdyvYSYmvCuBXbzZqMuMefEoRkabRIQTEgCwkpdSHwWNLAUxnaFxSkkNzkDOSWvNLBWRzdPbJBeIiQDqpCOQctbuWPXaLoZLbickEdYklDOqfBEIGmyqiELsABUKfPpuCsGZNsMmDD();
					num = ((((int)num2 + -1292665167) ^ -1107309140) << 0 << 0) - 0 + 0;
					continue;
				case 599u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu = null;
					num = (int)((((num2 + 167492551) ^ 0x5EE9D04D ^ 0) + 0 << 0) ^ 0);
					continue;
				case 589u:
					num = ((((int)num2 + -407865040) ^ 0x18E9B3BB) + 0 - 0 << 0) ^ 0;
					continue;
				case 590u:
					flag5 = rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt[50];
					num = (0x77C3BB78 ^ 0) << 0;
					continue;
				case 591u:
				{
					int num13;
					int num14;
					if (!flag5)
					{
						num13 = 1489122706;
						num14 = num13;
					}
					else
					{
						num13 = 1649440842;
						num14 = num13;
					}
					num = (((num13 - 0 - 0) ^ ((int)num2 + -81175827)) << 0 << 0) ^ 0 ^ 0;
					continue;
				}
				case 592u:
					num = (int)(((num2 + 923792119) ^ 0x47DF30F7) + 0 - 0 - 0 - 0);
					continue;
				case 593u:
					network_player.PfXTMsQKxfECZLoimNFZfUejIlPJAWECHavqQTdvPqHXfduAiXxxFGAUbOlACgjAAbVYpXrtJkkOngdFQpADyhWbAApcICSIggwehwlkFeNuvLHVKFKmGGbtfTxOIpKhrCIgJZxuepXuuBFPTurcSGczedYnZwCptGdTdBlLiphqJHZDoHVoXIoLAibGajvHNHaNyMMriGUCyLQxdvZrBorLrrtVAFLYUADbGleBVDfrNLnOrECEjdgyqovgtRRDVVIYiPQSqywYiZXGeEDVcgPQte();
					num = ((((int)num2 + -1221001185) ^ -1810860181) >> 0) - 0 >> 0 >> 0;
					continue;
				case 594u:
					num = (int)(((((num2 + 699908627) ^ 0x73B5C1E8) + 0) ^ 0) + 0) >> 0;
					continue;
				case 595u:
					num = ((((int)num2 + -1463855703) ^ -850830056) + 0 >> 0 >> 0) - 0;
					continue;
				case 596u:
					flag4 = sPbkSsnJhTPpqWqAzXuoLSgHPhOJqlggKrjEUKXGGwNvQKixwhWmjKqAItuLEDsWMIEYNMFPaNIoeLRfYrnjpUWZaIVBqlccdRIhfjKJBhlwccvXBoMnqjGSMEXeReyOLFkncKZPGDIiIAXYmXZbzOMUkPvAlFSwIxKxRhVQoWGMBykmHYRTexpWSqdmpzDaLlAlPAheciNCiatMFjTmOYrlhNEBeIBPtFapYZwhRMRVKMOSWrHgFrmNTpdbWGatHXjCZdOFMMvbgvAuZLENbvjbtnvJWuklMxoMDlTSDbtTWlGyOIckcnslNhjMIeJsBkoIgOROSLkacqfhGXVosaizfdYvbhkyrbsMWXrZQosrcrjxccfLjvZBbPDdQvMLAMIaXtkJFVxeHRwOTAtZbzoWbQKhunjvCHQqIiAIRwfoXVTjsPkpbMJbxMZhIcosLcCabffKaLiFtZYfWAOFcUtPYOTWjsZOhNCV == ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("켙켘켅켚켖켛", 1191366519, true);
					num = (1570726222 - 0 << 0) + 0 >> 0;
					continue;
				case 597u:
				{
					int num11;
					int num12;
					if (!flag4)
					{
						num11 = 802804105;
						num12 = num11;
					}
					else
					{
						num11 = 879377952;
						num12 = num11;
					}
					num = ((((num11 ^ 0) << 0) ^ ((int)num2 + -273786404)) - 0 + 0 + 0) ^ 0;
					continue;
				}
				case 598u:
					num = (((((int)num2 + -208028663) ^ 0x515FD1AD) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 43u:
					MjdnoRxnpPZBDYxKonsFcwQsHaCfiPqQAxkXbeCLKJyomypFpjcuzknptLFnoseAziagOAJjLGUsYCgjKXPYMVqqjUEpzoxsEXPdxjRPzTJTpUrQEwCqCfNESKWTVuKwjCOaNdLBgaySlxaoDNKdMgPykklMnXTfjnJMgqdBKbkCHUsuKHqiJGKdNqQCRYnjgtJYNoimJisLVnRpRQcFGLwCDFZPABKMNavnluGvzeyAoYhzzBKbVICvWgvhptLiyGYVSDexjHgCmVoEyzpZQJQeyZreZzgfsqbHamHWxmRoCajaSQJPdMrPPTwSlZyKAajWUGElRtCERCCxQqmi = Color.green;
					num = ((((int)num2 + -1300034006) ^ -1600415092) >> 0 << 0 << 0) ^ 0;
					continue;
				case 600u:
					PqcGZmSgPPKxOgNBQnglmyYKkNXnrYcVNqVjYDWHOxvcIePLOaHCjaVrsswloFOQMPKylEDmqyxPcWbfXmyrrzLMuDRGhLtjIFpTurAkxumLDgpwqqocgxzmeXdHMXeFfngxGhKGMnUWnainovpQwqckfdPxnSxzqHFpaSP = new Color(0f, 0f, 0f);
					num = (((int)num2 + -2002565063) ^ -2130561962) - 0 + 0 << 0 >> 0;
					continue;
				case 613u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX = null;
					num = ((((int)num2 + -360598403) ^ 0x4FCF634E ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 602u:
				{
					int num9;
					int num10;
					if (flag3)
					{
						num9 = 862731651;
						num10 = num9;
					}
					else
					{
						num9 = 1105673540;
						num10 = num9;
					}
					num = ((((num9 >> 0) + 0) ^ ((int)num2 + -404752528) ^ 0) + 0 << 0) ^ 0;
					continue;
				}
				case 603u:
					num = (((int)num2 + -2062381257) ^ -913666686) - 0 >> 0 << 0 >> 0;
					continue;
				case 604u:
					mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb.color = Color.Lerp(jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak, DksrKhdtfTLOMOmnRaZcspducViMdYQzoSCoZRvlDKdFAfvqsnNMQXSohYpPYqqhclzTmXnZFNzHlyTWzStPkeJraohbCGnmuWCpFBevZOhdykcIespfXAXXCiTXQmwYAnnpVEqYOYQvXGTQlyWkrhpUZEMxIgFMsjClWNMAbrrZJBZWpdLrplGsXsqqRTpHsddOdITyMwiaQqkxFQiEvoxgCknEwvIibJGGylSGjmETdGCHhSLaKKmeGWmTvpbqNaZgJDZtXBviJDdWHFwEJHxqwBaBZZlUlofcGvXETsdjpevcSplPSxGgCIKiDxuYpAXuxapmISKrEoasgXJJOwbNIZzXLPawXfTPgaFRZZhaNoBoIrcFOLjTyjMyBrBTRouzullfsRJPpbatylptMvImVaqWohqIyojyTcUwgWmWbuDxjsZqchgwGiEtUo, qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp / RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo);
					num = (((int)num2 + -48121816) ^ 0x71A6FA66 ^ 0) - 0 + 0 - 0;
					continue;
				case 605u:
					num = (((((int)num2 + -11267305) ^ 0x36115851 ^ 0) >> 0) + 0) ^ 0;
					continue;
				case 606u:
					qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp += Time.deltaTime;
					num = (((int)num2 + -695917590) ^ -1793213001 ^ 0 ^ 0) + 0 >> 0;
					continue;
				case 607u:
					num = ((int)(((num2 + 714081872) ^ 0xFA547151u) - 0) >> 0) + 0 << 0;
					continue;
				case 608u:
					num = ((((((int)num2 + -88781519) ^ 0x3D22F56E) << 0) + 0) ^ 0) - 0;
					continue;
				case 609u:
					if (qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp >= RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo)
					{
						num = 1189239360 + 0 + 0 >> 0 >> 0;
						continue;
					}
					num8 = 0;
					goto IL_a4c6;
				case 610u:
					num8 = ((mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb.color != jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak) ? 1 : 0);
					goto IL_a4c6;
				case 611u:
				{
					int num6;
					int num7;
					if (flag2)
					{
						num6 = -139390642;
						num7 = num6;
					}
					else
					{
						num6 = -2064406190;
						num7 = num6;
					}
					num = (((((num6 ^ 0) << 0) ^ ((int)num2 + -1602763469)) >> 0) - 0 << 0) + 0;
					continue;
				}
				case 612u:
					num = ((((((int)num2 + -854723255) ^ 0x2216F2D9) << 0) - 0) ^ 0) + 0;
					continue;
				case 44u:
					mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb.color = Color.Lerp(DksrKhdtfTLOMOmnRaZcspducViMdYQzoSCoZRvlDKdFAfvqsnNMQXSohYpPYqqhclzTmXnZFNzHlyTWzStPkeJraohbCGnmuWCpFBevZOhdykcIespfXAXXCiTXQmwYAnnpVEqYOYQvXGTQlyWkrhpUZEMxIgFMsjClWNMAbrrZJBZWpdLrplGsXsqqRTpHsddOdITyMwiaQqkxFQiEvoxgCknEwvIibJGGylSGjmETdGCHhSLaKKmeGWmTvpbqNaZgJDZtXBviJDdWHFwEJHxqwBaBZZlUlofcGvXETsdjpevcSplPSxGgCIKiDxuYpAXuxapmISKrEoasgXJJOwbNIZzXLPawXfTPgaFRZZhaNoBoIrcFOLjTyjMyBrBTRouzullfsRJPpbatylptMvImVaqWohqIyojyTcUwgWmWbuDxjsZqchgwGiEtUo, jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak, (qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp - RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo) / RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo);
					num = ((((int)((num2 + 603411014) ^ 0x70089577) >> 0) ^ 0) << 0) - 0;
					continue;
				case 614u:
					num = ((((int)num2 + -1515344132) ^ -735940250 ^ 0) + 0 + 0) ^ 0;
					continue;
				case 46u:
					num = (int)((num2 + 1946470355) ^ 0x8370F2B4u ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 616u:
					num = (((((int)num2 + -564640954) ^ 0x8D08B62) << 0) - 0 + 0) ^ 0;
					continue;
				case 617u:
					num = (((int)((num2 + 1519569450) ^ 0x231E409C) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 618u:
					if (qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp >= RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo)
					{
						num = 1805430619 - 0 << 0 >> 0 << 0;
						continue;
					}
					num5 = 0;
					goto IL_a60c;
				case 619u:
					num5 = ((mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb.color == jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak) ? 1 : 0);
					goto IL_a60c;
				case 620u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 219608935;
						num4 = num3;
					}
					else
					{
						num3 = 635710281;
						num4 = num3;
					}
					num = ((int)(((uint)(num3 >> 0 >> 0) ^ (num2 + 1450373794) ^ 0) - 0) >> 0) ^ 0;
					continue;
				}
				case 621u:
					num = (((int)num2 + -1558034427) ^ 0x78752AF1) - 0 >> 0 << 0 >> 0;
					continue;
				case 622u:
					qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp = 0f;
					num = (int)((((num2 + 1737861150) ^ 0xF190DD3Eu) << 0) - 0 - 0 << 0);
					continue;
				case 623u:
					num = ((((int)num2 + -757699846) ^ 0x5E5E66CA) >> 0) + 0 >> 0 >> 0;
					continue;
				case 624u:
					num = (0x62946AA3 ^ 0) - 0 + 0;
					continue;
				case 47u:
					num = 255853173 - 0 - 0 - 0 - 0;
					continue;
				case 45u:
					return;
					IL_a60c:
					flag = (byte)num5 != 0;
					num = (0x1DD56070 ^ 0) - 0 + 0;
					continue;
					IL_a4c6:
					flag2 = (byte)num8 != 0;
					num = 0x158CBAA9 ^ 0;
					continue;
					IL_7fb6:
					flag46 = (byte)num104 != 0;
					num = (0x394A8B2C ^ 0) << 0 << 0;
					continue;
					IL_5088:
					flag52 = (byte)num111 != 0;
					num = 0x5CF4410F ^ 0;
					continue;
					IL_4f05:
					flag58 = (byte)num124 != 0;
					num = (1243643175 >> 0 << 0) + 0 << 0;
					continue;
					IL_4c43:
					flag63 = (byte)num55 != 0;
					num = 461627554 + 0 << 0 << 0 << 0;
					continue;
				}
				break;
			}
		}
	}

	public Menu()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 + -0 - 0 + 0 + 0 + (0 >> 1)) ^ 0) << 0)) % 3)
				{
				case 2u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 0u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB3) - 0 << 0) + 0 - 0;
			}
		}
	}

	static Menu()
	{
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Expected O, but got Unknown
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301853;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 - (0 >> 1) + 0 + 0) ^ 0) >> (0 >> 1) << 0 >> 0)) % 17)
				{
				case 2u:
					break;
				default:
					return;
				case 4u:
					dCQWugCxhzecFuwehTpYXpCOsNXlavniFQgeSwVztXsxcXwlpHAAwBgNacEGirwLlWwPnrmKYPEaXeLurLVtVNLdJsePRoqcAGlgAHXYuPBHXgQVqkpwvdQyktfUmxTJzCzqSETJOXZflegDCiyHZTHwQNVhCcLXWSiuGAdLqGIxdKmgnBseYlKFUczeILhLlcjtWLXceNqtkjtfBPUaKHZKhCzDaZdEyXlbBSkCDpZlVruLJuDTRgaEdzmtlucfJLUnXrDIEsxuHOOPiOTFwjNsWGYcGRqjnUBjxhNrQUozIGXpKwlwAwJAYBqrtBbNbogNmEsbbBOBUnKqJIsjFUIRkalWQwYpSAxu = null;
					num = (((((int)num2 + -733318432) ^ -994542) - 0 << 0) ^ 0) >> 0;
					continue;
				case 15u:
					RlAbrbSBzwqSnQiLlAwTNVhaGqhMSLxACRfbwZdCEISDZjUpoVXeWbBVeAvaTfJNYQqvKgolwUoecDawwSyXOtDAqjWWEdIyZeFjTyEhGLHcMwTBzYEbHLZEmPfBjsHtlQfXXRDXnrqdMBOUqvxFyHRnfaWdtdXo = 3f;
					num = (((int)num2 + -1827602905) ^ -997299123) + 0 << 0 >> 0 >> 0;
					continue;
				case 5u:
					zjcfekvYHiFKRZHKjSihGpCmtvkFDzItQpRAGmfvyJjcuBfROnfasqOjGPMIZQvizlUBiheWMMIWfARRqtQqtHbzBHTQAxwIobCiHEIHjjoGHRefYUrGZeOSkuZAnnvpqZIeYIkMKjhktuRKDNSGfPJjnJXmEitVNZqHiahpJFVQWDzQCpXAuPjAqzQoLXhCPlxtekBDFDWzTSmJkhJpkSAXPPqJjSELxtaKffMsNuURSKGymheDoSrWKzEoTSuMZkcARBEevrBQYJffiSxbOaxEcdZFBxzVZhSHHgGKDZiWrAYbuyfausYYMxxOBYDXRGRQRxxcmNyPSBnCfYkcrzAHjTUkJSiEvkeKJhkXbdNHTifljVIDNBGsfjHXCmsuFTtIwCTXOnanLSNaOJbNjERUDLFzzmvOKscZOxPGbKPAAsHmwGjTlFlacyeKXuyBRlCsQNlqTuLyPruke = null;
					num = ((((int)num2 + -678915685) ^ -239294844) << 0 << 0) - 0 >> 0;
					continue;
				case 6u:
					sdTdCDfhcXpsfJHmnIoPowIuSZQTMkKeTFFqEyoIxlNQWYOLdlCIfuQVuykDMmuRmlyzdrHPtGsdIRyUkfPAIcYyPKWgnLVkQWDKzpHMDNozcNmCZqsHxTjkmZJtuBBILimMoOvVxcXUNzwcxtgXtnNXMsyzForclGOUAzolUxkuWoxNCHWbvDoxupaVpVpiKUIhLCBX = null;
					num = ((((int)num2 + -1186296972) ^ -679555467 ^ 0 ^ 0) << 0) + 0;
					continue;
				case 7u:
					eUcWdsaxVLWYsqGIrrzlzsVZhbKbFqbafYXABstcoCZEYrQunaPudpyLYdOcIYRFJWSusggYXxWWtqaQkpNFAHWPzlByErtqKtVcywbhUQwGtBsHdYRskmfbZcUhEIuGdGmZvXrOoGLJkqwYSTvGzbfxoTcwBUClwQCMpt = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("硛", 958560362, true);
					num = (((int)num2 + -1701687338) ^ -410177556 ^ 0) - 0 - 0 >> 0;
					continue;
				case 8u:
					mfGddEBvRJFWoLnNgbAOKBVVmudzntNJJzHpawXBWScsQFFRYIKBmAILjKQJAcixWWnPdXNJdYSRyCfGPmBEJmxiQVfpFobUKFwUsPNaUbxnIQmHFkUoADOJyfZiRxdPXXgTfloZyBJHPjzZJyKvtNthRMvnPFiwYHqKJtBtVUPZTgUoFZytNHvjEZb = new Material(Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蘭蘎蘌蘗蘊蘛蘍虑蘺蘛蘘蘟蘋蘒蘊", 563775102, true)));
					num = ((((((int)num2 + -1219895373) ^ 0x45F37EA6) << 0) - 0) ^ 0) >> 0;
					continue;
				case 9u:
					sPbkSsnJhTPpqWqAzXuoLSgHPhOJqlggKrjEUKXGGwNvQKixwhWmjKqAItuLEDsWMIEYNMFPaNIoeLRfYrnjpUWZaIVBqlccdRIhfjKJBhlwccvXBoMnqjGSMEXeReyOLFkncKZPGDIiIAXYmXZbzOMUkPvAlFSwIxKxRhVQoWGMBykmHYRTexpWSqdmpzDaLlAlPAheciNCiatMFjTmOYrlhNEBeIBPtFapYZwhRMRVKMOSWrHgFrmNTpdbWGatHXjCZdOFMMvbgvAuZLENbvjbtnvJWuklMxoMDlTSDbtTWlGyOIckcnslNhjMIeJsBkoIgOROSLkacqfhGXVosaizfdYvbhkyrbsMWXrZQosrcrjxccfLjvZBbPDdQvMLAMIaXtkJFVxeHRwOTAtZbzoWbQKhunjvCHQqIiAIRwfoXVTjsPkpbMJbxMZhIcosLcCabffKaLiFtZYfWAOFcUtPYOTWjsZOhNCV = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("秆秇秚秅秉秄", 1608219048, true);
					num = (int)(((num2 + 900749756) ^ 0x3968E2D7 ^ 0) + 0 + 0 - 0);
					continue;
				case 10u:
					uoQjXUGVHTlLURDayUykMMvyRNRLWrycoKvXYgdlPmUdKvYygQffOYdITrrjdVYpviwjwGbsQnuzS = 0f;
					num = ((int)((num2 + 1709781230) ^ 0xDDCA7C3Cu) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 11u:
					rOwOsEgmsnqGMeHOThUoEICZObAONoBDEPBDUvKqSccUfDJCuDXfAloJlxZrerzdMMcXCdUyxEvCFHTlrYtkrvdsARrwvtlADZisALZrIzIVPMeEENZgXpM = 0.25f;
					num = (((((int)num2 + -1650322207) ^ 0x5EE508F5) >> 0) + 0 << 0) - 0;
					continue;
				case 12u:
					qJJxKLxcdsVYFzALGYcBRMhDONNSHtfCnnRJQooFkxEDUNyfdctiVNUEBfIXYFuKnsKsHQUrJxruhEJboIOFaXHAsniKGrGEcUqBcgxnicyxwzwWwGJqRPKpLkZuIjKsRMsnoiZikBwXykdSQloZIqNmkaPRgcEYrgGKhiIoHAfqsMRBghDxULKBYfdoshciWxGsDtLICZrhkxUyjoLZzgeGveLbfuWAyXtUfyXMvVVUtDqBlEeevdJQtaXzHJCidRIneZsKqYDDljmSOkPApRevoCAeByfLsNQCUcwmmtNxzfEkNeKwTbSlMnZBynjSTRkysKYLNDoVeHViYqrwOIRrUEPGdVNYjUDIUgSdgYIqNWhesQDiWNelaTDNUrISPp = 0f;
					num = ((((int)num2 + -871797673) ^ 0x7745FB2A) >> 0 << 0) - 0 - 0;
					continue;
				case 0u:
					jGHpTDDZeOPsrIniOlVrDsnsTQuGGuSnwFfkObjHCdLIxAfRcyQeeAmQspwcjWtJWCVMCdtNcoPzHFUtKCEhEOiWtpSzEgxFKcMVEtpYfcbQLMiNucsGsmehtZsmlTiVQjPFTZOqnFbBMskGgefCOQnyXECFacNlTfZBXDTvnbsNkCvaOMggOGhaWqIoxjplRQIGtJIDlJoMyzoujBQoWHwmYZFHVEXdLhVtUOHfdCVfsvBwcnfVtbpktvIuebIGLkbqEUzvULktMrUDxiEHzcKJSLazgnbcUotitlShNKbIRVycBfXVwagJzryTUapHKiyxYLjlqwTOacSWmXXapfFUhJIcMYnNvuXIxadPVLEahsJxyCGWdorEDEppdgzrjgtGejymUhfEAENPak = Color.magenta;
					num = ((((int)num2 + -1439813256) ^ 0x366B46E8) + 0 + 0 + 0) ^ 0;
					continue;
				case 14u:
					DksrKhdtfTLOMOmnRaZcspducViMdYQzoSCoZRvlDKdFAfvqsnNMQXSohYpPYqqhclzTmXnZFNzHlyTWzStPkeJraohbCGnmuWCpFBevZOhdykcIespfXAXXCiTXQmwYAnnpVEqYOYQvXGTQlyWkrhpUZEMxIgFMsjClWNMAbrrZJBZWpdLrplGsXsqqRTpHsddOdITyMwiaQqkxFQiEvoxgCknEwvIibJGGylSGjmETdGCHhSLaKKmeGWmTvpbqNaZgJDZtXBviJDdWHFwEJHxqwBaBZZlUlofcGvXETsdjpevcSplPSxGgCIKiDxuYpAXuxapmISKrEoasgXJJOwbNIZzXLPawXfTPgaFRZZhaNoBoIrcFOLjTyjMyBrBTRouzullfsRJPpbatylptMvImVaqWohqIyojyTcUwgWmWbuDxjsZqchgwGiEtUo = new Color(0.2f, 0.2f, 0.2f);
					num = (((((int)num2 + -2033110311) ^ -1416073038) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 13u:
					fJiREDexWpbbkImtmkwrkWlwsVImKHAfPHxZbyUSfRSvHzduiCjGLSRixMyJURMoPWlClnrNqDlseQOTRnehxUuXQoCpalXoeDGLnAjVlvphGyeHXERHMEQVCoMWLcNfFXoBjdFrejWbEmqsjU = new bool[60];
					num = (int)((num2 + 1259723679) ^ 0x862465D9u) >> 0 << 0 << 0 << 0;
					continue;
				case 16u:
					eoRWqVDHvHOqvWSLblkOVbUDYSRWUzDjtcYyJSDvSPjRTBRjilciTjtdtnXydGMVdEWtXubjHPWfRdKxaIOJxuqkJVewUfslcoNoEylNjTBemnlqDzxvRdxJoLJcpEoCxKdDpvSBwazETlXvKOTvIXtYQeaSOjxFEZHCkHahGVYRESPcOosBLTUzreNlvaNnCUaUEvlcNLOMYCuXoXeAQWTLfhlfTPMGiLoKSVyscpOaehBOJPWxVmwGaoPxkgiYYhEmoJeszLyBiTGXFwvdSoLVpHJEgaiVgPbXCozZLDYkOUygHRSNKefJwIXGazmyCCusSJuqXv = 0.037f;
					num = (((int)num2 + -509051253) ^ 0x272C0F0C) - 0 + 0 << 0 << 0;
					continue;
				case 3u:
					rvtqBAMLjZNmkjIkCJkDxUZzCDIPqpYtNQKrLovNOyUGDRZMtt = new bool[60];
					num = (((int)num2 + -434485547) ^ 0x62B41E) + 0 >> 0 >> 0 << 0;
					continue;
				case 1u:
					return;
				}
				break;
			}
		}
	}
}
