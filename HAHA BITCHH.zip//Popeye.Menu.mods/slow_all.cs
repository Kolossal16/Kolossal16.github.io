using System.Collections.Generic;
using Il2CppSystem;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.mods;

internal class slow_all
{
	public static void iaixEmLwwZHSydeZNCYWGOIeSIUhvtOqmNsaYQCqDbFVhxrwIiOJVosurdEWrDbdkqFLLeaWaIsEiMXvryzmEfvYuXIUlGYZZCLQSFKEhSInWNmFgjETePyeVGqNwgLuJsFFbhCLNUeMwicGLdObbfUkdGUlpXibgoDDiGDZGTfkKMIMEJbsrJtDyuBvmrwQMdFiEzxfzPvhaKzrXiGFVPKxUaeOeiNpxpxHhAiflWTComDNVkxeKQUXtinEuJarcgJKmSkxZAtZVhjIwrSTLJEG()
	{
		Player current = default(Player);
		PhotonView val = default(PhotonView);
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) + (0 >> 1) + 0) ^ 0) - 0 << (0 << 1)) - 0 >> 0)) % 4)
				{
				case 0u:
					break;
				case 1u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((int)num2 + -1874950498) ^ -859104563) + 0 - 0) ^ 0 ^ 0;
					continue;
				case 2u:
					num = (int)(((((num2 + 414745695) ^ 0x55FC76F6) << 0) + 0) ^ 0 ^ 0);
					continue;
				default:
				{
					IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList).GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 1414165224;
								num4 = num3;
							}
							else
							{
								num3 = 1190796307;
								num4 = num3;
							}
							int num5 = (num3 + 0 << 0 << 0) - 0;
							while (true)
							{
								switch ((num2 = (uint)(((((num5 - 0 - -0) ^ 0) << 0) + 0 << (0 >> 1) >> 0) - 0)) % 14)
								{
								case 0u:
									num5 = 1190796307;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (1898524966 << 0 >> 0) - 0 >> 0;
									continue;
								case 2u:
									num5 = (((int)((num2 + 428697817) ^ 0xDA98D700u) >> 0) + 0 << 0) ^ 0;
									continue;
								case 11u:
									val = GorillaGameManager.instance.FindVRRigForPlayer(current);
									num5 = (int)(((num2 + 2106842273) ^ 0xA6B06B25u) + 0 << 0 << 0) >> 0;
									continue;
								case 13u:
									break;
								case 3u:
									flag2 = (Object)(object)val != (Object)null;
									num5 = (((((int)num2 + -1125345364) ^ 0xB95EF39) >> 0 >> 0) ^ 0) >> 0;
									continue;
								case 4u:
									flag = flag2;
									num5 = (int)(((((num2 + 1952503976) ^ 0x992816F7u) - 0) ^ 0) - 0 + 0);
									continue;
								case 5u:
								{
									int num6;
									int num7;
									if (flag)
									{
										num6 = -313983741;
										num7 = num6;
									}
									else
									{
										num6 = -607534910;
										num7 = num6;
									}
									num5 = (((((num6 ^ 0) - 0) ^ ((int)num2 + -1127256878)) >> 0 << 0) ^ 0) - 0;
									continue;
								}
								case 9u:
									num5 = 0x26918817 ^ 0;
									continue;
								case 12u:
									num5 = (((int)num2 + -295483064) ^ 0x2B9132CE) - 0 + 0 - 0 << 0;
									continue;
								case 6u:
									val.RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ؽ؋\u061aغ؏؉؉؋؊غ؇\u0603؋", 1348404846, true), (RpcTarget)1, (Il2CppReferenceArray<Object>)null);
									num5 = (((int)num2 + -517084339) ^ -1115145630 ^ 0) << 0 >> 0 << 0;
									continue;
								case 7u:
									num5 = ((int)((num2 + 1464826632) ^ 0xC2C84F3Bu) >> 0) ^ 0 ^ 0 ^ 0;
									continue;
								case 8u:
									num5 = ((int)((num2 + 2029155507) ^ 0xBF85C890u) >> 0 << 0) - 0 << 0;
									continue;
								case 10u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_03d8:
								int num8 = 908887761;
								while (true)
								{
									switch ((num2 = (uint)(((((num8 << 0) - (0 << 1) - 0 << 0) ^ 0) << 0 + 0 >> 0) - 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_03dd;
									case 1u:
										enumerator.Dispose();
										num8 = (int)(((num2 + 2123088869) ^ 0xCA9F16FCu ^ 0) + 0 + 0 << 0);
										continue;
									case 2u:
										num8 = (int)(((((num2 + 67065565) ^ 0xEB462034u) - 0 << 0) ^ 0) + 0);
										continue;
									case 3u:
										goto end_IL_03dd;
									}
									goto IL_03d8;
									continue;
									end_IL_03dd:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public slow_all()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0 ^ 0) - 0) ^ 0 ^ 0) + (0 ^ 0) - 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0) - 0 + 0 - 0;
			}
		}
	}
}
