using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.mods;

internal class testttt
{
	public static void thCNbcwxXXICIjYzEhKMvwFIBjNjiplyKBoCJWgAaMsplBCJwzvILapXBUmRomoILjRhVwPHbkLIeqwaHdNJUDNJlqbPKomNyKEbJuOaJNGBpGTlxmjkzFNiwhVEvaXMXXktLvqnoMZgWluFxQryfbnTWwFCykFJQUDrvzzcVWVMFHlkNpgEJyHVJrxpQOOdhqqcIcjXqpCigBnpkuOieaZrmHHecjlhhRFpriBKgiotWyPidhfvZFZhqYPaufVgduaoWXYbTecVMGvOSzaUeQiCSxZssBpbnhpBxBmfjdCUCevJCbiVeacnlywyYFJrObHEqUqqmVLbooZNcpQrttWnfcpYfOhDukfBwQtIKRJjoaYXyIwJPrYueuznFrlyNhHdiyrl()
	{
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = default(GameObject);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 << (0 << 1)) - 0 + 0 >> 0) ^ 0 ^ 0) + 0)) % 9)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					val = GameObject.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("臍臤臷臤臭膮臯臤臶臲自臸", 515801473, true));
					num = ((((int)num2 + -956687329) ^ 0x1A00A54A) >> 0) - 0 - 0 + 0;
					continue;
				case 2u:
					((Renderer)val.GetComponent<MeshRenderer>()).material.shader = Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uebbc\ueb9b\ueb8e\ueb81\ueb8b\ueb8e\ueb9d\ueb8b", 75295727, true));
					num = (int)(((num2 + 1345212153) ^ 0x9E76BC4Du ^ 0) << 0 << 0 << 0);
					continue;
				case 7u:
					num = ((int)((num2 + 600520462) ^ 0x2F719F14) >> 0) - 0 + 0 + 0;
					continue;
				case 8u:
					num = ((((int)num2 + -733318432) ^ 0x60F0CBF2 ^ 0) >> 0) + 0 >> 0;
					continue;
				case 3u:
					((Renderer)val.GetComponent<MeshRenderer>()).material.color = new Color(((Renderer)((Component)GorillaTagger.Instance.myVRRig).GetComponent<SkinnedMeshRenderer>()).material.color.r, ((Renderer)((Component)GorillaTagger.Instance.myVRRig).GetComponent<SkinnedMeshRenderer>()).material.color.g, ((Renderer)((Component)GorillaTagger.Instance.myVRRig).GetComponent<SkinnedMeshRenderer>()).material.color.b);
					num = (((((int)num2 + -795116775) ^ -157171963) << 0) ^ 0) - 0 + 0;
					continue;
				case 4u:
					num = (int)(((num2 + 1259723679) ^ 0x79291E3F ^ 0) << 0) >> 0 >> 0;
					continue;
				case 5u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\uee98\uee94\uee92\uee90\uee9b\uee81\uee94", 715124469, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("桰案桚栃桀桌桏桌桑", 928540707, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("捨捐捂挛捸捔捗捔捉挛捓捚捈挛捙捞捞捕挛捈捞捏挛捏捔挛捖捔捕捐捞捂挛捘捔捗捔捉挚", 274162491, true));
					num = ((((int)num2 + -434485547) ^ -1441451814) - 0 << 0) ^ 0 ^ 0;
					continue;
				case 6u:
					return;
				}
				break;
			}
		}
	}

	public testttt()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num + 0 + (0 << 1) >> 0) ^ 0 ^ 0 ^ 0) + 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) + 0 << 0 >> 0 << 0;
			}
		}
	}
}
