using GorillaLocomotion;
using MenuTemplate;
using UnityEngine;
using easyInputs;

namespace Popeye.Menu.mods;

internal class tp_gun
{
	private static bool WiGBKNYeerzxsyOclKwcrfcsGlvhsUPaqkMHLxKqvujnROgpsFRxboUQfnVzsQLjBzghLhqOagGWVPARffONcsZbpWBxBlXEI = true;

	public static void ZMsIYElodwVIYUqNduncYgiAeSPFTmPibnVdijgBDzZVdtrblKyQKCKSDSDfPFuQHNGKZnFUnMzzhnwKAOujOYxzDczpFaLXejoqNHcYfDDYckLqvSFbllbJpggWNpomaCvYYgXTLvdluzwsrjUMvKLShFaGAglQprYAPMrpVMpPiQoQKOEDuBQpQCQtfqsFknVdBVCESFRJvVKrrkWMBHvNAIKmWXjEtJFUUkoOlZKPKhUUSzcUuGeCSiCSlpIUvmqLqPwgViABXFdtNPuxVpkMEccMHwCVrPuxRiDccVYlfCFmfjfvVlZgcDgoNKyzFFjhkFCFlruZqYGcxPGyrgZgQounbpprxyGAtxczHzjEQZPeWeQYeaizFdrWloDWcdCRsfIZNhQRWvqQypqWzqnwqhVqffosVnCMxYMRvQlXjrCjMBxVYHxLQfBkksUHSxVJTDsACzAIeqnYFLDEIsuoQQWswBGdWEeLvS()
	{
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0456: Unknown result type (might be due to invalid IL or missing references)
		//IL_0553: Unknown result type (might be due to invalid IL or missing references)
		//IL_0736: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val2 = default(RaycastHit);
		GameObject val = default(GameObject);
		bool flag = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301835;
			while (true)
			{
				uint num2;
				int num5;
				switch ((num2 = (uint)(((((num ^ 0) - (0 ^ 0) - 0) ^ 0 ^ 0) << (0 >> 1)) + 0) ^ 0u) % 31)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = ((int)((num2 + 900749756) ^ 0xABBAE79Eu) >> 0 >> 0) - 0 >> 0;
					continue;
				case 2u:
					val = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (int)(((num2 + 1709781230) ^ 0x8033A206u) - 0 + 0 + 0 << 0);
					continue;
				case 29u:
					val.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
					num = ((((int)num2 + -1650322207) ^ -1457819354) << 0 << 0) - 0 >> 0;
					continue;
				case 19u:
					WiGBKNYeerzxsyOclKwcrfcsGlvhsUPaqkMHLxKqvujnROgpsFRxboUQfnVzsQLjBzghLhqOagGWVPARffONcsZbpWBxBlXEI = true;
					num = ((((int)num2 + -1204999380) ^ 0xC8B8CB7) << 0 << 0) + 0 - 0;
					continue;
				case 3u:
					num = ((((int)num2 + -871797673) ^ -902017937) << 0 << 0 >> 0) ^ 0;
					continue;
				case 4u:
					val.transform.position = ((RaycastHit)(ref val2)).point;
					num = ((((int)num2 + -1439813256) ^ -669944716) - 0 >> 0 >> 0) + 0;
					continue;
				case 5u:
					num = (((((int)num2 + -2033110311) ^ -884060989) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 26u:
					num = (((((int)num2 + -1172829669) ^ -812776902) + 0) ^ 0) + 0 - 0;
					continue;
				case 24u:
					Object.Destroy((Object)(object)val.GetComponent<Rigidbody>());
					num = (((int)num2 + -1827602905) ^ -1371906253 ^ 0 ^ 0) - 0 - 0;
					continue;
				case 6u:
					num = (((int)num2 + -509051253) ^ 0x6D713FA2 ^ 0) + 0 + 0 >> 0;
					continue;
				case 7u:
					Object.Destroy((Object)(object)val.GetComponent<Collider>());
					num = (((((int)num2 + -1891630081) ^ -1491922686) >> 0) ^ 0) << 0 << 0;
					continue;
				case 8u:
					num = ((((int)num2 + -903840450) ^ 0x6B67E0A7) + 0 - 0 << 0) + 0;
					continue;
				case 20u:
					num = (int)(((((num2 + 2112378798) ^ 0xF5B83D41u ^ 0) + 0) ^ 0) << 0);
					continue;
				case 9u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val, Color.red);
					num = (int)((((num2 + 1455221297) ^ 0xCD9979B4u ^ 0 ^ 0) - 0) ^ 0);
					continue;
				case 25u:
					num = (int)(((num2 + 1473386669) ^ 0xE08F6FC0u) + 0 - 0 + 0 + 0);
					continue;
				case 10u:
					Object.Destroy((Object)(object)val, Time.deltaTime);
					num = (int)(((((num2 + 1376848916) ^ 0x74D85A51) << 0) ^ 0 ^ 0) + 0);
					continue;
				case 30u:
					num = (int)(((((num2 + 2022602987) ^ 0xE0B48AB6u) << 0) - 0 << 0) ^ 0);
					continue;
				case 11u:
					num = (((int)num2 + -182552646) ^ -1497764873) + 0 - 0 - 0 + 0;
					continue;
				case 12u:
					if (EasyInputs.GetTriggerButtonDown((EasyHand)1))
					{
						num = (((int)num2 + -1563535789) ^ -435804170 ^ 0 ^ 0 ^ 0) << 0;
						continue;
					}
					num5 = 0;
					goto IL_0620;
				case 28u:
					num5 = ((!WiGBKNYeerzxsyOclKwcrfcsGlvhsUPaqkMHLxKqvujnROgpsFRxboUQfnVzsQLjBzghLhqOagGWVPARffONcsZbpWBxBlXEI) ? 1 : 0);
					goto IL_0620;
				case 22u:
					WiGBKNYeerzxsyOclKwcrfcsGlvhsUPaqkMHLxKqvujnROgpsFRxboUQfnVzsQLjBzghLhqOagGWVPARffONcsZbpWBxBlXEI = false;
					num = (((int)((num2 + 1493219093) ^ 0xFA285008u ^ 0) >> 0) ^ 0) >> 0;
					continue;
				case 13u:
					flag = flag2;
					num = (((int)num2 + -1829903696) ^ -1095850045) + 0 + 0 - 0 + 0;
					continue;
				case 14u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1678582704;
						num4 = num3;
					}
					else
					{
						num3 = 411380363;
						num4 = num3;
					}
					num = (((int)((uint)((num3 ^ 0) >> 0) ^ (num2 + 502420178) ^ 0) >> 0) ^ 0) << 0;
					continue;
				}
				case 15u:
					num = ((int)(((num2 + 1855391286) ^ 0xF220C50Bu) - 0) >> 0) - 0 >> 0;
					continue;
				case 27u:
					((Component)Player.Instance).transform.position = val.transform.position;
					num = (int)((((num2 + 1919092371) ^ 0xCCBEFC74u) + 0 + 0 << 0) - 0);
					continue;
				case 21u:
					num = (0x7460D8B7 ^ 0) << 0;
					continue;
				case 16u:
					num = (int)((((num2 + 1363915621) ^ 0xBC1B4EEDu) << 0 << 0) - 0 - 0);
					continue;
				case 17u:
					((Component)Player.Instance).GetComponent<Rigidbody>().velocity = new Vector3(0f, 0f, 0f);
					num = (int)((((((num2 + 823506666) ^ 0x1D2B8E10) << 0) + 0) ^ 0) << 0);
					continue;
				case 18u:
					num = (((((int)num2 + -1504328649) ^ -2142402185) - 0 << 0) ^ 0) << 0;
					continue;
				case 23u:
					return;
					IL_0620:
					flag2 = (byte)num5 != 0;
					num = (0x4B15DB96 ^ 0) + 0;
					continue;
				}
				break;
			}
		}
	}

	public tp_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0 ^ 0) - 0 >> 0 << 0) ^ 0) - 0 >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0 ^ 0) + 0 << 0;
			}
		}
	}
}
