using System.Collections.Generic;
using Il2CppSystem;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.mods;

internal class tag_all
{
	public static void uAoYmELCVCAiCSAcaZekxUblYFhcQhFtBdpMDllvPRetHbgEQPSLEujAzdZGwILNWhGyCOzPOIuGQHDXzDmaoUOhTPmAlEYggqxzuHbcqdXVZDJSzchTwKzctyFMCYEjJoAAkeCRBjKlWShpgubjxfJvQugVcozszOlLdjHvzqrmanfArpGiWuLEEeJPXGPnKrLiGwmXMGJhNwvCpGEMHrvecHgZzSySAeCICXUUcJvqLEQhIgAqccFsWHgYqnxTiRGJUNasMKJYVetxQYqsrhQyzkLUQVDPmCiUYhnVfiErsHwRoIisWeBaaikJbgBRhULtWzyJKvnjDzfROUGiNlShahTQWETZGMkyVcVPjyHBRsxBcsVhAteVbEtPFIMgBnDQoH()
	{
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b3: Expected O, but got Unknown
		//IL_0763: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b8: Unknown result type (might be due to invalid IL or missing references)
		GorillaTagManager current = default(GorillaTagManager);
		bool flag2 = default(bool);
		bool flag3 = default(bool);
		Player[] array = default(Player[]);
		Random val2 = default(Random);
		int num8 = default(int);
		PhotonView val = default(PhotonView);
		bool flag4 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0 >> (0 << 1)) ^ 0) << 0) - 0 >> (0 ^ 0) << 0) - 0)) % 3)
				{
				case 0u:
					break;
				case 1u:
					goto IL_004a;
				default:
				{
					IEnumerator<GorillaTagManager> enumerator = Object.FindObjectsOfType<GorillaTagManager>().GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (!enumerator.MoveNext())
							{
								num3 = 114373355;
								num4 = num3;
							}
							else
							{
								num3 = 414745692;
								num4 = num3;
							}
							int num5 = (num3 + 0 << 0) + 0 - 0;
							while (true)
							{
								switch ((num2 = (uint)((((((num5 >> 0) - (0 >> 1)) ^ 0) - 0 << 0) ^ 0) >> 0) ^ 0u) % 37)
								{
								case 0u:
									num5 = 414745692;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (0x54C7FBC4 ^ 0) - 0 << 0 << 0;
									continue;
								case 2u:
									num5 = ((int)(((num2 + 1548432940) ^ 0xF8F194C6u) << 0) >> 0 >> 0) + 0;
									continue;
								case 29u:
									flag2 = current.currentInfected.Contains(PhotonNetwork.LocalPlayer);
									num5 = ((((((int)num2 + -1008375456) ^ 0x4B321281) + 0) ^ 0) >> 0) - 0;
									continue;
								case 23u:
									num5 = (1333463152 + 0 << 0) + 0 << 0;
									continue;
								case 3u:
									flag3 = flag2;
									num5 = ((int)((num2 + 1457370637) ^ 0xECFEE331u) >> 0 >> 0 << 0) + 0;
									continue;
								case 4u:
								{
									int num9;
									int num10;
									if (flag3)
									{
										num9 = -5005432;
										num10 = num9;
									}
									else
									{
										num9 = -1304443488;
										num10 = num9;
									}
									num5 = ((int)((uint)((num9 ^ 0) - 0) ^ (num2 + 1047830633) ^ 0) >> 0 << 0) ^ 0;
									continue;
								}
								case 5u:
									num5 = (((int)((num2 + 830770635) ^ 0xEAC09C63u) >> 0) ^ 0 ^ 0) + 0;
									continue;
								case 25u:
									num5 = (int)(((((num2 + 590235451) ^ 0x1D430057) << 0) ^ 0) - 0 + 0);
									continue;
								case 31u:
									array = Il2CppArrayBase<Player>.op_Implicit((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList);
									num5 = (((((int)num2 + -1377430272) ^ 0x3A93635A) >> 0) + 0 << 0) - 0;
									continue;
								case 6u:
									val2 = new Random();
									num5 = (int)(((num2 + 337346832) ^ 0x36E2A141 ^ 0) << 0 << 0 << 0);
									continue;
								case 7u:
									num8 = val2.Next(array.Length);
									num5 = (((((int)num2 + -1160147690) ^ -347677313) + 0 + 0) ^ 0) - 0;
									continue;
								case 8u:
									val = GorillaGameManager.instance.FindVRRigForPlayer(array[num8]);
									num5 = (int)((((num2 + 1394277627) ^ 0xB6D98EBCu) << 0) + 0) >> 0 >> 0;
									continue;
								case 34u:
									num5 = (int)((((num2 + 1344036829) ^ 0xE8BF22D1u ^ 0) - 0 << 0) ^ 0);
									continue;
								case 9u:
									flag4 = !current.currentInfected.Contains(val.Owner);
									num5 = (((((int)num2 + -1336085439) ^ -1898368651) >> 0) ^ 0) - 0 << 0;
									continue;
								case 32u:
									flag = flag4;
									num5 = (int)(((num2 + 1016054125) ^ 0xE7088494u) + 0 + 0 + 0 << 0);
									continue;
								case 10u:
								{
									int num6;
									int num7;
									if (!flag)
									{
										num6 = -222934588;
										num7 = num6;
									}
									else
									{
										num6 = -247119991;
										num7 = num6;
									}
									num5 = (int)((((uint)((num6 << 0) + 0) ^ (num2 + 917659543)) - 0 + 0 << 0) ^ 0);
									continue;
								}
								case 30u:
									num5 = (int)((((num2 + 1115582667) ^ 0x5A478F0E) + 0 + 0 << 0) + 0);
									continue;
								case 11u:
									num5 = (((int)num2 + -1812791908) ^ -593706079) - 0 << 0 << 0 >> 0;
									continue;
								case 12u:
									((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
									num5 = (int)(((((num2 + 1705340762) ^ 0xD87C85A2u ^ 0) + 0) ^ 0) << 0);
									continue;
								case 36u:
									num5 = ((((int)num2 + -357004051) ^ 0x268F970A) - 0 >> 0) + 0 + 0;
									continue;
								case 22u:
									num5 = (770395567 << 0) + 0 + 0 << 0;
									continue;
								case 13u:
									((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)val).transform.position;
									num5 = ((int)(((num2 + 923559321) ^ 0x7115FC5) + 0) >> 0) - 0 - 0;
									continue;
								case 14u:
									num5 = ((int)(((num2 + 747926746) ^ 0xF98EDA2Cu) + 0) >> 0 >> 0) + 0;
									continue;
								case 15u:
									GorillaTagger.Instance.myVRRig.head.rigTarget.localEulerAngles = Vector3.right;
									num5 = (int)((((num2 + 461723281) ^ 0xA053B8B2u) - 0 << 0) + 0 + 0);
									continue;
								case 35u:
									num5 = (((((int)num2 + -1372250924) ^ -611106854) + 0 >> 0) ^ 0) - 0;
									continue;
								case 26u:
									num5 = ((0x41FE8F49 ^ 0) << 0) - 0;
									continue;
								case 16u:
									current.AddInfectedPlayer(val.Owner);
									num5 = ((((int)num2 + -1403453257) ^ -203958345) + 0 - 0 + 0) ^ 0;
									continue;
								case 17u:
									num5 = ((int)((num2 + 293113464) ^ 0x586A06A2) >> 0 >> 0) ^ 0 ^ 0;
									continue;
								case 18u:
									current.currentInfected.Add(val.Owner);
									num5 = ((int)((num2 + 1866650904) ^ 0xD4EA720Fu) >> 0 >> 0) + 0 >> 0;
									continue;
								case 24u:
									((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
									num5 = (((int)((num2 + 878567154) ^ 0xCFD18B06u) >> 0) ^ 0) - 0 >> 0;
									continue;
								case 19u:
									num5 = ((int)((((num2 + 641832775) ^ 0x12E7A4CF) << 0) - 0) >> 0) ^ 0;
									continue;
								case 33u:
									current.UpdateState();
									num5 = (((int)(((num2 + 435749897) ^ 0x5CD58FE9) << 0) >> 0) + 0) ^ 0;
									continue;
								case 20u:
									num5 = (int)((((num2 + 1198527402) ^ 0x1E69255B) - 0 - 0 + 0) ^ 0);
									continue;
								case 27u:
									break;
								case 21u:
									num5 = (((((int)num2 + -877465945) ^ 0x4B150639) - 0) ^ 0) - 0 << 0;
									continue;
								case 28u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_094c:
								int num11 = 176292833;
								while (true)
								{
									switch ((num2 = (uint)(((((num11 >> 0) ^ 0 ^ 0) - 0 - 0 << (0 >> 1)) ^ 0) - 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_0951;
									case 1u:
										enumerator.Dispose();
										num11 = ((int)(((num2 + 669534340) ^ 0x4E5DE7AB) - 0) >> 0 << 0) - 0;
										continue;
									case 2u:
										num11 = ((((((int)num2 + -29651670) ^ 0x7119245B) >> 0) - 0) ^ 0) << 0;
										continue;
									case 3u:
										goto end_IL_0951;
									}
									goto IL_094c;
									continue;
									end_IL_0951:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
				IL_004a:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0) << 0) + 0 + 0;
			}
		}
	}

	public static void WLYRYoDrqIJrNEJMznIowrJgjBLBaDOHnvwjiJvPrKoLfoUiwOOqiZkEcSHwDcqMTceshzEPRSWMdXaUHDelOyynlRhpbZmptBScjCaXkZypcxBfSNPaXeXuDRgqsoOSGHsBfXLeChbPajkOpbxojmsoExysvKEVkFJveaZUbKxPdiuuGsaqRAItpeXHysISDfFuAOJpcCmzOClwdeLdKneKWpgadsvJbFmYCZTSILoonjEMTBEuHFipbUxlIJlKhCxjpnTdkTvZZPwNK()
	{
		Player current = default(Player);
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0) ^ 0) - 0 + 0) ^ 0) + (0 + 0) << 0 >> 0)) % 5)
				{
				case 0u:
					break;
				case 1u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)(((((num2 + 377208505) ^ 0x4A8E42A9) + 0 + 0) ^ 0) + 0);
					continue;
				case 2u:
					num = ((((int)num2 + -725091362) ^ 0x110CE96B) + 0 >> 0) - 0 - 0;
					continue;
				case 4u:
					num = ((((((int)num2 + -956687329) ^ -230459291) << 0) ^ 0) >> 0) ^ 0;
					continue;
				default:
				{
					IEnumerator<Player> enumerator = ((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList).GetEnumerator();
					try
					{
						while (true)
						{
							int num3;
							int num4;
							if (enumerator.MoveNext())
							{
								num3 = 1802649737;
								num4 = num3;
							}
							else
							{
								num3 = 1621957014;
								num4 = num3;
							}
							int num5 = ((num3 ^ 0) - 0 << 0) - 0;
							while (true)
							{
								switch ((num2 = (uint)(((num5 << 0) ^ -0) + 0 + 0 - 0 + (0 + 0) + 0 >> 0)) % 8)
								{
								case 0u:
									num5 = 1802649737;
									continue;
								default:
									return;
								case 1u:
									current = enumerator.Current;
									num5 = (600520458 + 0 >> 0 >> 0) + 0;
									continue;
								case 2u:
									num5 = (((int)num2 + -434485547) ^ 0x8E16498) << 0 << 0 >> 0 >> 0;
									continue;
								case 7u:
									PhotonView.Get((Component)(object)((Component)GorillaGameManager.instance).GetComponent<GorillaGameManager>()).RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꍈꍿꍪꍵꍨꍮꍎꍻꍽꍈꍊꍙ", 688366362, true), (RpcTarget)2, Il2CppReferenceArray<Object>.op_Implicit((Object[])(object)new Object[1] { (Object)current }));
									num5 = ((((int)num2 + -733318432) ^ -2049575108) << 0 >> 0) + 0 + 0;
									continue;
								case 5u:
									break;
								case 3u:
									num5 = (((((int)num2 + -678915685) ^ 0x3D4BFA12) << 0) - 0 - 0) ^ 0;
									continue;
								case 4u:
									num5 = ((((int)num2 + -1186296972) ^ -2052105851) + 0 + 0) ^ 0 ^ 0;
									continue;
								case 6u:
									return;
								}
								break;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							while (true)
							{
								IL_02a7:
								int num6 = 863264985;
								while (true)
								{
									switch ((num2 = (uint)((((((num6 << 0) ^ 0) >> 0) + 0 + 0 - (0 << 1)) ^ 0) << 0)) % 4)
									{
									case 0u:
										break;
									default:
										goto end_IL_02ac;
									case 1u:
										enumerator.Dispose();
										num6 = ((int)(((num2 + 758493273) ^ 0x7D1D58EC) << 0) >> 0) + 0 >> 0;
										continue;
									case 2u:
										num6 = ((((int)num2 + -1536825040) ^ -19767331) - 0 + 0 >> 0) + 0;
										continue;
									case 3u:
										goto end_IL_02ac;
									}
									goto IL_02a7;
									continue;
									end_IL_02ac:
									break;
								}
								break;
							}
						}
					}
				}
				}
				break;
			}
		}
	}

	public tag_all()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0) ^ -0 ^ 0) >> 0 >> 0 << (0 << 1)) + 0 + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0) << 0 << 0 >> 0;
			}
		}
	}
}
