using System.Collections.Generic;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace MenuTemplate.mods.NotificationLib;

[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
internal class JoinNotifacation
{
	private static List<Player> dewhcIlJcidfmhVPdPvUVgQlOKInletHTOofdPhfQNgKjWjHcekyPKSXnlssaXyXOvlyTPLoHqdiZfcRAblhUVRjVqSSwPeTpjWNKLOmsVQzHKYiiARYMqdTDcCCXTSSlkTPjphPnYOYesBlsJKVYggYfcjHilpzdYowRiYTtbLOCeOlArjnjWTeeUKgfzGbIpU = new List<Player>();

	public static bool gdetjKQCWurwaoYhRcbqhejsWySOUvKfmjIhvXaDsuXKMyJSgsPZHZNcUMxLScHBJljRGRLTbyXMhzFyPZHBFLxnwGmJAoKqMwaBoSmpHVXjbbUvgYWSugVYNWvZEbtMNHZKyejWNrUJOoluLRDBsRVGAbNsxmLFCkvtbkWbOZfdllkzKaoNyRtWMtjwrRzAGohDSStBUBNtMRupRnHxXYhLQzGHaAKXzEwXeHGSGNSWeajUZUFdkcCIhvMslMAuRQUhvxlkGOQkflHQpMIfUGMwcNQIUoHUmyengczBIuwvmsDVNWcyduzkdxeIHCpshWXHgtKmngxzkrkJkUUXliQRYUkIXQUffenpuVPumPlXXZaLnvxMIrgYggJmibpwlrufdUopfALvW;

	[HarmonyPrefix]
	private static void STYTzuCthxNXojomClkAPLGEUHsgiHhGLbnmKsJGMdeUHiOLacCoAVhgnuYRbwkzpglnVcCjBEOMHLWLSHfgfTfQUhYpuREpSEEAXBQYAsMWgvzCxmYuqetwbvsOemPKZyTchvOqQhFNgiJyHwShTkZOkizBjcToCcXICxubyHDiyGqSMUgHtIQPzeRYWnhOnrkdlbWjbRJlGQqESGOoVmUUmiixGwekzPVgvmHLYWGCYFiJOmfpySSbxqRcSyDEMzLRVjiFZdqYGsVGZzJtqPLHWTJfvESztbPzUrNFezqvCTvfukdsOkoXNeUbzdkukQFECwMILeoQyqecyELkBzLiNSMPxMfbpWkLoQCXyuHKVxyxZRDVraSLfwRKKWlZYnBCftOHcNLhSanptoQFijJodzFSZRnBjHLHVVrFdWTEoLSfjBqvgFQPDmzGOWHkzkXkoFtyXkBmpfasHAJxBSvER(Player newPlayer)
	{
		bool flag = default(bool);
		bool flag2 = default(bool);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				int num5;
				switch ((num2 = (uint)((((num >> 0 << -0 >> 0) - 0) ^ 0 ^ 0 ^ 0) - 0)) % 12)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					if (!dewhcIlJcidfmhVPdPvUVgQlOKInletHTOofdPhfQNgKjWjHcekyPKSXnlssaXyXOvlyTPLoHqdiZfcRAblhUVRjVqSSwPeTpjWNKLOmsVQzHKYiiARYMqdTDcCCXTSSlkTPjphPnYOYesBlsJKVYggYfcjHilpzdYowRiYTtbLOCeOlArjnjWTeeUKgfzGbIpU.Contains(newPlayer))
					{
						num = (((int)num2 + -344833909) ^ 0x61F8C0DF ^ 0) - 0 + 0 - 0;
						continue;
					}
					num5 = 0;
					goto IL_0184;
				case 11u:
					num5 = (gdetjKQCWurwaoYhRcbqhejsWySOUvKfmjIhvXaDsuXKMyJSgsPZHZNcUMxLScHBJljRGRLTbyXMhzFyPZHBFLxnwGmJAoKqMwaBoSmpHVXjbbUvgYWSugVYNWvZEbtMNHZKyejWNrUJOoluLRDBsRVGAbNsxmLFCkvtbkWbOZfdllkzKaoNyRtWMtjwrRzAGohDSStBUBNtMRupRnHxXYhLQzGHaAKXzEwXeHGSGNSWeajUZUFdkcCIhvMslMAuRQUhvxlkGOQkflHQpMIfUGMwcNQIUoHUmyengczBIuwvmsDVNWcyduzkdxeIHCpshWXHgtKmngxzkrkJkUUXliQRYUkIXQUffenpuVPumPlXXZaLnvxMIrgYggJmibpwlrufdUopfALvW ? 1 : 0);
					goto IL_0184;
				case 10u:
					num = ((((int)num2 + -692261737) ^ 0x6C9E399A) << 0 << 0 >> 0) + 0;
					continue;
				case 2u:
					flag = flag2;
					num = ((((int)num2 + -2130437817) ^ -1934000782 ^ 0) >> 0) - 0 << 0;
					continue;
				case 3u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -8537995;
						num4 = num3;
					}
					else
					{
						num3 = -1188542415;
						num4 = num3;
					}
					num = (((num3 + 0 << 0) ^ ((int)num2 + -1625985034)) + 0 << 0 >> 0) + 0;
					continue;
				}
				case 4u:
					num = ((((int)num2 + -715084519) ^ -211488848) + 0 - 0 >> 0) + 0;
					continue;
				case 7u:
					num = (((((int)num2 + -1284218664) ^ 0x74B3DF03 ^ 0) + 0) ^ 0) + 0;
					continue;
				case 9u:
					dewhcIlJcidfmhVPdPvUVgQlOKInletHTOofdPhfQNgKjWjHcekyPKSXnlssaXyXOvlyTPLoHqdiZfcRAblhUVRjVqSSwPeTpjWNKLOmsVQzHKYiiARYMqdTDcCCXTSSlkTPjphPnYOYesBlsJKVYggYfcjHilpzdYowRiYTtbLOCeOlArjnjWTeeUKgfzGbIpU.Add(newPlayer);
					num = ((((int)num2 + -534343288) ^ -1407652304) << 0) + 0 >> 0 >> 0;
					continue;
				case 5u:
					num = (((((int)num2 + -1692824216) ^ -1509741461) << 0) - 0) ^ 0 ^ 0;
					continue;
				case 6u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䂣䂰䂰䃆䃆䂳䂱", 592396416, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("᎗ᎫᎦᎾᎢᎵᏧᎍᎨᎮᎩᎢᎣᏦ", 1027019719, true), newPlayer.NickName + ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("S", 1086259315, true) + newPlayer.UserId);
					num = (((int)((num2 + 1954386908) ^ 0xF89A2528u) >> 0 << 0) - 0) ^ 0;
					continue;
				case 8u:
					return;
					IL_0184:
					flag2 = (byte)num5 != 0;
					num = ((0x1B83E29E ^ 0) >> 0) - 0;
					continue;
				}
				break;
			}
		}
	}

	public JoinNotifacation()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num - 0 + (0 >> 1)) ^ 0) + 0) ^ 0) >> 0 + 0) + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) >> 0 >> 0 >> 0 << 0;
			}
		}
	}

	static JoinNotifacation()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num >> 0) ^ 0) << 0) - 0 >> 0) ^ 0) - 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_0052;
				case 2u:
					return;
				}
				break;
				IL_0052:
				gdetjKQCWurwaoYhRcbqhejsWySOUvKfmjIhvXaDsuXKMyJSgsPZHZNcUMxLScHBJljRGRLTbyXMhzFyPZHBFLxnwGmJAoKqMwaBoSmpHVXjbbUvgYWSugVYNWvZEbtMNHZKyejWNrUJOoluLRDBsRVGAbNsxmLFCkvtbkWbOZfdllkzKaoNyRtWMtjwrRzAGohDSStBUBNtMRupRnHxXYhLQzGHaAKXzEwXeHGSGNSWeajUZUFdkcCIhvMslMAuRQUhvxlkGOQkflHQpMIfUGMwcNQIUoHUmyengczBIuwvmsDVNWcyduzkdxeIHCpshWXHgtKmngxzkrkJkUUXliQRYUkIXQUffenpuVPumPlXXZaLnvxMIrgYggJmibpwlrufdUopfALvW = true;
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 >> 0) + 0 << 0;
			}
		}
	}
}
