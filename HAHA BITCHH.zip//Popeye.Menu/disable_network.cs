using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu;

internal class disable_network
{
	public static void akmoYGPwAWzWWUIPfjJJvApUWrGgURwdNHzXlXZVJWvafmMHEJCmLUxzVssGaIBIAvjouLDhkNazeoPKF()
	{
		Hashtable val = default(Hashtable);
		while (true)
		{
			int num = 1758301861;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 << 0 + 0) - 0 >> 0 >> 0) ^ 0 ^ 0) >> 0)) % 8)
				{
				case 0u:
					break;
				default:
					return;
				case 5u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((int)num2 + -907893453) ^ 0x7773C29 ^ 0) << 0 >> 0 >> 0;
					continue;
				case 7u:
					edsRYHExBVKBMuwUlPscDCHLrFwVqlHHDsesJqHeHvCBSfHUXgGKctpBvGztlIgpodXupdlVhovhagTmXBXkEWEkcDWcRoTYpmnOimFUULCOYiBpNmvJKVKrzNsLhidTvwSNTeeKWdpTtPlUbGpETjotCVpu(xGrQXybNsnRcqZOCGuKTfltuNHnhmJLEGQuPKYSHanvKjGVVronWFKulnWcplUAICnvAFZSIBcSSQIlgMrPXwOYWviCNVCwgNMiWlvqrwEvDRCvELVCTeCmNozexxeNYFLeeAoVrayBStueSNXcZZCckzuHMqTUrQwYgyqewalTFatuUumJzbOYcJUEgHiahDkcXwYuwTGYOJwjgaNrejvpcxVwELYPRkLcQrxxwSnGvPksmKygURWYiUaAABQKVQhDYutOCpVmVOUmmCkTnRVanMUVrWWVbCKEHGuSqKDEWKctaNnYqWxdVhqlzyxFsaktdpFFisDDoqdCJBUEJYEffHIAqisSnXmWAJpLiHQYtUOFdNBYDSWtvenwGepZZLqrehcaljwbiGMlSdxDHuouaSAvwT(), val, null, null);
					num = (int)(((num2 + 1621957012) ^ 0x2DA2662F) - 0 + 0 << 0 << 0);
					continue;
				case 1u:
					num = (((((int)num2 + -248958683) ^ 0x3D73A3B0) - 0 << 0) ^ 0) << 0;
					continue;
				case 3u:
					num = (int)(((num2 + 359659174) ^ 0x3353313E) - 0 + 0 - 0) >> 0;
					continue;
				case 6u:
					val = YBlpjrSkZcTFtVauNAJdxnTfucYUYvGDIbbhqsqdqeuJKCRSaerOfHhLIgVhtXlEvpWrUSeujFMsSkuRlgUTdSxaTpyjxjKsTQnvGzXhaWEzUOTyLeVndsADRVxEuUXaVtzbWZlMiNThnYgewaytnwpBpKDKbtNfZDDApRBMTjepytpTPsitwDNzeYMmwAKPaNhKuFPEzLzerZcWuJUIltJvQewqfpqsyppLlFykDDTKdJhfWQRMGcDGdMTpizzjvhFbKrKPkJfIzYrhXrupyDLwMIHyLicedKpWdfuFfbBWWVgeuMsRekLRvjpbJldbHbEPJvdRWPjwcPzQBCeZQkZSYyAUPtVTYApVqrvZIAUpaoPGJyzghelwbMQkUjbDTqyCADAkheqpqJSKJTkrUOLToSTEAkezyrvJQngfYoZd();
					num = ((((int)num2 + -344833909) ^ 0x16C8A5AB) << 0 >> 0) + 0 - 0;
					continue;
				case 2u:
					((Dictionary<Object, Object>)(object)val).Add(NWgsUgBaYKIfFEnHKVKWZRQYoiUwNesFPIgsLBKtJeAOIqelZyvcDcdWfheLmenUrdpXyUVilrmVqcqXdIwoIqbMEjnExYgFQFwFahMeDnQmQiFdRgIDHYlbcDspHrLnlHeLFLXWWsLvzPWwEjMqpCXSuvDwPxwlBDbidUxgjMHpnQBnHVKxEvXIKmqkhAhzVATWNNsJMGgDUHEDTqPTMYGgFsyRDmYJFitNWEzTDaLYouOcHNqRKnMWTNrvpBgzHwYMnRHoQWpLnHRlEvkQVgZrvxTindDcUlrRwbOQgcaNYaJlVgRTqqEA(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\u1ae2\u1ae4\u1ae8\u1ae0\u1ac8\u1aea\u1ae1\u1ae0", 2057116293, true)), NWgsUgBaYKIfFEnHKVKWZRQYoiUwNesFPIgsLBKtJeAOIqelZyvcDcdWfheLmenUrdpXyUVilrmVqcqXdIwoIqbMEjnExYgFQFwFahMeDnQmQiFdRgIDHYlbcDspHrLnlHeLFLXWWsLvzPWwEjMqpCXSuvDwPxwlBDbidUxgjMHpnQBnHVKxEvXIKmqkhAhzVATWNNsJMGgDUHEDTqPTMYGgFsyRDmYJFitNWEzTDaLYouOcHNqRKnMWTNrvpBgzHwYMnRHoQWpLnHRlEvkQVgZrvxTindDcUlrRwbOQgcaNYaJlVgRTqqEA(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("斟斖斋斜斊斍斚斐斍斀斚斘斏斜斚斘斗斀斖斗斔斖斌斗斍斘斐斗施於斿斸斬斵断", 85353977, true)));
					num = ((((int)num2 + -2130437817) ^ -2026299046 ^ 0) >> 0 >> 0) - 0;
					continue;
				case 4u:
					return;
				}
				break;
			}
		}
	}

	private static Hashtable YBlpjrSkZcTFtVauNAJdxnTfucYUYvGDIbbhqsqdqeuJKCRSaerOfHhLIgVhtXlEvpWrUSeujFMsSkuRlgUTdSxaTpyjxjKsTQnvGzXhaWEzUOTyLeVndsADRVxEuUXaVtzbWZlMiNThnYgewaytnwpBpKDKbtNfZDDApRBMTjepytpTPsitwDNzeYMmwAKPaNhKuFPEzLzerZcWuJUIltJvQewqfpqsyppLlFykDDTKdJhfWQRMGcDGdMTpizzjvhFbKrKPkJfIzYrhXrupyDLwMIHyLicedKpWdfuFfbBWWVgeuMsRekLRvjpbJldbHbEPJvdRWPjwcPzQBCeZQkZSYyAUPtVTYApVqrvZIAUpaoPGJyzghelwbMQkUjbDTqyCADAkheqpqJSKJTkrUOLToSTEAkezyrvJQngfYoZd()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Expected O, but got Unknown
		Hashtable result = default(Hashtable);
		while (true)
		{
			int num = 1758301859;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) + (0 + 0) << 0) ^ 0) - 0 >> 0 + 0 >> 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 3u:
					result = new Hashtable();
					num = ((((int)num2 + -1874950498) ^ -859104592) << 0 << 0 << 0) + 0;
					continue;
				case 1u:
					num = ((int)((((num2 + 414745695) ^ 0x55FC76F6) << 0) + 0) >> 0) ^ 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static Object NWgsUgBaYKIfFEnHKVKWZRQYoiUwNesFPIgsLBKtJeAOIqelZyvcDcdWfheLmenUrdpXyUVilrmVqcqXdIwoIqbMEjnExYgFQFwFahMeDnQmQiFdRgIDHYlbcDspHrLnlHeLFLXWWsLvzPWwEjMqpCXSuvDwPxwlBDbidUxgjMHpnQBnHVKxEvXIKmqkhAhzVATWNNsJMGgDUHEDTqPTMYGgFsyRDmYJFitNWEzTDaLYouOcHNqRKnMWTNrvpBgzHwYMnRHoQWpLnHRlEvkQVgZrvxTindDcUlrRwbOQgcaNYaJlVgRTqqEA(string string_0)
	{
		Object result = default(Object);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num << 0) ^ -0) << 0) - 0) ^ 0 ^ 0) >> 0) + 0)) % 4)
				{
				case 0u:
					break;
				case 2u:
					result = Object.op_Implicit(string_0);
					num = (((((int)num2 + -1874950498) ^ -859104589) << 0) + 0 - 0) ^ 0;
					continue;
				case 3u:
					num = (((int)((num2 + 414745695) ^ 0x55FC76F7) >> 0) - 0 << 0) ^ 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	private static Room xGrQXybNsnRcqZOCGuKTfltuNHnhmJLEGQuPKYSHanvKjGVVronWFKulnWcplUAICnvAFZSIBcSSQIlgMrPXwOYWviCNVCwgNMiWlvqrwEvDRCvELVCTeCmNozexxeNYFLeeAoVrayBStueSNXcZZCckzuHMqTUrQwYgyqewalTFatuUumJzbOYcJUEgHiahDkcXwYuwTGYOJwjgaNrejvpcxVwELYPRkLcQrxxwSnGvPksmKygURWYiUaAABQKVQhDYutOCpVmVOUmmCkTnRVanMUVrWWVbCKEHGuSqKDEWKctaNnYqWxdVhqlzyxFsaktdpFFisDDoqdCJBUEJYEffHIAqisSnXmWAJpLiHQYtUOFdNBYDSWtvenwGepZZLqrehcaljwbiGMlSdxDHuouaSAvwT()
	{
		Room currentRoom = default(Room);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num << 0 << -0 >> 0 >> 0 >> 0) - -0 >> 0 << 0)) % 4)
				{
				case 0u:
					break;
				case 2u:
					currentRoom = PhotonNetwork.CurrentRoom;
					num = ((((int)num2 + -1874950498) ^ -859104589) >> 0) + 0 >> 0 << 0;
					continue;
				case 3u:
					num = (int)(((num2 + 414745695) ^ 0x55FC76F7) + 0 << 0 << 0 << 0);
					continue;
				default:
					return currentRoom;
				}
				break;
			}
		}
	}

	private static bool edsRYHExBVKBMuwUlPscDCHLrFwVqlHHDsesJqHeHvCBSfHUXgGKctpBvGztlIgpodXupdlVhovhagTmXBXkEWEkcDWcRoTYpmnOimFUULCOYiBpNmvJKVKrzNsLhidTvwSNTeeKWdpTtPlUbGpETjotCVpu(Room room_0, Hashtable hashtable_0, Hashtable hashtable_1, WebFlags webFlags_0)
	{
		bool result = default(bool);
		while (true)
		{
			int num = 1758301858;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num << 0) - (0 + 0) - 0 << 0) + 0) ^ 0) + 0 << 0)) % 4)
				{
				case 0u:
					break;
				case 2u:
					result = room_0.SetCustomProperties(hashtable_0, hashtable_1, webFlags_0);
					num = (((int)num2 + -1874950498) ^ -859104589) >> 0 << 0 >> 0 << 0;
					continue;
				case 3u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F7) << 0) >> 0) + 0 + 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	public disable_network()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num >> 0) + (0 + 0) << 0) ^ 0) + 0) ^ 0) + 0 + 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) - 0) ^ 0) + 0 - 0;
			}
		}
	}
}
