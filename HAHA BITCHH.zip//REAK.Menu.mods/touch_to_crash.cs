using Il2CppSystem.Collections.Generic;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace REAK.Menu.mods;

internal class touch_to_crash
{
	public static void tkgHsvKQqkvemmtKTGrTGfMVBTfiejKVYPgzpMCQqhtesIwawgDPfUhoxlfzqBMgAzfxgUuhdBDzMHDTwfMXGUPdHRbeGdAPumESCZTCLvMErHBPHlclOPAGJbPoSqAZaNfzdKrxljlkhlMaqlwvbpaELXiAjFKvVNEEBcMWUEaEDqyypOYGTfXLMAOfCQoFzQpuHhyozzBxpvavzKkuHdBPPTRanGudqufNbdRhpJgtEAvrAtGRGTXwozFNqyaTfxgUqntvSceX()
	{
		//IL_092e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0933: Unknown result type (might be due to invalid IL or missing references)
		//IL_0956: Unknown result type (might be due to invalid IL or missing references)
		//IL_095b: Unknown result type (might be due to invalid IL or missing references)
		//IL_098c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0991: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0907: Unknown result type (might be due to invalid IL or missing references)
		//IL_090c: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		Player owner = default(Player);
		Vector3 position3 = default(Vector3);
		Vector3 position = default(Vector3);
		Vector3 position4 = default(Vector3);
		Vector3 position2 = default(Vector3);
		float num5 = default(float);
		float num7 = default(float);
		float num13 = default(float);
		bool flag3 = default(bool);
		bool flag2 = default(bool);
		int num25 = default(int);
		int num16 = default(int);
		int num17 = default(int);
		int num26 = default(int);
		bool flag9 = default(bool);
		bool flag5 = default(bool);
		bool flag7 = default(bool);
		bool flag8 = default(bool);
		int num14 = default(int);
		int num15 = default(int);
		bool flag6 = default(bool);
		bool flag = default(bool);
		bool flag4 = default(bool);
		while (true)
		{
			int num = 1758301795;
			while (true)
			{
				uint num2;
				int num6;
				int num22;
				int num8;
				switch ((num2 = (uint)(((num + 0 - (0 ^ 0) + 0 + 0) ^ 0) - (0 ^ 0) - 0 - 0)) % 71)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((int)(((num2 + 364309176) ^ 0x4B4376FD) - 0) >> 0 >> 0) + 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = ((int)((num2 + 1438922508) ^ 0x9008A459u) >> 0 << 0) + 0 >> 0;
					continue;
				case 62u:
					num = (int)((((num2 + 757804180) ^ 0x31C6AFC) + 0) ^ 0) >> 0 << 0;
					continue;
				case 49u:
					num = (int)((num2 + 1448854582) ^ 0x9739A020u ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 3u:
					current = enumerator.Current;
					num = 0x167BBE81 ^ 0;
					continue;
				case 4u:
					num = (int)(((num2 + 1452403640) ^ 0x75B52E0C) + 0) >> 0 >> 0 << 0;
					continue;
				case 5u:
					owner = ((MonoBehaviourPun)current).photonView.Owner;
					num = (int)(((num2 + 483666874) ^ 0x614B53FB) + 0 << 0) >> 0 << 0;
					continue;
				case 52u:
					num = ((((int)num2 + -1411656096) ^ 0x61B8252B) >> 0) + 0 << 0 >> 0;
					continue;
				case 66u:
					position3 = current.headMesh.transform.position;
					num = (int)((((num2 + 11998589) ^ 0x1C9DB56F) << 0 << 0 << 0) - 0);
					continue;
				case 6u:
					position = current.leftHandTransform.position;
					num = (((int)num2 + -1904678002) ^ -1633579888) - 0 + 0 << 0 >> 0;
					continue;
				case 7u:
					position4 = current.rightHandTransform.position;
					num = (((((int)num2 + -719845573) ^ 0x6D3B124B) >> 0) ^ 0) - 0 + 0;
					continue;
				case 8u:
					position2 = GorillaTagger.Instance.myVRRig.headMesh.transform.position;
					num = (((((int)num2 + -1756947900) ^ 0x585E059F) << 0) ^ 0) << 0 >> 0;
					continue;
				case 53u:
				{
					int num20;
					int num21;
					if (enumerator.MoveNext())
					{
						num20 = 272533148;
						num21 = num20;
					}
					else
					{
						num20 = 216877932;
						num21 = num20;
					}
					num = ((num20 << 0) + 0) ^ 0 ^ 0;
					continue;
				}
				case 9u:
					num5 = Vector3.Distance(position3, position2);
					num = (int)(((num2 + 67747431) ^ 0x3F4A4DEA) - 0 + 0) >> 0 << 0;
					continue;
				case 68u:
					num7 = Vector3.Distance(position, position2);
					num = (int)((((((num2 + 329939053) ^ 0x5CD78E11) << 0) + 0) ^ 0) << 0);
					continue;
				case 10u:
					num13 = Vector3.Distance(position4, position2);
					num = (((((int)num2 + -290999538) ^ 0x1376F0BF ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 46u:
					PhotonNetwork.DestroyPlayerObjects(owner);
					num = (int)((((num2 + 1334533754) ^ 0xBE924253u) - 0 + 0) ^ 0 ^ 0);
					continue;
				case 11u:
					if (((MonoBehaviourPun)current).photonView.Owner.UserId != PhotonNetwork.LocalPlayer.UserId)
					{
						num = (((int)(((num2 + 1892383293) ^ 0x2154E976) + 0) >> 0) ^ 0) - 0;
						continue;
					}
					num6 = 0;
					goto IL_0aaf;
				case 12u:
					num6 = ((num5 <= 0.55f) ? 1 : 0);
					goto IL_0aaf;
				case 59u:
					flag3 = flag2;
					num = ((((int)num2 + -1532611491) ^ -251400040) << 0) + 0 << 0 >> 0;
					continue;
				case 60u:
					num = 0x5CF4420F ^ 0;
					continue;
				case 13u:
				{
					int num27;
					int num28;
					if (!flag3)
					{
						num27 = 1417004277;
						num28 = num27;
					}
					else
					{
						num27 = 1469158803;
						num28 = num27;
					}
					num = (((((num27 + 0) ^ 0 ^ ((int)num2 + -333008605)) << 0) ^ 0) >> 0) - 0;
					continue;
				}
				case 14u:
					num = ((((int)num2 + -2049404080) ^ -2137003516 ^ 0) + 0 << 0) ^ 0;
					continue;
				case 15u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = ((int)((((num2 + 65139428) ^ 0x4F6DB19A) << 0) - 0) >> 0) - 0;
					continue;
				case 58u:
					num = ((int)((num2 + 480410679) ^ 0x177E76E6) >> 0) - 0 - 0 << 0;
					continue;
				case 56u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)((((((num2 + 1657774638) ^ 0xED6DB969u) << 0) - 0) ^ 0) - 0);
					continue;
				case 16u:
					num25 = 0;
					num = ((int)((((num2 + 1127294952) ^ 0x8EF6F259u) << 0) ^ 0) >> 0) ^ 0;
					continue;
				case 17u:
					num = ((((((int)num2 + -217055685) ^ 0x3BD4B8CF) - 0) ^ 0) << 0) - 0;
					continue;
				case 18u:
					num = ((0x7D93DC79 ^ 0) - 0 << 0) + 0;
					continue;
				case 65u:
					num16 = num17 + 1;
					num = ((((int)num2 + -1740227389) ^ -522500664) << 0) + 0 - 0 << 0;
					continue;
				case 19u:
					PhotonNetwork.DestroyPlayerObjects(owner);
					num = ((((int)num2 + -1155788487) ^ 0x1E56624) << 0) + 0 + 0 + 0;
					continue;
				case 70u:
					num = ((((((int)num2 + -900572852) ^ 0x3F707361) >> 0) ^ 0) >> 0) ^ 0;
					continue;
				case 20u:
					num26 = num25;
					num = (((int)((num2 + 64584048) ^ 0x5A545F2B) >> 0 << 0) - 0) ^ 0;
					continue;
				case 45u:
					num = ((int)((num2 + 501888951) ^ 0x2FE10512) >> 0 >> 0) - 0 + 0;
					continue;
				case 21u:
					num = (int)((((num2 + 271593804) ^ 0x5EA2599A) + 0 + 0 << 0) + 0);
					continue;
				case 22u:
					num25 = num26 + 1;
					num = (int)((((num2 + 1954100370) ^ 0xDF93D298u) - 0 + 0 << 0) ^ 0);
					continue;
				case 63u:
					flag9 = num25 < 160;
					num = (1332531715 >> 0) - 0 << 0 >> 0;
					continue;
				case 23u:
				{
					int num23;
					int num24;
					if (flag9)
					{
						num23 = -542982878;
						num24 = num23;
					}
					else
					{
						num23 = -1113950831;
						num24 = num23;
					}
					num = (int)((((uint)(num23 - 0 + 0) ^ (num2 + 951933518)) + 0 + 0 - 0) ^ 0);
					continue;
				}
				case 50u:
					flag5 = num16 < 160;
					num = (0x7D9C3779 ^ 0) << 0;
					continue;
				case 24u:
					num = (((int)num2 + -171470482) ^ 0x483EA316) + 0 - 0 - 0 - 0;
					continue;
				case 25u:
					if (((MonoBehaviourPun)current).photonView.Owner.UserId != PhotonNetwork.LocalPlayer.UserId)
					{
						num = (1709781232 << 0) + 0 + 0 >> 0;
						continue;
					}
					num22 = 0;
					goto IL_0d80;
				case 57u:
					num22 = ((num13 <= 0.55f) ? 1 : 0);
					goto IL_0d80;
				case 43u:
					num = ((((int)num2 + -113808718) ^ 0x27DAF673) << 0) - 0 >> 0 << 0;
					continue;
				case 26u:
					flag7 = flag8;
					num = (int)(((((num2 + 142740142) ^ 0x2BCF4CFD) + 0 << 0) ^ 0) + 0);
					continue;
				case 27u:
				{
					int num18;
					int num19;
					if (flag7)
					{
						num18 = 856003001;
						num19 = num18;
					}
					else
					{
						num18 = 2029212250;
						num19 = num18;
					}
					num = ((int)(((uint)((num18 >> 0) - 0) ^ (num2 + 1591510134)) << 0) >> 0) + 0 >> 0;
					continue;
				}
				case 28u:
					num = (((int)num2 + -1654301974) ^ -1595339002 ^ 0 ^ 0 ^ 0) << 0;
					continue;
				case 48u:
					num17 = num16;
					num = (int)((((num2 + 1402561575) ^ 0x1108004F ^ 0) + 0 << 0) ^ 0);
					continue;
				case 29u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)((((num2 + 416924880) ^ 0x16978292) - 0 + 0) ^ 0) >> 0;
					continue;
				case 64u:
					num = (int)(((num2 + 462091793) ^ 0xA7D198AAu) + 0 + 0 - 0 - 0);
					continue;
				case 30u:
					num14 = 0;
					num = (int)(((num2 + 1446341817) ^ 0xC19D1164u ^ 0) - 0 - 0) >> 0;
					continue;
				case 31u:
					num = (int)((((num2 + 1587006848) ^ 0xAFD658CEu) << 0) - 0) >> 0 << 0;
					continue;
				case 69u:
					num = 0x4BB365C3 ^ 0;
					continue;
				case 32u:
					num = (1548432949 << 0 << 0) - 0 << 0;
					continue;
				case 55u:
					PhotonNetwork.DestroyPlayerObjects(owner);
					num = ((((int)num2 + -880128457) ^ 0x34C57A73) << 0) - 0 >> 0 << 0;
					continue;
				case 33u:
					num = (int)((((num2 + 274505005) ^ 0x6088F225) + 0 + 0 << 0) + 0);
					continue;
				case 44u:
					num16 = 0;
					num = (int)(((num2 + 485455216) ^ 0x88F11139u) - 0 - 0 - 0 - 0);
					continue;
				case 34u:
					num15 = num14;
					num = (int)(((((num2 + 150701655) ^ 0x2D489143) + 0) ^ 0) << 0 << 0);
					continue;
				case 35u:
					num = (((((int)num2 + -1415490461) ^ 0x5B9464AC) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 61u:
					num14 = num15 + 1;
					num = (int)((((num2 + 43582141) ^ 0x5636BD0E ^ 0) << 0) ^ 0) >> 0;
					continue;
				case 47u:
					num = (int)((((((num2 + 1175360126) ^ 0x573D18BF) << 0) ^ 0) + 0) ^ 0);
					continue;
				case 36u:
					flag6 = num14 < 160;
					num = (0x74A06964 ^ 0) + 0 - 0 + 0;
					continue;
				case 37u:
				{
					int num11;
					int num12;
					if (flag6)
					{
						num11 = 1648290584;
						num12 = num11;
					}
					else
					{
						num11 = 785360037;
						num12 = num11;
					}
					num = ((num11 - 0 + 0) ^ ((int)num2 + -263229304)) - 0 - 0 - 0 + 0;
					continue;
				}
				case 38u:
					num = (int)(((((num2 + 2146902915) ^ 0xCE9A6BAEu) - 0) ^ 0) - 0 + 0);
					continue;
				case 39u:
					if (((MonoBehaviourPun)current).photonView.Owner.UserId != PhotonNetwork.LocalPlayer.UserId)
					{
						num = (0x56BCEA49 ^ 0) + 0;
						continue;
					}
					num8 = 0;
					goto IL_107a;
				case 51u:
				{
					int num9;
					int num10;
					if (!flag5)
					{
						num9 = 941533670;
						num10 = num9;
					}
					else
					{
						num9 = 2044095555;
						num10 = num9;
					}
					num = (((num9 << 0 >> 0) ^ ((int)num2 + -579075425) ^ 0) << 0 << 0) - 0;
					continue;
				}
				case 67u:
					num8 = ((num7 <= 0.55f) ? 1 : 0);
					goto IL_107a;
				case 40u:
					flag = flag4;
					num = (((((int)num2 + -656729457) ^ 0x6922023D) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 41u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 2039461322;
						num4 = num3;
					}
					else
					{
						num3 = 223668757;
						num4 = num3;
					}
					num = ((((num3 << 0) - 0) ^ ((int)num2 + -1090264534)) + 0 - 0 << 0) + 0;
					continue;
				}
				case 42u:
					num = (int)(((num2 + 2100385416) ^ 0xCAA36B08u) - 0 << 0 << 0 << 0);
					continue;
				case 54u:
					return;
					IL_0aaf:
					flag2 = (byte)num6 != 0;
					num = (359659221 - 0 - 0 >> 0) + 0;
					continue;
					IL_107a:
					flag4 = (byte)num8 != 0;
					num = (0x66150019 ^ 0) << 0;
					continue;
					IL_0d80:
					flag8 = (byte)num22 != 0;
					num = (0x2DEB4D91 ^ 0) + 0;
					continue;
				}
				break;
			}
		}
	}

	public touch_to_crash()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) + (0 >> 1) - 0 + 0 >> 0 >> 0 + 0 << 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0) >> 0) ^ 0 ^ 0;
			}
		}
	}
}
