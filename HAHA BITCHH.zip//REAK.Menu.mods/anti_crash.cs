using Photon.Pun;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace REAK.Menu.mods;

internal class anti_crash
{
	public static float qiiWsygOGzSCFzPpZzdGSdHaeaTxLAlBCMuvwLaWicjwATWhoHFFIPanBiSrFIcgoraTetSnzgyQTkAkeLjeVGSNMhToSIqzZdijTccUOrfCqjtqHHnTzYkHymhWAEuRPYRQbrqcIppEAqwCNCGluxaaSBKHVgukWoMssDpqqkkkJGgiPEjXX;

	public static bool jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa = false;

	private static float laUCCmusBIkMVlqGmYjDLSombpWlNhHjZKntNQjMHQkWcOVFJfrBNvotLIBnqiEuabNkYWSvOwWUIrjntqBIQfvDvUIfpWwymQWbaLHMmVNqztLtyoTZHVDVFjOdoNfRZxIRvimIJOvUrfebioGadxRqmavQWDyzPWqbLTXqbkqSAIDAfMUZhfNCGrFuMwMfqWevOdqpqpZShZQExVLkIzrKiOutoCEFykBDDiMbwFIRgVvHBbXQKBwREumZIWbOLtuWxnaojJOdQAEntNSnENVWOKYjVMszEUfMAyjoaJGaNsaePZGVdNjYyxiNoQsxrozVvRMUDEmVgUjvJUtWfxwQLgodqwZjqjJyTfIYmMsyBnRDnMduxwsTSIkoCJDgFcFXkLBE;

	private static int lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP;

	public static float MHjSDJHaGioVpFJEFhyQFTCeOuhqgROobFkZFRNezLObRcYZBiTgrekTfeejBrUPuaTJuKZNuuqTeBnMwiOXXHXXvqUANECiRZHRioERifMXNqODRsMsCWRMcWodPzaQRicfUvDiEXPRUZjeBqIvRkFVhUOmZAbJfWfFoJIvOEOEhZRdNjCzQEYHChXaHrieWfMYTDQSHmGnvbNicKzQYCTAYycgLINxvKIbnTjjsJRDYKlBtPXWRrftllavAJgZyjRLsLViBpxoLpCnmBNWKRFeEoQbTNIICRePTAjHTOvBTRIWJNjZWjoHDNhdVUpOHPLTlNtMsfdVwdkMGTrgEIMtDwlgtfLZzGUefPKVtxHQgslzCuxbCjjYdsqOBntmtdwPj;

	public static void fHRjvNhbVmklMDYIKxqxVbNzWufduxcVwpxNFSgwcXigfDPKuEJGgroeUsmbHdGxjoOwglcRqUvXTGttFvJQNvPfbsSnGeOYqKWQOsDiBRqlWqlnYTwltPJNzJvNsOllfwGjKDEmRBpWfDiKhFpNICEBairfWQPMGegzJbDvojuSANIVALGN()
	{
		int num12 = default(int);
		bool flag8 = default(bool);
		bool flag6 = default(bool);
		float num5 = default(float);
		bool flag2 = default(bool);
		bool flag10 = default(bool);
		bool flag9 = default(bool);
		bool flag4 = default(bool);
		bool flag7 = default(bool);
		bool flag5 = default(bool);
		bool flag3 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301851;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0) ^ 0 ^ 0) - 0 + 0 - (0 + 0) << 0) - 0)) % 50)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					qiiWsygOGzSCFzPpZzdGSdHaeaTxLAlBCMuvwLaWicjwATWhoHFFIPanBiSrFIcgoraTetSnzgyQTkAkeLjeVGSNMhToSIqzZdijTccUOrfCqjtqHHnTzYkHymhWAEuRPYRQbrqcIppEAqwCNCGluxaaSBKHVgukWoMssDpqqkkkJGgiPEjXX -= Time.deltaTime;
					num = (((((int)num2 + -2071082168) ^ -660842965) << 0) ^ 0) >> 0 >> 0;
					continue;
				case 2u:
					laUCCmusBIkMVlqGmYjDLSombpWlNhHjZKntNQjMHQkWcOVFJfrBNvotLIBnqiEuabNkYWSvOwWUIrjntqBIQfvDvUIfpWwymQWbaLHMmVNqztLtyoTZHVDVFjOdoNfRZxIRvimIJOvUrfebioGadxRqmavQWDyzPWqbLTXqbkqSAIDAfMUZhfNCGrFuMwMfqWevOdqpqpZShZQExVLkIzrKiOutoCEFykBDDiMbwFIRgVvHBbXQKBwREumZIWbOLtuWxnaojJOdQAEntNSnENVWOKYjVMszEUfMAyjoaJGaNsaePZGVdNjYyxiNoQsxrozVvRMUDEmVgUjvJUtWfxwQLgodqwZjqjJyTfIYmMsyBnRDnMduxwsTSIkoCJDgFcFXkLBE += Time.timeScale / Time.deltaTime;
					num = ((int)num2 + -434831334) ^ 0x5FED20 ^ 0 ^ 0 ^ 0 ^ 0;
					continue;
				case 48u:
					num12 = lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP + 1;
					num = (int)(((num2 + 461443217) ^ 0x273A75F2 ^ 0 ^ 0) - 0 + 0);
					continue;
				case 39u:
					PhotonNetwork.Disconnect();
					num = (int)(((((num2 + 1812043280) ^ 0xF45878D9u) + 0) ^ 0) - 0 + 0);
					continue;
				case 3u:
					lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP = num12;
					num = (((((int)num2 + -645064961) ^ -5233896) + 0) ^ 0) - 0 - 0;
					continue;
				case 4u:
					flag8 = (double)qiiWsygOGzSCFzPpZzdGSdHaeaTxLAlBCMuvwLaWicjwATWhoHFFIPanBiSrFIcgoraTetSnzgyQTkAkeLjeVGSNMhToSIqzZdijTccUOrfCqjtqHHnTzYkHymhWAEuRPYRQbrqcIppEAqwCNCGluxaaSBKHVgukWoMssDpqqkkkJGgiPEjXX <= 0.0;
					num = (((int)(((num2 + 452787187) ^ 0x29C03E9C) + 0) >> 0) ^ 0) + 0;
					continue;
				case 5u:
					flag6 = flag8;
					num = (int)((((num2 + 1559511532) ^ 0x216B3DC1) - 0 << 0) ^ 0) >> 0;
					continue;
				case 32u:
					num = (int)(((((num2 + 2115827143) ^ 0xD8A51EB4u) << 0 << 0) + 0) ^ 0);
					continue;
				case 40u:
				{
					int num8;
					int num9;
					if (!flag6)
					{
						num8 = -188838477;
						num9 = num8;
					}
					else
					{
						num8 = -659220413;
						num9 = num8;
					}
					num = ((int)(((uint)(num8 - 0 >> 0) ^ (num2 + 1016054125)) << 0) >> 0) + 0 + 0;
					continue;
				}
				case 6u:
					num = (((((int)num2 + -1302358218) ^ -1162338223) - 0) ^ 0) << 0 >> 0;
					continue;
				case 7u:
					num5 = laUCCmusBIkMVlqGmYjDLSombpWlNhHjZKntNQjMHQkWcOVFJfrBNvotLIBnqiEuabNkYWSvOwWUIrjntqBIQfvDvUIfpWwymQWbaLHMmVNqztLtyoTZHVDVFjOdoNfRZxIRvimIJOvUrfebioGadxRqmavQWDyzPWqbLTXqbkqSAIDAfMUZhfNCGrFuMwMfqWevOdqpqpZShZQExVLkIzrKiOutoCEFykBDDiMbwFIRgVvHBbXQKBwREumZIWbOLtuWxnaojJOdQAEntNSnENVWOKYjVMszEUfMAyjoaJGaNsaePZGVdNjYyxiNoQsxrozVvRMUDEmVgUjvJUtWfxwQLgodqwZjqjJyTfIYmMsyBnRDnMduxwsTSIkoCJDgFcFXkLBE / (float)lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP;
					num = ((((int)num2 + -218260425) ^ 0x48DE8954 ^ 0) >> 0 >> 0) - 0;
					continue;
				case 8u:
					flag2 = num5 < 15f;
					num = (((((int)num2 + -1519429041) ^ 0x46B6C592) << 0 >> 0) ^ 0) >> 0;
					continue;
				case 43u:
					num = ((((((int)num2 + -1453520766) ^ 0x16B8C0AC) - 0) ^ 0) << 0) - 0;
					continue;
				case 9u:
					flag10 = flag2;
					num = (((int)num2 + -1198723765) ^ 0x63C97CC7 ^ 0) << 0 << 0 << 0;
					continue;
				case 41u:
				{
					int num13;
					int num14;
					if (flag10)
					{
						num13 = -2118807254;
						num14 = num13;
					}
					else
					{
						num13 = -1000021819;
						num14 = num13;
					}
					num = ((int)(((uint)((num13 - 0) ^ 0) ^ (num2 + 923559321) ^ 0) << 0) >> 0) - 0;
					continue;
				}
				case 10u:
					num = (int)((((num2 + 747926746) ^ 0x515BB2D5) + 0 << 0) ^ 0) >> 0;
					continue;
				case 36u:
					jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa = false;
					num = (((int)num2 + -123593846) ^ 0x734276C7 ^ 0) + 0 + 0 >> 0;
					continue;
				case 11u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("综绰绶维绿绥绰", 916815505, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䎾䎑䎋䎖䏟䎼䎍䎞䎌䎗", 618677247, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᭈ᭴᭶\u1b7e᭴᭵\u1b7e\u1b3b᭺\u1b6f\u1b6f\u1b7e᭶\u1b6b\u1b6f\u1b7e\u1b7f\u1b3b\u1b6f᭴\u1b3b᭸᭩᭺᭨\u1b73\u1b3b᭢᭴\u1b6e", 1506614043, true));
					num = (((int)((num2 + 461723281) ^ 0x4C1214CA ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 12u:
					num = (((((int)num2 + -1372250924) ^ -339779234) + 0 >> 0) ^ 0) - 0;
					continue;
				case 46u:
					jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa = true;
					num = (((((int)num2 + -1403453257) ^ -1965216516) << 0) ^ 0) + 0 + 0;
					continue;
				case 47u:
					num = (((int)num2 + -808576807) ^ 0x29EBCAE2) - 0 + 0 << 0 << 0;
					continue;
				case 13u:
					num = (int)(((num2 + 293113464) ^ 0x3C237391) - 0 - 0 + 0) >> 0;
					continue;
				case 14u:
					num = (int)((((num2 + 1866650904) ^ 0xF8A63165u ^ 0) << 0) + 0 + 0);
					continue;
				case 15u:
					num = (0x26918833 ^ 0) - 0 >> 0;
					continue;
				case 45u:
					flag9 = num5 < 10f;
					num = (int)((((num2 + 440672968) ^ 0x149FD81B) - 0 - 0 + 0) ^ 0);
					continue;
				case 33u:
					flag4 = !PhotonNetwork.InRoom;
					num = (0x43E56958 ^ 0) >> 0;
					continue;
				case 16u:
					flag7 = flag9;
					num = ((((int)num2 + -1100503962) ^ 0xB3F7F9F ^ 0) << 0) - 0 + 0;
					continue;
				case 17u:
				{
					int num10;
					int num11;
					if (!flag7)
					{
						num10 = -1335554363;
						num11 = num10;
					}
					else
					{
						num10 = -1819457599;
						num11 = num10;
					}
					num = (((num10 + 0) ^ 0 ^ ((int)num2 + -1434948216)) >> 0 << 0 >> 0) - 0;
					continue;
				}
				case 18u:
					num = (((((int)num2 + -1481437530) ^ -2102887205) >> 0) ^ 0) - 0 << 0;
					continue;
				case 30u:
					num = (int)(((num2 + 1201792116) ^ 0x302E9AB9) + 0 + 0 + 0 << 0);
					continue;
				case 19u:
					NotificationManager.wMBvmtooJNdrFvOudEntooWKjGLGpDoqATrbgWMSAOPHaXkcpJbGJNShQQmGIHZgzNQMeMohRuTzzoJmwIqGCHHNajlpKgkS(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ua711ꜝꜛꜙ\ua712\ua708ꜝ", 1426171772, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udc8a\udca5\udcbf\udca2\udceb\udc88\udcb9\udcaa\udcb8\udca3", 30006475, true), ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ଘତଦମତଥମ୫ପ\u0b3f\u0b3fମଦ\u0b3b\u0b3fମଯ୫\u0b3fତ୫ନହପସଣ୫ଲତ\u0b3e", 2054884171, true));
					num = (((((int)num2 + -881181427) ^ 0x7044922E) >> 0) ^ 0) >> 0 >> 0;
					continue;
				case 42u:
					num = (((int)num2 + -1506517538) ^ -476938500 ^ 0 ^ 0) << 0 << 0;
					continue;
				case 20u:
					jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa = true;
					num = ((((int)num2 + -1323094457) ^ -191002108) + 0 >> 0) + 0 - 0;
					continue;
				case 35u:
				{
					int num6;
					int num7;
					if (!flag5)
					{
						num6 = 1013933778;
						num7 = num6;
					}
					else
					{
						num6 = 546483697;
						num7 = num6;
					}
					num = (int)(((((uint)(num6 - 0 + 0) ^ (num2 + 346463589)) << 0) ^ 0) - 0 + 0);
					continue;
				}
				case 21u:
					num = ((((int)num2 + -1823466401) ^ -645745436 ^ 0) << 0) + 0 - 0;
					continue;
				case 22u:
					num = (0x3749DFCB ^ 0) + 0;
					continue;
				case 49u:
					qiiWsygOGzSCFzPpZzdGSdHaeaTxLAlBCMuvwLaWicjwATWhoHFFIPanBiSrFIcgoraTetSnzgyQTkAkeLjeVGSNMhToSIqzZdijTccUOrfCqjtqHHnTzYkHymhWAEuRPYRQbrqcIppEAqwCNCGluxaaSBKHVgukWoMssDpqqkkkJGgiPEjXX = MHjSDJHaGioVpFJEFhyQFTCeOuhqgROobFkZFRNezLObRcYZBiTgrekTfeejBrUPuaTJuKZNuuqTeBnMwiOXXHXXvqUANECiRZHRioERifMXNqODRsMsCWRMcWodPzaQRicfUvDiEXPRUZjeBqIvRkFVhUOmZAbJfWfFoJIvOEOEhZRdNjCzQEYHChXaHrieWfMYTDQSHmGnvbNicKzQYCTAYycgLINxvKIbnTjjsJRDYKlBtPXWRrftllavAJgZyjRLsLViBpxoLpCnmBNWKRFeEoQbTNIICRePTAjHTOvBTRIWJNjZWjoHDNhdVUpOHPLTlNtMsfdVwdkMGTrgEIMtDwlgtfLZzGUefPKVtxHQgslzCuxbCjjYdsqOBntmtdwPj;
					num = 0x4F6CD20B ^ 0;
					continue;
				case 23u:
					laUCCmusBIkMVlqGmYjDLSombpWlNhHjZKntNQjMHQkWcOVFJfrBNvotLIBnqiEuabNkYWSvOwWUIrjntqBIQfvDvUIfpWwymQWbaLHMmVNqztLtyoTZHVDVFjOdoNfRZxIRvimIJOvUrfebioGadxRqmavQWDyzPWqbLTXqbkqSAIDAfMUZhfNCGrFuMwMfqWevOdqpqpZShZQExVLkIzrKiOutoCEFykBDDiMbwFIRgVvHBbXQKBwREumZIWbOLtuWxnaojJOdQAEntNSnENVWOKYjVMszEUfMAyjoaJGaNsaePZGVdNjYyxiNoQsxrozVvRMUDEmVgUjvJUtWfxwQLgodqwZjqjJyTfIYmMsyBnRDnMduxwsTSIkoCJDgFcFXkLBE = 0f;
					num = ((((((int)num2 + -219879456) ^ 0x77E1E025) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 31u:
					jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa = false;
					num = ((int)(((num2 + 990853309) ^ 0x7BDCFAC2 ^ 0) << 0) >> 0) - 0;
					continue;
				case 24u:
					lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP = 0;
					num = ((int)(((num2 + 2084023244) ^ 0xD2A14D85u) << 0) >> 0) + 0 + 0;
					continue;
				case 25u:
					num = ((int)(((num2 + 669534340) ^ 0xEED8A05Fu) << 0) >> 0 >> 0) - 0;
					continue;
				case 44u:
					flag3 = jwsYQXAGJhCVeImDekjnpUkmPrmuBRqWwnMSttBGOJHdHpEYUEKuZJHplgjyLffSRFyRVukLIDzFmgEzNoAWgVXMFxGnkcUIEPmbRMcAuZMvkccfBJLxFiLVILmyNXAFIQbxUCIalaCgjBCDuBLBqxdwdqtfAEMwzgNubEkYaLlEFEMgiJdmlYokMEuDjDzGofHcOiCPqNBFmyQzEmWRAzlASCHwkGOxmEqzWJsahoVxxJYnNUZWGIgOUhkmAfFKYesHirCVTWKmENciDtIpHSQEyCFPzgzbIkztqrfwsecJXUjgebIhwpdgnOiFMNwNwIDtoJRlnmXDPgGEsyLxxsEthsfCizKFIpnoqQRujwTksArghEnncYpeekmWDpdOCrUzTrnCGqobyuaHbZvEmwDJZikgEVQUtfHaFRmPrLGLKoFKjFVEUzCfOlzKhgYLztHtMZbjMFmAQRZLDAXYa;
					num = (770395576 >> 0) + 0 + 0 >> 0;
					continue;
				case 34u:
					flag5 = flag4;
					num = (((((int)num2 + -1520509820) ^ -1997784227) + 0 << 0) ^ 0) << 0;
					continue;
				case 26u:
					flag = flag3;
					num = ((((int)num2 + -29651670) ^ 0x3184CE31 ^ 0) << 0 >> 0) ^ 0;
					continue;
				case 27u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -214037357;
						num4 = num3;
					}
					else
					{
						num3 = -1353319932;
						num4 = num3;
					}
					num = (((num3 + 0 << 0) ^ ((int)num2 + -1030955589)) >> 0 >> 0) - 0 - 0;
					continue;
				}
				case 28u:
					num = ((((int)num2 + -1524965430) ^ -1197702129) - 0 << 0) - 0 + 0;
					continue;
				case 37u:
					num = ((int)(((num2 + 1538676277) ^ 0x9A76C2A4u ^ 0) + 0) >> 0) + 0;
					continue;
				case 29u:
					num = (int)((((((num2 + 1742690051) ^ 0xC19C70FBu) << 0) - 0) ^ 0) << 0);
					continue;
				case 38u:
					return;
				}
				break;
			}
		}
	}

	public anti_crash()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 << (0 >> 1)) - 0 - 0 >> 0 >> (0 >> 1)) + 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 >> 0) - 0 - 0;
			}
		}
	}

	static anti_crash()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 << 0 + 0) + 0 >> 0) ^ 0) << (0 << 1) << 0 >> 0)) % 5)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					laUCCmusBIkMVlqGmYjDLSombpWlNhHjZKntNQjMHQkWcOVFJfrBNvotLIBnqiEuabNkYWSvOwWUIrjntqBIQfvDvUIfpWwymQWbaLHMmVNqztLtyoTZHVDVFjOdoNfRZxIRvimIJOvUrfebioGadxRqmavQWDyzPWqbLTXqbkqSAIDAfMUZhfNCGrFuMwMfqWevOdqpqpZShZQExVLkIzrKiOutoCEFykBDDiMbwFIRgVvHBbXQKBwREumZIWbOLtuWxnaojJOdQAEntNSnENVWOKYjVMszEUfMAyjoaJGaNsaePZGVdNjYyxiNoQsxrozVvRMUDEmVgUjvJUtWfxwQLgodqwZjqjJyTfIYmMsyBnRDnMduxwsTSIkoCJDgFcFXkLBE = 0f;
					num = (int)(((num2 + 377208505) ^ 0x4A8E42A9) + 0 - 0 + 0) >> 0;
					continue;
				case 2u:
					lvKteXpxpKPEtEMTRPFlUuvDilTyHUtCkzjcMYOVtMZRTZNaqLfufqJRZglTdQQurntUvKhSbKRivDJiyShWOYxUPscFNVRCWEzGGTFGDntvyBvwxculITGtPyfdHCffSplQdcCFmBsBEbvnWGhLBGTcXgQhNCYbioCjqEsvAPYhBfPNcRgbutElviSXluRKCqspzmXroMkLIMBSqdfWvXHOKrNhMujgXnEkMzoQUP = 0;
					num = (((((int)num2 + -725091362) ^ 0x110CE96B) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 4u:
					MHjSDJHaGioVpFJEFhyQFTCeOuhqgROobFkZFRNezLObRcYZBiTgrekTfeejBrUPuaTJuKZNuuqTeBnMwiOXXHXXvqUANECiRZHRioERifMXNqODRsMsCWRMcWodPzaQRicfUvDiEXPRUZjeBqIvRkFVhUOmZAbJfWfFoJIvOEOEhZRdNjCzQEYHChXaHrieWfMYTDQSHmGnvbNicKzQYCTAYycgLINxvKIbnTjjsJRDYKlBtPXWRrftllavAJgZyjRLsLViBpxoLpCnmBNWKRFeEoQbTNIICRePTAjHTOvBTRIWJNjZWjoHDNhdVUpOHPLTlNtMsfdVwdkMGTrgEIMtDwlgtfLZzGUefPKVtxHQgslzCuxbCjjYdsqOBntmtdwPj = 0.5f;
					num = ((((int)num2 + -956687329) ^ -230459291) - 0 << 0) - 0 - 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}
}
