using UnityEngine;
using easyInputs;

namespace REAK.Menu.mods;

internal class freeze_rig_in_menu
{
	public static void RQvshcmrMvGvOLpvGFYQflDEdNdyDAWJLcWXSekYSmrzxreYVqDJkqeFmRpuZOOlzWKMPsDBvZYSTegLJeCmWnzvXqLbPPZdygaBHrjDNcnkslLhKDLUmBolwoOyGCMFaVuNeFdrVYzUZpcMEDqlefQWROesDKWlpIjxRYdfAuZoctlgmbTdlBBVexWpAKNkbnFrfFUGAlKKf()
	{
		bool flag2 = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0) ^ -0 ^ 0) << 0 >> 0) ^ 0) << 0 << 0)) % 24)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					flag2 = !EasyInputs.GetSecondaryButtonDown((EasyHand)0);
					num = (int)((((num2 + 2106842273) ^ 0xD3A664C8u) - 0 << 0) ^ 0) >> 0;
					continue;
				case 2u:
				{
					int num5;
					int num6;
					if (!flag2)
					{
						num5 = 1164007847;
						num6 = num5;
					}
					else
					{
						num5 = 385883694;
						num6 = num5;
					}
					num = ((num5 << 0 >> 0) ^ ((int)num2 + -692261737) ^ 0 ^ 0) - 0 << 0;
					continue;
				}
				case 23u:
					num = (((int)num2 + -1284218664) ^ -557398540 ^ 0) + 0 >> 0 << 0;
					continue;
				case 15u:
					num = ((0x2691881D ^ 0) << 0 >> 0) - 0;
					continue;
				case 3u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = (((int)num2 + -1127256878) ^ -613003807) + 0 + 0 << 0 >> 0;
					continue;
				case 4u:
					num = (((((int)num2 + -295483064) ^ 0x1C678C51) << 0) + 0 >> 0) - 0;
					continue;
				case 5u:
					num = ((((int)num2 + -517084339) ^ -1390308279) >> 0) - 0 << 0 >> 0;
					continue;
				case 21u:
					((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
					num = (((int)(((num2 + 202644353) ^ 0x66EFD17E) - 0) >> 0) ^ 0) + 0;
					continue;
				case 19u:
					num = (int)(((num2 + 1464826632) ^ 0xC765367Fu) + 0 - 0 + 0 + 0);
					continue;
				case 6u:
					num = 0x46FA1C1F ^ 0;
					continue;
				case 7u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = ((((int)num2 + -1395914388) ^ -2098260845) << 0) - 0 + 0 - 0;
					continue;
				case 8u:
					num = (int)((((num2 + 1319775793) ^ 0xEFFD11B0u) << 0) + 0 << 0 << 0);
					continue;
				case 16u:
					num = (int)((((num2 + 2008734093) ^ 0xD5882484u) + 0 << 0) - 0 << 0);
					continue;
				case 9u:
					num = (int)(((((num2 + 747032882) ^ 0x17C760A7) << 0) ^ 0) + 0 + 0);
					continue;
				case 20u:
					flag = !EasyInputs.GetSecondaryButtonDown((EasyHand)0);
					num = (0x23CB3702 ^ 0) + 0;
					continue;
				case 10u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = -349074211;
						num4 = num3;
					}
					else
					{
						num3 = -1943022807;
						num4 = num3;
					}
					num = (((int)((uint)(num3 << 0 << 0) ^ (num2 + 1767936784)) >> 0 >> 0) ^ 0) >> 0;
					continue;
				}
				case 14u:
					num = ((((int)((num2 + 277960658) ^ 0x26B6E0EA) >> 0) ^ 0) << 0) - 0;
					continue;
				case 11u:
					num = (((((int)num2 + -1240604248) ^ -410353161 ^ 0) << 0) ^ 0) << 0;
					continue;
				case 12u:
					((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
					num = (int)(((num2 + 1766035264) ^ 0xACB0FCF2u ^ 0 ^ 0 ^ 0) - 0);
					continue;
				case 22u:
					num = (((int)num2 + -884422112) ^ -1414718629) - 0 >> 0 << 0 >> 0;
					continue;
				case 17u:
					num = ((int)(((num2 + 1448286972) ^ 0x3868127F) << 0) >> 0 >> 0) - 0;
					continue;
				case 13u:
					num = ((int)(((num2 + 1726140) ^ 0x2B9D2BC7) - 0) >> 0) ^ 0 ^ 0;
					continue;
				case 18u:
					return;
				}
				break;
			}
		}
	}

	public freeze_rig_in_menu()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num << 0 >> 0 + 0 << 0 << 0 >> 0 << (0 >> 1) >> 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 >> 0 << 0) + 0;
			}
		}
	}
}
