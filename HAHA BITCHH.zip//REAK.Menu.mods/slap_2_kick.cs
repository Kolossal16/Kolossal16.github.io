using GorillaLocomotion;
using GorillaNetworking;
using Il2CppSystem;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace REAK.Menu.mods;

internal class slap_2_kick
{
	public static void xcjRsPOkFyNaTGamVeLnoXWVZTvjCIucLtcXZrJeoOOKhFCOFeUdKSQzgnRyuEIXeKozEcmDvHYAjmOuqGExOrsSDCRMzlKJfRFwqdjCRqHdTqpTzxhNaljNsvWblAdkWourGsdnxbFxJoZnnXmceWJUISeUhhrrmxgFVYmhtTqZFLedwIOnnbfaFzJOoigpKokliuroKfIkFKpWOaxysdelrgZvpyTkMboqASVcrADhsVuVkManLIWHjYTbuWZmmyxEvYvVeuhSAWTwLdkDxFzefHhCZTIuAqVUxPzmqfiqBdhnfxpqLwOHYtzORTVkMMsjbZZVDYnswjDbATwCErJeCnVeqLvwjXEOLYlgytMMjvkPPxnXxtGucoGNeUFSDQjyFOqCHqekEXVhdfoSyxYQrjLwrycDOUjsmLkahLqgpwQftzKYGMtgSshvcTkjoBvJ()
	{
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_060c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0611: Unknown result type (might be due to invalid IL or missing references)
		float num8 = default(float);
		RaycastHit[] array = default(RaycastHit[]);
		RaycastHit[] array2 = default(RaycastHit[]);
		int num12 = default(int);
		RaycastHit val2 = default(RaycastHit);
		PhotonView componentInParent = default(PhotonView);
		bool flag5 = default(bool);
		bool flag3 = default(bool);
		bool flag4 = default(bool);
		Player owner = default(Player);
		int num3 = default(int);
		PhotonView val = default(PhotonView);
		bool flag = default(bool);
		bool flag2 = default(bool);
		int num4 = default(int);
		while (true)
		{
			int num = 1758301821;
			while (true)
			{
				uint num2;
				int num7;
				int num9;
				switch ((num2 = (uint)(((((num << 0 << -0 >> 0) ^ 0) << 0 >> (0 << 1)) ^ 0) - 0)) % 44)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num8 = 0.3f;
					num = ((((int)num2 + -1008375456) ^ 0x1975F803) + 0 + 0 - 0) ^ 0;
					continue;
				case 2u:
					array = Il2CppArrayBase<RaycastHit>.op_Implicit((Il2CppArrayBase<RaycastHit>)(object)Physics.RaycastAll(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, num8));
					num = (((int)((num2 + 1457370637) ^ 0x97272722u) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 37u:
					num = ((int)(((num2 + 1956669763) ^ 0x801ACA9Bu) - 0 + 0) >> 0) - 0;
					continue;
				case 39u:
					num = (int)(((((num2 + 671236913) ^ 0xB058C77Au) << 0) ^ 0) - 0 - 0);
					continue;
				case 3u:
					array2 = array;
					num = (((int)num2 + -2071082168) ^ -2101874821 ^ 0) - 0 - 0 - 0;
					continue;
				case 4u:
					num12 = 0;
					num = ((((((int)num2 + -434831334) ^ -467125517) << 0) + 0) ^ 0) >> 0;
					continue;
				case 5u:
					num = (int)(((num2 + 461443217) ^ 0x6872A2E9) - 0 - 0 - 0 + 0);
					continue;
				case 32u:
					num12++;
					num = (int)((((num2 + 289010447) ^ 0x44401030) + 0 - 0 << 0) - 0);
					continue;
				case 40u:
					val2 = array2[num12];
					num = ((0x49E2A526 ^ 0) >> 0) + 0 + 0;
					continue;
				case 6u:
					num = ((int)(((num2 + 1376848916) ^ 0xDD09AD3Du) << 0) >> 0 << 0) + 0;
					continue;
				case 7u:
					componentInParent = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>();
					num = (((int)num2 + -182552646) ^ 0x4D31A2D1) + 0 + 0 - 0 + 0;
					continue;
				case 8u:
					if ((Object)(object)componentInParent != (Object)null)
					{
						num = (((((int)num2 + -1563535789) ^ 0x43D9C98E ^ 0) >> 0) ^ 0) << 0;
						continue;
					}
					num7 = 0;
					goto IL_06be;
				case 43u:
				{
					int num15;
					int num16;
					if (num12 < array2.Length)
					{
						num15 = 1422392308;
						num16 = num15;
					}
					else
					{
						num15 = 319880737;
						num16 = num15;
					}
					num = ((num15 << 0 >> 0) ^ 0) - 0;
					continue;
				}
				case 9u:
					num7 = ((componentInParent.Owner != null) ? 1 : 0);
					goto IL_06be;
				case 41u:
					flag5 = flag3;
					num = ((((int)num2 + -1829903696) ^ -575990701) >> 0 >> 0) - 0 >> 0;
					continue;
				case 10u:
				{
					int num13;
					int num14;
					if (!flag5)
					{
						num13 = 4392603;
						num14 = num13;
					}
					else
					{
						num13 = 1085903003;
						num14 = num13;
					}
					num = ((int)((uint)(num13 + 0 >> 0) ^ (num2 + 502420178)) >> 0) + 0 + 0 >> 0;
					continue;
				}
				case 29u:
				{
					int num10;
					int num11;
					if (flag4)
					{
						num10 = -1742775500;
						num11 = num10;
					}
					else
					{
						num10 = -1526252888;
						num11 = num10;
					}
					num = ((num10 >> 0 >> 0) ^ ((int)num2 + -1955980126)) - 0 + 0 - 0 - 0;
					continue;
				}
				case 11u:
					num = (int)(((((num2 + 1855391286) ^ 0x3F006479) + 0 + 0) ^ 0) << 0);
					continue;
				case 12u:
					owner = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = ((int)((((num2 + 1919092371) ^ 0xD7917753u) + 0) ^ 0) >> 0) + 0;
					continue;
				case 36u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)((((num2 + 1363915621) ^ 0x2DAE71B8) - 0 - 0 << 0) + 0);
					continue;
				case 28u:
					flag4 = num3 < 10;
					num = 0x4C096C71 ^ 0;
					continue;
				case 13u:
					num = (int)((((num2 + 823506666) ^ 0x1C868BE9) + 0 - 0 << 0) ^ 0);
					continue;
				case 14u:
					GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Add(owner.UserId);
					num = ((((int)num2 + -1504328649) ^ 0x61189B2A) - 0 << 0) ^ 0 ^ 0;
					continue;
				case 15u:
					num = ((((int)num2 + -1204999380) ^ 0x38D6FA2C) >> 0) + 0 + 0 << 0;
					continue;
				case 35u:
					PhotonNetworkController.instance.friendIDList.Add(owner.UserId);
					num = (((((int)num2 + -1172829669) ^ -1260134170) >> 0) - 0 >> 0) - 0;
					continue;
				case 26u:
					num = (((int)num2 + -1031415661) ^ -304925962 ^ 0) >> 0 >> 0 >> 0;
					continue;
				case 16u:
					num = ((int)((num2 + 2112378798) ^ 0xCBBFA267u) >> 0 << 0) + 0 << 0;
					continue;
				case 17u:
					val = PhotonView.Get((Component)(object)((Component)GorillaGameManager.instance).GetComponent<GorillaGameManager>());
					num = (((int)num2 + -1907731796) ^ -262198753) - 0 << 0 >> 0 >> 0;
					continue;
				case 18u:
					if ((Object)(object)val != (Object)null)
					{
						num = (int)(((((num2 + 1006238481) ^ 0xEE115028u) - 0) ^ 0) + 0 - 0);
						continue;
					}
					num9 = 0;
					goto IL_0928;
				case 30u:
					num = (0x41FE8F47 ^ 0) - 0;
					continue;
				case 19u:
					num9 = (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(owner.UserId) ? 1 : 0);
					goto IL_0928;
				case 42u:
					flag = flag2;
					num = (int)(((((num2 + 1143130223) ^ 0x4181C445) + 0 + 0) ^ 0) << 0);
					continue;
				case 20u:
				{
					int num5;
					int num6;
					if (!flag)
					{
						num5 = -780530280;
						num6 = num5;
					}
					else
					{
						num5 = -507087917;
						num6 = num5;
					}
					num = ((num5 - 0 - 0) ^ ((int)num2 + -1100503962) ^ 0 ^ 0 ^ 0) << 0;
					continue;
				}
				case 27u:
					num3 = num4 + 1;
					num = (((((int)num2 + -2113674766) ^ -790692163) << 0) + 0 >> 0) - 0;
					continue;
				case 21u:
					num = (int)((((num2 + 2020444366) ^ 0xE69F0005u) + 0 << 0) + 0) >> 0;
					continue;
				case 22u:
					num3 = 0;
					num = ((((int)num2 + -1290885437) ^ 0x1026A0CB) << 0 >> 0 << 0) ^ 0;
					continue;
				case 38u:
					num = (int)((((num2 + 2050821622) ^ 0xFEFDE5DCu) << 0) - 0 + 0 - 0);
					continue;
				case 23u:
					num = 900749764 - 0 - 0 >> 0 >> 0;
					continue;
				case 31u:
					num = ((0x6D132F8 ^ 0) << 0) + 0 + 0;
					continue;
				case 24u:
					val.RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ꡰꡕꡓꡔꡪꡏꡘꡭꡓꡎꡒ\ua87cꡈꡟꡓꡔꡞꡉ", 1882957882, true), owner, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 1115582667) ^ 0x1B6782CE) + 0 - 0 + 0) ^ 0);
					continue;
				case 25u:
					num = ((((int)num2 + -43473754) ^ 0x558DDE5) << 0 >> 0) + 0 >> 0;
					continue;
				case 34u:
					num4 = num3;
					num = (((int)((num2 + 1609311921) ^ 0xE83E1A25u) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 33u:
					return;
					IL_06be:
					flag3 = (byte)num7 != 0;
					num = (0x6B7240A9 ^ 0) << 0;
					continue;
					IL_0928:
					flag2 = (byte)num9 != 0;
					num = ((0x394A8B7E ^ 0) << 0) + 0;
					continue;
				}
				break;
			}
		}
	}

	public slap_2_kick()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num + 0 - (0 ^ 0) << 0 >> 0 >> 0) - (0 ^ 0) + 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB1) - 0 >> 0) ^ 0) << 0;
			}
		}
	}
}
