using GorillaLocomotion;
using Il2CppSystem;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace REAK.Menu.mods;

internal class fuckcsmtcs_gun
{
	public static void BUxCXgBQTZOgosucNFPGOmPOUbHhmCaQRPCDyNCEmthnQkRmAENFVdroeJIWzuDqZYpzPQDacltufBXJkvGIPuVNxnyPfFfRPRoSVrwJbNDJJWjDLYMdOVAEdBbBsNUwgCEnneOSYWHcRldBeUehTbdUqJPtqUrnSgChsWqGjUfRoyNRxAxxJNDfyKXDpuBeEtkKIWihExXZVlFSVXWQwTDeDxJIYMrPsamUncjBrpTmQDjmeeHryLHLQghlmAiRgiHVYKESOuygarnZnwDUfZqGtBehVXoQgbfIWontzOCdmALzShXPXoMhRaBxGxXRfIZYlFdZjjuqwmtSQFpOazTSpYQVMQNcRLYEBMnmdYGNUvKEHJGbiiQGOhInOhmtwsyLoOrdrcLcSfYTomocjLUJUrPteaxVLmrBXYpSsDKfxONJjOZCTkjKxPQ()
	{
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_061f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0484: Unknown result type (might be due to invalid IL or missing references)
		//IL_0858: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val3 = default(RaycastHit);
		GameObject val4 = default(GameObject);
		PhotonView val = default(PhotonView);
		Player owner = default(Player);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		GameObject val2 = default(GameObject);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0 ^ 0) >> 0 << 0) + 0 + (0 >> 1) << 0) - 0)) % 36)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val3);
					num = (int)(((num2 + 1333463150) ^ 0x8D8F98F5u) + 0 - 0 + 0) >> 0;
					continue;
				case 2u:
					val4 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (((((int)num2 + -227232852) ^ 0x33B8213F) - 0) ^ 0) - 0 >> 0;
					continue;
				case 29u:
					val4.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (int)(((((num2 + 1107201870) ^ 0x4DBCF778) << 0) + 0) ^ 0) >> 0;
					continue;
				case 23u:
					num = (int)((num2 + 1115582667) ^ 0xA45B1B2Au ^ 0) >> 0 << 0 >> 0;
					continue;
				case 3u:
					num = (int)((((((num2 + 1548432940) ^ 0x7AF2027F) + 0) ^ 0) << 0) - 0);
					continue;
				case 4u:
					val4.transform.position = ((RaycastHit)(ref val3)).point;
					num = (((int)num2 + -1008375456) ^ -1025921963) << 0 << 0 >> 0 >> 0;
					continue;
				case 5u:
					num = (((int)((num2 + 1457370637) ^ 0x3B51C189) >> 0 << 0) ^ 0) >> 0;
					continue;
				case 25u:
					num = 1709781262 + 0 - 0 + 0 - 0;
					continue;
				case 31u:
					Object.Destroy((Object)(object)val4.GetComponent<BoxCollider>());
					num = (int)((((num2 + 1956669763) ^ 0x808AC034u) - 0 + 0 << 0) - 0);
					continue;
				case 6u:
					num = ((((int)num2 + -2071082168) ^ -2004194227) + 0 - 0 << 0) + 0;
					continue;
				case 7u:
					Object.Destroy((Object)(object)val4.GetComponent<Rigidbody>());
					num = (((int)num2 + -434831334) ^ 0x5C262D35) >> 0 >> 0 << 0 >> 0;
					continue;
				case 8u:
					num = (int)(((num2 + 461443217) ^ 0xDC840F50u) - 0 - 0 - 0 - 0);
					continue;
				case 34u:
					num = (((int)(((num2 + 590235451) ^ 0x94B56CB2u) + 0) >> 0) - 0) ^ 0;
					continue;
				case 9u:
					Object.Destroy((Object)(object)val4.GetComponent<Collider>());
					num = (((((int)num2 + -645064961) ^ 0x42C92574) + 0 << 0) ^ 0) + 0;
					continue;
				case 32u:
					num = ((int)((num2 + 452787187) ^ 0xA5A40A89u) >> 0) + 0 >> 0 << 0;
					continue;
				case 10u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val4, Color.red);
					num = (int)(((num2 + 1559511532) ^ 0x81BB61A5u) - 0 + 0 + 0 << 0);
					continue;
				case 30u:
					num = ((((int)num2 + -877465945) ^ 0x4D901C4A) - 0 + 0 << 0) + 0;
					continue;
				case 11u:
					num = (((((int)num2 + -1883148872) ^ -1067516437) >> 0) + 0 << 0) ^ 0;
					continue;
				case 12u:
					Object.Destroy((Object)(object)val4, Time.deltaTime);
					num = (int)(((((num2 + 1603745309) ^ 0xA55D479Du) << 0) - 0 << 0) - 0);
					continue;
				case 28u:
					num = (((int)num2 + -40093842) ^ 0x5819F587 ^ 0) >> 0 >> 0 << 0;
					continue;
				case 22u:
					val.RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("摈摿摫摯摿摩摮摙摵摩摷摿摮摳摹摩", 630023194, true), owner, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 1198527402) ^ 0x8C9933FAu) << 0) ^ 0) << 0) >> 0;
					continue;
				case 13u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = ((int)((num2 + 1868189554) ^ 0xDADD329Du) >> 0 >> 0) - 0 << 0;
					continue;
				case 14u:
				{
					int num5;
					int num6;
					if (triggerButtonDown)
					{
						num5 = 2132819986;
						num6 = num5;
					}
					else
					{
						num5 = 77074982;
						num6 = num5;
					}
					num = (((num5 >> 0 >> 0) ^ ((int)num2 + -1198723765)) - 0 + 0 >> 0) - 0;
					continue;
				}
				case 15u:
					num = (int)(((num2 + 207985003) ^ 0x54EE6825) - 0 - 0) >> 0 << 0;
					continue;
				case 35u:
					flag = Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>());
					num = ((((int)num2 + -1804281275) ^ -280227704) << 0 << 0) + 0 >> 0;
					continue;
				case 26u:
					num = 497161467 - 0 + 0 + 0 >> 0;
					continue;
				case 16u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 1984078252;
						num4 = num3;
					}
					else
					{
						num3 = 210141520;
						num4 = num3;
					}
					num = (int)(((((uint)((num3 >> 0) - 0) ^ (num2 + 461723281)) << 0) + 0 << 0) + 0);
					continue;
				}
				case 17u:
					num = ((((((int)num2 + -1372250924) ^ -1874193345) << 0) ^ 0) >> 0) - 0;
					continue;
				case 18u:
					val2 = val4;
					num = (((int)num2 + -1403453257) ^ 0x7E724EF2) - 0 - 0 >> 0 >> 0;
					continue;
				case 24u:
					num = ((((int)num2 + -43473754) ^ 0x1EF3B3CC) - 0 << 0 << 0) - 0;
					continue;
				case 19u:
					owner = ((Component)((RaycastHit)(ref val3)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (int)(((((num2 + 293113464) ^ 0xB646E06Eu) << 0) ^ 0) + 0 + 0);
					continue;
				case 33u:
					val2.GetComponent<Renderer>().material.color = Color.green;
					num = (((int)(((num2 + 1866650904) ^ 0x9461F731u) + 0) >> 0) + 0) ^ 0;
					continue;
				case 20u:
					num = (int)(((num2 + 641832775) ^ 0x79BC60CE) + 0) >> 0 >> 0 >> 0;
					continue;
				case 21u:
					val = GorillaGameManager.instance.FindVRRigForPlayer(owner);
					num = (int)((((num2 + 435749897) ^ 0x40EB8B7C) << 0) - 0 - 0 - 0);
					continue;
				case 27u:
					return;
				}
				break;
			}
		}
	}

	public fuckcsmtcs_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0) ^ -0) >> 0) - 0 << 0) - (0 << 1) << 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB1) - 0) ^ 0) - 0) ^ 0;
			}
		}
	}
}
