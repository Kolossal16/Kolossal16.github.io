using MenuTemplate;

namespace REAK.Menu.mods;

internal class fix_handtap
{
	public static void qOuNWSWYWLbVbNzYnkTCLNcQjgYotujAXrdjxUUzBbNapdbCsSDmYvmCLDDPTHFBBAYJKpAsqtbJacBgfwWBRWCBfAxUqeFTwlyOerRcslWEuDCJcxJxLdKFYwEjSFblNhnODMcNEUiFZXhCYNRTviisATQHNHjMjLRnpNgqvWSRUfFapclfNiQFYUnJWuaWLwvogTmkHByzprxvoPsKwdYbVmovAwtaVVfyJqUvQbymJrpGwRvgcpAHyutUEQKkhxDtlZMXVWUuFMrDXIYIanYFvyaoXZQZrnemNVvwfykfvgbLcPXWRckUyYYNZxaVfVcrHfQbmBCCcSkowomhcThpdkNPWIxHypazdKeXZVKqzIRFNJqLlSTlNNoxrafEeVdNSKlMkoihj()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) << (0 << 1) >> 0) + 0) ^ 0 ^ 0) - 0 - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					soundspammers.ESIAcCByKfVFHgXziUpfXWVPJvWsdAYMehwLQYPcmbXLAHZcdhVObdQHWTQHGivkgjAAKmJkfmSWZkpcvTpVEkKbqOOWhivdFMEqhzrRyLJPkTILEOlMTzGWzyjWxMcWQOqmGYUWCyxTBURwfcssWJkfgHRIpvtLIMYvCw(8, 0f, 0f, 1f);
					num = (((int)num2 + -1874950498) ^ -859104563) - 0 + 0 - 0 << 0;
					continue;
				case 2u:
					num = (((int)(((num2 + 414745695) ^ 0x55FC76F6) << 0) >> 0) + 0) ^ 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public fix_handtap()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) + -0 - 0) ^ 0) << 0) + (0 ^ 0) << 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 << 0 >> 0) ^ 0;
			}
		}
	}
}
