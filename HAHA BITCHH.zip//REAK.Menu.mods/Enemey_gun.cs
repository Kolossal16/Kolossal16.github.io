using GorillaLocomotion;
using Il2CppSystem;
using MenuTemplate;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace REAK.Menu.mods;

internal class Enemey_gun
{
	public static void gQSvRGUJAnIugZxkeHRixUvZeZkEaewAeghZeymlqGlyjZpQjTAtxsJmvTqSvqIvQhpaSxfGvGRRIWPfKuugEdcMwUElitQZXQIbJoXMOTXRASEydkhaWCQNfDDXTTybQSTRoNwvwHrKflmEqghXmPduaUWfLaTVvWaIYMjqOMDpkfHTrZGNLAPaOyRtRqKwOwojkEFEWRjzmOkUncOMtgjVgaTzUQyxcgANQyINtcQTrpOaoWgOCXdHntckKfJgsLxfnxeOtbsrppERmSlXJKVedSAwwycnsKBFSINRSsuAFLsXPlYSULwIQtbuWHsVZeYEOYYDeufrpuyrACHkzjtGoSPyGtUkayBANNjQmvOzFfsvUKTuahwPLsqVjzXLAVqQTYEMsRYevUaiztEWzzjScLPuxnGMycZKOCBWfhbjiruQrhwPValaLyNhijofkmGsVqtXRIQsxaKLrYcqRQRxRYY()
	{
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0550: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0721: Unknown result type (might be due to invalid IL or missing references)
		//IL_065f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0661: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val = default(RaycastHit);
		GameObject val3 = default(GameObject);
		Vector3 val4 = default(Vector3);
		Vector3 val2 = default(Vector3);
		Quaternion rotation = default(Quaternion);
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num - 0 - (0 ^ 0)) ^ 0) + 0 + 0) ^ 0) >> 0) ^ 0u) % 32)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val);
					num = (int)((((num2 + 1665746989) ^ 0xF9D1D92Cu ^ 0 ^ 0) + 0) ^ 0);
					continue;
				case 2u:
					val3 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = (int)(((num2 + 770395556) ^ 0x7831BF3B) + 0 + 0) >> 0 << 0;
					continue;
				case 29u:
					val3.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = ((int)(((num2 + 1333463150) ^ 0x7AC06DA8) << 0) >> 0 << 0) + 0;
					continue;
				case 23u:
					num = (int)((((num2 + 1880337016) ^ 0x8A302537u) - 0 << 0) + 0 + 0);
					continue;
				case 3u:
					num = (((((int)num2 + -227232852) ^ 0x14C8848B) + 0) ^ 0) - 0 << 0;
					continue;
				case 4u:
					val3.transform.position = ((RaycastHit)(ref val)).point;
					num = (((int)((num2 + 1107201870) ^ 0x40C2C9B7) >> 0) ^ 0) - 0 << 0;
					continue;
				case 5u:
					num = ((int)(((num2 + 1548432940) ^ 0x21C441AE) - 0) >> 0 << 0) + 0;
					continue;
				case 26u:
					num = (int)(((num2 + 1493219093) ^ 0xAEA7D53Bu) + 0 - 0 - 0 << 0);
					continue;
				case 31u:
					Object.Destroy((Object)(object)val3.GetComponent<BoxCollider>());
					num = ((((int)num2 + -1008375456) ^ 0x514FC019 ^ 0) << 0) - 0 + 0;
					continue;
				case 6u:
					num = (((int)((num2 + 1457370637) ^ 0xE63A4734u) >> 0) + 0 << 0) - 0;
					continue;
				case 7u:
					Object.Destroy((Object)(object)val3.GetComponent<Rigidbody>());
					num = (int)(((((num2 + 1956669763) ^ 0xCAB3B462u) - 0 + 0) ^ 0) + 0);
					continue;
				case 8u:
					num = ((((int)num2 + -2071082168) ^ -1516719463) - 0 + 0) ^ 0 ^ 0;
					continue;
				case 20u:
					val4 = val2;
					num = (int)(((((num2 + 2022602987) ^ 0xAFE95F4Au ^ 0) << 0) ^ 0) << 0);
					continue;
				case 9u:
					Object.Destroy((Object)(object)val3.GetComponent<Collider>());
					num = ((((int)num2 + -434831334) ^ 0x5D310F9A) >> 0 >> 0) ^ 0 ^ 0;
					continue;
				case 25u:
					num = ((int)((num2 + 461443217) ^ 0xA5386620u) >> 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 10u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val3, Color.magenta);
					num = ((((int)num2 + -645064961) ^ -61057214 ^ 0) << 0 >> 0) - 0;
					continue;
				case 30u:
					num = ((((int)num2 + -117175874) ^ 0x7F213B6B) >> 0) + 0 >> 0 >> 0;
					continue;
				case 11u:
					num = (int)((((num2 + 452787187) ^ 0x4C9A6E32) << 0) + 0 + 0 + 0);
					continue;
				case 12u:
					Object.Destroy((Object)(object)val3, Time.deltaTime);
					num = (((int)((num2 + 1559511532) ^ 0xB8E04A44u ^ 0) >> 0) ^ 0) + 0;
					continue;
				case 28u:
					num = ((((((int)num2 + -1883148872) ^ -299581447) >> 0) - 0) ^ 0) + 0;
					continue;
				case 22u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᣎᣆᣛᣀᣅᣅᣈᣙᣛᣌᣏᣈᣋᣚ\u1886ᣎᣆᣛᣀᣅᣅᣈᣌᣇᣌᣄᣐ", 1034688681, true), val4, rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 1100433178) ^ 0x82B1C06Eu) + 0) ^ 0 ^ 0) << 0);
					continue;
				case 13u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (int)(((num2 + 1603745309) ^ 0xCA000824u ^ 0) + 0 - 0) >> 0;
					continue;
				case 14u:
					flag = triggerButtonDown;
					num = (((int)num2 + -40093842) ^ 0x38531633) << 0 >> 0 >> 0 >> 0;
					continue;
				case 15u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1043986598;
						num4 = num3;
					}
					else
					{
						num3 = 756558085;
						num4 = num3;
					}
					num = ((num3 + 0 << 0) ^ ((int)num2 + -1519429041)) - 0 + 0 - 0 - 0;
					continue;
				}
				case 27u:
					num = ((((int)num2 + -1198723765) ^ -1957427306 ^ 0) - 0 - 0) ^ 0;
					continue;
				case 21u:
					rotation = ((Component)Player.Instance.bodyCollider).transform.rotation;
					num = (int)((((((num2 + 1121261575) ^ 0x2907BF6A) + 0) ^ 0) << 0) - 0);
					continue;
				case 16u:
					num = (int)(((num2 + 207985003) ^ 0x793D648A) + 0 + 0 << 0) >> 0;
					continue;
				case 17u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val3, Color.green);
					num = ((((int)num2 + -1804281275) ^ -108342652) << 0 >> 0 >> 0) + 0;
					continue;
				case 18u:
					num = ((((int)num2 + -2057924117) ^ -1588789298) >> 0 >> 0) - 0 - 0;
					continue;
				case 19u:
					val2 = (((Component)Player.Instance.bodyCollider).transform.position = ((RaycastHit)(ref val)).point);
					num = (int)(((num2 + 891081771) ^ 0x8BFA3BA4u) + 0 - 0 - 0 - 0);
					continue;
				case 24u:
					return;
				}
				break;
			}
		}
	}

	public Enemey_gun()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((((num << 0) ^ 0) - 0) ^ 0) >> 0) ^ 0) - 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1) + 0 - 0 - 0 >> 0;
			}
		}
	}
}
