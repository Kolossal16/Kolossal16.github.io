using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace REAK.Menu.mods;

internal class disable_network_triggers
{
	public static void nHdyugWTQLwWPEXRtfSJlmpISvZuFIGfrYCSGoAFwItYodbGEHthNWcbsuFZhBoierEQcfkeEnmCSrtOutQXpysvWAAmIByVulTXzkEywoDzJzjaaRENLqTFZiUBFYwcOriGxwpjOrBaVSLxrzlRWKkdsoYqqdTyRALsqDCEBvYtPSJgwxkgNEfehenjyYSLxdjvhtgNWHpBLQoAERUTSNLmuHllptgDDnVMInZdqwjfpEsqQNEGdZTKsWbAhUyCBMYyUBRrSRCwDFXPoVuBOzzDuluMmzVvYHECGTvpWnOmxxgMZllmAWNbnueJheetVgxWaujuzfFBLmgXeHNbnJVbTDplPMhRivrqZjLEbRMuqmpaoh()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num >> 0) - (0 << 1) >> 0) ^ 0) >> 0) + (0 + 0) << 0) - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ZnucoCeDaRVDXXgqUKKBhRQiuQrZidBRjVmtDmAmQtzsCPHDEELRNIdhwlHykfuXpeucKMMIkyKOryFEiOvErKdBRfXsFbbLZCcyvFSRSdHpXpPXGcpwKQFFaSkFPuciwYPPwgiDWDLocNDCpaLDLEajWwxDumcxayTYzaAzTMAgerCnoIqPIzwRXGTaJFiJBnnDUEcpzmKYeUeFTkoLVnPBcbaTgAQnEQFQeYsKFbpvOxMdBngyrwNoyLBTDjiYwwuoooBUREfUXtMEoWsTurWhcrssxzgwTrZsdyPnMlHMrTqeYXFGQpEfznmWVixrxIbFuuBPhfgiJjQiaouzUzGEMUSPlTrENpoISLKEwPzLivvqxdVHNYxYcxSABLEoNBvuUhqpEQdfZUvrzCsiXJQPSqFvSjcKklXHZbvpMGdXVrYibBaZtwrdKGBECVxuNsUOWNrygcvqGSUArxtqjcqOUUWtzRNRiJkCxklnjCTraax(SLamfCgkLbfUcRYYopDiXIsdglfhGiZOTweHyEHpcyzArqjwlEFbwSAjtWgTwZECcraFMqzJHofyjRMPcJWcDXrbWVnCyOSdTXyZqDJUeVuhMbZCkqQNdBYeaYIRcXkTwcEmtMzyZbYHDjoVVLsiXfasYtZrURSgLBLJwNixQrNbDqARJNWrFcVrcmnZNhEhiRWcxFyhCVrFrYOHThHhVABJFuHjzjJINFSMuxteoOOKKpZeyGgGAwmHqnxdYoItlJRMfcnvNDSgMQYpuCLTdcirtkvhaqgagvybynZwtKSWEgVzohIvDPqjAAsUGfuxwSZrsXRhDpAsjlNnpWSTHKwrepBXUePnpvzLgEgrqBSnpXZoNfFJnBPMvImdwUmyzmcOLbgLQBDgSjcgpmjOzgZOGNqxrdVwptOcVlCMYUTMYJUmGgNjKxZtmnhYLJtMFhQyualeJxPFmnQXTdRlpLLRtvPHdEapAg(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ud8bb\ud890\ud881\ud882\ud89a\ud887\ud89e\ud8a1\ud887\ud89c\ud892\ud892\ud890\ud887\ud886\ud8da\ud8bb\ud890\ud881\ud882\ud89a\ud887\ud89e\ud89c\ud89b\ud892\ud8d5\ud8a1\ud887\ud89c\ud892\ud892\ud890\ud887", 748017909, true)), bool_0: false);
					num = (((((int)num2 + -1874950498) ^ -859104563) >> 0) - 0 << 0) ^ 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) << 0) - 0 - 0 << 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public static void EzrdfmkwdxfXFNXOsqVPXUViZwWBLGnpXIhIzfpefDgozelZwBUZfyjKDieIqJKwjQaWGppnaQKuOHJVkWejMojyyweqaGOvSJeJdptglGYoOOVWzjytFAKVGByjl()
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) + (0 << 1) << 0) ^ 0 ^ 0) >> (0 >> 1) >> 0) - 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					ZnucoCeDaRVDXXgqUKKBhRQiuQrZidBRjVmtDmAmQtzsCPHDEELRNIdhwlHykfuXpeucKMMIkyKOryFEiOvErKdBRfXsFbbLZCcyvFSRSdHpXpPXGcpwKQFFaSkFPuciwYPPwgiDWDLocNDCpaLDLEajWwxDumcxayTYzaAzTMAgerCnoIqPIzwRXGTaJFiJBnnDUEcpzmKYeUeFTkoLVnPBcbaTgAQnEQFQeYsKFbpvOxMdBngyrwNoyLBTDjiYwwuoooBUREfUXtMEoWsTurWhcrssxzgwTrZsdyPnMlHMrTqeYXFGQpEfznmWVixrxIbFuuBPhfgiJjQiaouzUzGEMUSPlTrENpoISLKEwPzLivvqxdVHNYxYcxSABLEoNBvuUhqpEQdfZUvrzCsiXJQPSqFvSjcKklXHZbvpMGdXVrYibBaZtwrdKGBECVxuNsUOWNrygcvqGSUArxtqjcqOUUWtzRNRiJkCxklnjCTraax(SLamfCgkLbfUcRYYopDiXIsdglfhGiZOTweHyEHpcyzArqjwlEFbwSAjtWgTwZECcraFMqzJHofyjRMPcJWcDXrbWVnCyOSdTXyZqDJUeVuhMbZCkqQNdBYeaYIRcXkTwcEmtMzyZbYHDjoVVLsiXfasYtZrURSgLBLJwNixQrNbDqARJNWrFcVrcmnZNhEhiRWcxFyhCVrFrYOHThHhVABJFuHjzjJINFSMuxteoOOKKpZeyGgGAwmHqnxdYoItlJRMfcnvNDSgMQYpuCLTdcirtkvhaqgagvybynZwtKSWEgVzohIvDPqjAAsUGfuxwSZrsXRhDpAsjlNnpWSTHKwrepBXUePnpvzLgEgrqBSnpXZoNfFJnBPMvImdwUmyzmcOLbgLQBDgSjcgpmjOzgZOGNqxrdVwptOcVlCMYUTMYJUmGgNjKxZtmnhYLJtMFhQyualeJxPFmnQXTdRlpLLRtvPHdEapAg(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䇗䇼䇭䇮䇶䇫䇲䇍䇫䇰䇾䇾䇼䇫䇪䆶䇗䇼䇭䇮䇶䇫䇲䇰䇷䇾䆹䇍䇫䇰䇾䇾䇼䇫", 850805145, true)), bool_0: true);
					num = ((((int)num2 + -1874950498) ^ -859104563) >> 0 << 0 << 0) + 0;
					continue;
				case 2u:
					num = (int)(((((num2 + 414745695) ^ 0x55FC76F6 ^ 0) << 0) ^ 0) << 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private static void ZnucoCeDaRVDXXgqUKKBhRQiuQrZidBRjVmtDmAmQtzsCPHDEELRNIdhwlHykfuXpeucKMMIkyKOryFEiOvErKdBRfXsFbbLZCcyvFSRSdHpXpPXGcpwKQFFaSkFPuciwYPPwgiDWDLocNDCpaLDLEajWwxDumcxayTYzaAzTMAgerCnoIqPIzwRXGTaJFiJBnnDUEcpzmKYeUeFTkoLVnPBcbaTgAQnEQFQeYsKFbpvOxMdBngyrwNoyLBTDjiYwwuoooBUREfUXtMEoWsTurWhcrssxzgwTrZsdyPnMlHMrTqeYXFGQpEfznmWVixrxIbFuuBPhfgiJjQiaouzUzGEMUSPlTrENpoISLKEwPzLivvqxdVHNYxYcxSABLEoNBvuUhqpEQdfZUvrzCsiXJQPSqFvSjcKklXHZbvpMGdXVrYibBaZtwrdKGBECVxuNsUOWNrygcvqGSUArxtqjcqOUUWtzRNRiJkCxklnjCTraax(GameObject gameObject_0, bool bool_0)
	{
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 + (0 >> 1)) ^ 0) >> 0) ^ 0) - -0 + 0 << 0)) % 4)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					gameObject_0.SetActive(bool_0);
					num = (((((int)num2 + -1874950498) ^ -859104563) << 0) + 0 << 0) - 0;
					continue;
				case 2u:
					num = (int)((((num2 + 414745695) ^ 0x55FC76F6) - 0 << 0) + 0 - 0);
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	private static GameObject SLamfCgkLbfUcRYYopDiXIsdglfhGiZOTweHyEHpcyzArqjwlEFbwSAjtWgTwZECcraFMqzJHofyjRMPcJWcDXrbWVnCyOSdTXyZqDJUeVuhMbZCkqQNdBYeaYIRcXkTwcEmtMzyZbYHDjoVVLsiXfasYtZrURSgLBLJwNixQrNbDqARJNWrFcVrcmnZNhEhiRWcxFyhCVrFrYOHThHhVABJFuHjzjJINFSMuxteoOOKKpZeyGgGAwmHqnxdYoItlJRMfcnvNDSgMQYpuCLTdcirtkvhaqgagvybynZwtKSWEgVzohIvDPqjAAsUGfuxwSZrsXRhDpAsjlNnpWSTHKwrepBXUePnpvzLgEgrqBSnpXZoNfFJnBPMvImdwUmyzmcOLbgLQBDgSjcgpmjOzgZOGNqxrdVwptOcVlCMYUTMYJUmGgNjKxZtmnhYLJtMFhQyualeJxPFmnQXTdRlpLLRtvPHdEapAg(string string_0)
	{
		GameObject result = default(GameObject);
		while (true)
		{
			int num = 1758301857;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num - 0 << 0 + 0 >> 0) + 0 + 0 - (0 << 1) + 0) ^ 0u) % 4)
				{
				case 0u:
					break;
				case 1u:
					result = GameObject.Find(string_0);
					num = ((((int)num2 + -1874950498) ^ -859104563 ^ 0) >> 0) - 0 + 0;
					continue;
				case 2u:
					num = ((int)(((num2 + 414745695) ^ 0x55FC76F6) - 0 - 0) >> 0) - 0;
					continue;
				default:
					return result;
				}
				break;
			}
		}
	}

	public disable_network_triggers()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0) ^ 0 ^ 0) >> 0) + 0 - (0 >> 1) + 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB1) << 0 << 0 << 0) - 0;
			}
		}
	}
}
