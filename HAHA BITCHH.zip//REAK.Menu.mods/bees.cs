using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using easyInputs;

namespace REAK.Menu.mods;

internal class bees
{
	public static void zyDCRfjBlypbLCpbxIafcUyyiLamAwEljbniADHESbjPTshXyGxRKALEZfugeWaPTeRJohBUbwmaLIEPEcOUYNBIqJiuiBzWbtVPAyJqfDQooLTqBEBbigRgCjtFZgLzWqZrNOpgtxPuWmuEPRTEZyNUCOmredrYSrsXMCDMpvHLrwkqOOPhnhzxDeOYCXbpfQCFUwSnngoDQbDgEWCqnjLKRUuHNFkrurFBTEvsVCTgSWHBAItFuLcVeSOabkAIWWjyvcnaAkuLqFRVmThfmEXJpKwbQvqLcljWMjfyutekqqFzaSNiduwrZAiLGmjfUIJevVic()
	{
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Expected O, but got Unknown
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		bool gripButtonDown = default(bool);
		bool flag = default(bool);
		Player[] array = default(Player[]);
		Random val2 = default(Random);
		int num3 = default(int);
		PhotonView val = default(PhotonView);
		while (true)
		{
			int num = 1758301843;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num - 0 + (0 + 0) >> 0) + 0 << 0) + -0 - 0 + 0)) % 22)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)0);
					num = (int)(((num2 + 428697817) ^ 0xB79DF8B2u) - 0 + 0 + 0) >> 0;
					continue;
				case 2u:
					flag = gripButtonDown;
					num = (((int)((num2 + 2106842273) ^ 0xA8D90EC9u) >> 0) - 0 >> 0) ^ 0;
					continue;
				case 18u:
				{
					int num4;
					int num5;
					if (!flag)
					{
						num4 = -1185606422;
						num5 = num4;
					}
					else
					{
						num4 = -495040038;
						num5 = num4;
					}
					num = (((num4 - 0 >> 0) ^ ((int)num2 + -692261737)) << 0) - 0 + 0 << 0;
					continue;
				}
				case 15u:
					num = ((((int)num2 + -11398900) ^ 0x43FDDFFA) - 0 - 0 >> 0) ^ 0;
					continue;
				case 3u:
					num = ((((((int)num2 + -1284218664) ^ -708224555) << 0) ^ 0) << 0) + 0;
					continue;
				case 4u:
					array = Il2CppArrayBase<Player>.op_Implicit((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList);
					num = ((((int)num2 + -1127256878) ^ -873222161 ^ 0 ^ 0) >> 0) - 0;
					continue;
				case 5u:
					val2 = new Random();
					num = (((((int)num2 + -295483064) ^ 0x53DC3674) + 0 << 0) ^ 0) << 0;
					continue;
				case 21u:
					num = (((((int)num2 + -202039689) ^ 0x4ECCD462) - 0 >> 0) + 0) ^ 0;
					continue;
				case 19u:
					num3 = val2.Next(array.Length);
					num = ((((int)num2 + -517084339) ^ 0x7C17420A) - 0 >> 0 << 0) ^ 0;
					continue;
				case 6u:
					val = GorillaGameManager.instance.FindVRRigForPlayer(array[num3]);
					num = (int)((((((num2 + 1464826632) ^ 0xE7C83C33u) << 0) ^ 0) << 0) ^ 0);
					continue;
				case 7u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = (int)((((num2 + 2029155507) ^ 0xCEC5A1F6u) - 0 << 0) ^ 0 ^ 0);
					continue;
				case 8u:
					num = (((((int)num2 + -649986417) ^ 0x1A456158) - 0) ^ 0) + 0 + 0;
					continue;
				case 13u:
					num = (1621957010 - 0 << 0) + 0 + 0;
					continue;
				case 9u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)val).transform.position;
					num = (int)((num2 + 660359990) ^ 0x1CF8DAB7 ^ 0 ^ 0) >> 0 >> 0;
					continue;
				case 20u:
					num = (((((int)num2 + -1950096023) ^ -721612041 ^ 0) - 0) ^ 0) - 0;
					continue;
				case 10u:
					GorillaTagger.Instance.myVRRig.head.rigTarget.localEulerAngles = Vector3.right;
					num = ((((int)num2 + -11084362) ^ 0x22260D87) + 0 << 0) + 0 << 0;
					continue;
				case 14u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = ((((int)num2 + -1856515560) ^ -1809928887 ^ 0) >> 0) + 0 >> 0;
					continue;
				case 11u:
					num = (int)(((((num2 + 1047830633) ^ 0x6FE3C2AA ^ 0) + 0) ^ 0) + 0);
					continue;
				case 12u:
					num = ((int)(((num2 + 830770635) ^ 0x974FFE54u) + 0 + 0) >> 0) + 0;
					continue;
				case 17u:
					num = (((int)num2 + -1377430272) ^ -1759741601) << 0 << 0 >> 0 << 0;
					continue;
				case 16u:
					return;
				}
				break;
			}
		}
	}

	public static void OIKSAMsZeXaXHiHHPRWmbtSijYqHGBdeKKuuJDRmhiGIlmyMbcoEYWbuQCJBwKsDUVnWNmXmaKeSNjWXADGEnyfNIaEhTqPxQdOpYBYOebEoRjHGGMaSdOqvPznNIQtJUHcJvGYZFSzlURVztXBhqXtcNtzznkfoIUtkhXlZNanloeAYDOuKoltXnaWchzLuMlDaxLsvMCupJiNISBVzQvZwAwXgaiSnpSycBAASvYXMRenfmojFEmErlgzbOlvDJgZRJLgsaddRxnFwiRULZmJdnhRvazekDucLewwBiREAiMTYAdSWrJExwWDBTKrBZTodkUrMusDhHjUBoSUXGhTTPFohTVHxzdBoyPNGLgBYfxPnbcmaQuVRauoFFjTzLgHEHGcyfnlzFUNrPbfQIGHfiKoeBibBncmZPlGvZNVCivmfGWPDecQeyBvXrYXWmKmDHOC()
	{
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f4: Expected O, but got Unknown
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_062c: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		Player[] array = default(Player[]);
		Random val2 = default(Random);
		int num3 = default(int);
		PhotonView val = default(PhotonView);
		while (true)
		{
			int num = 1758301833;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) << 0 + 0) + 0 + 0) ^ 0) - (0 >> 1) + 0) ^ 0u) % 28)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (int)(((num2 + 1952503976) ^ 0xE8E968D3u ^ 0) + 0 + 0 + 0);
					continue;
				case 2u:
					flag = triggerButtonDown;
					num = (((((int)num2 + -814951907) ^ 0x1EB00358) >> 0) - 0 << 0) + 0;
					continue;
				case 23u:
				{
					int num4;
					int num5;
					if (flag)
					{
						num4 = 433696100;
						num5 = num4;
					}
					else
					{
						num4 = 1584380537;
						num5 = num4;
					}
					num = ((((num4 + 0 << 0) ^ ((int)num2 + -295483064)) + 0 >> 0) - 0) ^ 0;
					continue;
				}
				case 19u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = (int)((((num2 + 823506666) ^ 0x97E318FBu) + 0 << 0) - 0 - 0);
					continue;
				case 3u:
					num = ((((int)num2 + -517084339) ^ -417869972) - 0 - 0) ^ 0 ^ 0;
					continue;
				case 4u:
					array = Il2CppArrayBase<Player>.op_Implicit((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList);
					num = ((int)(((num2 + 1464826632) ^ 0x7573BDE1) - 0 << 0) >> 0) + 0;
					continue;
				case 5u:
					val2 = new Random();
					num = (int)((((num2 + 2029155507) ^ 0xC56D02F8u) + 0 << 0) ^ 0 ^ 0);
					continue;
				case 26u:
					num = (((((int)num2 + -1504328649) ^ -481503207) >> 0) ^ 0) >> 0 << 0;
					continue;
				case 24u:
					num3 = val2.Next(array.Length);
					num = (((((int)num2 + -649986417) ^ 0x67EB5F59) - 0) ^ 0 ^ 0) + 0;
					continue;
				case 6u:
					val = GorillaGameManager.instance.FindVRRigForPlayer(array[num3]);
					num = (int)((((num2 + 660359990) ^ 0x37C4EC6F ^ 0) << 0) + 0) >> 0;
					continue;
				case 7u:
					touch_to_crash.tkgHsvKQqkvemmtKTGrTGfMVBTfiejKVYPgzpMCQqhtesIwawgDPfUhoxlfzqBMgAzfxgUuhdBDzMHDTwfMXGUPdHRbeGdAPumESCZTCLvMErHBPHlclOPAGJbPoSqAZaNfzdKrxljlkhlMaqlwvbpaELXiAjFKvVNEEBcMWUEaEDqyypOYGTfXLMAOfCQoFzQpuHhyozzBxpvavzKkuHdBPPTRanGudqufNbdRhpJgtEAvrAtGRGTXwozFNqyaTfxgUqntvSceX();
					num = ((((int)num2 + -1950096023) ^ -1550372776 ^ 0) - 0 >> 0) ^ 0;
					continue;
				case 8u:
					num = ((((int)num2 + -11084362) ^ 0x20AE401F) + 0 - 0 >> 0) + 0;
					continue;
				case 20u:
					num = (((((int)num2 + -1204999380) ^ -276067059) + 0) ^ 0) - 0 >> 0;
					continue;
				case 9u:
					EvJRVKfXNxixEtxxlliBnPIebQZpyjJxSuliulVttEIzjBsCOmbrzmoOMFQfLPzEOKEkipdapOhJhjUAxwBlirYFfwvOuQIEfeLyWiuyjabLfFGDKqHooowwMZeLUoFzgDDdxwDoccbhqmAAQRdeitqRIoLXdJEUvCECbDfoMtmlmpgzyDUclAqMnLviKGltygLNIYznMOsPheEtimyzOBJVmSopiWEfiSMfDtRAeHqwhAEihcayiLFXxPAPJjePkmHorzPPuXvgkmOLngifWfXwnPIOSbRVDBmUSqQH();
					num = (int)(((((num2 + 1047830633) ^ 0xE5D0AFEBu) - 0 + 0) ^ 0) + 0);
					continue;
				case 25u:
					num = (int)((((num2 + 830770635) ^ 0xBF3DF956u) + 0 - 0 << 0) ^ 0);
					continue;
				case 10u:
					soundspammers.TyTrmBCuCWKYMAJfPbwSLyCEoMBefPBnzmEAyKIJjRJCFsmBbKZeIGcvWpdAaxpNuwyAViGesNJTOZYWzZcvQxFTkjDiHiILCWhiTMFSdULVWiGWqgaauTXXREpLFywjeXrRRQcMujsVLJWcCGSBiHqIZkrpxTnEx();
					num = ((((int)num2 + -1377430272) ^ -793422543) + 0 - 0 >> 0) ^ 0;
					continue;
				case 18u:
					num = (2106842267 - 0 + 0 << 0) - 0;
					continue;
				case 11u:
					num = (int)((((num2 + 337346832) ^ 0x4584E143) - 0 - 0 + 0) ^ 0);
					continue;
				case 12u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = ((((int)num2 + -1160147690) ^ 0x1E1AFE8C) >> 0 >> 0 << 0) + 0;
					continue;
				case 22u:
					num = ((int)((num2 + 1394277627) ^ 0x239F2808 ^ 0) >> 0) + 0 >> 0;
					continue;
				case 17u:
					num = (((int)num2 + -1198723765) ^ -930604551) + 0 + 0 + 0 - 0;
					continue;
				case 13u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)val).transform.position;
					num = ((((int)num2 + -1336085439) ^ -1679829380) + 0 << 0) + 0 + 0;
					continue;
				case 14u:
					num = (int)((((num2 + 1016054125) ^ 0xFB269DD8u) << 0) + 0 + 0 + 0);
					continue;
				case 15u:
					GorillaTagger.Instance.myVRRig.head.rigTarget.localEulerAngles = Vector3.right;
					num = (((((int)num2 + -1302358218) ^ 0x3EE8561E) << 0 >> 0) - 0) ^ 0;
					continue;
				case 27u:
					num = ((((int)num2 + -218260425) ^ 0x4DC556AE) >> 0 << 0) - 0 >> 0;
					continue;
				case 16u:
					num = (((((int)num2 + -1519429041) ^ -533420594) << 0 << 0) - 0) ^ 0;
					continue;
				case 21u:
					return;
				}
				break;
			}
		}
	}

	public static void EvJRVKfXNxixEtxxlliBnPIebQZpyjJxSuliulVttEIzjBsCOmbrzmoOMFQfLPzEOKEkipdapOhJhjUAxwBlirYFfwvOuQIEfeLyWiuyjabLfFGDKqHooowwMZeLUoFzgDDdxwDoccbhqmAAQRdeitqRIoLXdJEUvCECbDfoMtmlmpgzyDUclAqMnLviKGltygLNIYznMOsPheEtimyzOBJVmSopiWEfiSMfDtRAeHqwhAEihcayiLFXxPAPJjePkmHorzPPuXvgkmOLngifWfXwnPIOSbRVDBmUSqQH()
	{
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		int[] array = default(int[]);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301846;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0 << (0 << 1) << 0) ^ 0) + 0 - (0 << 1) + 0) ^ 0u) % 15)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					num = ((((int)num2 + -795116775) ^ 0xCAE0649) << 0 << 0 << 0) + 0;
					continue;
				case 2u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = (int)((((num2 + 1259723679) ^ 0x9B5F092Fu ^ 0) + 0 - 0) ^ 0);
					continue;
				case 14u:
					num = ((((int)num2 + -434485547) ^ 0x22551E6E ^ 0) << 0) - 0 << 0;
					continue;
				case 13u:
					num = (int)(((num2 + 770395556) ^ 0xBA96B929u) - 0 + 0 + 0) >> 0;
					continue;
				case 3u:
					current = enumerator.Current;
					num = ((0x167BBEB3 ^ 0) << 0) - 0 << 0;
					continue;
				case 4u:
					num = (((int)((num2 + 647071759) ^ 0x25B5C2A6) >> 0 << 0) + 0) ^ 0;
					continue;
				case 5u:
					array = new int[3] { 1, 2, 3 };
					num = (int)(((num2 + 428697817) ^ 0x668216D9) - 0 + 0) >> 0 >> 0;
					continue;
				case 10u:
				{
					int num4;
					int num5;
					if (enumerator.MoveNext())
					{
						num4 = 272533143;
						num5 = num4;
					}
					else
					{
						num4 = 17045831;
						num5 = num4;
					}
					num = (((num4 ^ 0) >> 0) ^ 0) - 0;
					continue;
				}
				case 12u:
					num3 = Random.Range(0, array.Length);
					num = ((int)((num2 + 2106842273) ^ 0x9BB97DB1u ^ 0) >> 0) + 0 >> 0;
					continue;
				case 6u:
					current.ChangeMaterialLocal(array[num3]);
					num = (((((int)num2 + -1125345364) ^ 0x403520C2) << 0) ^ 0) - 0 + 0;
					continue;
				case 7u:
					num = (int)((num2 + 1952503976) ^ 0xCA73C5E7u ^ 0) >> 0 >> 0 >> 0;
					continue;
				case 8u:
					current.lavaParticleSystem.Play();
					num = ((((int)num2 + -814951907) ^ 0x10B84DB5) << 0 << 0 >> 0) + 0;
					continue;
				case 9u:
					num = (int)((((num2 + 1665746989) ^ 0xD805D7B8u) + 0 - 0 << 0) + 0);
					continue;
				case 11u:
					return;
				}
				break;
			}
		}
	}

	public static void nkekpyNlbOCCaZSepkbCRaXsgzDIZTTXpASLbMhOcwMdzoUDIiEIpoQmnLePVeliVFnAghcDdmAunTTRFZaRokIbJGxqHrSXkEhTbuxBfbEcNwYuSmkWeuTLXlQAJMVMtCkJLZQkByMnFFn()
	{
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Expected O, but got Unknown
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		Player[] array = default(Player[]);
		Random val2 = default(Random);
		int num3 = default(int);
		PhotonView val = default(PhotonView);
		while (true)
		{
			int num = 1758301845;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num << 0) ^ -0) - 0) ^ 0) << 0 >> (0 ^ 0)) + 0 << 0)) % 26)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = (((int)num2 + -1125345364) ^ 0x107D299B) - 0 + 0 + 0 << 0;
					continue;
				case 2u:
					flag = triggerButtonDown;
					num = (int)(((((num2 + 1952503976) ^ 0xB1A40A2Bu) - 0) ^ 0) - 0) >> 0;
					continue;
				case 23u:
				{
					int num4;
					int num5;
					if (flag)
					{
						num4 = -932328992;
						num5 = num4;
					}
					else
					{
						num4 = -1944502879;
						num5 = num4;
					}
					num = (((num4 >> 0 >> 0) ^ ((int)num2 + -1127256878)) + 0 >> 0 << 0) - 0;
					continue;
				}
				case 19u:
					num = (((int)((num2 + 1363915621) ^ 0xF7951B96u) >> 0) + 0 - 0) ^ 0;
					continue;
				case 3u:
					num = ((((int)num2 + -295483064) ^ -388337327 ^ 0) + 0 + 0) ^ 0;
					continue;
				case 4u:
					array = Il2CppArrayBase<Player>.op_Implicit((Il2CppArrayBase<Player>)(object)PhotonNetwork.PlayerList);
					num = ((((int)num2 + -517084339) ^ -284086872) >> 0) + 0 >> 0 << 0;
					continue;
				case 5u:
					val2 = new Random();
					num = (int)(((num2 + 1464826632) ^ 0x24C004B9 ^ 0) + 0 + 0 + 0);
					continue;
				case 21u:
					num = ((((int)num2 + -1302358218) ^ -507800367) >> 0 >> 0) + 0 << 0;
					continue;
				case 24u:
					num3 = val2.Next(array.Length);
					num = (int)(((((num2 + 2029155507) ^ 0x8458D5B9u) - 0 - 0) ^ 0) - 0);
					continue;
				case 6u:
					val = GorillaGameManager.instance.FindVRRigForPlayer(array[num3]);
					num = ((((int)num2 + -649986417) ^ 0x65DEBFB4) + 0 >> 0 << 0) - 0;
					continue;
				case 7u:
					EvJRVKfXNxixEtxxlliBnPIebQZpyjJxSuliulVttEIzjBsCOmbrzmoOMFQfLPzEOKEkipdapOhJhjUAxwBlirYFfwvOuQIEfeLyWiuyjabLfFGDKqHooowwMZeLUoFzgDDdxwDoccbhqmAAQRdeitqRIoLXdJEUvCECbDfoMtmlmpgzyDUclAqMnLviKGltygLNIYznMOsPheEtimyzOBJVmSopiWEfiSMfDtRAeHqwhAEihcayiLFXxPAPJjePkmHorzPPuXvgkmOLngifWfXwnPIOSbRVDBmUSqQH();
					num = (int)(((num2 + 660359990) ^ 0x1F7F5645) + 0 - 0 - 0) >> 0;
					continue;
				case 8u:
					num = ((((int)num2 + -1950096023) ^ -1396483948 ^ 0) << 0 >> 0) - 0;
					continue;
				case 16u:
					num = ((0x198D68DB ^ 0) << 0 << 0) - 0;
					continue;
				case 9u:
					soundspammers.TyTrmBCuCWKYMAJfPbwSLyCEoMBefPBnzmEAyKIJjRJCFsmBbKZeIGcvWpdAaxpNuwyAViGesNJTOZYWzZcvQxFTkjDiHiILCWhiTMFSdULVWiGWqgaauTXXREpLFywjeXrRRQcMujsVLJWcCGSBiHqIZkrpxTnEx();
					num = (((int)num2 + -11084362) ^ 0x24F76C02) - 0 + 0 << 0 << 0;
					continue;
				case 25u:
					num = (int)(((num2 + 1047830633) ^ 0x8A2DD604u ^ 0 ^ 0) + 0) >> 0;
					continue;
				case 10u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = false;
					num = (int)(((((num2 + 830770635) ^ 0x544BDDF6) << 0) ^ 0 ^ 0) + 0);
					continue;
				case 18u:
					num = (int)((((num2 + 1919092371) ^ 0xB478448Au) << 0) + 0) >> 0 >> 0;
					continue;
				case 11u:
					num = (((((int)num2 + -1377430272) ^ -26127069) >> 0) + 0) ^ 0 ^ 0;
					continue;
				case 12u:
					((Component)GorillaTagger.Instance.myVRRig).transform.position = ((Component)val).transform.position;
					num = (int)((((num2 + 337346832) ^ 0x71D90A90) - 0 + 0 << 0) + 0);
					continue;
				case 22u:
					num = ((((int)num2 + -1160147690) ^ -1688446889) << 0 << 0 << 0) ^ 0;
					continue;
				case 17u:
					((Behaviour)GorillaTagger.Instance.myVRRig).enabled = true;
					num = ((int)((num2 + 1855391286) ^ 0xDFACFEB9u) >> 0 >> 0) + 0 - 0;
					continue;
				case 13u:
					GorillaTagger.Instance.myVRRig.head.rigTarget.localEulerAngles = Vector3.right;
					num = (int)((((((num2 + 1394277627) ^ 0xFE9DC136u) - 0) ^ 0) << 0) ^ 0);
					continue;
				case 14u:
					num = (((int)num2 + -1336085439) ^ 0x77104B38) - 0 + 0 >> 0 << 0;
					continue;
				case 15u:
					num = ((int)(((num2 + 1016054125) ^ 0x843B8053u) - 0) >> 0 >> 0) + 0;
					continue;
				case 20u:
					return;
				}
				break;
			}
		}
	}

	public bees()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num - 0 - (0 << 1)) ^ 0) >> 0) + 0 - (0 << 1) + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0 ^ 0) + 0 + 0;
			}
		}
	}
}
