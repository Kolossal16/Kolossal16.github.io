using ExitGames.Client.Photon;
using GorillaNetworking;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace REAK.Menu.mods;

internal class make_room_priv
{
	public static void DBpcIpEIwmxxroDazXvExZbHUdOVHEMvcCcWlBasZbXFpmYwjPdkWkJEAHiEAIbRzcuOlHPYXcFwbvsIfsMRBCySTywEtvSqZggnRjkBafnTFmCeozziWjpXDCUMllFBkowVpeQVhkRwpEmHVrpTVKtQQjJpoypOALJqQHPkJDaMsTIYpnRTWLFAVGeguBHJUcVDVWQnCeksJHxWALZaGvSOfiujCIPhWqRpXedswDrRBnRoihFJBGcykhyNBHLTocvsPiZwHHDdebmSrgbudgGposfQFpRPSyCzRyzaiibUcZuiUGvvGqPiwfe()
	{
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Expected O, but got Unknown
		Hashtable val = default(Hashtable);
		while (true)
		{
			int num = 1758301849;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) - -0 - 0) ^ 0 ^ 0) + (0 << 1) + 0) ^ 0u) % 12)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((((int)num2 + -344833909) ^ 0x61F8C0D6) << 0) - 0) ^ 0 ^ 0;
					continue;
				case 2u:
					num = (((int)num2 + -2130437817) ^ -1387738210) + 0 >> 0 >> 0 << 0;
					continue;
				case 11u:
					val = new Hashtable();
					num = (((int)((num2 + 359659174) ^ 0x20CD5FDA) >> 0) + 0) ^ 0 ^ 0;
					continue;
				case 8u:
					num = (((((int)num2 + -814951907) ^ 0x10B84DB8) - 0) ^ 0) >> 0 >> 0;
					continue;
				case 3u:
					((Dictionary<Object, Object>)(object)val).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("硟硙硕硝硵硗硜硝", 1799190584, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㓀㓉㓔㓃㓕㓒㓅㓏㓒㓟㓄㓇㓕㓃㓋㓃㓈㓒㓅㓇㓈㓟㓉㓈㓕㓋㓉㓓㓈㓒㓇㓏㓈㓕㓄㓃㓇㓅㓎㓕㓍㓟㓅㓇㓐㓃㓕", 1813197990, true) + GorillaComputer.instance.currentGameMode));
					num = (int)((((num2 + 1621957012) ^ 0x66901E97) + 0 << 0 << 0) + 0);
					continue;
				case 4u:
					num = (int)((((num2 + 647071759) ^ 0x25B5C2AA) + 0) ^ 0 ^ 0) >> 0;
					continue;
				case 5u:
					PhotonNetwork.CurrentRoom.SetCustomProperties(val, (Hashtable)null, (WebFlags)null);
					num = (int)(((num2 + 428697817) ^ 0x668216D8) << 0 << 0) >> 0 << 0;
					continue;
				case 7u:
					PhotonNetwork.CurrentRoom.IsOffline = true;
					num = (int)(((((num2 + 1952503976) ^ 0xCA73C5E3u) << 0 << 0) - 0) ^ 0);
					continue;
				case 10u:
					GorillaNot.instance.CloseInvalidRoom();
					num = (int)((((num2 + 2106842273) ^ 0x9BB97DADu) << 0 << 0) - 0 + 0);
					continue;
				case 6u:
					num = ((((int)num2 + -1125345364) ^ 0x403520C5) - 0 << 0 << 0) - 0;
					continue;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	public make_room_priv()
	{
		while (true)
		{
			int num = 1758301855;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num + 0 - (0 ^ 0)) ^ 0) >> 0 >> 0) - (0 ^ 0) << 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 1u:
					goto IL_004e;
				case 2u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB1 ^ 0 ^ 0) >> 0 >> 0;
			}
		}
	}
}
