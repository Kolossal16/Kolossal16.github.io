using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;

namespace cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

public class ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr
{
	public static string oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT(string P_0, int P_1, bool P_2)
	{
		string text = string.Empty;
		StringBuilder stringBuilder = default(StringBuilder);
		Dictionary<string, string> obj = default(Dictionary<string, string>);
		int num8 = default(int);
		string text2 = default(string);
		char c = default(char);
		while (true)
		{
			int num = 14;
			while (true)
			{
				int num2 = (num ^ 0x186BE2B7) << 0;
				_ = -588300820 + 588300820;
				_ = -2113692507 - -2113692507;
				int num3 = num2 << 0;
				_ = -1737295400 + 1737295400;
				_ = -1709360641 - -1709360641;
				uint num4 = (uint)num3;
				switch ((uint)num3 % 6u)
				{
				case 2u:
					break;
				case 4u:
					if (Assembly.GetExecutingAssembly() == Assembly.GetCallingAssembly() && P_2)
					{
						num = 3 + 0;
						_ = -1716578625 + 1716578625;
						_ = -705402864 - -705402864;
						continue;
					}
					return null;
				case 3u:
				{
					global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD = new Dictionary<string, string>();
					uint num35 = num4;
					uint[] array = new uint[3];
					array[0] = 162u;
					array[1] = 112 + array[0];
					array[2] = 901 - array[1] - array[0];
					uint num36 = num35 + array[2] + 0;
					num = (int)(num36 - 409724025 - 0);
					_ = -1812815821 + 1812815821;
					_ = -80163306 - -80163306;
					continue;
				}
				case 0u:
				{
					Dictionary<string, string> qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD = global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD;
					stringBuilder = new StringBuilder();
					obj = qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD;
					uint num31 = num4;
					uint[] array = new uint[5];
					array[0] = 108u;
					array[1] = 335 + array[0];
					array[2] = 903 - array[1] - array[0];
					array[3] = (uint)(-511 + (int)array[2] + (int)array[1]) + array[0];
					array[4] = 636 - array[3] - array[2] + array[1] - array[0];
					uint num32 = num31 + array[4] + 0;
					num = (int)(num32 - 409723797) >> 0;
					_ = -1932445508 + 1932445508;
					_ = -1844731356 - -1844731356;
					continue;
				}
				case 5u:
				{
					int num33;
					int num34;
					if (global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD != null)
					{
						num33 = -1195173495;
						num34 = num33;
					}
					else
					{
						num33 = -1195173498;
						num34 = num33;
					}
					num = num33 ^ ((int)num4 + -1604897075) ^ 0;
					_ = -675621822 + 675621822;
					_ = -1532487834 - -1532487834;
					continue;
				}
				default:
				{
					bool lockTaken = false;
					try
					{
						Monitor.Enter(obj, ref lockTaken);
						while (true)
						{
							IL_0204:
							int num5 = 11;
							while (true)
							{
								int num6 = (num5 ^ 0x186BE2B7) >> 0;
								_ = -70881038 + 70881038;
								_ = -2135975619 - -2135975619;
								int num7 = num6 + 0;
								_ = -1336880342 + 1336880342;
								_ = -737987507 - -737987507;
								num4 = (uint)num7;
								switch ((uint)num7 % 15u)
								{
								case 10u:
									break;
								default:
									goto end_IL_0206;
								case 12u:
								{
									num8++;
									uint num24 = num4;
									uint[] array = new uint[3];
									array[0] = 233u;
									array[1] = 4294967164u + array[0];
									array[2] = 87 + array[1] + array[0];
									uint num25 = num24 + array[2] + 0;
									num5 = (int)((num25 - 409723893) ^ 0);
									_ = -1847947884 + 1847947884;
									_ = -1118612475 - -1118612475;
									continue;
								}
								case 7u:
								{
									num8 = 0;
									uint num22 = num4;
									uint[] array = new uint[3];
									array[0] = 362u;
									array[1] = 74 + array[0];
									array[2] = 1133 - array[1] - array[0];
									uint num23 = num22 + array[2] + 0;
									num5 = (int)(num23 - 409723909 + 0);
									_ = -1098947212 + 1098947212;
									_ = -114391182 - -114391182;
									continue;
								}
								case 0u:
								{
									int num10;
									if (P_2)
									{
										num5 = 10;
										num10 = num5;
									}
									else
									{
										num5 = 114;
										num10 = num5;
									}
									continue;
								}
								case 6u:
								{
									text2 = P_0;
									uint num11 = num4;
									uint[] array = new uint[3];
									array[0] = 147u;
									array[1] = 485 - array[0];
									array[2] = 602 - array[1] + array[0];
									uint num12 = num11 + array[2] + 0;
									num5 = (int)(num12 - 409723983 - 0);
									_ = -663730671 + 663730671;
									_ = -1901304398 - -1901304398;
									continue;
								}
								case 5u:
								{
									int num20;
									int num21;
									if (!global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD.ContainsKey(P_0))
									{
										num20 = 677170057;
										num21 = num20;
									}
									else
									{
										num20 = 677170052;
										num21 = num20;
									}
									num5 = (int)(((uint)num20 ^ (num4 + 267446477)) - 0);
									_ = -739063074 + 739063074;
									_ = -252981488 - -252981488;
									continue;
								}
								case 8u:
								{
									uint num19 = num4 + 2212668469u;
									num5 = ((int)num19 - -1672575359) ^ 0;
									_ = -1929668594 + 1929668594;
									_ = -1214765949 - -1214765949;
									continue;
								}
								case 9u:
									c = text2[num8];
									num5 = 15 + 0;
									_ = -1839587780 + 1839587780;
									_ = -494337107 - -494337107;
									continue;
								case 1u:
								{
									stringBuilder.Append((char)(c ^ P_1));
									uint num17 = num4;
									uint[] array = new uint[3];
									array[0] = 406u;
									array[1] = 510 - array[0];
									array[2] = 122 - array[1] + array[0];
									uint num18 = num17 + array[2] + 0;
									num5 = (int)(num18 - 409723883 << 0);
									_ = -799223523 + 799223523;
									_ = -451601255 - -451601255;
									continue;
								}
								case 11u:
								{
									text = stringBuilder.ToString();
									uint num15 = num4;
									uint[] array = new uint[4];
									array[0] = 238u;
									array[1] = 658 - array[0];
									array[2] = 52 + array[1] - array[0];
									array[3] = 871 - array[2] - array[1] + array[0];
									uint num16 = num15 + array[3] + 0;
									num5 = (int)(num16 - 409723925 << 0);
									_ = -898131191 + 898131191;
									_ = -1755310113 - -1755310113;
									continue;
								}
								case 3u:
								{
									text = global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD[P_0];
									uint num13 = num4;
									uint[] array = new uint[4];
									array[0] = 140u;
									array[1] = 403 - array[0];
									array[2] = 286 + array[1] - array[0];
									array[3] = 263 - array[2] + array[1] + array[0];
									uint num14 = num13 + array[3] + 0;
									num5 = (int)(num14 - 409723823 + 0);
									_ = -1870748459 + 1870748459;
									_ = -1523858238 - -1523858238;
									continue;
								}
								case 13u:
								{
									int num9;
									if (num8 >= text2.Length)
									{
										num5 = 114;
										num9 = num5;
									}
									else
									{
										num5 = 119;
										num9 = num5;
									}
									continue;
								}
								case 14u:
									global::_003CModule_003E.qwxmDbwkmmdomRsdRmzaaBMVqbDUtGMcFTPuOuajFYcuvpqHMQXVlcSPKBWCyBQGAbIscYoxmqvbzszaLViCJQQDaZKnyyKdiwTuGXFOBzJUGRqrbVQCtnWKkfrcnbZOFrTdyeuNquajhWWjJslCHiKUzjkBGDAAAVppYnTXBdmZnNCnihsVQxgxGZDpUTgMTAJlGHlwzobD[P_0] = text;
									num5 = 14 >> 0;
									_ = -2062287944 + 2062287944;
									_ = -854944662 - -854944662;
									continue;
								case 4u:
									goto end_IL_0206;
								case 2u:
									goto end_IL_0206;
								}
								goto IL_0204;
								continue;
								end_IL_0206:
								break;
							}
							break;
						}
					}
					finally
					{
						if (lockTaken)
						{
							while (true)
							{
								IL_06d2:
								int num26 = 15;
								while (true)
								{
									int num27 = (num26 ^ 0x186BE2B7) - 0;
									_ = -661576031 + 661576031;
									_ = -385823578 - -385823578;
									int num28 = num27 - 0;
									_ = -701715592 + 701715592;
									_ = -587720524 - -587720524;
									num4 = (uint)num28;
									switch ((uint)num28 % 3u)
									{
									case 2u:
										break;
									default:
										goto end_IL_06d4;
									case 1u:
									{
										Monitor.Exit(obj);
										uint num29 = num4;
										uint[] array = new uint[3];
										array[0] = 105u;
										array[1] = 81 + array[0];
										array[2] = 438 - array[1] + array[0];
										uint num30 = num29 + array[2] + 0;
										num26 = (int)((num30 - 409723933) ^ 0);
										_ = -281484770 + 281484770;
										_ = -944920213 - -944920213;
										continue;
									}
									case 0u:
										goto end_IL_06d4;
									}
									goto IL_06d2;
									continue;
									end_IL_06d4:
									break;
								}
								break;
							}
						}
					}
					return text;
				}
				}
				break;
			}
		}
	}
}
