using GorillaLocomotion;
using Il2CppSystem;
using MenuTemplate;
using MenuTemplate.mods;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace Popeye.Menu.modsss;

internal class SIGMA_NEW_LAG_METHOD
{
	public static void kGGJntqilJfJtmVqGFjIhsMaMDLrLvjJLhAJjoKsicjcshKhaaAslYLSTGXKHYwPzwYlMmgsURAeiKHETDrKVRxMwHPDqaKjGtCWiyvNThxuyGJjYsRdGLUIYlPexDcUgqyPiLwuiERNtdoPYGEXjHDUzTXXIqqqfDohiUamWwUbUgpUWagQYeLzNDpoOyLSoBHQPhGdFsaMMBasEcaIkzrbROtEEMyxLcNszyfPtclGeZMlCXKLycIPjGYaNcyTTCaKOHTfXkphoLWScibHcNZItXjS()
	{
		//IL_0810: Unknown result type (might be due to invalid IL or missing references)
		//IL_0824: Unknown result type (might be due to invalid IL or missing references)
		//IL_0829: Unknown result type (might be due to invalid IL or missing references)
		//IL_0838: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0597: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0501: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0529: Unknown result type (might be due to invalid IL or missing references)
		//IL_073c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0750: Unknown result type (might be due to invalid IL or missing references)
		//IL_0755: Unknown result type (might be due to invalid IL or missing references)
		//IL_0764: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_087a: Unknown result type (might be due to invalid IL or missing references)
		//IL_088e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0893: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_0466: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_090c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0983: Unknown result type (might be due to invalid IL or missing references)
		//IL_0997: Unknown result type (might be due to invalid IL or missing references)
		//IL_099c: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ab: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		bool flag2 = default(bool);
		bool flag = default(bool);
		bool triggerButtonDown2 = default(bool);
		while (true)
		{
			int num = 1758301869;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num ^ 0) << -0 << 0) - 0 - 0 >> (0 ^ 0)) - 0 >> 0)) % 36)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((int)((num2 + 1333463150) ^ 0x8D8F871Au ^ 0) >> 0) + 0 + 0;
					continue;
				case 23u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("萇萏萒萉萌萌萁萐萒萅萆萁萂萓葏萇萏萒萉萌萌萁萐萌萁萙萅萒萓萃萏萒萅萂萏萁萒萄萌萉萎萅", 1444971616, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)((num2 + 891081771) ^ 0x1922AC93) >> 0) - 0) ^ 0) - 0;
					continue;
				case 7u:
					num = (((((int)num2 + -1198723765) ^ 0x7F204002) + 0 - 0) ^ 0) - 0;
					continue;
				case 17u:
					flag2 = triggerButtonDown;
					num = ((((int)num2 + -227232852) ^ 0x33B82128) - 0 << 0) + 0 - 0;
					continue;
				case 12u:
					prefab_destoyer.bWqVqKpdZencDvbLaYENpFhGIkzgLlxtTYcbGvmqqUygjdxXpPlDCjsvOKmgkirOGTjEtZeELnxvhbwEMBRWaURJFGmWigfh();
					num = ((int)num2 + -877465945) ^ 0x2EAF9973 ^ 0 ^ 0 ^ 0 ^ 0;
					continue;
				case 16u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㮉㮁㮜㮇㮂㮂㮏㮞㮜㮋㮈㮏㮌㮝㯁㮩㮁㮜㮇㮂㮂㮏㮽㮍㮁㮜㮋㮬㮁㮏㮜㮊", 1011039214, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1302358218) ^ 0x1794E4D8) - 0) ^ 0) << 0 >> 0;
					continue;
				case 1u:
				{
					int num5;
					int num6;
					if (!flag2)
					{
						num5 = -1990836803;
						num6 = num5;
					}
					else
					{
						num5 = -453285979;
						num6 = num5;
					}
					num = (((num5 - 0 + 0) ^ ((int)num2 + -649986417)) << 0 >> 0) - 0 >> 0;
					continue;
				}
				case 8u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("爇爏爒爉爌爌爁爐爒爅爆爁爂爓牏爇爏爒爉爌爌爁爐爌爁爙爅爒爓爃爏爒爅爂爏爁爒爄爌爉爎爅", 2023256672, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1804281275) ^ -280227653) >> 0 >> 0) ^ 0) >> 0;
					continue;
				case 29u:
					num = (int)((((num2 + 660359990) ^ 0x21E16F3D) << 0 << 0 << 0) - 0);
					continue;
				case 10u:
					flag = triggerButtonDown2;
					num = (((int)((num2 + 2022602987) ^ 0x8D35938Au) >> 0) ^ 0) - 0 + 0;
					continue;
				case 28u:
					num = (int)((((num2 + 641832775) ^ 0x34B33F84) + 0 << 0 << 0) - 0);
					continue;
				case 34u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = ((((int)num2 + -1950096023) ^ -1165549563) >> 0) - 0 + 0 - 0;
					continue;
				case 33u:
					prefab_destoyer.CKzpUSEqKGSoMWoNoItJrvOLczZMNivEipTwBhJTXAltcCXJrzHANvPgVOnvTRCBknfwdRlhYzMQjuJzCqvnAVRMzMANToafYKiOxBFzoABnJZXAfNTDwpbpwtWrqynKzGSzmUcbKVZZuDdAPaIfvwJIJTsdEojPnQOdgxokLRSBpbUSqvBqPhodWjQsBYwwMjMDPZurLxuDDitHYzNiMSZfCKgWHWJMvwPfordqbkFsNL();
					num = (((int)num2 + -43473754) ^ 0x558DC22) - 0 - 0 + 0 + 0;
					continue;
				case 2u:
					num = ((((int)num2 + -11084362) ^ 0x4CC89A2F) - 0 + 0 >> 0) ^ 0;
					continue;
				case 6u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("നഠഽദണണമ\u0d3fഽപഩമഭ\u0d3cൠനഠഽദണണമ\u0d3fണമശപഽ\u0d3cബഠഽപഭഠമഽഫണദഡപ", 1440222543, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -218260425) ^ 0x4378496F) + 0 + 0) ^ 0) << 0;
					continue;
				case 18u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = ((((int)num2 + -1519429041) ^ -1876415366) + 0 >> 0) - 0 + 0;
					continue;
				case 19u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⇿⇷⇪⇱⇴⇴⇹⇨⇪⇽⇾⇹⇺⇫↷⇟⇷⇪⇱⇴⇴⇹⇋⇻⇷⇪⇽⇚⇷⇹⇪⇼", 1994203544, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)((((num2 + 1047830633) ^ 0xDADE392Fu) - 0 << 0) - 0 + 0);
					continue;
				case 20u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("钶钾钣钸钽钽钰钡钣钴钷钰钳钢链钖钾钣钸钽钽钰钂钲钾钣钴钓钾钰钣钵", 1277334737, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 207985003) ^ 0x54EE683B) << 0) >> 0 << 0 >> 0;
					continue;
				case 3u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("蚆蚎蚓蚈蚍蚍蚀蚑蚓蚄蚇蚀蚃蚒蛎蚆蚎蚓蚈蚍蚍蚀蚑蚍蚀蚘蚄蚓蚒蚂蚎蚓蚄蚃蚎蚀蚓蚅蚍蚈蚏蚄", 1869580001, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((int)((num2 + 830770635) ^ 0x3D9D2EFA) >> 0 << 0 << 0) ^ 0;
					continue;
				case 22u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueee3\ueeeb\ueef6\ueeed\ueee8\ueee8\ueee5\ueef4\ueef6\ueee1\ueee2\ueee5\ueee6\ueef7\ueeab\ueec3\ueeeb\ueef6\ueeed\ueee8\ueee8\ueee5\ueed7\ueee7\ueeeb\ueef6\ueee1\ueec6\ueeeb\ueee5\ueef6\ueee0", 1011936900, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -2057924117) ^ -1070830582) << 0 << 0 << 0) - 0;
					continue;
				case 24u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("陻陳陮陵陰陰陽陬陮陹険陽陾陯阳陛陳陮陵陰陰陽陏陿陳陮陹陞陳陽陮陸", 46831132, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -1377430272) ^ -2050424818) >> 0) + 0 >> 0) ^ 0;
					continue;
				case 9u:
					num = (int)(((num2 + 1493219093) ^ 0xCD1A940Fu) - 0) >> 0 >> 0 >> 0;
					continue;
				case 25u:
					triggerButtonDown2 = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (961186654 << 0) - 0 - 0 - 0;
					continue;
				case 26u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㚜㚔㚉㚒㚗㚗㚚㚋㚉㚞㚝㚚㚙㚈㛔㚜㚔㚉㚒㚗㚗㚚㚋㚗㚚㚂㚞㚉㚈㚘㚔㚉㚞㚙㚔㚚㚉㚟㚗㚒㚕㚞", 1677211387, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((((num2 + 337346832) ^ 0xD56AFCCEu) - 0) ^ 0 ^ 0) + 0);
					continue;
				case 27u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = -1229118705;
						num4 = num3;
					}
					else
					{
						num3 = -1316128715;
						num4 = num3;
					}
					num = (int)(((uint)(num3 >> 0 << 0) ^ (num2 + 1866650904) ^ 0) + 0) >> 0 << 0;
					continue;
				}
				case 4u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((int)num2 + -1160147690) ^ 0x60759C81) - 0 >> 0 >> 0 >> 0;
					continue;
				case 11u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (int)((((num2 + 435749897) ^ 0xB9100306u) - 0 + 0) ^ 0) >> 0;
					continue;
				case 30u:
					num = (((int)((num2 + 1198527402) ^ 0x31D5214C) >> 0) - 0 >> 0) ^ 0;
					continue;
				case 31u:
					num = (int)((((num2 + 1394277627) ^ 0x9D460B77u) - 0 << 0) - 0 - 0);
					continue;
				case 32u:
					num = ((int)(((num2 + 1115582667) ^ 0x1B6782A6) << 0) >> 0) ^ 0 ^ 0;
					continue;
				case 5u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("⍔⍜⍁⍚⍟⍟⍒⍃⍁⍖⍕⍒⍑⍀⌜⍴⍜⍁⍚⍟⍟⍒⍠⍐⍜⍁⍖⍱⍜⍒⍁⍗", 1916543795, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = ((((((int)num2 + -1336085439) ^ -718523783) >> 0) - 0) ^ 0) - 0;
					continue;
				case 13u:
					num = (int)((((num2 + 1609311921) ^ 0xE83E1A19u) - 0 - 0 << 0) ^ 0);
					continue;
				case 35u:
					num = (((int)num2 + -1031415661) ^ -304926040 ^ 0 ^ 0) + 0 << 0;
					continue;
				case 15u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("㓽㓵㓨㓳㓶㓶㓻㓪㓨㓿㓼㓻㓸㓩㒵㓽㓵㓨㓳㓶㓶㓻㓪㓶㓻㓣㓿㓨㓩㓹㓵㓨㓿㓸㓵㓻㓨㓾㓶㓳㓴㓿", 841299098, true), ((Component)Player.Instance).transform.position - new Vector3(9000000f, 1f, 0f), ((Component)Player.Instance).transform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (int)(((num2 + 1016054125) ^ 0x6D08A1A0) + 0) >> 0 >> 0 >> 0;
					continue;
				case 14u:
					return;
				}
				break;
			}
		}
	}

	public SIGMA_NEW_LAG_METHOD()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num >> 0 << (0 ^ 0)) ^ 0) + 0 + 0) ^ 0 ^ 0) << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) << 0 << 0) - 0) ^ 0;
			}
		}
	}
}
