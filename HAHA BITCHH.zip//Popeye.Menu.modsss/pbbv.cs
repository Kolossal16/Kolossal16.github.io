using System;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modsss;

internal class pbbv
{
	public static void LrPXieMCwScoGBNKnLHiqqqPcOnVAOgREeeyctqrlGDfDPYbisSdjlOvbaVtRQbILlKCxpHUvqWJMllmQlNhWcIspJxbxWAvEVusewESLXHSpeIPOJDFcULICsmORFxzPAeRRThtGVwYuPdlbHnOtUsKjLQMkQafAidOZQYVBjYhyNnMoaMksIfUhuIfcuiQUqxlMolkIrmjWllwxdyjdQMRdiGEhTShainipbaaOBBbwWYWjmIYWZMdDGiDIHdPyfiNXdhvdxvBoLvgkKvVkTkbvjEISwshyLCqNkYfemVyDkOSkctXlhEEVgsNzyCHfncCiesZLpQYYLykvMyQduVrhYvHS()
	{
		//IL_0450: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Expected O, but got Unknown
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Expected O, but got Unknown
		bool[] array = default(bool[]);
		Hashtable val = default(Hashtable);
		int num5 = default(int);
		bool flag2 = default(bool);
		bool flag = default(bool);
		Hashtable val2 = default(Hashtable);
		while (true)
		{
			int num = 1758301863;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num ^ 0) + (0 ^ 0) + 0 << 0 >> 0) ^ 0) << 0) - 0)) % 22)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					array = new bool[8] { true, true, true, true, false, false, false, false };
					num = ((int)(((num2 + 428697817) ^ 0xB79DF86Du) - 0) >> 0) - 0 - 0;
					continue;
				case 11u:
					((Dictionary<Object, Object>)(object)val).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\udb48\udb4e\udb42\udb4a\udb62\udb40\udb4b\udb4a", 126606127, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("썸썱썬썻썭썪썽썿썰썧썱썰썭썳썱썫썰썪썿썷썰썭썽썿써썻썭썚썛썘썟썋썒썊썓썑썚썚썛썚썁썓썑썚썚썛썚썁썗썐썘썛썝썊썗썑썐", 379044638, true)));
					num = (((((int)num2 + -649986417) ^ 0x1A456150) << 0) ^ 0) + 0 + 0;
					continue;
				case 7u:
					num = (((int)num2 + -1856515560) ^ -1809928885 ^ 0) + 0 >> 0 >> 0;
					continue;
				case 17u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((int)((num2 + 2106842273) ^ 0xA8D90E2Bu) >> 0) ^ 0 ^ 0) - 0;
					continue;
				case 5u:
					num = ((((int)num2 + -11084362) ^ 0x22260DF0) + 0 - 0 << 0) - 0;
					continue;
				case 16u:
					num = 0x156FF6A6 ^ 0;
					continue;
				case 1u:
					num = ((((int)num2 + -1125345364) ^ -934347535) << 0) + 0 + 0 + 0;
					continue;
				case 8u:
					num = ((((int)num2 + -202039689) ^ 0x4ECCD498) << 0) + 0 >> 0 << 0;
					continue;
				case 12u:
					num5 = new Random().Next(array.Length);
					num = ((int)((num2 + 1952503976) ^ 0x92E4E18Cu) >> 0 >> 0 << 0) - 0;
					continue;
				case 4u:
					num = (int)(((num2 + 660359990) ^ 0x1CF8DA93) + 0 - 0) >> 0 << 0;
					continue;
				case 13u:
					PhotonNetwork.CurrentRoom.SetCustomProperties(val, (Hashtable)null, (WebFlags)null);
					num = ((((int)num2 + -1950096023) ^ -721612045) - 0 << 0 >> 0) - 0;
					continue;
				case 14u:
					flag2 = array[num5];
					num = (((int)num2 + -814951907) ^ -45083519 ^ 0 ^ 0 ^ 0) - 0;
					continue;
				case 15u:
					num = (int)((((num2 + 1047830633) ^ 0x6B32CB53) << 0) + 0) >> 0 << 0;
					continue;
				case 2u:
					flag = flag2;
					num = (((int)((num2 + 1665746989) ^ 0x28C63752) >> 0 << 0) ^ 0) << 0;
					continue;
				case 6u:
					val2 = new Hashtable();
					num = ((int)((num2 + 1221206141) ^ 0x152FCC8F ^ 0 ^ 0) >> 0) ^ 0;
					continue;
				case 18u:
					((Dictionary<Object, Object>)(object)val2).Add(Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("殀殆殊殂殪殈殃殂", 1234529255, true)), Object.op_Implicit(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ᴟᴖᴋᴜᴊᴍᴚᴐᴍᴀᴚᴘᴗᴀᴖᴗᴊᴔᴖᴌᴗᴍᴘᴐᴗᴊᴚᴘᴏᴜᴊᴽᴼᴿᴸᴬᴵᴭᴴᴶᴽᴽᴼᴽᴦᴴᴶᴽᴽᴼᴽᴦᴺᴸᴪᴬᴸᴵᴺᴸᴪᴬᴸᴵ", 1248206201, true)));
					num = ((int)(((num2 + 441892074) ^ 0x5C1811D) + 0) >> 0) - 0 + 0;
					continue;
				case 19u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 1701747762;
						num4 = num3;
					}
					else
					{
						num3 = 2081899023;
						num4 = num3;
					}
					num = ((((num3 - 0 << 0) ^ ((int)num2 + -517084339)) + 0 + 0) ^ 0) - 0;
					continue;
				}
				case 20u:
					PhotonNetwork.CurrentRoom.SetCustomProperties(val2, (Hashtable)null, (WebFlags)null);
					num = ((((int)num2 + -11398900) ^ 0x43FDDFFC ^ 0) << 0) + 0 - 0;
					continue;
				case 3u:
					num = (int)((((num2 + 1464826632) ^ 0xE7C83C0Bu) - 0) ^ 0 ^ 0) >> 0;
					continue;
				case 10u:
					val = new Hashtable();
					num = (int)((((num2 + 2029155507) ^ 0xCEC5A1FAu) + 0 << 0) + 0 << 0);
					continue;
				case 9u:
					return;
				}
				break;
			}
		}
	}

	public pbbv()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num >> 0) ^ 0) >> 0 << 0 >> 0 << -0 >> 0) ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) << 0) ^ 0) >> 0;
			}
		}
	}
}
