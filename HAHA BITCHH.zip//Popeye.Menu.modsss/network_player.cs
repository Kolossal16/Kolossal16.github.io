using System;
using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace Popeye.Menu.modsss;

internal class network_player
{
	public static void PfXTMsQKxfECZLoimNFZfUejIlPJAWECHavqQTdvPqHXfduAiXxxFGAUbOlACgjAAbVYpXrtJkkOngdFQpADyhWbAApcICSIggwehwlkFeNuvLHVKFKmGGbtfTxOIpKhrCIgJZxuepXuuBFPTurcSGczedYnZwCptGdTdBlLiphqJHZDoHVoXIoLAibGajvHNHaNyMMriGUCyLQxdvZrBorLrrtVAFLYUADbGleBVDfrNLnOrECEjdgyqovgtRRDVVIYiPQSqywYiZXGeEDVcgPQte()
	{
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		string[] array = default(string[]);
		int num3 = default(int);
		bool flag = default(bool);
		bool gripButtonDown = default(bool);
		bool flag2 = default(bool);
		string userId = default(string);
		while (true)
		{
			int num = 1758301848;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((num >> 0) + (0 ^ 0) - 0 + 0 + 0 + (0 >> 1) >> 0 >> 0)) % 21)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					array = new string[7]
					{
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("၃ဌဖစယ၂၎၏၏၏၁၃လတဓတဍ၂ဆယဓဓတဈ၁\u103a\u102d\u1032၃ၐလတဓတဍ၁၃ၐဌဖစယ၁ၵ၃ဌဖစယ၂၎၏၏ၑ၉၁၃လတဓတဍ၂ဆယဓဓတဈ၁ရဖဌလတဍရၑဘဘၐ\u1033\u103c\u1032၃ၐလတဓတဍ၁၃ၐဌဖစယ၁", 846401663, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("睓眜眆眕眊睒睞睟睟睟睑睓県眀眃眀眝睒眈眝眊眊省睑眪眽眢睓着県眀眃眀眝睑睓着眜眆眕眊睑睥睓眜眆眕眊睒睞睟睟睁睙睑睓県眀眃眀眝睒眈眝眊眊省睑看眆眜県眀眝看睁眈眈着眣眬眢睓着県眀眃眀眝睑睓着眜眆眕眊睑", 310474607, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("襼褳褩褺褥襽襱襰襰襰襾襼褣褯褬褯褲襽褢褬褵褥襾褅褒褍襼襯褣褯褬褯褲襾襼襯褳褩褺褥襾襊襼褳褩褺褥襽襱襰襰襮襶襾襼褣褯褬褯褲襽褢褬褵褥襾褤褩褳褣褯褲褤襮褧褧襯褌褃褍襼襯褣褯褬褯褲襾襼襯褳褩褺褥襾", 87198016, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("偘倗倍倞倁偙偕偔偔偔做偘倇個倈個倖偙倈倍倉倁做倡倶倩偘偋倇個倈個倖做偘偋倗倍倞倁做偮偘倗倍倞倁偙偕偔偔偊偒做偘倇個倈個倖偙倒倍個倈倁倐做倀倍倗倇個倖倀偊倃倃偋倨倧倩偘偋倇個倈個倖做偘偋倗倍倞倁做", 233197668, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䩇䨈䨒䨁䨞䩆䩊䩋䩋䩋䩅䩇䨘䨔䨗䨔䨉䩆䨉䨞䨟䩅䨾䨩䨶䩇䩔䨘䨔䨗䨔䨉䩅䩇䩔䨈䨒䨁䨞䩅䩱䩇䨈䨒䨁䨞䩆䩊䩋䩋䩕䩍䩅䩇䨘䨔䨗䨔䨉䩆䨉䨞䨟䩅䨟䨒䨈䨘䨔䨉䨟䩕䨜䨜䩔䨷䨸䨶䩇䩔䨘䨔䨗䨔䨉䩅䩇䩔䨈䨒䨁䨞䩅", 181422715, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("܂ݍݗ\u0744ݛ܃\u070f\u070e\u070e\u070e܀܂ݝݑݒݑ\u074c܃\u074cݛݚ܀ݻݬݳܞ܂\u0711ݝݑݒݑ\u074c܀܂\u0711ݍݗ\u0744ݛ܀\u0734܂ݍݗ\u0744ݛ܃\u070f\u070e\u070eܐ܈܀܂ݝݑݒݑ\u074c܃\u074cݛݚ܀ݚݗݍݝݑ\u074cݚܐݙݙ\u0711ݲݽݳ܂\u0711ݝݑݒݑ\u074c܀܂\u0711ݍݗ\u0744ݛ܀", 1582106430, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("罸缷缭缾缡罹罵罴罴罴罺罸缧缫缨缫缶罹缶缡缠罺缁编缉罸罫缧缫缨缫缶罺罸罫缷缭缾缡罺罎罸缷缭缾缡罹罵罴罴罪署罺罸缧缫缨缫缶罹缶缡缠罺缠缭缷缧缫缶缠罪缣缣罫缈缇缉罸罫缧缫缨缫缶罺罸罫缷缭缾缡罺", 1330609988, true)
					};
					num = ((((int)num2 + -733318432) ^ 0x8DF0E80 ^ 0) + 0 >> 0) + 0;
					continue;
				case 11u:
					PlayerPrefs.Save();
					num = (((int)num2 + -1439813256) ^ 0x4B792C68) - 0 << 0 >> 0 << 0;
					continue;
				case 7u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("糛糰糡糢糺糧糾粵糅糹糴糬糰糧", 87653525, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -11398900) ^ 0x39E56C45) + 0 << 0) ^ 0) + 0;
					continue;
				case 17u:
					num3 = new Random().Next(array.Length);
					num = (((int)num2 + -678915685) ^ 0x16CC4302) + 0 - 0 - 0 + 0;
					continue;
				case 5u:
					flag = gripButtonDown;
					num = (((((int)num2 + -509051253) ^ 0x477ACC5) << 0) ^ 0) - 0 << 0;
					continue;
				case 16u:
				{
					int num4;
					int num5;
					if (!flag2)
					{
						num4 = -1074523233;
						num5 = num4;
					}
					else
					{
						num4 = -1945473730;
						num5 = num4;
					}
					num = (int)((((uint)(num4 - 0 + 0) ^ (num2 + 1221206141)) + 0 + 0) ^ 0) >> 0;
					continue;
				}
				case 1u:
					PhotonNetwork.LocalPlayer.NickName = array[num3];
					num = ((((int)num2 + -1186296972) ^ -990844756) + 0 + 0 << 0) + 0;
					continue;
				case 10u:
					num = ((((int)num2 + -871797673) ^ 0x622AB952) >> 0) + 0 - 0 << 0;
					continue;
				case 12u:
					num = (((int)num2 + -1701687338) ^ -1129617208) + 0 - 0 + 0 << 0;
					continue;
				case 4u:
					num = ((((int)num2 + -2033110311) ^ -1114783422) << 0 >> 0) ^ 0 ^ 0;
					continue;
				case 13u:
					gripButtonDown = EasyInputs.GetGripButtonDown((EasyHand)1);
					num = (((((int)num2 + -1827602905) ^ -582481498) >> 0) ^ 0) + 0 << 0;
					continue;
				case 14u:
					PlayerPrefs.SetString(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("뚪뚂뚟뚄뚁뚁뚌뚡뚂뚎뚂뚀뚂뚙뚄뚂뚃뛃뚽뚁뚌뚔뚈뚟뚣뚌뚀뚈", 368621293, true), array[num3]);
					num = (((((int)num2 + -1219895373) ^ -713221621 ^ 0) >> 0) ^ 0) << 0;
					continue;
				case 15u:
					flag2 = flag;
					num = (((((int)num2 + -1891630081) ^ -1059101106) + 0) ^ 0) - 0 - 0;
					continue;
				case 2u:
					num = (int)(((num2 + 900749756) ^ 0x1AAF25EC) + 0 + 0 + 0 + 0);
					continue;
				case 6u:
					num = (int)((num2 + 441892074) ^ 0x64D36810 ^ 0 ^ 0 ^ 0) >> 0;
					continue;
				case 18u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((((int)num2 + -1856515560) ^ -1128221664) - 0) ^ 0) << 0) ^ 0;
					continue;
				case 19u:
					userId = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("\ueefd\uee94\ueefd즹გ\ueefd\uee96\ueeb4\ueea9\ueea9\ueea4\ueefd\uee9e\ueebc\ueea9\ueeae\ueefd", 1087434461, true);
					num = (int)((((num2 + 1709781230) ^ 0xF35389F4u) << 0 << 0) - 0 + 0);
					continue;
				case 20u:
					num = ((((int)num2 + -202039689) ^ 0x7C9EED59) - 0 << 0) + 0 + 0;
					continue;
				case 3u:
					PhotonNetwork.LocalPlayer.UserId = userId;
					num = ((((int)num2 + -1650322207) ^ -1585535472 ^ 0 ^ 0) + 0) ^ 0;
					continue;
				case 8u:
					return;
				}
				break;
			}
		}
	}

	public network_player()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) >> (0 ^ 0)) + 0) ^ 0) + 0 >> 0 + 0 << 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) ^ 0) << 0) + 0;
			}
		}
	}
}
