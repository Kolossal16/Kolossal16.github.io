using Il2CppSystem.Collections.Generic;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modsss;

internal class Beacons
{
	public static void vIRyzroyDXMYILJEAzPFRtxoYprAlqpMZQwOQvUUtNgGopiDYytaVBYblCAjaNnmIZYSpUOeFVldnRaJhNCMXo()
	{
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_078c: Unknown result type (might be due to invalid IL or missing references)
		//IL_053d: Unknown result type (might be due to invalid IL or missing references)
		//IL_053f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0549: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e9: Expected O, but got Unknown
		//IL_0726: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0576: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_0587: Unknown result type (might be due to invalid IL or missing references)
		//IL_0803: Unknown result type (might be due to invalid IL or missing references)
		//IL_0898: Unknown result type (might be due to invalid IL or missing references)
		LineRenderer val = default(LineRenderer);
		Enumerator<VRRig> enumerator = default(Enumerator<VRRig>);
		VRRig current = default(VRRig);
		Vector3 position = default(Vector3);
		bool flag = default(bool);
		GameObject val2 = default(GameObject);
		Color magenta = default(Color);
		while (true)
		{
			int num = 1758301848;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num + 0) ^ 0) >> 0) ^ 0 ^ 0) + (0 + 0) >> 0) + 0)) % 37)
				{
				case 0u:
					break;
				default:
					return;
				case 21u:
					num = ((((int)num2 + -871797673) ^ 0x111EAEE) - 0 << 0) ^ 0 ^ 0;
					continue;
				case 23u:
					val.useWorldSpace = true;
					num = (((((int)num2 + -2057924117) ^ -915707030) << 0 << 0) + 0) ^ 0;
					continue;
				case 7u:
					val.endWidth = 0.025f;
					num = ((((((int)num2 + -1519429041) ^ 0x6006352F) + 0) ^ 0) + 0) ^ 0;
					continue;
				case 17u:
					enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
					num = ((((int)num2 + -1439813256) ^ -998857758) >> 0) - 0 - 0 << 0;
					continue;
				case 12u:
					num = (((((int)num2 + -1292982349) ^ 0x37EB2012) << 0) + 0 << 0) + 0;
					continue;
				case 14u:
				{
					int num5;
					int num6;
					if (enumerator.MoveNext())
					{
						num5 = 272533149;
						num6 = num5;
					}
					else
					{
						num5 = 1333463143;
						num6 = num5;
					}
					num = (((num5 >> 0) ^ 0) << 0) + 0;
					continue;
				}
				case 1u:
					num = (((((int)num2 + -2033110311) ^ -1074331231) - 0) ^ 0) >> 0 << 0;
					continue;
				case 8u:
					val.positionCount = 2;
					num = (int)((((num2 + 207985003) ^ 0x66BD5383) << 0) ^ 0) >> 0 >> 0;
					continue;
				case 29u:
					current = enumerator.Current;
					num = (0x167BBECA ^ 0) << 0;
					continue;
				case 10u:
					val.SetPosition(0, position + Vector3.up * 9999f);
					num = (int)(((num2 + 2022602987) ^ 0x8D359399u) + 0) >> 0 >> 0 >> 0;
					continue;
				case 28u:
					val.SetPosition(1, position - Vector3.up * 9999f);
					num = (int)((((num2 + 1100433178) ^ 0x28494E72) + 0 - 0) ^ 0 ^ 0);
					continue;
				case 34u:
					num = (int)((((num2 + 1548432940) ^ 0x6A7E70AB) - 0 - 0 + 0) ^ 0);
					continue;
				case 33u:
					num = (int)((((num2 + 1755620916) ^ 0xAE04DE89u ^ 0) << 0) - 0 << 0);
					continue;
				case 2u:
					flag = (Object)(object)current != (Object)(object)GorillaTagger.Instance.offlineVRRig;
					num = ((((((int)num2 + -1008375456) ^ -2007361944) >> 0) + 0) ^ 0) - 0;
					continue;
				case 6u:
					val.startWidth = 0.025f;
					num = (((((int)num2 + -1302358218) ^ -1931848107) << 0 << 0) ^ 0) >> 0;
					continue;
				case 18u:
					num = ((((int)num2 + -218260425) ^ 0x5EBE6E5D ^ 0 ^ 0) << 0) - 0;
					continue;
				case 19u:
				{
					int num3;
					int num4;
					if (flag)
					{
						num3 = 503086231;
						num4 = num3;
					}
					else
					{
						num3 = 2046137407;
						num4 = num3;
					}
					num = (((num3 >> 0) - 0) ^ ((int)num2 + -11084362)) >> 0 << 0 << 0 << 0;
					continue;
				}
				case 20u:
					num = (((int)num2 + -1198723765) ^ 0x3836B3E5) >> 0 >> 0 << 0 << 0;
					continue;
				case 3u:
					num = (int)(((num2 + 1047830633) ^ 0xCEAD59A9u ^ 0) + 0 - 0 - 0);
					continue;
				case 22u:
					num = ((((int)num2 + -1804281275) ^ -248371722) << 0 >> 0 >> 0) ^ 0;
					continue;
				case 24u:
					val2 = new GameObject(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("都糖宅﨏", 591919722, true));
					num = (int)(((num2 + 830770635) ^ 0x95798DC) + 0 + 0 + 0 + 0);
					continue;
				case 9u:
					num = (int)((((num2 + 891081771) ^ 0xF136B976u) << 0 << 0 << 0) ^ 0);
					continue;
				case 25u:
					position = ((Component)current).transform.position;
					num = (int)((((num2 + 1493219093) ^ 0xEFDE18B9u ^ 0 ^ 0) << 0) + 0);
					continue;
				case 26u:
					val = val2.AddComponent<LineRenderer>();
					num = (((((int)num2 + -1377430272) ^ 0x4F2108DE) << 0 << 0) ^ 0) >> 0;
					continue;
				case 27u:
					num = ((int)((((num2 + 1121261575) ^ 0x6553E01D) - 0) ^ 0) >> 0) + 0;
					continue;
				case 4u:
					magenta = Color.magenta;
					num = (int)((((num2 + 337346832) ^ 0xF3B90A7) << 0 << 0) + 0 + 0);
					continue;
				case 11u:
					num = ((((int)num2 + -117175874) ^ 0x5A2D3D95) << 0 << 0 >> 0) ^ 0;
					continue;
				case 30u:
					((Renderer)val).material.shader = Shader.Find(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鄰鄢鄾酘鄣鄒鄏鄃酗鄤鄟鄖鄓鄒鄅", 706449783, true));
					num = (int)(((num2 + 1880337016) ^ 0xE8315820u ^ 0 ^ 0) + 0) >> 0;
					continue;
				case 31u:
					val.startColor = magenta;
					num = ((((((int)num2 + -1160147690) ^ 0x580FB4F) + 0) ^ 0) >> 0) - 0;
					continue;
				case 32u:
					Object.Destroy((Object)(object)val2, Time.deltaTime);
					num = (int)(((((num2 + 2121321338) ^ 0xD7686D7Bu) << 0) ^ 0 ^ 0) - 0);
					continue;
				case 5u:
					num = (int)((((num2 + 1394277627) ^ 0x77E22A94) << 0) ^ 0 ^ 0) >> 0;
					continue;
				case 13u:
					num = (((((int)num2 + -333008605) ^ 0x7FE4AFBF) + 0 + 0) ^ 0) >> 0;
					continue;
				case 35u:
					num = (0x1DA214D5 ^ 0) - 0;
					continue;
				case 36u:
					val.endColor = magenta;
					num = (((int)num2 + -1336085439) ^ -503679345) >> 0 << 0 >> 0 >> 0;
					continue;
				case 16u:
					num = ((int)(((num2 + 1016054125) ^ 0x9844CA31u) << 0) >> 0 << 0) + 0;
					continue;
				case 15u:
					return;
				}
				break;
			}
		}
	}

	public Beacons()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0 + (0 >> 1)) ^ 0 ^ 0) >> 0) ^ 0 ^ 0) >> 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 >> 0) + 0 << 0;
			}
		}
	}
}
