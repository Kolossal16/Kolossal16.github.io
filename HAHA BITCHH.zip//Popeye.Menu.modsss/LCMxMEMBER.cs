using System;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modsss;

internal class LCMxMEMBER
{
	public static void BUJAhwheVKDjpIqBsyqZJEUggCqiXbvYhicJMEkKOmQhrtWqdUrQFWLWZCtEfYhToEbgFGONnGlwONPNFaedKFtlxfKklFF()
	{
		string[] array = default(string[]);
		string userId = default(string);
		int num3 = default(int);
		while (true)
		{
			int num = 1758301853;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((((num ^ 0) - (0 ^ 0) << 0) - 0 << 0) - (0 ^ 0)) ^ 0) >> 0)) % 13)
				{
				case 0u:
					break;
				default:
					return;
				case 9u:
					array = new string[5]
					{
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("珲玭玡玢玡玼珳玼玫玪珰玂玍玃玶玞玏率玊珮玃王玃玌王玜珲珡玭玡玢玡玼珰珄玪玧玽玭玡玼玪珠玩玩珡玝玔玉玦玙玘玌玷玦玏", 1096053710, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("嘑噎噂噁噂噟嘐噔噈噁噁噂噚嘓噡噮噠噕噽噬噤噩嘍嘑嘂噎噂噁噂噟嘓嘧噉噄噞噎噂噟噉嘃噊噊嘂噾噷噪噅噺噻噯噔噅噬", 655250989, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("펋폔폘폛폘폅펊폐폅폒폒폙펉폻폴폺폏폧폶폾폳펗폸폠폹폲폥펋페폔폘폛폘폅펉펽폓폞폄폔폘폅폓펙폐폐페폤폭폰폟폠폡폵폎폟폶", 208589751, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("䬤䭻䭷䭴䭷䭪䬥䭺䭴䭭䭽䬦䭔䭛䭕䭠䭈䭙䭑䭜䬸䭗䭏䭖䭝䭊䬤䬷䭻䭷䭴䭷䭪䬦䬒䭼䭱䭫䭻䭷䭪䭼䬶䭿䭿䬷䭋䭂䭟䭰䭏䭎䭚䭡䭰䭙", 1360481048, true),
						ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("썓쌌쌀쌃쌀쌝썒쌂쌎쌈쌊쌁쌛쌎썑쌣쌬쌢쌗쌿쌮쌦쌫썏썓썀쌌쌀쌃쌀쌝썑썥쌋쌆쌜쌌쌀쌝쌋썁쌈쌈썀쌼쌵쌨쌇쌸쌹쌭쌖쌇쌮", 1191625583, true)
					};
					num = (((int)((num2 + 600520462) ^ 0xB95FCA47u) >> 0) + 0 << 0) ^ 0;
					continue;
				case 11u:
					PhotonNetwork.LocalPlayer.UserId = userId;
					num = ((int)(((num2 + 900749756) ^ 0xF6F7C411u ^ 0) + 0) >> 0) - 0;
					continue;
				case 3u:
					num = ((((int)num2 + -1701687338) ^ -1567692514) << 0) - 0 << 0 << 0;
					continue;
				case 7u:
					num3 = new Random().Next(array.Length);
					num = ((((int)num2 + -795116775) ^ 0x1DE169A5) >> 0) + 0 - 0 + 0;
					continue;
				case 2u:
					num = (((int)num2 + -678915685) ^ -1534661089 ^ 0 ^ 0) + 0 >> 0;
					continue;
				case 8u:
					PlayerPrefs.SetString(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("腛腳腮腵腰腰腽腐腳腿腳腱腳腨腵腳腲脲腌腰腽腥腹腮腒腽腱腹", 1351319836, true), array[num3]);
					num = (((((int)num2 + -1186296972) ^ 0x47F0227D) >> 0) ^ 0) + 0 >> 0;
					continue;
				case 1u:
					PhotonNetwork.LocalPlayer.NickName = array[num3];
					num = (int)(((num2 + 1259723679) ^ 0x76A7389B) + 0 - 0 - 0 << 0);
					continue;
				case 10u:
					userId = ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("숷숸숶숃숶숾숶숹숾숩쉚쉱쉱쉱쉱쉱쉱쉱쉱쉱쉱쉱쉱", 1835778683, true);
					num = (((((int)num2 + -1219895373) ^ -1888826635) - 0) ^ 0) - 0 >> 0;
					continue;
				case 12u:
					num = (((((int)num2 + -434485547) ^ -534547507) << 0 << 0) + 0) ^ 0;
					continue;
				case 4u:
					num = (int)(((((num2 + 1709781230) ^ 0xDD653F56u) << 0) ^ 0 ^ 0) - 0);
					continue;
				case 6u:
					GorillaComputer.instance.currentName = array[num3];
					num = (((((int)num2 + -733318432) ^ -226576907) >> 0 >> 0) + 0) ^ 0;
					continue;
				case 5u:
					return;
				}
				break;
			}
		}
	}

	public LCMxMEMBER()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num >> 0 >> (0 ^ 0) << 0) + 0 + 0 - (0 ^ 0)) ^ 0) - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((int)num2 + -1685855580) ^ 0x31967EB5) - 0 + 0 - 0 - 0;
			}
		}
	}
}
