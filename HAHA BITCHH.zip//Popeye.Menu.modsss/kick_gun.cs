using GorillaLocomotion;
using GorillaNetworking;
using Il2CppSystem;
using MenuTemplate;
using Photon.Pun;
using Photon.Realtime;
using UnhollowerBaseLib;
using UnityEngine;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;
using easyInputs;

namespace Popeye.Menu.modsss;

internal class kick_gun
{
	public static void qqWeZEZOAwUVHTvgLwSWOwjAPGZhDdPYIfHplXfSHtfXWzBLuGBAdivTgvosESkxHWnClfVNqZpvrmEpfnMWCoVAJOjPJNoOiIpZmZAoLNkdSZCTQYnqfnUsaMSxWfeDLAmIWEdgNylPeRHKlpYKAXJUOXZAhcsFIGssMUWlVgCHcenjeimGhtdNRrUZFDZLfFgyypXrsMPtvbSJJQwYQLyoDFAuaXGshRBwXPKOkUnuDKrPzkpPgaVugSUTOCrvgxlEAvMUfHNVxeKTnLVPHQlhVhpfURZIDSogyNpdyvKzmZWchbFdGBNpmdIsfGZoHfrFPEuAvRrmgLVWlmYTlWccfYUufWYSvvShIqnCHfIOkAjAiMhSHgdLdpzRKZuyTzRLTOnUZvlgonREPtmtPfkoshetQwSHKjVLJxHuymTlUWwPxUbqNbJOoCsMKUdDDEvergVrMSUCmYuvKoVVu()
	{
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef1: Unknown result type (might be due to invalid IL or missing references)
		//IL_085d: Unknown result type (might be due to invalid IL or missing references)
		//IL_088a: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0705: Unknown result type (might be due to invalid IL or missing references)
		RaycastHit val2 = default(RaycastHit);
		int num15 = default(int);
		int num3 = default(int);
		PhotonView val4 = default(PhotonView);
		GameObject val3 = default(GameObject);
		bool flag4 = default(bool);
		bool flag5 = default(bool);
		Player owner2 = default(Player);
		bool flag3 = default(bool);
		bool flag6 = default(bool);
		bool flag = default(bool);
		bool triggerButtonDown = default(bool);
		bool flag2 = default(bool);
		GameObject val = default(GameObject);
		while (true)
		{
			int num = 1758301871;
			while (true)
			{
				uint num2;
				int num10;
				switch ((num2 = (uint)(((num >> 0 >> (0 >> 1) >> 0) + 0 << 0) - (0 << 1) - 0 - 0)) % 61)
				{
				case 0u:
					break;
				default:
					return;
				case 51u:
					Physics.Raycast(((Component)Player.Instance.rightHandTransform).transform.position, ((Component)Player.Instance.rightHandTransform).transform.forward, ref val2);
					num = (((((int)num2 + -1829903696) ^ -830709432) + 0) ^ 0 ^ 0) << 0;
					continue;
				case 21u:
					num15 = num3;
					num = ((((int)num2 + -1817294979) ^ -1374593248 ^ 0) << 0 >> 0) + 0;
					continue;
				case 17u:
					if ((Object)(object)val4 != (Object)null)
					{
						num = (((int)((num2 + 150701655) ^ 0x7656425C) >> 0) - 0 << 0) - 0;
						continue;
					}
					num10 = 0;
					goto IL_0cae;
				case 41u:
					val3 = GameObject.CreatePrimitive((PrimitiveType)0);
					num = ((((int)num2 + -229453252) ^ 0x339A00C5) << 0 << 0) + 0 - 0;
					continue;
				case 12u:
					flag4 = flag5;
					num = ((int)((num2 + 951933518) ^ 0xBD9A7591u ^ 0) >> 0) - 0 << 0;
					continue;
				case 14u:
					set_master.DqxmowMqeUyTwsknNitiVMlmYxjIknJQfSrYQAPsNfaJqkXgzFaatDDRfkoRmegQlHNEblxmsbvPLBVOzdiFnJxCoATFmXfIZkyJwseoiOHrhNfEoArjVBDBklpBsRavVNQBcmrhYUwycfvAuoqLGVMyGWyldDVqNlwtXEBciklbeezePOgdAoOZasUfNgduYgLQJbDQNoCwKLtCxuwowSPywwtEJvocgQdYtIuNkqqmMsppYsItKOYgqmtnIZgraApTHviOZIegBDMegeFqNVsrSXHgoheljZlmdvHDkTtbKSENzpgEtQDfhXbKObASESWCrAaLwcgUBrGasUHZaAStvgefuWOitBwSVbvZpvhqJJEQqarTuARdaDhlvVqznYBZUOfryHKFsBJMCoOtFVNSKtSsUkDueHdLhEWCVavNQmLzTuIhgWUskJpBWMxoeqALxXEXsmyFAabyIsyzBvniNKAypuFiCgIALabWPKPTypSkHR();
					num = (((int)num2 + -1506364251) ^ -1935425250) + 0 << 0 >> 0 >> 0;
					continue;
				case 1u:
					val3.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					num = (((((int)num2 + -1761200462) ^ -1565220911) << 0) - 0 + 0) ^ 0;
					continue;
				case 19u:
					num3 = 0;
					num = (int)((((num2 + 2146902915) ^ 0xFB974E30u) - 0 - 0 << 0) - 0);
					continue;
				case 29u:
					num = (int)((num2 + 1661375474) ^ 0x653EA414) >> 0 >> 0 << 0 >> 0;
					continue;
				case 24u:
					num = 0x5CF441D3 ^ 0;
					continue;
				case 28u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val3, Color.green);
					num = ((int)(((num2 + 1459870073) ^ 0x5F6F121) - 0) >> 0) - 0 + 0;
					continue;
				case 34u:
					val3.transform.position = ((RaycastHit)(ref val2)).point;
					num = (int)((((((num2 + 1270048165) ^ 0x7A97A077) - 0) ^ 0) << 0) - 0);
					continue;
				case 33u:
					num = (int)(((((num2 + 1560838666) ^ 0xA5B8FAF3u) << 0) - 0 - 0) ^ 0);
					continue;
				case 2u:
					num = (((int)((num2 + 364309176) ^ 0x7AA89513) >> 0 >> 0) ^ 0) - 0;
					continue;
				case 15u:
					GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Add(owner2.UserId);
					num = (((((int)num2 + -1398681650) ^ -1965060155) + 0) ^ 0 ^ 0) - 0;
					continue;
				case 40u:
					PhotonNetworkController.instance.friendIDList.Add(owner2.UserId);
					num = (((int)((num2 + 2097241014) ^ 0xE6D10251u) >> 0) - 0 >> 0) - 0;
					continue;
				case 46u:
					Object.Destroy((Object)(object)val3.GetComponent<BoxCollider>());
					num = ((int)((num2 + 1438922508) ^ 0xE36E960Du ^ 0) >> 0) ^ 0 ^ 0;
					continue;
				case 45u:
					flag3 = flag6;
					num = ((((int)num2 + -1415490461) ^ -1909537983 ^ 0) >> 0 << 0) + 0;
					continue;
				case 3u:
					num = ((int)((num2 + 757804180) ^ 0x31F7CDCC) >> 0) - 0 + 0 - 0;
					continue;
				case 50u:
					num = (0x48DCB4B ^ 0) + 0;
					continue;
				case 58u:
					Object.Destroy((Object)(object)val3.GetComponent<Rigidbody>());
					num = (int)((((num2 + 403315589) ^ 0x2E2D06EC ^ 0) - 0 + 0) ^ 0);
					continue;
				case 22u:
					num3 = num15 + 1;
					num = (((int)num2 + -1582795527) ^ -281507512 ^ 0) - 0 >> 0 >> 0;
					continue;
				case 57u:
				{
					int num13;
					int num14;
					if (flag)
					{
						num13 = 1145179709;
						num14 = num13;
					}
					else
					{
						num13 = 2071725248;
						num14 = num13;
					}
					num = ((((num13 + 0 >> 0) ^ ((int)num2 + -1261085613)) << 0) - 0 >> 0) + 0;
					continue;
				}
				case 26u:
					num = ((((int)num2 + -396906955) ^ 0x9AE9181) >> 0) - 0 - 0 << 0;
					continue;
				case 27u:
					num = (((int)num2 + -540388775) ^ 0x624A5E9) + 0 >> 0 >> 0 << 0;
					continue;
				case 4u:
					Object.Destroy((Object)(object)val3.GetComponent<Collider>());
					num = (((int)((num2 + 1246932057) ^ 0xF1F2BBE1u) >> 0) ^ 0) - 0 - 0;
					continue;
				case 11u:
					num = ((((int)num2 + -1777323983) ^ 0x3D38D76A) + 0 << 0) - 0 >> 0;
					continue;
				case 30u:
					flag5 = !Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>());
					num = (((((int)num2 + -462128844) ^ 0x54D28AF9) + 0) ^ 0) + 0 + 0;
					continue;
				case 31u:
					num = ((((((int)num2 + -100986504) ^ 0x46A664F8) << 0) ^ 0) >> 0) - 0;
					continue;
				case 32u:
				{
					int num11;
					int num12;
					if (!flag4)
					{
						num11 = 2135780576;
						num12 = num11;
					}
					else
					{
						num11 = 837773686;
						num12 = num11;
					}
					num = ((((int)((uint)(num11 - 0 - 0) ^ (num2 + 485869457)) >> 0) ^ 0) << 0) ^ 0;
					continue;
				}
				case 5u:
					linerenderer.bVtjnGIXvieEPObWuiFMaDiHpOhXlKgvVCEbsqyGfSBXjVDxRIMqdPUyNMUzyKMLcJJmjaEeKZHibkxukJfCXPrfIgoGwZhufQVAmqoReIGeiMwDozoOFjNmrDDcLXHKRmcloXiUvoypjnWWKKsWKsPWcJiINlfgb(val3, Color.magenta);
					num = (int)((((num2 + 583561026) ^ 0x4797BF1F) << 0) + 0 << 0) >> 0;
					continue;
				case 13u:
					num = ((int)(((num2 + 1591510134) ^ 0x9831F480u ^ 0) - 0) >> 0) - 0;
					continue;
				case 35u:
					owner2 = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (497161421 >> 0 >> 0) - 0 - 0;
					continue;
				case 36u:
					num = ((((int)num2 + -1536809407) ^ -168737686) >> 0 >> 0 >> 0) - 0;
					continue;
				case 37u:
					num = ((int)(((num2 + 1241846950) ^ 0xD5897121u) + 0 << 0) >> 0) ^ 0;
					continue;
				case 38u:
					Object.Destroy((Object)(object)val3, Time.deltaTime);
					num = ((((int)num2 + -1999758855) ^ -871996511) + 0) ^ 0 ^ 0 ^ 0;
					continue;
				case 39u:
					num = ((((((int)num2 + -1325533022) ^ 0x95C9D03) >> 0) ^ 0) << 0) ^ 0;
					continue;
				case 6u:
					num = (((int)num2 + -1497151632) ^ -148445812) << 0 >> 0 >> 0 >> 0;
					continue;
				case 16u:
					num = ((((((int)num2 + -880128457) ^ 0xB59EF57) + 0) ^ 0) << 0) + 0;
					continue;
				case 42u:
					val4 = PhotonView.Get((Component)(object)((Component)GorillaGameManager.instance).GetComponent<GorillaGameManager>());
					num = (int)(((((num2 + 274505005) ^ 0x4B66E618) + 0) ^ 0) - 0 << 0);
					continue;
				case 43u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)1);
					num = (int)((((num2 + 234277810) ^ 0x39A1BEC6) + 0 - 0 << 0) - 0);
					continue;
				case 44u:
					num10 = (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(owner2.UserId) ? 1 : 0);
					goto IL_0cae;
				case 7u:
				{
					int num8;
					int num9;
					if (!triggerButtonDown)
					{
						num8 = -495433213;
						num9 = num8;
					}
					else
					{
						num8 = -661238576;
						num9 = num8;
					}
					num = ((int)((uint)(num8 - 0 << 0) ^ (num2 + 1574892098)) >> 0 >> 0) - 0 + 0;
					continue;
				}
				case 18u:
				{
					int num6;
					int num7;
					if (flag3)
					{
						num6 = 1685496199;
						num7 = num6;
					}
					else
					{
						num6 = 676850812;
						num7 = num6;
					}
					num = ((((num6 + 0 + 0) ^ ((int)num2 + -788358910)) >> 0) + 0 + 0) ^ 0;
					continue;
				}
				case 47u:
					num = ((((int)num2 + -263229304) ^ 0x486D256F) >> 0 >> 0) + 0 - 0;
					continue;
				case 48u:
					num = (int)(((((num2 + 776420349) ^ 0xB2F00514u) - 0) ^ 0) << 0 << 0);
					continue;
				case 49u:
					num = (((((int)num2 + -656729457) ^ 0x1F6A8FC4) >> 0 << 0) ^ 0) - 0;
					continue;
				case 8u:
					flag2 = Object.op_Implicit((Object)(object)((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>());
					num = (int)((((num2 + 476044639) ^ 0x16BB1649) << 0 << 0 << 0) ^ 0);
					continue;
				case 20u:
					val4.RPC(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("ṿṚṜṛṥṀṗṢṜṁṝṳṇṐṜṛṑṆ", 2141986357, true), owner2, (Il2CppReferenceArray<Object>)null);
					num = ((((int)num2 + -1588119460) ^ -212211307) + 0 >> 0 << 0) ^ 0;
					continue;
				case 52u:
					num = (((int)num2 + -727923521) ^ 0x4D4CAEE5 ^ 0) - 0 + 0 >> 0;
					continue;
				case 53u:
				{
					int num4;
					int num5;
					if (!flag2)
					{
						num4 = 469501203;
						num5 = num4;
					}
					else
					{
						num4 = 549403168;
						num5 = num4;
					}
					num = (((num4 >> 0) - 0) ^ ((int)num2 + -454565845)) - 0 >> 0 >> 0 << 0;
					continue;
				}
				case 54u:
					num = (((((int)num2 + -852338334) ^ 0x3E856263) - 0) ^ 0) + 0 << 0;
					continue;
				case 55u:
					num = (int)(((((num2 + 934005898) ^ 0x6B1A4EB ^ 0) + 0) ^ 0) << 0);
					continue;
				case 56u:
					flag = num3 < 10;
					num = 0x598D1717 ^ 0;
					continue;
				case 9u:
					val = val3;
					num = (((((int)num2 + -397900661) ^ 0x4242CAAD) - 0 >> 0) + 0) ^ 0;
					continue;
				case 23u:
					num = ((int)((num2 + 1334533754) ^ 0xDE552DDBu) >> 0) - 0 + 0 - 0;
					continue;
				case 59u:
					num = (583947839 << 0 << 0) + 0 + 0;
					continue;
				case 60u:
				{
					Player owner = ((Component)((RaycastHit)(ref val2)).collider).GetComponentInParent<PhotonView>().Owner;
					num = (int)(((num2 + 999107112) ^ 0x806B8D95u) + 0 + 0 << 0) >> 0;
					continue;
				}
				case 10u:
					val.GetComponent<Renderer>().material.color = Color.green;
					num = (((((int)num2 + -574940143) ^ 0x2BE930DD) << 0 >> 0) ^ 0) >> 0;
					continue;
				case 25u:
					return;
					IL_0cae:
					flag6 = (byte)num10 != 0;
					num = (1139108189 << 0 << 0) + 0 << 0;
					continue;
				}
				break;
			}
		}
	}

	public kick_gun()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((((num + 0) ^ 0) - 0 >> 0 >> 0) ^ 0) + 0 - 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5 ^ 0) - 0) ^ 0) - 0;
			}
		}
	}
}
