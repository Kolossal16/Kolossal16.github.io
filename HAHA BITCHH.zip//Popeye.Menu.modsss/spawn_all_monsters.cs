using GorillaLocomotion;
using Il2CppSystem;
using Photon.Pun;
using UnhollowerBaseLib;
using cflwGCDYsASHcVlGTLnpZLrlkfDYMZNZaDJwBSvYCwbcvdgBJDmMeqQqNZmBZFlsMTGymOfapoMDJoQgYcoiNbUJNsIBGUZXkJqCwIpUylwQEmHzjfCXqcFLYXKTgDuupPtaYnJqNtKCFefBLjsAscGheFEzXvOURbAOTGBVwmkXscgTRjhXlTcmjlVtJjsrFPKDDqHeHwdfSIObzKHNoRJXZoFHLhlmTSsDrCpBCcpPQXuAwUUZBEdNfNEpKatzkRlZqlJWvgllBUhbTfkQnmKoP;

namespace Popeye.Menu.modsss;

internal class spawn_all_monsters
{
	public static void AebrDrMBYcxVdENnNABxJfYFaRRgDsqQyaETjYEWZvUZKgExZLVTwLiufwqMAFXFMGwcZUePWEyolZUTmtgSxwtNSjNMHRwtxom()
	{
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		while (true)
		{
			int num = 1758301860;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num << 0) + (0 >> 1) - 0 >> 0) - 0 << 0 + 0 << 0 >> 0)) % 8)
				{
				case 0u:
					break;
				default:
					return;
				case 4u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((int)num2 + -907893453) ^ 0x7773C20) + 0 + 0 >> 0) - 0;
					continue;
				case 6u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = (((int)((num2 + 359659174) ^ 0x3353313E ^ 0) >> 0) - 0) ^ 0;
					continue;
				case 5u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("卾卹卤卤卹卤匹卥卢卷卺卽即卤", 1192055574, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -2130437817) ^ -2026299046) - 0) ^ 0) - 0 + 0;
					continue;
				case 7u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("騵騲騯騯騲騯驲騩騴騰騰騤", 1147902557, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((((int)num2 + -248958683) ^ 0x3D73A3BD) + 0) ^ 0) + 0 - 0;
					continue;
				case 2u:
					PhotonNetwork.Instantiate(ExEYZQCJPEYLvjllXDvtRllGCwFPDmXgWjLOfYvpJCMpiqxVZEpJpVXslXvClMfDGSOmxwgZhfKpzVylZJPYWoQblsChCSeWwjJpClxDyqBklITqzkDBXhGrbMafUYxpaNTpmiJOmmzGNGQDzmIspDYoCr.oPlsJATmjxOEeqAPoLIaEvWwFHpeZwOFNUUTCUDZNBwsPVisRApnGBNTTOMbkOmNIjQjwHmuiIncYDHKzXnyhBYlhbZOhBPYoJJFeYVjoUfXnKUqhbCmANFhkFbuIxnGToNoTbGAbdkmvaXxgJHfZDyBdCuzXBBQHzeYWFwfvbkwCtMjHEoYQhGqQmlrHhDACuFVWZAAmBKXsbYKPkSsmCZzSOiJufyoyJUiNQnIdNLoxIXOoABwokoZvfdhQRghdvzIhPWZXkpzRKcjQtuTDcZovUMINgRlHEkbjpHyDCyeUPiKcT("鐚鐒鐏鐔鐑鐑鐜鐍鐏鐘鐛鐜鐟鐎鑒鐩鐵鐯鐲鐪", 1413977213, true), Player.Instance.rightHandTransform.position, Player.Instance.rightHandTransform.rotation, (byte)0, (Il2CppReferenceArray<Object>)null);
					num = (((int)((num2 + 1621957012) ^ 0x2DA26635) >> 0) - 0 + 0) ^ 0;
					continue;
				case 1u:
					PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
					num = ((((int)num2 + -344833909) ^ 0x16C8A5B1) >> 0) - 0 + 0 >> 0;
					continue;
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public spawn_all_monsters()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(((num ^ 0) << (0 << 1)) + 0 << 0 << 0 << (0 >> 1) >> 0 << 0)) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = ((((int)num2 + -1685855580) ^ 0x31967EB5) + 0 << 0 << 0) + 0;
			}
		}
	}
}
