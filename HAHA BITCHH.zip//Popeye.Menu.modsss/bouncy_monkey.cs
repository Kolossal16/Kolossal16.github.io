using GorillaLocomotion;
using UnityEngine;
using easyInputs;

namespace Popeye.Menu.modsss;

internal class bouncy_monkey
{
	public static void RxRuDnVKTGAUXoqqodKpvZpVOuCRcmlApthAaUrAiVbFCsTLsRzybHTRiVFiLeIHuaFEgPptMkgzXKsvBRykMMzHzpsepiOemukCNoEDBgMRBtUxDjHUFxUIBYfQwkeDvbnDAQImmVIGZHffvVBfBUyOABbPiNgrcivzgrXNBuHKOnJTSZvBIYcADycYOSeyOrEQlFZeXODgnNZmSiXjsFIdgVWHoYYJqiWxISHmarEUuWnPyQgGVUgiJBKqJrPYPUPeQCDZAKibbNIkHgjySsOvcNNhiqCJBFeAgjYWmgfkMfhVSAIDirfxgucdOwRjhzAvJidyhnmMnDJWGSoIIZBkzHuMgVhQpVcmFLlKwjvUftjCKfwWhiBiYpWcOrslfvwsAwrUGDmyDGegxRbbzlIgtUopPjWeRjPJXRboOBpDWdErlPFWqqMUNpYGhcfxHhGuQviFPMnXVek()
	{
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		bool triggerButtonDown = default(bool);
		bool flag = default(bool);
		while (true)
		{
			int num = 1758301852;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)((((num << 0) + (0 ^ 0) + 0 - 0 - 0) ^ -0 ^ 0) - 0)) % 9)
				{
				case 0u:
					break;
				default:
					return;
				case 4u:
					triggerButtonDown = EasyInputs.GetTriggerButtonDown((EasyHand)0);
					num = ((((int)num2 + -956687329) ^ 0x1A00A54C) + 0 << 0) + 0 + 0;
					continue;
				case 6u:
				{
					Transform transform = ((Component)Player.Instance).transform;
					transform.position += ((Component)Player.Instance.bodyCollider).transform.up * Time.deltaTime * 14f;
					num = (((((int)num2 + -1807018533) ^ -1300344584) << 0) ^ 0) - 0 - 0;
					continue;
				}
				case 5u:
					num = ((((((int)num2 + -1496278149) ^ -1586193245) >> 0) ^ 0) - 0) ^ 0;
					continue;
				case 7u:
					flag = triggerButtonDown;
					num = ((int)((((num2 + 1345212153) ^ 0x9E76BC50u) << 0) + 0) >> 0) - 0;
					continue;
				case 2u:
					num = (int)((((num2 + 266738246) ^ 0x7C596544) - 0 << 0) ^ 0) >> 0;
					continue;
				case 8u:
					num = (((int)num2 + -640398734) ^ 0x677EE37B) + 0 + 0 >> 0 << 0;
					continue;
				case 1u:
				{
					int num3;
					int num4;
					if (!flag)
					{
						num3 = 725944569;
						num4 = num3;
					}
					else
					{
						num3 = 1922640757;
						num4 = num3;
					}
					num = (int)((((uint)(num3 - 0 << 0) ^ (num2 + 1193528119)) + 0 << 0) + 0 << 0);
					continue;
				}
				case 3u:
					return;
				}
				break;
			}
		}
	}

	public bouncy_monkey()
	{
		while (true)
		{
			int num = 1758301856;
			while (true)
			{
				uint num2;
				switch ((num2 = (uint)(num - 0 - -0 + 0 + 0 >> 0 << 0 + 0) ^ 0u ^ 0u) % 3)
				{
				case 0u:
					break;
				default:
					return;
				case 2u:
					goto IL_004e;
				case 1u:
					return;
				}
				break;
				IL_004e:
				num = (((((int)num2 + -1685855580) ^ 0x31967EB5) >> 0) - 0 << 0) - 0;
			}
		}
	}
}
